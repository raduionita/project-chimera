#ifndef __gls_gls_hpp__
#define __gls_gls_hpp__

#include "../glm/glm.hpp"

namespace gls { // extend glm
  // forward declarations
  typedef glm::vec3 point;
  struct line;    // 2 points // point + distance + length
  struct plane;   // point + direction
  struct face;    // 4 points
  struct circle;  // point + direction + radius
  struct sphere;  // point + radius
  struct cube;    // point + length
  struct bbox;
  struct frustum; // 6 planes
  struct aabb;
  
  template <typename T> struct ocdata;
  template <typename T> struct ocnode;
  template <typename T> struct octree;
  
  struct polygon;
  
  struct plane {
    public:
      glm::vec3    normal;
      glm::float_t distance;
  };
  
  struct bbox {
    public:
      std::array<glm::vec3, 8> points;
  };
  
  struct aabb {
    public:
      enum state { INSIDE, INTERSECT, OUTSIDE, ENGULF };
    public:
      // @todo union w/ glm::float_t[6]
      glm::vec3 min;
      glm::vec3 max;
    public:
      aabb(glm::float_t val = 0.f) : min(val), max(val)                     {}
      aabb(const glm::vec3& min, const glm::vec3& max) : min(min), max(max) {}
      aabb(const glm::vec3& center, glm::float_t radius) {} // bbox that surounds a sphere
      aabb(const glm::vec3& p1, glm::vec3& p2)           {} // bbox from 2 points
    public:
      bool operator ==(glm::float_t val) { return (min.x + min.y + min.z + max.x + max.y + max.z) == val; }
    public:
      state compare(const aabb& that) const {
        const aabb& self = *this;
        // check guest's min is inside this aabb (guest.min > this.min && guest.min < this.max) 
        bool min = (that.min.x >= self.min.x) && (that.min.y >= self.min.y) && (that.min.z >= self.min.z) && (that.min.x <= self.max.x) && (that.min.y <= self.max.y) && (that.min.z <= self.max.z);
        // check guest's max is inside this aabb (guest.max > this.min && guest.max < this.max)
        bool max = (that.max.x >= self.min.x) && (that.max.y >= self.min.y) && (that.max.z >= self.min.z) && (that.max.x <= self.max.x) && (that.max.y <= self.max.y) && (that.max.z <= self.max.z);
        // return state
        return min ? (max ? INSIDE : INTERSECT ) : (max ? INTERSECT : OUTSIDE);
      };
  };
  
  struct frustum {
    public:
      enum side { LEFT = 0, RIGHT = 1, TOP = 2, BOTTOM = 3, BACK = 4, FAR = BACK, FRONT = 5, NEAR = FRONT };
      enum state { INSIDE, INTERSECT, OUTSIDE, ENGULF };
    public:
      frustum() {}
      frustum(const glm::mat4& mat); // frustum from glm::frustum() matrix
    public:  
      operator glm::mat4(); // convert to mat4 using glm::frustum
    public:
      std::array<plane, 6> planes;
    public:
      state compare(const aabb& that) const {
        state out = INSIDE; 
        glm::vec3 min, max;
        for (glm::uint i = 0; i < 6; i++) {
          // x
          if (planes[i].normal.x > 0) {
            min.x = that.min.x;
            max.x = that.max.x;
          } else {
            min.x = that.max.x;
            max.x = that.min.x;
          }
          // y
          if (planes[i].normal.y > 0) {
            min.y = that.min.y;
            max.y = that.max.y;
          } else {
            min.y = that.max.y;
            max.y = that.min.y;
          }
          // z
          if (planes[i].normal.z > 0) {
            min.z = that.min.z;
            max.z = that.max.z;
          } else {
            min.z = that.max.z;
            max.z = that.min.z;
          }
          // dot
#pragma clang diagnostic push
#pragma ide diagnostic ignored "err_typecheck_invalid_operands"
          if (glm::dot(planes[i].normal, min) + planes[i].distance > 0) {
            return OUTSIDE;
          }
          if (glm::dot(planes[i].normal, max) + planes[i].distance >= 0) {
            out = INTERSECT;
          }
#pragma clang diagnostic pop
        }
        return out;
      }
  };
  
  enum octype { NODE, LEAF };
  
  enum ocside { TFL = 0, TFR, BFL, BFR, TBL, TBR, BBL, BBR};
  
  struct ocaabb : public aabb {
      using aabb::aabb;
    public:
      std::array<ocaabb, 8> split() const {
        std::array<ocaabb, 8> a;
        
        a[TFL].min.x = min.x;
        a[TFL].min.y = (max.y - min.y) / 2.f;
        a[TFL].min.z = (max.z - min.z) / 2.f;
        a[TFL].max.x = (max.x - min.x) / 2.f;
        a[TFL].max.y = max.y;
        a[TFL].max.z = max.z;
        
        a[TFR].min.x = (max.x - min.x) / 2.f;
        a[TFR].min.y = (max.y - min.y) / 2.f;
        a[TFR].min.z = (max.z - min.z) / 2.f;
        a[TFR].max.x = max.x;
        a[TFR].max.y = max.y;
        a[TFR].max.z = max.z;
        
        a[BFL].min.x = min.x;
        a[BFL].min.y = min.y;
        a[BFL].min.z = (max.z - min.z) / 2.f;
        a[BFL].max.x = (max.x - min.x) / 2.f;
        a[BFL].max.y = (max.y - min.y) / 2.f;
        a[BFL].max.z = max.z;
        
        a[BFR].min.x = (max.x - min.x) / 2.f;
        a[BFR].min.y = min.y;
        a[BFR].min.z = (max.z - min.z) / 2.f;
        a[BFR].max.x = max.y;
        a[BFR].max.y = (max.y - min.y) / 2.f;
        a[BFR].max.z = max.z;
        
        a[TBL].min.x = min.x;
        a[TBL].min.y = (max.y - min.y) / 2.f;
        a[TBL].min.z = min.z;
        a[TBL].max.x = (max.x - min.x) / 2.f;
        a[TBL].max.y = max.y;
        a[TBL].max.z = (max.z - min.z) / 2.f;
        
        a[TBR].min.x = (max.x - min.x) / 2.f;
        a[TBR].min.y = (max.y - min.y) / 2.f;
        a[TBR].min.z = min.z;
        a[TBR].max.x = max.x;
        a[TBR].max.y = max.y;
        a[TBR].max.z = (max.z - min.z) / 2.f;;
        
        a[BBL].min.x = min.x;
        a[BBL].min.y = min.y;
        a[BBL].min.z = min.z;
        a[BBL].max.x = (max.x - min.x) / 2.f;
        a[BBL].max.y = (max.y - min.y) / 2.f;
        a[BBL].max.z = (max.z - min.z) / 2.f;
        
        a[BBR].min.x = (max.x - min.x) / 2.f;
        a[BBR].min.y = min.y;
        a[BBR].min.z = min.z;
        a[BBR].max.x = max.x;
        a[BBR].max.y = (max.y - min.y) / 2.f;
        a[BBR].max.z = (max.z - min.z) / 2.f;
        
        return a;
      }
  };
  
  template<typename T> struct ocdata final {
      friend class ocnode<T>;
    public:
      T      data;
      ocaabb aabb;
    public:
      /// default constructor
      ocdata(const T& data, const ocaabb& aabb) : data(data), aabb(aabb) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocdata<T>::ocdata(const T&, const gls::aabb&)" << std::endl;
        #endif // GLS_DEBUG
      }
      /// copy contructor
      ocdata(const ocdata& that) : data(that.data), aabb(that.aabb) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocdata<T>::ocdata(const gls::ocdata<T>&)" << std::endl;
        #endif // GLS_DEBUG
      }
      /// move constructor
      ocdata(ocdata&& that) noexcept : data(std::move(that.data)), aabb(std::move(that.aabb)) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocdata<T>::ocdata(gls::ocdata<T>&&)" << std::endl;
        #endif // GLS_DEBUG
      }
      /// destructor
      ~ocdata() {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocdata<T>::~ocdata()" << std::endl;
        #endif // GLS_DEBUG
      }
      /// assignment operator
      ocdata& operator =(const ocdata& that) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocdata<T>::operator=(const gls::ocdata<T>&)" << std::endl;
        #endif // GLS_DEBUG
        if (this != &that) {
          data = that.data;
          aabb = that.aabb;
        }
        return *this;
      }
      /// move assignment operator
      ocdata& operator =(ocdata&& that) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocdata<T>::operator=(gls::ocdata<T>&&)" << std::endl;
        #endif // GLS_DEBUG
        data = that.data;
        aabb = that.aabb;
        return *this;
      }
  };
  
  template<typename T> struct ocnode final {
      // @todo if T at intersection...it stays in the parent
      // @todo DO NOT subdivide if T has the same size as the node
      // @todo DO NOT subdivide if T is bigger than a chunk (T stays in parent)
      friend class ocdata<T>;
      friend class octree<T>;
    private:
      ocaabb                      aabb;
      octype                      type;
      std::vector<ocdata<T>>      data;
      ocnode<T>*                  parent;
      std::atomic<int>            count;
      std::array<ocnode<T>*, 8>*  chunks;
    public:
      /// default constructor
      ocnode()                        : type(octype::LEAF), parent(nullptr), count(0), chunks(nullptr)  {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocnode<T>::ocnode()" << std::endl;
        #endif // GLS_DEBUG
      }
      ocnode(const gls::ocaabb& aabb) : aabb(aabb), type(octype::LEAF), parent(nullptr), count(0), chunks(nullptr) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocnode<T>::ocnode(gls::ocaabb)" << std::endl;
        #endif // GLS_DEBUG
      }
      /// destructor
      ~ocnode() {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocnode<T>::~ocnode()" << std::endl;
        #endif // GLS_DEBUG
        // cleanup
        parent = nullptr;
        if (chunks != nullptr) {
          for(auto& node : *chunks) {
            delete node;
            node = nullptr;
          }
        }
      }
      /// insert gls::ocdata<T>
      ocnode<T>& operator +=(const ocdata<T>&) {}
    public:
      /// @todo insert ocdata<T> into this node, or (one of) its children
      ocnode<T>&             insert(ocdata<T>&& elem) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocnode<T>::insert(gls::ocdata<T>&&)" << std::endl;
        #endif // GLS_DEBUG
        
        assert(count != -1);
        
        const bool empty = !count; count++; // check if 0 then increment
        
        if (empty) {                        // only if root
          aabb = elem.aabb;                 // use input's size
          data.push_back(std::move(elem));  // insert here
        } else if (aabb.compare(elem.aabb) == aabb::INSIDE) {
          // IF inside
          const auto hafx = (aabb.max.x - aabb.min.x) / 2.f;
          const auto hafy = (aabb.max.y - aabb.min.y) / 2.f;
          const auto hafz = (aabb.max.z - aabb.min.z) / 2.f;
          
          if ((elem.aabb.min.x < hafx && hafx < elem.aabb.max.x)    // crosses half x 
              || (elem.aabb.min.y < hafy && hafy < elem.aabb.max.y)    // crosses half y
              || (elem.aabb.min.z < hafz && hafz < elem.aabb.max.z)) { // crosses half z
            // IF crosses the seems
            data.push_back(std::move(elem)); // insert here, and that's it
          } else {
            // ELSE: smaller that 1/8th
            if (chunks == nullptr) {
              // create chunks
              auto parts = aabb.split();
              chunks = new std::array<ocnode<T>*, 8>;
              (*chunks)[TFL] = new ocnode<T>(parts[TFL]);
              (*chunks)[TFR] = new ocnode<T>(parts[TFR]);
              (*chunks)[BFL] = new ocnode<T>(parts[BFL]);
              (*chunks)[BFR] = new ocnode<T>(parts[BFR]);
              (*chunks)[TBL] = new ocnode<T>(parts[TBL]);
              (*chunks)[TBR] = new ocnode<T>(parts[TBR]);
              (*chunks)[BBL] = new ocnode<T>(parts[BBL]);
              (*chunks)[BBR] = new ocnode<T>(parts[BBR]);
              // now you're a node
              type = octype::NODE;
            }
            // check elem against chunks 
            for (glm::uint i = 0; i < 8; i++) {
              if ((*chunks)[i]->aabb.compare(elem.aabb) == aabb::INSIDE) {
                (*chunks)[i]->insert(std::move(elem));
                break;
              }
            }
          }
        } else if (parent != nullptr) {     // try parent
          // IF outside OR intersect
          count--;
          parent->insert(std::move(elem));
        } else { // only if root
          data.push_back(std::move(elem));
          reeval();
        }
        // return reference to self for chaining
        return *this;
      }
      // @todo reeval yourself and your children // for each chunk in chunks trigger reeval...
      void                   reeval() {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocnode<T>::reeval()" << std::endl;
        #endif // GLS_DEBUG
        
        if (chunks != nullptr) {
          // gather data from all chunks // then delete the children (chunks)
          (*chunks)[TFL]->select(data); delete (*chunks)[TFL]; (*chunks)[TFL] = nullptr;
          (*chunks)[TFR]->select(data); delete (*chunks)[TFR]; (*chunks)[TFR] = nullptr;
          (*chunks)[BFL]->select(data); delete (*chunks)[BFL]; (*chunks)[BFL] = nullptr;
          (*chunks)[BFR]->select(data); delete (*chunks)[BFR]; (*chunks)[BFR] = nullptr;
          (*chunks)[TBL]->select(data); delete (*chunks)[TBL]; (*chunks)[TBL] = nullptr;
          (*chunks)[TBR]->select(data); delete (*chunks)[TBR]; (*chunks)[TBR] = nullptr;
          (*chunks)[BBL]->select(data); delete (*chunks)[BBL]; (*chunks)[BBL] = nullptr;
          (*chunks)[BBR]->select(data); delete (*chunks)[BBR]; (*chunks)[BBR] = nullptr;
        } else {
          chunks = new std::array<ocnode<T>*, 8>;
        }
        
        // compute node's aabb from all data elements min & max xyz
        for (auto& elem : data) {
          aabb.min.x = std::min(aabb.min.x, elem.aabb.min.x);
          aabb.min.y = std::min(aabb.min.y, elem.aabb.min.y);
          aabb.min.z = std::min(aabb.min.z, elem.aabb.min.z);
          aabb.max.x = std::max(aabb.max.x, elem.aabb.max.x);
          aabb.max.y = std::max(aabb.max.y, elem.aabb.max.y);
          aabb.max.z = std::max(aabb.max.z, elem.aabb.max.z);
        }
        
        // spit this node
        auto parts = aabb.split();
        (*chunks)[TFL] = new ocnode<T>(parts[TFL]);
        (*chunks)[TFR] = new ocnode<T>(parts[TFR]);
        (*chunks)[BFL] = new ocnode<T>(parts[BFL]);
        (*chunks)[BFR] = new ocnode<T>(parts[BFR]);
        (*chunks)[TBL] = new ocnode<T>(parts[TBL]);
        (*chunks)[TBR] = new ocnode<T>(parts[TBR]);
        (*chunks)[BBL] = new ocnode<T>(parts[BBL]);
        (*chunks)[BBR] = new ocnode<T>(parts[BBR]);
        
        // init sure this is a node
        type = octype::NODE;
        
        // check each data against each chunk
        for (auto it = data.begin(); it != data.end();/* ++it*/) {
          auto& elem = *it;
          bool  erased = false;
          // data (elem)
          for (glm::uint i = 0; i < 8; i++) {
            if ((*chunks)[i]->aabb.compare(elem.aabb) == aabb::INSIDE) {
              (*chunks)[i]->insert(std::move(elem));
              data.erase(it);
              erased = true;
              break;
            }
          }
          if (!erased) ++it;
        }
      }
      // @todo redo this select w/o condition
      std::vector<ocdata<T>> select() {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocnode<T>::select()" << std::endl;
        #endif // GLS_DEBUG
        // the output container
        std::vector<ocdata<T>> out;
        // get from current node
        select(out);
        return out;
      }
      /// select using a collector                       
      void                   select(std::vector<gls::ocdata<T>>& out) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocnode<T>::select(std::vector<gls::ocdata<T>>)" << std::endl;
        #endif // GLS_DEBUG
        
        // @todo std::vector<gls::ocdata<T>> << gls::ocnode<T>; put node data into vector
        
        // 1st: this node's data
        out.insert(out.end(), data.begin(), data.end());
        // 2nd: get from children
        if (chunks != nullptr) { // if NOT leaf
          // if leaf, look through all children
          for (auto& node : *chunks) {
            node->select(out);
          }
        }
      }
      /// move/extract data from node's data, leaving node w/o data
      void                   extract(std::vector<gls::ocdata<T>>& out) {
        #ifdef GLS_DEBUG
        std::cout << "gls::ocnode<T>::extract(std::vector<gls::ocdata<T>>)" << std::endl;
        #endif // GLS_DEBUG
        
        // 1st: this node's data
        out.insert(out.end(), std::make_move_iterator(data.begin()), std::make_move_iterator(data.end()));
        // 2nd: his children
        if (chunks != nullptr) {
          for (auto& node : *chunks) {
            node->extract(out);
            delete node;
          }
          // 3rd: destroy node's content
          delete chunks;
          type = octype::LEAF;
        }
      }
  };
  
  template<typename T> struct octree final {
      // @todo on 1st insert if node is empty => insert here
      // @todo on 2nd insert try to subdivide, but, IF T will be in intersection => insert here (parent)
      // @todo on nth insert IF subdivided try to insert in on of the children otherwise => insert here
    private:
      /// @todo std::hashmap<T*, ocnode<T>> index; /// insert T + node pair here for indexing
      ocnode<T>* root;
    public:
      /// default constructor
      octree() : root(new ocnode<T>)          {
        #ifdef GLS_DEBUG
        std::cout << "gls::octree<T>::octree()" << std::endl;
        #endif // GLS_DEBUG
      }
      /// @todo insert node into the tree
      octree<T>& operator +=(const ocdata<T>&) {}
      /// final destructor
      ~octree() {
        #ifdef GLS_DEBUG
        std::cout << "gls::octree<T>::~octree()" << std::endl;
        #endif // GLS_DEBUG
        delete root;
        root = nullptr;
      }
    public:
      /// goes down the tree and tries to find a place to put the node
      octree<T>&             insert(ocdata<T>&& data) {
        #ifdef GLS_DEBUG
        std::cout << "gls::octree<T>::insert(gls::ocdata<T>&&)" << std::endl;
        #endif // GLS_DEBUG
        root->insert(std::move(data));
        return *this;
      }
      // @todo trigger update on this tree using index
      octree<T>&             update(const ocdata<T>&)              {
        return *this;
      }
      /// calls gls::octree<T>::select();
      std::vector<ocdata<T>> select(/*const aabb&, callback(){}*/) {
        #ifdef GLS_DEBUG
        std::cout << "gls::octree<T>::select()" << std::endl;
        #endif // GLS_DEBUG
        return root->select();
      }
  };
}

#endif //__gls_gls_hpp__
