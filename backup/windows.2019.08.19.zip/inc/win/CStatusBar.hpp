#ifndef __win_cstatusbar_hpp__
#define __win_cstatusbar_hpp__

#include "CWindow.hpp"

namespace win {
  class CStatusBar : public CWindow { // CControl or CWidget
    public:
  };
}

#endif //__win_cstatusbar_hpp__
