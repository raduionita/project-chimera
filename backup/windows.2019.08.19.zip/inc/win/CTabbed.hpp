#ifndef __win_ctabbed_hpp__
#define __win_ctabbed_hpp__

#include "CControl.hpp"

namespace win {
  class CTabbed : public CControl {
    using CControl::CControl;
    typedef CControl super;
    protected:
      std::vector<CWindow*> mPages;
    public:
      CTabbed(CWindow* parent, const SShape& shape = AUTO, int hints = EHint::NONE);
      CTabbed() = default;
      ~CTabbed();
    protected:
      bool init(CWindow* parent, const SShape& sShape, int nHints) override;
    protected:
      static WNDPROC          prev;
      static LRESULT CALLBACK proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    public:
      CWindow* page(CWindow* pChild, const CString& title);
      CWindow* page(CWindow* pChild, int i, const CString& title);
      bool     change(int iPage);
  };
}

#endif //__win_ctabbed_hpp__
