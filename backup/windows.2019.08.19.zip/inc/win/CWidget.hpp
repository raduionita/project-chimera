#ifndef __win_cwidget_hpp__
#define __win_cwidget_hpp__

#include "CWindow.hpp"

namespace win {
  class CWidget : public CWindow {
    using CWindow::CWindow;
    typedef CWindow super;
    public:
      CWidget() = default;
  };
}

#endif //__win_cwidget_hpp__
