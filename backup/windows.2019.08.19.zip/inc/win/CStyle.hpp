#ifndef __win_cstyle_hpp__
#define __win_cstyle_hpp__

#include "CObject.hpp"

namespace win {
  class CStyle : public CObject {
    public:
      CStyle();
      ~CStyle();
      CStyle(const CStyle&);
      CStyle& operator =(const CStyle&);
  };
}

#endif // __win_cstyle_hpp__
