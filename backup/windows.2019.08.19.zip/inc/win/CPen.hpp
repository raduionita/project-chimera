#ifndef __win_cpen_hpp__
#define __win_cpen_hpp__

#include "win.hpp"
#include "CClass.hpp"

namespace win {
  class CPen : public CClass {
    public: 
  };
}

#endif //__win_cpen_hpp__
