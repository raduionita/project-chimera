#ifndef __win_ccontrol_hpp__
#define __win_ccontrol_hpp__

#include "CWidget.hpp"

namespace win {
  class CControl : public CWidget {
    using CWidget::CWidget;
    typedef CWidget super;
    public:
      CControl() = default;
  };
}

#endif //__win_ccontrol_hpp__
