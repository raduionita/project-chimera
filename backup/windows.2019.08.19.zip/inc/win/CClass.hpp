#ifndef __win_cclass_hpp__
#define __win_cclass_hpp__

#include "win.hpp"

namespace win {
  class CClass {
    public:
      CClass();
      virtual ~CClass();
  };
}

#endif //__win_cclass_hpp__
