#ifndef __win_ccheckbox_hpp__
#define __win_ccheckbox_hpp__

#include "CControl.hpp"

namespace win {
  class CCheckBox : public CControl {
    public:
  };
}

#endif //__win_ccheckbox_hpp__
