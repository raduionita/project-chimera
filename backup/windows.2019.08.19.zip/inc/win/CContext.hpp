#ifndef __win_ccontext_hpp__
#define __win_ccontext_hpp__

#include "CObject.hpp"
#include "CCanvas.hpp"

namespace win {
  class CContext : public CObject {
    protected:
      HGLRC    mRC     = {NULL};
      HDC      mDC     = {NULL};
      CCanvas* mCanvas = {nullptr};
    public:
      CContext() = default;
      CContext(CCanvas*);
      ~CContext();  
      operator       HGLRC();
      operator const HGLRC() const;
    protected:
      virtual bool init() = 0;
    public:
      HGLRC hrc();
      HDC   hdc();
      bool current(CCanvas*) const; 
      bool swap() const; 
  };
}

#endif //__win_ccontext_hpp__
