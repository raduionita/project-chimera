#ifndef __win_cwindow_hpp__
#define __win_cwindow_hpp__

#include "CObject.hpp"
#include "CHandler.hpp"
#include "CTooltip.hpp"
#include "CLayout.hpp"
#include "CStyle.hpp"

namespace win {
  class CWindow : public CObject, public CHandler {
    friend class CFrame;
    friend class CDialog;
    friend class CWidget;
    friend class CPanel;
    private:
      typedef CObject super;
    protected:
      // windows
      HWND                    mHandle   = {NULL};
      // structure
      CWindow*                mParent   = {nullptr};
      CTooltip*               mTooltip  = {nullptr};
      CLayout*                mLayout   = {nullptr};
      CStyle*                 mStyle    = {nullptr};
      // @todo use a object manager instead of storing parent and childrens here
      std::vector<CWindow*>   mChildren = {};
      // meta
      SShape                  mShape    = {0};
      int                     mHints    = {0};
      bool                    mInited   = {false};
      int                     mState    = {EState::_STATE_};
    public:
      CWindow() = default;
      ~CWindow();
      CWindow(const CWindow&);
      // operators
      CWindow& operator          =(const CWindow&);
      explicit operator       HWND();
      explicit operator const HWND() const;
    protected:
      virtual bool init(CWindow* parent, const SShape& sShape, int nHints);
      virtual bool free() final;
    public:
      bool      show(bool show = true);
      bool      hide(bool hide = true);
      bool      move(int,int);
      bool      size(int,int);
      SSize     size() const;
      bool      shape(int,int,int,int);
      SShape    shape() const;
      bool      maximize();
      bool      minimize();
      bool      center();
      bool      pack();
      bool      front();
    public:
      virtual void onInit();
      virtual void onFree();
    public:
      // @todo: use getters and setters where u should!!!
      
      CTooltip* tooltip(const CString&);
      
      inline bool     hasStyle() const { return mStyle != nullptr; }
             CStyle*  getStyle() const;
             bool     setStyle(CStyle*);
      
      inline bool     hasParent() const           { return mParent != nullptr; }
      inline CWindow* getParent() const           { return mParent; }
             bool     setParent(CWindow*);
    
      inline bool     hasLayout() const           { return mLayout != nullptr; }
      inline CLayout* getLayout() const           { return mLayout; }
             bool     setLayout(CLayout*);
      
      HDC       hdc() const;
      HWND      hwnd();
      CString   name() const;
      void      child(CWindow*);
      int       hints() const;
    public:
      static CWindow* find(const CString&);
    protected:
      static LRESULT CALLBACK proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
  };
}

#endif //__win_cwindow_hpp__
