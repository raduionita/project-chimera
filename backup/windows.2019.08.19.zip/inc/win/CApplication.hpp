#ifndef __win_capplication_hpp__
#define __win_capplication_hpp__

#include "CClass.hpp"

namespace win {
  class CApplication : public CClass {
    protected:
      bool mRunning     = {false};
      HINSTANCE mHandle = {NULL};
    public:
      CApplication();
      ~CApplication();
      operator HINSTANCE();
      operator HINSTANCE() const;
    protected:
      bool init();
      bool free();
    public:
      int  exec();
      int  quit();
    public: // listeners
      virtual void onInit();
      virtual void onIdle();
      virtual void onFree();
  };
}

#define DECLARE_APPLICATION(cls)                                                                                       \
INT WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)                        \
{                                                                                                                      \
  auto app   = new cls;                                                                                                \
  INT result = app->exec();                                                                                            \
  delete app;                                                                                                          \
  return result;                                                                                                       \
}                                                                                                                     //

#endif //__win_capplication_hpp__
