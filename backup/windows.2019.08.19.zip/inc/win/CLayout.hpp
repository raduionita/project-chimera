#ifndef __win_clayout_hpp__
#define __win_clayout_hpp__

#include "CObject.hpp"
#include "CWindow.hpp"

namespace win {
  class CLayout : public CObject {
    public: 
      class CItem : public CObject {
        protected:
          int mHints    = {0};
          SShape mShape = {0};
        public:
          CItem(int hints = 0);
          ~CItem();
        public:
          virtual bool size(int, int) = 0;
          virtual bool move(int, int) = 0;
          virtual bool shape(int, int, int, int) = 0;
      };
      template <typename T>
      class TItem : public CItem {
        protected:
          T mItem;
        public:
          TItem(T item, int hints = 0);
        public:
          bool size(int, int) override;
          bool move(int, int) override;
          bool shape(int, int, int, int) override;
      };
    protected:
      CWindow* mOwner = {nullptr}; // set on CWindow::layout(CLayout*)
      SShape   mShape = {0};
    public:
      CLayout() = default;
    protected:
      virtual bool calc() = 0;
      virtual bool size(int, int); // size/move all elements inside
      virtual bool move(int, int);
      virtual bool shape(int, int, int, int);
    public:
      virtual bool layout(CWindow* pOwner = nullptr);
      virtual SShape shape() const;
  };
  
  class CBoxLayout : public CLayout {
    // stacks added items vertically or horizontally
    // equally spaced
    // children re-aranged on CWindow::layout(CLayout*) call
    // when window resizes so does its layout...
    protected:
      EHint               mOrientation;
      std::vector<CItem*> mItems;
    public:
      CBoxLayout(EHint hint = EHint::VERTICAL);
      ~CBoxLayout();
    protected:
      bool calc() override;
    public:
      bool add(CWindow*, int hints = 0); 
      bool add(CLayout*, int hints = 0); 
      // new window
        // create/init window w/parent => position window relative to parent
      // new layout + strategy
      // add window
        // 
      // set layout => recompute children size/position
  };
}

#endif //__win_clayout_hpp__

// box layout (vertical & horizontal)
// grid layout
// form layout (row:[label, input])
