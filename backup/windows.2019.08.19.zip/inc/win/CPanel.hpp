#ifndef __win_cpanel_hpp__
#define __win_cpanel_hpp__

#include "CWidget.hpp"

namespace win {
  class CPanel : public CWidget {
    using CWidget::CWidget;
    typedef CWidget super;
    public:
      CPanel() = default;
      CPanel(CWindow* parent,                             int hints);
      CPanel(CWindow* parent, const SShape& shape = AUTO, int hints = EHint::NONE);
      ~CPanel();
    protected:
      bool init(CWindow* parent, const SShape& sShape, int nHints) override;
  };
}

#endif //__win_cpanel_hpp__
