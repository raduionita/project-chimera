#ifndef __win_cdialog_hpp__
#define __win_cdialog_hpp__

#include "win.hpp"
#include "CWindow.hpp"

namespace win {
  class CDialog : public CObject {
    protected:
      int mCode;
    public:
      CDialog();
  };
}

#endif //__win_cdialog_hpp__
