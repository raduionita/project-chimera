#ifndef __win_cbutton_hpp__
#define __win_cbutton_hpp__

#include "CControl.hpp"

namespace win {
  class CButton : public CControl {
    typedef CControl super;
    using CControl::CControl;
    protected:
      CString mText  = {""};
    public:
      CButton() = default;
      CButton(CWindow* parent, CString text,                                          int hints);
      CButton(CWindow* parent, CString text,              const SShape& shape = AUTO, int hints = EHint::NONE);
    //CButton(CWindow* parent, CIcon* icon, CString text, const SShape& shape = AUTO, int hints = EHint::NONE);
      ~CButton();
    protected:
      bool init(CWindow* parent, const SShape& shape, int hints) override;
    protected:
      static WNDPROC          prev;
      static LRESULT CALLBACK proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
  };
}

#endif //__win_cbutton_hpp__
