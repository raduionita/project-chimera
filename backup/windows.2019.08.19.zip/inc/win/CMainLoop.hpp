#ifndef __win_cmainloop_hpp__
#define __win_cmainloop_hpp__

namespace win {
  class CMainLoop {
      
  };
}

#endif //__win_cmainloop_hpp__
