#ifndef __win_cmenubar_hpp__
#define __win_cmenubar_hpp__

#include "CWindow.hpp"

namespace win {
  class CMenuBar : public CWindow {
    public:
  };
}

#endif //__win_cmenubar_hpp__
