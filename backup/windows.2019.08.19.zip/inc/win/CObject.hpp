#ifndef __win_cobject_hpp__
#define __win_cobject_hpp__

#include "CClass.hpp"

namespace win {  
  class CObject : public CClass {
    class CRegistry {
      protected:
        std::vector<CObject*> mObjects;
      public:
        CRegistry();
        virtual ~CRegistry();
      public:
        void insert(CObject*);
        void remove(CObject*);
    };
    protected:
      static CRegistry          sRegistry;
      static std::atomic<int>   sId;
    protected:
      const int                 mId = {++sId};
    public:
      // constructor / destructor
      CObject();
      ~CObject();
      // needed
      CObject(const CObject&);
      CObject& operator =(const CObject&);
    public:
      const int getId() const;
  };
}

#endif //__win_cobject_hpp__
