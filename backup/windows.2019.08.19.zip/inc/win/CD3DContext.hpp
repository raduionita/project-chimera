#ifndef __win_cd3dcontext_hpp__
#define __win_cd3dcontext_hpp__

#include "win.hpp"

namespace win {
  class CD3DContext {
      
  };
}

#endif //__win_cd3dcontext_hpp__
