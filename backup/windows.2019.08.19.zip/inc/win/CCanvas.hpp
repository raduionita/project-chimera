#ifndef __win_ccanvas_hpp__
#define __win_ccanvas_hpp__

#include "CPanel.hpp"
#include "CContext.hpp"

namespace win {
  class CCanvas : public CPanel {
    typedef CPanel super;
    protected:
      CContext* mContext = {nullptr};
    public:
      CCanvas(CWindow* parent,                                                int hints = EHint::NONE);
      CCanvas(CWindow* parent,                    const SShape& shape = AUTO, int hints = EHint::NONE);
      CCanvas(CWindow* parent, CContext* context, const SShape& shape = AUTO, int hints = EHint::NONE);
      CCanvas() = default;
      ~CCanvas();
    protected:
      bool init(CWindow* parent, const SShape& shape, int hints = EHint::WINDOW) override;
      bool current(CContext*) const;
  };
}

#endif //__win_ccanvas_hpp__
