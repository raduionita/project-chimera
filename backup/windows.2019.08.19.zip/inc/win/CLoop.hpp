#ifndef __win_cloop_hpp__
#define __win_cloop_hpp__

#include <functional>

namespace win {
  class CLoop {
    protected:
      bool mLooping = {false};
    public:
      bool onStart(std::function<void(void)>&& start);
      bool onTick(std::function<void(void)>&& tick);
      bool onEnd(std::function<void(void)>&& end);
  };
}

#endif //__win_cloop_hpp__
