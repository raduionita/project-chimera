#ifndef __win_cframe_hpp__
#define __win_cframe_hpp__

#include "CWindow.hpp"

namespace win {
  class CFrame : public CWindow {
    using CWindow::CWindow;
    typedef CWindow super;
    protected:
      CString mTitle  = {""};
    public:
      CFrame() = default;
      CFrame(                                                                        int hints);
      CFrame(                                            const SShape& shape,        int hints = EHint::WINDOW);
      CFrame(                 const CString& title,      const SShape& shape = AUTO, int hints = EHint::WINDOW);
      CFrame(CWindow* parent, const CString& title = "", const SShape& shape = AUTO, int hints = EHint::WINDOW);
      ~CFrame();
    protected:
      bool init(CWindow* parent,                       const SShape& shape, int hints = EHint::WINDOW) override;
      bool init(CWindow* parent, const CString& title, const SShape& shape, int hints = EHint::WINDOW);
    public:
      // @todo other stuff
  };
}

#endif //__win_cframe_hpp__
