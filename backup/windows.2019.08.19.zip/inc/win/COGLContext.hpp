#ifndef __win_coglcontext_hpp__
#define __win_coglcontext_hpp__

#include "CContext.hpp"

#define GL_GLEXT_PROTOTYPES

#include "gl/glcorearb.h"
#include "gl/glext.h"
#include "gl/wglext.h"

namespace win {
  class COGLContext : public CContext {
    public:
      enum EHint {
        DOUBLE_BUFFER,
        SAMPLE_BUFFER,
        ACCELERATION,
        CORE,
        COMPATIBILITY,
        RGBA
      };
      struct SConfig {
        int   nMjorVersion  = {1};
        int   nMinorVersion = {1};
        int   nColorBits    = {32};
        int   nDepthBits    = {24};
        int   nStencilBits  = {8};
        int   nAlphaBits    = {8};
        int   nSamples      = {0};
        int   nHints        = {EHint::CORE | EHint::DOUBLE_BUFFER | EHint::RGBA | EHint::SAMPLE_BUFFER | EHint::ACCELERATION};
      };
    public:
      SConfig mConfig;
    public:
      COGLContext() = default;
      COGLContext(CCanvas*);
      COGLContext(CCanvas*, const SConfig&);
      ~COGLContext();
    protected:
      bool init() override;
  };
}

#endif //__win_coglcontext_hpp__
