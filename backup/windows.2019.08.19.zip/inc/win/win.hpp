#ifndef __win_win_hpp__
#define __win_win_hpp__

// windows
#include <windows.h>
#include <windowsx.h>
#include <windef.h>
#include <commctrl.h>
// common
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <atomic>
#include <algorithm>
#include <functional>
#include <map>
#include <utility>

// default shapes
#ifndef WIN_DEFAULT_WINDOW_X
  #define WIN_DEFAULT_WINDOW_X      CW_USEDEFAULT
#endif // WIN_DEFAULT_WINDOW_X
#ifndef WIN_DEFAULT_WINDOW_Y
  #define WIN_DEFAULT_WINDOW_Y      CW_USEDEFAULT
#endif // WIN_DEFAULT_WINDOW_Y
#ifndef WIN_DEFAULT_WINDOW_WIDTH
  #define WIN_DEFAULT_WINDOW_WIDTH  CW_USEDEFAULT
#endif // WIN_DEFAULT_WINDOW_WIDTH
#ifndef WIN_DEFAULT_WINDOW_HEIGHT
  #define WIN_DEFAULT_WINDOW_HEIGHT CW_USEDEFAULT
#endif // WIN_DEFAULT_WINDOW_HEIGHT

#ifndef WIN_COL_WND_BG 
  #define WIN_COL_WND_BG RGB(  0,   0,   0)
#endif // WIN_COL_WND_BG

// #define WIN_COL_DEF_BORDER  RGB( 90,  90,  90)
// #define WIN_COL_WND_BORDER  RGB(  5,   5,   5)
// #define WIN_COL_WND_BG      RGB( 40,  40,  40)
// #define WIN_COL_PNL_BORDER  RGB( 75,  75,  75)
// #define WIN_COL_PNL_BG      RGB( 55,  55,  55)
// #define WIN_COL_BTN_BORDER  RGB( 90,  90,  90)
// #define WIN_COL_BTN_BG      RGB( 45,  45,  45)

#define PFD PIXELFORMATDESCRIPTOR

#define CM_INIT      (WM_USER + 0x0001) // custom message
#define CM_TABCHANGE (CM_INIT + 0x0001)


#define RETURNN(cond)     {if(cond)return;}
#define RETURNV(cond,out) {if(cond)return out;}
#define GET3RDARG(arg0,arg1,arg2,...) arg2
#define CHOOSERETURN(...) GET3RDARG(__VA_ARGS__, RETURNV, RETURNN,) 
#define _RETURN_(...)       CHOOSERETURN(__VA_ARGS__)(__VA_ARGS__)
#define _DELETE_(what)      {delete what;what = nullptr;}
#define _BREAK_(cond)       {if(cond)break;}
#define _CONTINUE_(cond)    {if(cond)continue;}

namespace win {
  class CHandler;
  class CObject;
    class CStyle;
    class CTooltip;
    class CContext;
    class CEvent;
    class CTimer;
    class CMenu;
    class CWindow;
      class CMenuBar;
      class CStatusBar;
      class CCanvas;
      class CFrame;
      class CDialog;
      class CWidget;
        class CPanel;
          class CLayout;
          class CGridLayout;
          class CBoxLayout;
            class CVBoxLayout;
            class CHBoxLayout;
        class CControl;
          class CButton;
          class CCheckBox;
          class CRadioBox;
  
  typedef std::string CString;
  
  constexpr int ANY   =            -1;
  constexpr int AUTO  = CW_USEDEFAULT;
  constexpr int ZERO  =             0;
  constexpr int EMPTY =             0;
  constexpr int FULL  =            -1;
  
  typedef int id_t;
  
  struct SPoint {
    int x, y;
    SPoint(int v = 0) : x(v), y(v) { }
    SPoint(int x, int y) : x(x), y(y) { }
    bool operator ==(int v) { return v == x && v == y; }
    bool operator !=(int v) { return !(operator ==(v)); }
  };
  
  struct SRect {
    int l, t, r, b;
    SRect(int v = 0) : l(v), t(v), r(v), b(v) { }
    SRect(int l, int t, int r, int b) : l(l), t(t), r(r), b(b) { }
  };
  
  struct SSize {
    int w, h;
    SSize(int v = 0) : w(v), h(v) { }
    SSize(int w, int h) : w(w), h(h) { }
    bool operator ==(int v) { return v == w && v == h; }
    bool operator !=(int v) { return !(operator ==(v)); }
  };
  
  struct SShape {
    union { struct { int x; int y; }; SPoint xy; SPoint point; };
    union { struct { int w; int h; }; SSize  wh; SSize  size;  };
    SShape(int v = 0) : x(v), y(v), w(v), h(v) { }
    SShape(int x, int y, int w, int h) : x(x), y(y), w(w), h(h) { }
    SShape(const SPoint& p, int w, int h) : x(p.x), y(p.y), w(w), h(h) { }
    SShape(int x, int y, const SSize& s) : x(x), y(y), w(s.w), h(s.h) { }
    SShape(const SPoint& p, const SSize& s) : x(p.x), y(p.y), w(s.w), h(s.h) { }
    SShape(const SPoint& p) : x(p.x), y(p.y), w(AUTO), h(AUTO) { }
    SShape(const SSize& s) : x(AUTO), y(AUTO), w(s.w), h(s.h) { }
    operator RECT() { RECT rect = {x, y, x + w, y + h}; return rect; }
    SShape& operator  =(const RECT& r) { x = r.left; y = r.top; w = r.right - x; h = r.bottom - y; return *this; }
    bool    operator ==(int v) { return v == x && v == y && v == w && v == h; }
    bool    operator !=(int v) { return !(operator ==(v)); }
    friend std::ostream& operator <<(std::ostream& o, const SShape& s);
    friend SShape        operator -(const SShape& l, const SShape& r);
  };
  
  struct SCounter {
    std::size_t mCounter = {0};
    SCounter() {}
    SCounter(std::size_t counter) : mCounter(counter) { }
    SCounter(const SCounter& that) { mCounter = that.mCounter; }
    SCounter& operator  =(SCounter& that) { if(this == &that) { mCounter = that.mCounter; } return *this; }
    bool      operator ==(int v) { return v == mCounter; }
    bool      operator !=(int v) { return v != mCounter; }
    SCounter& operator ++()    { ++mCounter; return *this; }
    SCounter  operator ++(int) { SCounter sTemp(mCounter); ++mCounter; return sTemp; }
    SCounter& operator --()    { --mCounter; return *this; }
    SCounter  operator --(int) { SCounter sTemp(mCounter); --mCounter; return sTemp; }
    friend std::ostream& operator <<(std::ostream&, const SCounter&);
    operator std::size_t() const       { return mCounter; }
    operator const std::size_t() const { return mCounter; }
    operator bool() const       { return mCounter != 0; }
    operator const bool() const { return mCounter != 0; }
  };
  
  inline std::ostream& operator <<(std::ostream&o, const SCounter& c) { return o << c.mCounter; }
  inline std::ostream& operator <<(std::ostream&o, const SPoint& s) { return o << s.x << " " << s.y; }
  inline std::ostream& operator <<(std::ostream&o, const SShape& s) { return o << s.x << " " << s.y << " " << s.w << " " << s.h; }
  inline std::ostream& operator <<(std::ostream&o, const RECT& r) { return o << r.left << " " << r.top << " " << r.right << " " << r.bottom; }
  inline SShape        operator -(const SShape& l, const SShape& r) { return {l.x-r.x, l.y-r.y, l.w-r.w, l.h-r.h}; }
  
  typedef SPoint P;
  typedef SRect  R;
  typedef SSize  S;
  typedef SShape G;
  
  enum EState {
    _STATE_   = 0,
    PUSHED    = 0b00000001,
    FOCUSED   = 0b00000100,
    CHECKED   = 0b00010000,
    MINIMIZED = 0b00100000,
    MAXIMIZED = 0b01000000,
  };
  
  enum EModifier {
    _MODIFIER_ = 0,
    RBUTTON    = MK_RBUTTON,  //  2
    SHIFT      = MK_SHIFT,    //  4
    CONTROL    = MK_CONTROL,  //  8
    MBUTTON    = MK_MBUTTON,  // 10
    X1BUTTON   = MK_XBUTTON1, // 20
    X2BUTTON   = MK_XBUTTON2  // 40
  };
  
  enum EEvent {
    _EVENT_ = 0,
    CLOSE,
    QUIT,
    KEYDOWN,
    KEYUP,
    KEYPRESS,
    MOVE,
    MOVING,
    RESIZE, SIZE = RESIZE,
    SIZING,
    FOCUS,
    UNFOCUS, BLUR = UNFOCUS,
    LBUTTONDOWN,
    LBUTTONUP,
    RBUTTONDOWN,
    RBUTTONUP,
    CLICK, LCLICK = CLICK, // LBUTTONDOWN + LBUTTONUP
    RCLICK,
    DBLCLICK,
    PAINT, DRAW = PAINT,
    SHOW,
    HIDE,
    COMMAND,
  };
  
  enum EKey {
    _KEY_     = 0,
    KEY_DOWN      = VK_DOWN,
    KEY_BACKSPACE = VK_BACK,
    KEY_TAB       = VK_TAB,
    KEY_Q         = 0x00,
    KEY_ZERO      = 0x30,
    KEY_ONE       = 0x31,
    // ...
    KEY_A         = 0x41,
    KEY_B         = 0x42,
  };
  
  enum EHint {
    _HINT_     = 0,
    NONE       = 0b00000000000000000000000000000000, // FRAMELESS
    BORDER     = 0b00000000000000000000000000000001, // WS_BORDER
    TITLE      = 0b00000000000000000000000000000010, // WS_CAPTION + WS_BORDER
    HSCROLL    = 0b00000000000000000000000000000100,
    VSCROLL    = 0b00000000000000000000000000001000,
    FRAME      = 0b00000000000000000000000000010000, // WS_THICKFRAME (resizing border)
    CHILD      = 0b00000000000000000000000000100000,
    GROUP      = 0b00000000000000000000000001000000,
    SYSMENU    = 0b00000000000000000000000010000010, // WS_SYSMENU
    MINBOX     = 0b00000000000000000000000100000000,
    MAXBOX     = 0b00000000000000000000001000000000,
    SIZER      = 0b00000000000000000000010000000000,
    VISIBLE    = 0b00000000000000000000100000000000,
    HIDDEN     = 0b00000000000000000001000000000000,
    FRAMELESS  = NONE | VISIBLE,             // NONE
    WINDOW     = BORDER | TITLE | FRAME | SYSMENU | MINBOX | MAXBOX | SIZER, // WS_OVERLAPPEDWINDOW
#undef ABSOLUTE
#undef RELATIVE
    ABSOLUTE   = 0b00000000000000000010000000000000,
    RELATIVE   = 0b00000000000000000100000000000000,
#define ABSOLUTE 1
#define RELATIVE 2
    LEFT       = 0b00000000000000001000000000000000,
    RIGHT      = 0b00000000000000010000000000000000,
    TOP        = 0b00000000000000100000000000000000,
    BOTTOM     = 0b00000000000001000000000000000000,
    EXPAND     = 0b00000000000010000000000000000000,
    VERTICAL   = 0b00000000000100000000000000000000,
    HORIZONTAL = 0b00000000001000000000000000000000,
    CENTERED   = 0b00000000010000000000000000000000,
    AUTOW      = 0b00000000100000000000000000000000,
    AUTOWIDTH  = AUTOW,
    AUTOH      = 0b00000001000000000000000000000000,
    AUTOHEIGHT = AUTOH,
    AUTOWH     = AUTOW | AUTOH,
    AUTOSIZE   = AUTOWH,
    AUTOX      = 0b00000010000000000000000000000000,
    AUTOY      = 0b00000100000000000000000000000000,
    AUTOXY     = AUTOX | AUTOY,
    AUTOMOVE   = AUTOXY,
    AUTOSHAPE  = AUTOX | AUTOY | AUTOH | AUTOW,
    TOPLEVEL   = 0b00001000000000000000000000000000,
    MINIMIZE   = 0b00010000000000000000000000000000,
    MAXIMIZE   = 0b00100000000000000000000000000000,
  };
  
  // @todo: replace multiple hints (int) with SHintBag
  struct SHintBag {
    private:
      int mHints = {EHint::_HINT_};
    public:
      SHintBag(int h = 0) : mHints(0) { }
      explicit operator       int() const { return mHints; }
      explicit operator const int() const { return mHints; }
      SHintBag  operator  |(EHint eHint) { return SHintBag(mHints | eHint); } 
      SHintBag  operator  &(EHint eHint) { return SHintBag(mHints & eHint); } 
      SHintBag& operator |=(EHint eHint) { mHints |= eHint; return *this; };
      SHintBag& operator &=(EHint eHint) { mHints &= eHint; return *this; };
      bool      operator ==(int v)             { return mHints == v; }
      bool      operator ==(const SHintBag& b) { return mHints == b.mHints; }
  };
  
  inline CString T(const char* text) { return CString(text); }
  inline CString T(int num)          { return std::to_string(num); }
}

// @todo move this somewhere better
inline std::string GetLastErrorString() {
  DWORD errid = ::GetLastError();
  if (errid == 0)
    return std::string();
  
  LPSTR buffer = nullptr;
  size_t size = ::FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                                NULL, errid, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPSTR)&buffer, 0, NULL);
  std::string errmsg(buffer, size);
  ::LocalFree(buffer);
  return errmsg;
}

inline void SetDefaultFont(HWND hWnd) {
  ::SendMessage(hWnd, WM_SETFONT, (WPARAM)::GetStockObject(DEFAULT_GUI_FONT), (LPARAM)true);
}

#endif //__win_win_hpp__
