#ifndef __win_clistener_hpp__
#define __win_clistener_hpp__

#include "CClass.hpp"
#include "CEvent.hpp"

namespace win {
  class CHandler : public CClass {
    friend class CWindow;
    private:
      std::map<EEvent, std::vector<std::function<void(CEvent*)>>> mCallbacks;
      std::map<EEvent, CEvent*>                                   mEnqueued;
    public:
      CHandler();
      ~CHandler();
    protected:
      template <typename T, typename E>
      bool attach(CHandler* pTrigger, EEvent eEvent, void(T::*callback)(E*)) {
        std::cout << "win::CHandler::attach(CHandler*, EEvent, void(T::*callback)(CEvent*))::" << this << std::endl;
        
        auto aCallbacks =& pTrigger->mCallbacks[eEvent]; // pointer to vector inside map
        
        auto fCallback  = [this, callback] (CEvent* pEvent) -> void {
          T* pHandler = dynamic_cast<T*>(this);
          E* pCasted  = dynamic_cast<E*>(pEvent);
          (pHandler->*callback)(pCasted);
        };
          
        // if has queued (already triggered)
        auto it = mEnqueued.find(eEvent);
        // pre-trigger the previously enqueued event
        if(it != mEnqueued.end()) { fCallback(it->second); }
    
        aCallbacks->push_back(std::move(fCallback));
        
        return true;
      }
      bool detach(CHandler* pTrigger, EEvent eEvent);
      
      // @todo: an attach method that accepts lambdas :)
    public:
      bool handle(CEvent* pEvent);
    
  };
}

#endif //__win_clistener_hpp__
