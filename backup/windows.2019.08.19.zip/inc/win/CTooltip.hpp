#ifndef __win_ctooltip_hpp__
#define __win_ctooltip_hpp__

#include "CObject.hpp"
#include "CWindow.hpp"

namespace win {
  class CTooltip : public CObject {
    protected:
      HWND mHandle = {NULL};
    public:
      CTooltip(const CString&);
    protected:
      bool init(CWindow*);
    public:
      bool text(const CString&); 
  };
}

#endif //__win_ctooltip_hpp__
