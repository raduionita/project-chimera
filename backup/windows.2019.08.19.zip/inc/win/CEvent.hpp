#ifndef __win_cevent_hpp__
#define __win_cevent_hpp__

#include "CClass.hpp"

namespace win {
  
  // @todo: need a better way to define event types (mouse-event, left-button-event...)
  
  class CEvent : public CClass {
    public:
      bool      mPropagate = {true};
      bool      mDefault   = {true};
    public:
      EEvent    mType      = {EEvent::_EVENT_};
      CHandler* mTarget    = {nullptr};
      CHandler* mOriginal  = {nullptr};
    public:
      CEvent(EEvent type, CHandler* target = nullptr);
    public:
      inline void noPropagation() { mPropagate = false; }
      inline void noDefault()     { mDefault   = false; }
      inline bool doPropagation() const { return mPropagate; }
      inline bool doDefault()     const { return mDefault;   } // prevent default (ex: WM_CLOSE - closes the app)
  };
  
  class CCloseEvent : public CEvent {
    using CEvent::CEvent;
    public:
      CCloseEvent(CHandler* pTarget = nullptr);
  };
  
  class CMouseEvent : public CEvent {
    using CEvent::CEvent;
    friend std::ostream& operator <<(std::ostream&, const CMouseEvent&);
    public:
      int       mClientX   = {0};
      int       mClientY   = {0};
      bool      mClick     = {false};
      EModifier mModifier  = {EModifier(0)};
    public:
      CMouseEvent(EEvent type = EEvent::CLICK, CHandler* target = nullptr);
    public:
      inline bool isClick() { return mClick; }
  };
  
  class CResizeEvent : public CEvent {
    using CEvent::CEvent;
    public:
      int    mWidth  = {0};
      int    mHeight = {0};
      EState mState  = {EState::_STATE_};
    public:
      CResizeEvent(CHandler* pHandler = nullptr);
    public:
      inline int    getWidth()  const { return mWidth;  }
      inline int    getHeight() const { return mHeight; }
      inline EState getState()  const { return mState;  }
  };
  
  class CKeyEvent : public CEvent {
    using CEvent::CEvent;
    public:
      char mKey = {0};
    public:
      CKeyEvent(EEvent type = EEvent::KEYDOWN, CHandler* target = nullptr);
  };
  
  class CCommandEvent : public CEvent {
    using CEvent::CEvent;
    public:
      CControl* mControl = {nullptr};
      int       mState   = {0};
  };
  
  class CPaintEvent : public CEvent {
    using CEvent::CEvent;
  };
}

#endif //__win_cevent_hpp__
