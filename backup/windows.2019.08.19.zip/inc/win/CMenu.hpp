#ifndef __win_cmenu_hpp__
#define __win_cmenu_hpp__

#include "CObject.hpp"
#include "CHandler.hpp"

namespace win {
  class CMenu : public CObject, public CHandler {
    public:
      CMenu();
      ~CMenu();
  };
}

#endif //__win_cmenu_hpp__
