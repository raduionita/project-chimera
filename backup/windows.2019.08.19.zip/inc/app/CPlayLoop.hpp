#ifndef __app_cgameloop_hpp__
#define __app_cgameloop_hpp__

namespace app {
  class CGameLoop {
      
  };
}

#endif //__app_cgameloop_hpp__
