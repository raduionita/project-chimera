#ifndef __app_ceditwindow_hpp__
#define __app_ceditwindow_hpp__

#include "win/CEvent.hpp"
#include "win/CFrame.hpp"
#include "win/CPanel.hpp"
#include "win/CButton.hpp"
#include "win/CTabbed.hpp"
#include "win/CLayout.hpp"

namespace app {
  class CEditWindow : public win::CFrame {
    public:
      CEditWindow();
      ~CEditWindow();
    public:
      void onInit();
      void onShow(win::CEvent*);
      void onButtonDown(win::CMouseEvent*);
      void onFocus(win::CEvent*);
      void onKeyDown(win::CKeyEvent*);
      void onResize(win::CResizeEvent*);
      void onCommand(win::CCommandEvent*);
  };
}

#endif //__app_ceditwindow_hpp__
