#ifndef __app_cgamewindow_hpp__
#define __app_cgamewindow_hpp__

#include "win/CFrame.hpp"

namespace app {
  class CGameWindow : public win::CFrame {
      
  };
}

#endif //__app_cgamewindow_hpp__
