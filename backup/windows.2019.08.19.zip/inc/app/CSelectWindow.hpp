#ifndef __app_cselectwindow_hpp__
#define __app_cselectwindow_hpp__

#include "win/CFrame.hpp"

namespace app {
  class CSelectWindow : public win::CFrame {
      
  };
}

#endif //__app_cselectwindow_hpp__
