#ifndef __app_capplication_hpp__
#define __app_capplication_hpp__

#include "win/CApplication.hpp"
#include "app/CEditWindow.hpp"
#include "win/CFrame.hpp"

#include <iostream>

namespace app {
  class CApplication : public win::CApplication {
    private:
      CEditWindow* mEditWindow = {nullptr};
    public:
      CApplication();
    public:
      void onInit() override;
      void onIdle() override;
      void onFree() override;
  };  
}


#endif //__app_capplication_hpp__


// editor app
 // + scene
 // + window(s)
