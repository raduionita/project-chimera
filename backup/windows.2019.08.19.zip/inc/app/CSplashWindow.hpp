#ifndef __app_csplashwindow_hpp__
#define __app_csplashwindow_hpp__

#include "win/CFrame.hpp"

namespace app {
  class CSplashWindow : public win::CFrame {
      
  };
}

#endif //__app_csplashwindow_hpp__
