#include <iostream>
#include <unordered_map>
#include <vector>
#include <array>
#include <atomic>
#include <functional>
#include <initializer_list>
#include <cassert>

#define GLM_FORCE_DEPTH_ZERO_TO_ONE

#define GLS_DEBUG

#include "gls/gls.hpp"

namespace std {
  template<typename K, typename V> using hashmap = std::unordered_map<K, V>;
}

namespace xtd {} // extended standard

namespace phx {}

namespace snd {}

namespace gfx {
  class CAnimation {
  };
  
  class CModel {
  };
}

namespace app {
  // types of nodes
  enum ENode {
    SCENE = 0, JOINT, MODEL, ANIMT, CNTRL, FORCE, EFFEX, LIGHT, AUDIO
  };
  
  class CNode;
  
  class CScene;
  
  template<ENode tType>
  class BNode;
  
  template<ENode tType>
  class TNode;
  
  template<>
  class TNode<ENode::ANIMT>;
  
  class CScene {
    public:
      std::vector<CNode*> mNodes;
      gls::octree<CNode*> mTree;
  };
  
  template<>
  class TNode<ENode::MODEL>;
  
  class CNode {
    private:
      static std::atomic<int> sNIDs;
    protected:
      ENode mType;
      int mNID;
    public:
      CNode* mParent;
      std::vector<CNode*> mNodes;
    public:
      CNode() = delete;
      
      CNode(ENode type) : mType(type), mNID(++sNIDs), mParent(nullptr) {
        std::cout << "CNode::CNode(ENode = " << mType << ")" << std::endl;
      }
      
      virtual ~CNode() {
        for (auto& pNode : mNodes) {
          delete pNode;
          pNode = nullptr;
        }
        std::cout << "CNode::~CNode() [mType=" << mType << "]" << std::endl;
      }
    
    public:
      const ENode getType() const { return mType; }
      
      void addNode(CNode*&& pNode) {
        std::cout << "CNode::addNode(CNode* = TNode<" << pNode->getType() << ">*)" << std::endl;
        pNode->mParent = this;
        mNodes.push_back(std::move(pNode));
      }
  };
  
  std::atomic<int> CNode::sNIDs(0);
  
  template<ENode tType>
  class BNode : public CNode {
    public:
      BNode(ENode) = delete;
      
      BNode() : CNode(tType) {
        std::cout << "BNode::BNode()" << std::endl;
      }
      
      ~BNode() {
        std::cout << "BNode<ENode>::~BNode()" << std::endl;
      }
  };
  
  
  template<ENode tType>
  class TNode : public BNode<tType> {
    public:
      TNode() {
        std::cout << "TNode<ENode = " << tType << ">::TNode()" << std::endl;
      }
  };
  
  template<>
  class TNode<ENode::ANIMT> : public BNode<ENode::ANIMT> {
    public:
      std::hashmap<std::string, gfx::CAnimation*> mAnimations;
    public:
      ~TNode() {
        std::cout << "TNode<ENode::ANIMT>::~TNode()" << std::endl;
        for (auto it = mAnimations.cbegin(); it != mAnimations.cend(); ++it) {
          gfx::CAnimation* pAnimation = it->second;
          delete pAnimation;
          pAnimation = nullptr;
        }
      }
  };
  
  template<>
  class TNode<ENode::MODEL> : public BNode<ENode::MODEL> {
    public:
      gfx::CModel* mModel;
    public:
      ~TNode() {
        std::cout << "TNode<ENode::MODEL>::~TNode()" << std::endl;
        delete mModel;
        mModel = nullptr;
      }
  };
}

#include "app/CApplication.hpp"

DECLARE_APPLICATION(app::CApplication)

// auto scene = new app::CScene;
// auto model = new app::TNode<app::ENode::MODEL>;
// delete model;
// delete scene;

//  gls::octree<int> tree;
//  
//  tree.insert(gls::ocdata<int>{1, {glm::vec3( 0.f), glm::vec3( 40.f)}});
//  tree.insert(gls::ocdata<int>{2, {glm::vec3(60.f), glm::vec3(100.f)}});
//  tree.insert(gls::ocdata<int>{3, {glm::vec3(40.f), glm::vec3( 60.f)}});
//  
//  for(auto& data : tree.select()) {
//    std::cout << data.data << std::endl;
//  }

// insert
// main:
// add model to scene // scene->addNode(model)
// scene:
// add node to CScene::mNodes // mNodes.push_back(pNode)
// from T create a gls::ocdata<T>
// insert gls::ocdata<T> into gls::octree<T> [CScene::mTree] // mTree->insert(gls::ocdata<CNode*>)
// octree:
// insert gls::ocdata<T> into gls::ocnode<T> (gls::octree<T>::root)
// ocnode:
// IF gls::ocnode<T> is empty                  => insert here (no subdivide)
// IF gls::ocdata<T> > 1/8th of gls::ocnode<T> => insert here (no subdivide)
// ELSE insert here +
//    + subdivide (create leafs) +
//    + try to move from this gls::ocnode<T>::data to gls::ocnode<T>::chunks
// @todo what to do with children data when re-evaluation this node
// update : on scale, translate or rotate
// main:
// send update to the tree // gls::octree<T>::update(gls::ocdata<T>)
// octree:
// send update to gls::octree<T>::root OR use gls::octree<T>::index
// ocnode:
// IF gls::ocdata<T> stil in (aabb::INSIDE the gls::ocnode<T>::aabb) this node  => do nothing
// ELSE remove T & gls::ocdata<T> from this node +
//    + if node is ROOT => resize()
//    + queue reeval event on this node + (queue because the parent may need to be re-eval and this one will be skipped)
//    + go to gls::ocnode<T>::parent +
//    + IF gls::ocdata<INSIDE> stil aabb::INSIDE => insert here and trigger reevel
//      ELSE got to the gls::ocnode<T>::parent...
// reeval (all data + children of this node)
// get all gls::ocdata<T> from all childre

// opengl: 
// window creation (glfw3)
// extension init  (glew)
