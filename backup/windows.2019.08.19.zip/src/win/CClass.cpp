#include "win/CClass.hpp"

namespace win {
  CClass::CClass() {}
  CClass::~CClass() {}
}
