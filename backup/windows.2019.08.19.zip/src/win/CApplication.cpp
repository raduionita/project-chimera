#include "win/CApplication.hpp"

namespace win {
  
  // constructors and operators //////////////////////////////////////////////////////////////////////////////////////
  
  CApplication::CApplication() : mRunning{false}, mHandle{::GetModuleHandle(NULL)} {
    std::cout << "win::CApplication::CApplication()" << std::endl;
  }
  
  CApplication::~CApplication() {
    std::cout << "win::CApplication::~CApplication()" << std::endl;
    mHandle  = NULL;
    mRunning = false;
  }
  
  CApplication::operator HINSTANCE() {
    return mHandle;
  }
  
  CApplication::operator HINSTANCE() const {
    return mHandle;
  }
  
  // main metthods ///////////////////////////////////////////////////////////////////////////////////////////////////
  
  bool CApplication::init() {
    std::cout << "win::CApplication::init()" << std::endl;
    onInit();
    return true;
  }
  
  bool CApplication::free() {
    std::cout << "win::CApplication::free()" << std::endl;
    onFree();
    return true;
  }
  
  int CApplication::exec() {
    std::cout << "win::CApplication::exec()" << std::endl;
  
    // @todo: replace w/ custom loop
    
    mRunning = init();
  
    MSG msg;
    while(mRunning) {
      // @todo: should do a proper game loop taking in account fps
      // prevent message clogging (using if)
      if (::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
        ::TranslateMessage(&msg);
        ::DispatchMessage(&msg);
        mRunning = (msg.message != WM_QUIT);
      } else {
        onIdle(); // game loop
      }
    }
  
    // int     nNumArgs; // argc
    // LPWSTR* aArgs = ::CommandLineToArgvW(::GetCommandLineW(), &nNumArgs); // argv
    
    free();
  
    return (int)(msg.wParam);
  }
  
  int CApplication::quit() {
    std::cout << "win::CApplication::quit()" << std::endl;
    return !(mRunning = false);
  }
  
  // event handlers //////////////////////////////////////////////////////////////////////////////////////////////////
  
  void CApplication::onInit() {
    std::cout << "win::CApplication::onInit()" << std::endl;
  }
  
  void CApplication::onIdle() {
    std::cout << "win::CApplication::onIdle()" << std::endl;
  }
  
  void CApplication::onFree() {
    std::cout << "win::CApplication::onFree()" << std::endl;
  }
}
