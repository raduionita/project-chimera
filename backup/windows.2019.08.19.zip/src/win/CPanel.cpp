#include "win/CPanel.hpp"

namespace win {
  // constructors and operators //  //////////////////////////////////////////////////////////////////////////////////
  
  CPanel::CPanel(CWindow* parent, int hints) 
  : CPanel(parent, AUTO, hints) {
    std::cout << "win::CPanel::CPanel(parent, hints)::" << this << std::endl;
  }
  
  CPanel::CPanel(CWindow* parent, const SShape& shape/*=AUTO*/, int hints/*=NONE*/) 
  : CWidget() {
    std::cout << "win::CPanel::CPanel(parent, shape, hints)::" << this << std::endl;
    init(parent, shape, hints);
  }
  
  CPanel::~CPanel() {
    std::cout << "win::CPanel::CPanel()::" << this << std::endl;
  }
  
  // main metthods //  ///////////////////////////////////////////////////////////////////////////////////////////////
  
  bool CPanel::init(CWindow* parent, const SShape& shape/*=AUTO*/, int hints/*=NONE*/) {
    std::cout << "win::CPanel::init()::" << this << ":" << mHandle << ":" << mId << std::endl;
    // dont want to do
    _RETURN_(mInited,true);
    // set as initialized, so it doesn't enter this logic twice
    mInited = CWidget::init(parent, shape, hints);
  
    if (mParent == nullptr) {
      ::MessageBox(NULL, "[CPanel] No parent no panel!!", "Error", 0);
      return false;
    }

    // @todo move this to CWidget::getClass() OR CPanel::getClass() and init it static and track it (sPID) 
    WNDCLASSEX wndcls = {
      cbSize       : sizeof(WNDCLASSEX),                // UINT      // struct size  
      style        : CS_HREDRAW | CS_VREDRAW,           // UINT      
      lpfnWndProc  : CWindow::proc,                     // WNDPROC   // uix::CWidget::proc
      cbClsExtra   : 0,                                 // int       // no extra bytes after the window class
      cbWndExtra   : 0,                                 // int      // structure or the window instance
      hInstance    : NULL,/*(HINSTANCE)(*uix::app)*/    // HINSTANCE 
      hIcon        : ::LoadIcon(NULL, IDI_APPLICATION), // HICON     
      hCursor      : ::LoadCursor(NULL, IDC_ARROW),     // HCURSOR 
      hbrBackground: (HBRUSH)COLOR_ACTIVEBORDER,        // HBRUSH   // COLOR_ACTIVEBORDER|COLOR_WINDOW
      lpszMenuName : NULL,                              // LPCTSTR   // no menu
      lpszClassName: name().c_str(),                    // LPCTSTR   
      hIconSm      : ::LoadIcon(NULL, IDI_APPLICATION)  // HICON     
    };

    if (!::RegisterClassEx(&wndcls)) {
      std::cout << "[CPanel] RegisterClassEx failed!" << std::endl;
      ::MessageBox(NULL, "[CPanel] RegisterClassEx failed!", "Error", 0);
      return false;
    } // @todo trigger error event
  
    DWORD dwExStyle = 0;
//  dwExStyle |= WS_EX_TRANSPARENT;
    DWORD dwStyle   = 0;
//  dwStyle |= mHints & EHint::BORDER   ? WS_BORDER      : 0;
//  dwStyle |= mHints & EHint::FRAME    ? WS_THICKFRAME | WS_SIZEBOX | WS_CAPTION | WS_BORDER: 0;
    dwStyle |= mHints & EHint::HSCROLL  ? WS_HSCROLL     : 0;
    dwStyle |= mHints & EHint::VSCROLL  ? WS_VSCROLL     : 0;
    dwStyle |= WS_CHILD;
    dwStyle |= WS_CLIPCHILDREN;
    dwStyle |= WS_CLIPSIBLINGS;

    mHandle = ::CreateWindowEx(
      dwExStyle,                  // dwExStyle    // DWORD // ex. style (0 = default)
      wndcls.lpszClassName,       // lpClassName  // LPCSTR window class name
      name().c_str(),             // lpWindowName // LPCSTR window title name
      dwStyle,                    // dwStyle      // DWORD // style
      CW_USEDEFAULT, CW_USEDEFAULT, 
      CW_USEDEFAULT, CW_USEDEFAULT, 
      (HWND)(*mParent),           // HWND parent handle
      NULL,                       // HMENU menu handle
      wndcls.hInstance,           // HINSTANCE application handle
      this                        // LPVOID additional app data
    );

    if (mHandle == NULL) {
      // @todo trigger error event
      ::MessageBox(NULL, "[CPanel] CreateWindowEx failed!", "Error", 0);
      return false;
    }  // @todo trigger error event

    ::SetWindowLong(mHandle, GWL_STYLE,   dwStyle);
    ::SetWindowLong(mHandle, GWL_EXSTYLE, dwExStyle);
    ::SetWindowLongPtr(mHandle, GWLP_USERDATA, (LONG_PTR)(this));

    RECT sRect; ::GetClientRect((HWND)(*mParent), &sRect);
    (mHints & EHint::AUTOX) ? (sRect.left = 0) : (sRect.left = mShape.x);
    (mHints & EHint::AUTOY) ? (sRect.top  = 0) : (sRect.top  = mShape.y);
    (mHints & EHint::AUTOW) ? (sRect.right  = sRect.right)  : (sRect.right  = mShape.w);
    (mHints & EHint::AUTOH) ? (sRect.bottom = sRect.bottom) : (sRect.bottom = mShape.h);
    
    move(sRect.left, sRect.top) && size(sRect.right, sRect.bottom);

    // center window
    (mHints & EHint::CENTERED) && center();
    // set window visibility state
    (mHints & EHint::VISIBLE)  && show();

    // @todo init panel style 
    // mStyle->setBackground(CBrush(CColor(UIX_COL_PNL_BG)));
    // mStyle->setBorder(CPen(UIX_SZE_PNL_BORDER, CPen::SOLID, CColor(UIX_COL_PNL_BORDER)));

    // enumerates the children of this window (handle)
    ::EnumChildWindows(mHandle, [] (HWND hChild, LPARAM) -> BOOL {
        std::cout << hChild << "::child" << std::endl;
        return TRUE;
    } , 0);
    
    // trigger on init windows message
    ::SendMessage(mHandle, CM_INIT, 0, 0);
    
    // done
    return mInited;
  }
}
