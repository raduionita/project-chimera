#include "win/CTabbed.hpp"

namespace win {
  // statics ///////////////////////////////////////////////////////////////////////////////////////////////////////// 
  
  WNDPROC CTabbed::prev;
  
  // constructors and operators //////////////////////////////////////////////////////////////////////////////////////
  
  CTabbed::CTabbed(CWindow* parent, const SShape& shape/*=AUTO*/, int hints/*=NONE*/)
  : CControl() {
    std::cout << "win::CTabbed::CTabbed(parent, shape, hints)::" << this << std::endl;
    init(parent, shape, hints);
  }
  
  CTabbed::~CTabbed() {
    std::cout << "win::CTabbed::CTabbed()::" << this << std::endl;
  }
  
  // main metthods ///////////////////////////////////////////////////////////////////////////////////////////////////
  
  bool CTabbed::init(CWindow* parent, const SShape& shape/*=AUTO*/, int hints/*=NONE*/) {
    std::cout << "win::CTabbed::init()::" << this << ":" << mHandle << ":" << mId << std::endl;
  
    // dont want to do
    if (mInited) return mInited;
    // set as initialized, so it doesn't enter this logic twice
    mInited = CControl::init(parent, shape, hints);
  
    if (mParent == nullptr) {
      ::MessageBox(NULL, "[CPanel] No parent no panel!!", "Error", 0);
      return false;
    }
  
    mHandle = ::CreateWindowEx(
      0,
      WC_TABCONTROL,
      "",
      WS_CHILD | TCS_FIXEDWIDTH, // WS_VISIBLE
      CW_USEDEFAULT, CW_USEDEFAULT,
      CW_USEDEFAULT, CW_USEDEFAULT,
      (HWND)(*mParent),               // HWND parent handle
      NULL,                           // HMENU menu handle
      NULL,/*(HINSTANCE)(*uix::app)*/ // HINSTANCE hInstance // ::GetWindowLong((HWND)(*mParent), GWL_HINSTANCE);
      this                            // LPVOID lpParam // 
    );
    
    if (mHandle == NULL) {
      // @todo trigger error event
      ::MessageBox(NULL, "[CPanel] CreateWindowEx failed!", "Error", 0);
      return false;
    }  // @todo trigger error event
  
    prev = (WNDPROC) ::SetWindowLongPtr(mHandle, GWLP_WNDPROC,  (LONG_PTR)(&proc)); // (this) requires:
    /* LONG_PTR = */ ::SetWindowLongPtr(mHandle, GWLP_USERDATA, (LONG_PTR)(this));
  
    RECT sRect; ::GetClientRect((HWND)(*mParent), &sRect);
    (mHints & EHint::AUTOXY) && ((mShape.x = 0)           || (mShape.y = 0));
    (mHints & EHint::AUTOWH) && ((mShape.w = sRect.right) && (mShape.h = sRect.bottom));
    
    move(mShape.x, mShape.y) && size(mShape.w, mShape.h);
  
    // center window
    (mHints & EHint::CENTERED) && center();
    // set window visibility state
    (mHints & EHint::VISIBLE)  && show();
  
    ::SendMessage(mHandle, CM_INIT, 0, 0);
    
    ::SetDefaultFont(mHandle);
  
    return mInited;
  }
  
  CWindow* CTabbed::page(CWindow* pChild, const CString& title) {
    std::cout << "win::CTabbed::page(CWindow*, const CString&)::" << this << ":" << mHandle << ":" << mId << std::endl;
    
    // @todo rename to panel() w/o pChild param
    // @todo should return new CPanel 
    
    // @todo what about tab icons and tab close button
    
    auto iNext = mPages.size();
    TCITEM titem = {0};
    titem.mask       = TCIF_TEXT; // |TCIF_IMAGE;
    titem.pszText    = const_cast<LPSTR>(title.c_str());
    //titem.cchTextMax = static_cast<int>(title.length());
  
    // @see: TabCtrl_InsertItem()
    if (::SendMessage(mHandle,TCM_INSERTITEM, (WPARAM)(iNext), reinterpret_cast<LPARAM>(&titem)) == -1) {
      ::MessageBox(NULL, "[CTabbed] TCM_INSERTITEM failed!", "Error", 0);
      return false;
    }
    
    RECT sIRect = {0}; // item   rect
    RECT sCRect = {0}; // client rect
    // @see TabCtrl_GetItemRect()
    ::SendMessage(mHandle, TCM_GETITEMRECT, 0, (LPARAM)(&sIRect));
    ::GetClientRect(mHandle, &sCRect);
    
    //SShape sShape = pChild->shape();
    //int    nHints = pChild->hints();
    //(nHints & EHint::AUTOXY) && ((sShape.x = 0) || (sShape.y = 0)); 
    
    pChild->move(sIRect.left, sIRect.bottom + sIRect.top);
    pChild->size(sCRect.right - sCRect.left - 2*sIRect.left, sCRect.bottom - sIRect.bottom - 2*sIRect.top);
    
    std::cout << "tab item   rect:" << sIRect << std::endl; // left, top, right, bottom
    std::cout << "tab client rect:" << sCRect << std::endl; // left, top, right, bottom
    
    mPages.push_back(pChild);
    
    return pChild;
  }
  
  bool CTabbed::change(int iPage) {
    std::cout << "win::CTabbed::change(" << iPage << ")::" << this << ":" << mHandle << ":" << mId << std::endl;
    CWindow*& pChild = mPages[iPage];
    return pChild->front();
  }
  
  // static metthods /////////////////////////////////////////////////////////////////////////////////////////////////
  
  LRESULT CALLBACK CTabbed::proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) { // (void*, uint, uint*, long*)
    switch (uMsg) {
      case CM_TABCHANGE: {
        CTabbed* pWindow = reinterpret_cast<CTabbed*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":T:CM_TABCHANGE:" << wParam << std::endl;
        UNREFERENCED_PARAMETER(wParam);
        pWindow->change((int)lParam);
        return 0;
      }
      case WM_ERASEBKGND: {    // when window bg redrawn (ex on BeginPaint)
        CTabbed* pWindow = reinterpret_cast<CTabbed*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":T:WM_ERASEBKGND:" << wParam << std::endl;
        UNREFERENCED_PARAMETER(lParam); // worn compiler that this is unused
        break;
      }
      case WM_PAINT: {
        CTabbed* pWindow = reinterpret_cast<CTabbed*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":T:WM_PAINT:" << wParam << ":" << lParam << std::endl;
        UNREFERENCED_PARAMETER(lParam);
        UNREFERENCED_PARAMETER(wParam);
        // onDraw()
        // return 0; // if the program handled this message
        break;
      }
      default: break;
    }
    return ::CallWindowProc(CTabbed::prev, hWnd,  uMsg, wParam, lParam); // at the end of BtnProc()
  }
}
