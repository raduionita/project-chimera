#include "win/CHandler.hpp"

namespace win {
  // constructors & operators //
  
  CHandler::CHandler() {  }
  
  CHandler::~CHandler() {  }
  
  bool CHandler::handle(CEvent* pEvent) {
    std::cout << "app::CHandler::handle(CEvent*)::" << this << std::endl;
  
    auto   aCallbacks =& mCallbacks[pEvent->mType];
    bool   bTriggered = aCallbacks->size() != 0; // has handlers
    EEvent eType      = pEvent->mType;
  
    for (auto it = aCallbacks->begin(); it != aCallbacks->end(); ++it) {
      (*it)(pEvent);
    }
    
    // try to remove enqueued event 
    auto it = mEnqueued.find(eType);
    if (it != mEnqueued.end()) {
      _DELETE_(it->second);
      mEnqueued.erase(eType);
    }
  
    // no handlers attached // (replace) mark this event as queued
    if (!bTriggered) {mEnqueued[eType] = pEvent;}
  
    return bTriggered;
  }
  
  bool CHandler::detach(CHandler* pTrigger, EEvent eEvent) {
    std::cout << "win::CHandler::detach(CHandler*, EEvent)::" << this << " NOT IMPLEMENTED" << std::endl;
    return false; 
  }
}
