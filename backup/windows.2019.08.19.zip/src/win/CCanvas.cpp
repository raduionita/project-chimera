#include "win/CCanvas.hpp"

namespace win {
  // constructors and operators //////////////////////////////////////////////////////////////////////////////////////
  
  CCanvas::CCanvas(CWindow* parent, int hints/*=EHint::WINDOW*/) : CPanel() {
    std::cout << "win::CCanvas::CCanvas(parent, hints)::" << this << std::endl;
    init(parent, AUTO, hints);
  }
  
  CCanvas::CCanvas(CWindow* parent, const win::SShape& shape/*=AUTO*/, int hints/*=EHint::WINDOW*/) : CPanel() {
    std::cout << "win::CCanvas::CCanvas(parent, shape, hints)::" << this << std::endl;
    init(parent, shape, hints);
  }
  
  CCanvas::CCanvas(CWindow* parent, CContext* context, const win::SShape& shape/*=AUTO*/, int hints/*=EHint::WINDOW*/) : mContext{context}, CPanel()  {
    std::cout << "win::CCanvas::CCanvas(parent, context, shape, hints)::" << this << std::endl;
    init(parent, shape, hints);
  }
  
  CCanvas::~CCanvas() {
    std::cout << "win::CCanvas::~CCanvas()::" << this << std::endl;
  
    
  }
  
  // main methods ////////////////////////////////////////////////////////////////////////////////////////////////////
  
  bool CCanvas::init(CWindow* parent, const SShape& shape, int hints/*=EHint::WINDOW*/) {
    std::cout << "win::CCanvas::init()::" << this << ":" << mHandle << ":" << mId << std::endl;
    
    // dont want to do
    if (mInited) return mInited;
  
    // DEVMODE dmScreenSettings;                   // Device Mode
    // memset(&dmScreenSettings,0,sizeof(dmScreenSettings));       // Makes Sure Memory's Cleared
    // dmScreenSettings.dmSize=sizeof(dmScreenSettings);       // Size Of The Devmode Structure
    // dmScreenSettings.dmPelsWidth    = width;            // Selected Screen Width
    // dmScreenSettings.dmPelsHeight   = height;           // Selected Screen Height
    // dmScreenSettings.dmBitsPerPel   = bits;             // Selected Bits Per Pixel
    // dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;
    // ::ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
    // ::EnumDisplaySettings()
    
    
    
    
    
    
    
    // set as initialized, so it doesn't enter this logic twice
    mInited = CPanel::init(parent, shape, hints);

    
    
    // if (fullscreen)
      // dwExStyle = WS_EX_APPWINDOW;                  // Window Extended Style
      // dwStyle   = WS_POPUP;                       // Windows Style
      // ShowCursor(FALSE)
    // else 
      // dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;           // Window Extended Style
      // dwStyle=WS_OVERLAPPEDWINDOW;                    // Windows Style
      
    return true;
  }
  
  bool CCanvas::current(CContext* pContext) const {
    ::wglMakeCurrent(::GetDC(mHandle), (HGLRC)*pContext);
  }
}
