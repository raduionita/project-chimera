#include "win/CObject.hpp"

namespace win {
  
  std::atomic<int>   CObject::sId(0);
  CObject::CRegistry CObject::sRegistry;
  
  // constructors and operators //////////////////////////////////////////////////////////////////////////////////////
  
  CObject::CObject() : mId{++sId} {
    std::cout << "win::CObject::CObject(parent, hints)::" << this << std::endl;
    sRegistry.insert(this);
  }
  
  CObject::~CObject() {
    std::cout << "win::CObject::~CObject()::" << this << std::endl;
    sRegistry.remove(this);
  }
  
  CObject::CObject(const CObject& that) : mId{that.mId} {
    std::cout << "win::CObject::CObject(const CObject&)::" << this << std::endl;
  }
  
  CObject& CObject::operator =(const CObject& that) {
    if (this != &that) {
      std::cout << "win::CObject::operator =()::" << this << std::endl;
      // continue
      const_cast<int&>(mId) = that.mId;
    }
    return *this;
  }

  // secodary methods ////////////////////////////////////////////////////////////////////////////////////////////////
  
  inline const int CObject::getId() const {
    return mId;
  }
  
  // registry ///////////////////////////////////////////////////////////////////////////////////////////////////////
  
  CObject::CRegistry::CRegistry() {
    std::cout << "app::CRegistry::CRegistry()" << std::endl;
  }
  
  CObject::CRegistry::~CRegistry() {
    std::cout << "app::CRegistry::~CRegistry()" << std::endl;
    for (auto it = mObjects.begin(); it != mObjects.end(); ++it) {
      auto pObject = *it;
      //std::cout << "   deleting: [" << pObject << "] [" << (*it)->mId << "]" << std::endl;
      (*it) = nullptr;
      delete pObject;
    }
  }
    
  void CObject::CRegistry::insert(CObject* pObject) {
    std::cout << "app::CRegistry::insert(CObject*)::" << pObject << ":" << pObject->mId << std::endl;
    mObjects.push_back(pObject);
  }
  
  // @todo: Find a better way of handling delete/remove object from registry
  void CObject::CRegistry::remove(CObject* pObject) {
    std::cout << "app::CRegistry::remove(CObject*)::" << pObject << ":" << pObject->mId << std::endl;
    for (auto it = mObjects.begin(); it != mObjects.end(); ++it) {
      if (pObject == *it) {
        //std::cout << "   removing: [" << pObject << "] [" << (*it)->mId << "]" << std::endl; 
        delete (*it);
        (*it) = nullptr;
      }
    }
  }
}
