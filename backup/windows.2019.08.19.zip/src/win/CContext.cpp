#include "win/CContext.hpp"

namespace win {
  // constructors & operators //
  
  CContext::CContext(CCanvas* canvas) : CObject(), mCanvas(canvas) {
    std::cout << "win::CContext::CContext()::" << this << ":" << mId << std::endl;
  }
  
  CContext::~CContext() {
    std::cout << "win::CContext::~CContext()::" << this << ":" << mId << std::endl;
    ::wglMakeCurrent(NULL, NULL);
    ::wglDeleteContext(mRC);
    //::ReleaseDC(HWND, HDC);
    //
  }
  
  CContext::operator HGLRC() {
    return mRC;
  }
  
  CContext::operator const HGLRC() const {
    return mRC;
  }
  
  // main methods //
  
  HGLRC CContext::hrc() {
    return mRC;
  }
  
  HDC CContext::hdc() {
    return mDC;
  }
  
  bool CContext::current(CCanvas* pCanvas) const {
    ::wglMakeCurrent(::GetDC((HWND)(*pCanvas)), mRC);
  }
  
  bool CContext::swap() const {
    return ::SwapBuffers(mDC) != FALSE;
  }
}
