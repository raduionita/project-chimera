#include "win/CLayout.hpp"

namespace win {
  bool CLayout::layout(CWindow* pOwner) {
    std::cout << "win::CLayout::layout(CWindow*)::" << this << std::endl;
    mOwner = pOwner;
  
    // get owner shape
    RECT sRect; ::GetClientRect((HWND)(*mOwner), &sRect);
    
    mShape.w = sRect.right; mShape.h = sRect.bottom;
    
    return calc();
  }
  
  SShape CLayout::shape() const {
    return mShape;
  }
  
  bool CLayout::shape(int x, int y, int w, int h) {
    std::cout << "win::CLayout::shape(" << x << "," << y << "," << w << "," << h << ")::" << this << ":" << mId << " " << std::endl;
    mShape.x = x; mShape.y = y; mShape.w = w; mShape.h = h;
    return calc();
  }
  
  bool CLayout::size(int w, int h) {
    mShape.w = w; mShape.h = h;
    return true;
  }
  
  bool CLayout::move(int x, int y) {
    mShape.x = x; mShape.y = y;
    return true;
  }
  
  CLayout::CItem::CItem(int hints/*=0*/) : mHints(hints) {}
   
  CLayout::CItem::~CItem() {
    std::cout << "win::CLayout::CItem::~CItem()::" << this << std::endl;
  }
  
  template <typename T>
  CLayout::TItem<T>::TItem(T item, int hints/*=0*/) : CItem(hints), mItem(item) {}
  
  template <typename T>
  bool CLayout::TItem<T>::size(int w, int h) {
    std::cout << "win::CLayout::TItem<T>::size(" << w << "," << h << ")::" << this << std::endl;
  
    mShape.w = w; mShape.h = h;
    
    return (mHints & EHint::EXPAND) && mItem->size(w, h);
  }
  
  template <typename T>
  bool CLayout::TItem<T>::move(int x, int y) {
    std::cout << "win::CLayout::TItem<T>::move(" << x << "," << y << ")::" << this << std::endl;
    
    auto sShape = mItem->shape();
    
    sShape.x = x + ((mHints & EHint::LEFT) ? 0 : ((mHints & EHint::RIGHT)  ? (mShape.w - sShape.w) : sShape.x - mShape.x));
    sShape.y = y + ((mHints & EHint::TOP)  ? 0 : ((mHints & EHint::BOTTOM) ? (mShape.h - sShape.h) : sShape.y - mShape.y)); 
      
    mShape.x = x;
    mShape.y = y;
    
    return mItem->move(sShape.x, sShape.y);
  }
  
  template <typename T>
  bool CLayout::TItem<T>::shape(int x, int y, int w, int h) {
    std::cout << "win::CLayout::TItem<T>::shape(" << x << "," << y << "," << w << "," << h << ")::" << this << std::endl;
  
    mShape.w = w; mShape.h = h;
  
    auto sShape = mItem->shape();
  
    sShape.x = x + ((mHints & EHint::EXPAND) || (mHints & EHint::LEFT) ? 0 
                                                                       : ((mHints & EHint::RIGHT)  ? (mShape.w - sShape.w) 
                                                                                                   : ((mHints & EHint::CENTERED) ? ((mShape.w/2) - (sShape.w/2)) 
                                                                                                                                 : (sShape.x - mShape.x))));
    sShape.y = y + ((mHints & EHint::EXPAND) || (mHints & EHint::TOP)  ? 0 
                                                                       : ((mHints & EHint::BOTTOM) ? (mShape.h - sShape.h) 
                                                                                                   : ((mHints & EHint::CENTERED) ? ((mShape.h/2) - (sShape.h/2))
                                                                                                                                 : (sShape.y - mShape.y))));
    sShape.w = (mHints & EHint::EXPAND) ? w : sShape.w; 
    sShape.h = (mHints & EHint::EXPAND) ? h : sShape.h; 
    
    mShape.x = x; mShape.y = y;
  
    return mItem->shape(std::max(0,sShape.x), std::max(0,sShape.y), sShape.w, sShape.h);
  }
  
  CBoxLayout::CBoxLayout(EHint orientation/*=EHint::VERTICAL*/) : mOrientation{orientation} {
    std::cout << "win::CBoxLayout::CBoxLayout(hint)::" << this << std::endl;
  }
  
  CBoxLayout::~CBoxLayout() {
    std::cout << "win::CBoxLayout::~CBoxLayout()::" << this << std::endl;
    // std::for_each(mItems.begin(), mItems.end(), [](CItem*& pItem) { delete pItem; pItem = nullptr; });
  }
  
  bool CBoxLayout::calc() {
    std::cout << "win::CBoxLayout::calc()::" << this << " mOrientation:" << mOrientation << " nShape:" << mShape << " mItems:" << mItems.size() << std::endl;
  
    int nItems = (int)(mItems.size());
    
    if (!nItems) { return false; }
    
    // divide it by the number of items
    
    int nItemW = (int)(mShape.w / nItems);
    int nItemH = (int)(mShape.h / nItems);
    int nModW  = (int)(mShape.w % nItems); // @fix extra pixels at the bottom
    int nModH  = (int)(mShape.h % nItems);
    
    // vertical or horizontal
    if (mOrientation == EHint::HORIZONTAL) {
      // for each item 
      int nSumW = 0;
      for (int i = 0; i < nItems; i++) {
        // set new position size using the new shape
        CItem*& pItem = mItems[i];
        int     nOffW = --nModW >= 0 ? 1 : 0;
        // std::cout << "h: " << nSumW + mShape.x << " " << 0 + mShape.y << " " << nItemW + nOffW << " " << mShape.h << std::endl;
        pItem->shape(nSumW + mShape.x, 0 + mShape.y, nItemW + nOffW, mShape.h);
        nSumW += nItemW + nOffW;
      }
    } else {         // EHint::VERTICAL (default)
      int nSumH = 0;
      for (int i = 0; i < nItems; i++) {
        CItem*& pItem = mItems[i];
        int     nOffH = --nModH >= 0 ? 1 : 0;
        // std::cout << "v: " << 0 + mShape.x << " " << nSumH + mShape.y << " " << mShape.w << " " << nItemH + nOffH << std::endl;
        pItem->shape(0 + mShape.x, nSumH + mShape.y, mShape.w, nItemH + nOffH);
        nSumH += nItemH + nOffH;
      }
    }
    
    // confirm that this was calculated
    return true;
  }
  
  bool CBoxLayout::add(CWindow* pWindow, int hints/*=0*/) {
    std::cout << "win::CBoxLayout::add(CWindow*, hints)::" << this << std::endl;
    mItems.push_back(new TItem<CWindow*>(pWindow, hints));
    auto cShape = pWindow->shape();
    mShape.x = std::min(mShape.x, cShape.x);
    mShape.y = std::min(mShape.y, cShape.y);
    mShape.w = std::max(mShape.w, cShape.w);
    mShape.h = std::max(mShape.h, cShape.h);
    return true;
  }
  
  bool CBoxLayout::add(CLayout* pLayout, int hints/*=0*/) {
    std::cout << "win::CBoxLayout::add(CLayout*, hints)::" << this << std::endl;
    mItems.push_back(new TItem<CLayout*>(pLayout, hints | EHint::EXPAND));
    auto cShape = pLayout->shape();
    mShape.x = std::min(mShape.x, cShape.x);
    mShape.y = std::min(mShape.y, cShape.y);
    mShape.w = std::max(mShape.w, cShape.w);
    mShape.h = std::max(mShape.h, cShape.h);
    return true;
  }
}
