#include "win/CTooltip.hpp"

namespace win {
  bool CTooltip::init(CWindow* parent) {
    mHandle = ::CreateWindow(
      TOOLTIPS_CLASS,
      NULL,
      TTS_NOPREFIX,
      CW_USEDEFAULT, CW_USEDEFAULT,
      CW_USEDEFAULT, CW_USEDEFAULT,
      (HWND)(*parent),
      NULL,
      NULL,
      NULL
    );
    
    return false;
  }
}
