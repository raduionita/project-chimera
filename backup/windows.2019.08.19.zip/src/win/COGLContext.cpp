#include "win/COGLContext.hpp"

namespace win {
  // constructors & operators //
  
  COGLContext::COGLContext(CCanvas* pCanvas) : CContext(pCanvas) {
    std::cout << "win::COGLContext::COGLContext()::" << this << ":" << mId << std::endl;
    init();
  }
  
  COGLContext::COGLContext(CCanvas* pCanvas, const SConfig& sConfig) : CContext(pCanvas), mConfig(sConfig) {
    std::cout << "win::COGLContext::COGLContext()::" << this << ":" << mId << std::endl;
    init();
  }
  
  COGLContext::~COGLContext() {
    std::cout << "win::COGLContext::~COGLContext()::" << this << ":" << mId << std::endl;
  }
  
  // main methods //
  
  bool COGLContext::init() {
    PFNWGLCHOOSEPIXELFORMATARBPROC    wglChoosePixelFormatARB = nullptr;
    PFNWGLCREATECONTEXTATTRIBSARBPROC wglCreateContextAttribsARB = nullptr;
    
    {
      WNDCLASS wndcls = {
        style        : CS_HREDRAW | CS_VREDRAW | CS_OWNDC,
        lpfnWndProc  : ::DefDlgProc,
        cbClsExtra   : 0,
        cbWndExtra   : 0,
        hInstance    : (HINSTANCE)NULL,
        hIcon        : (HICON)NULL,
        hCursor      : (HCURSOR)NULL,
        hbrBackground: (HBRUSH)NULL,
        lpszMenuName : NULL,
        lpszClassName: "DummyOpenGLContexWindow"
      };
      
      if (!::RegisterClass(&wndcls)) {
        ::MessageBox(NULL, "[COGLContext] RegisterClass failed!", "Error", 0);
        return false;
      }
      
      HWND hWnd = ::CreateWindow(
        wndcls.lpszClassName,
        "DummyOpenGLContexWindow",
        0,
        0,0,1,1,
        NULL,NULL,
        wndcls.hInstance,
        NULL
      );
      
      HDC     hDC   = ::GetDC(hWnd);
      HGLRC   hRC   = NULL;
      BOOL    bSet  = FALSE;
      WINBOOL nCur  = FALSE;
      int     nPFId = 0;
      PFD     sPFD  = {
        sizeof(PFD),
        1,                                                          // Version Number
        PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, // support: window + opengl + dbl. buffering
        PFD_TYPE_RGBA,                                              // Request An RGBA Format
        32,                                                         // colorbuffer bits
        0, 0, 0, 0, 0, 0,                                           // Color Bits Ignored
        0,                                                          // No Alpha Buffer
        0,                                                          // Shift Bit Ignored
        0,                                                          // No Accumulation Buffer
        0, 0, 0, 0,                                                 // accumulation Bits Ignored
        24,                                                         // depthbuffer
        8,                                                          // stencilbuffer
        0,                                                          // aux framebuffer.
        PFD_MAIN_PLANE,                                             // main Drawing Layer
        0,                                                          // reserved
        0, 0, 0                                                     // layer Masks Ignored
      };
  
      if ((nPFId = ::ChoosePixelFormat(hDC, &sPFD)) == 0) {
        ::MessageBox(NULL, "[COGLContext] Failed to get pixel format!", "Error", 0);
        return false;
      }
  
      if ((bSet = ::SetPixelFormat(hDC, nPFId, &sPFD)) == FALSE) {
        ::MessageBox(NULL, "[COGLContext] Failed to set pixel format(1)!", "Error", 0);
        return false;
      }
      
      // << 'till here is the canvas part
      
      // @todo split these
      
      // >> here starts the context part
  
      if ((hRC = ::wglCreateContext(hDC)) == 0) {
        ::MessageBox(NULL, "[COGLContext] Failed to create context!", "Error", 0);
        return false;
      }
  
      if ((nCur = ::wglMakeCurrent(hDC, hRC)) == FALSE) {
        ::MessageBox(NULL, "[COGLContext] Failed to make current(1)!", "Error", 0);
        return false;
      }
  
      if ((wglChoosePixelFormatARB = reinterpret_cast<PFNWGLCHOOSEPIXELFORMATARBPROC>(wglGetProcAddress("wglChoosePixelFormatARB"))) ==  nullptr) {
        ::MessageBox(NULL, "[COGLContext] Failed wglGetProcAddress('wglChoosePixelFormatARB')!", "Error", 0);
        return false;
      }
  
      if ((wglCreateContextAttribsARB = reinterpret_cast<PFNWGLCREATECONTEXTATTRIBSARBPROC>(wglGetProcAddress("wglCreateContextAttribsARB"))) == nullptr) {
        ::MessageBox(NULL, "[COGLContext] Failed wglGetProcAddress('wglCreateContextAttribsARB')!", "Error", 0);
        return false;
      }
      
      ::wglMakeCurrent(hDC, NULL);
      ::wglDeleteContext(hRC);
      ::ReleaseDC(hWnd, hDC);
      ::DestroyWindow(hWnd);
      ::UnregisterClass(wndcls.lpszClassName, NULL/*(HINSTANCE)(*uix::app)*/);
    } // dummy
  
    {
      BOOL bFound      = FALSE;
      BOOL bSet        = FALSE;
      WINBOOL nCur     = FALSE;
      int  nPFId       = -1;
      UINT nNumFormats = 0;
      HDC  hDC = mDC   = mCanvas->hdc();
      int  aPixAttrs[] = {
        WGL_DRAW_TO_WINDOW_ARB,        GL_TRUE,
        WGL_SUPPORT_OPENGL_ARB,        GL_TRUE,
        WGL_DOUBLE_BUFFER_ARB,         GL_TRUE,
        WGL_PIXEL_TYPE_ARB,            WGL_TYPE_RGBA_ARB,
        WGL_ACCELERATION_ARB,          WGL_FULL_ACCELERATION_ARB,
        WGL_COLOR_BITS_ARB,            32,
        WGL_ALPHA_BITS_ARB,             8,
        WGL_DEPTH_BITS_ARB,            24,
        WGL_STENCIL_BITS_ARB,           8,
        WGL_SAMPLE_BUFFERS_ARB,        GL_TRUE,
        WGL_SAMPLES_ARB,                4,
        0
      };
      
      if ((bFound = wglChoosePixelFormatARB(hDC, aPixAttrs, NULL, 1, &nPFId, &nNumFormats)) == FALSE || nNumFormats == 0) {
        ::MessageBox(NULL, "[COGLContext] Failed wglCreateContextAttribsARB()!", "Error", 0);
        return false;
      }
  
      PFD sPFD;
      
      if ((bFound = ::DescribePixelFormat(hDC, nPFId, sizeof(sPFD), &sPFD) == FALSE)) {
        ::MessageBox(NULL, "[COGLContext] Failed to describe pixel format!", "Error", 0);
        return false;
      }
  
      if ((bSet = ::SetPixelFormat(hDC, nPFId, &sPFD) == FALSE)) {
        std::cout << ::GetLastErrorString() << std::endl;
        ::MessageBox(NULL, "[COGLContext] Failed to set pixel format(2)!", "Error", 0);
        return false;
      }
  
      int  aContextAttrs[] = {
        WGL_CONTEXT_MAJOR_VERSION_ARB, 4,
        WGL_CONTEXT_MINOR_VERSION_ARB, 4,
        WGL_CONTEXT_PROFILE_MASK_ARB,  WGL_CONTEXT_CORE_PROFILE_BIT_ARB,
        //WGL_CONTEXT_FLAGS_ARB, WGL_CONTEXT_DEBUG_BIT_ARB,
        0
      };
  
      if ((mRC = wglCreateContextAttribsARB(hDC, 0, aContextAttrs)) == NULL) {
        std::cout << ::GetLastErrorString() << std::endl;
        ::MessageBox(NULL, "[COGLContext] Failed to create ARB context!", "Error", 0);
        return false;
      }
  
      if ((nCur = ::wglMakeCurrent(hDC, mRC)) == FALSE) {
        ::MessageBox(NULL, "[COGLContext] Failed to make current(2)!", "Error", 0);
        return false;
      }
    } // real
    
    //::SetForegroundWindow()
    
    return true;
  }
}
