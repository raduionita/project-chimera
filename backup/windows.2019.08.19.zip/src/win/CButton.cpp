#include "win/CButton.hpp"

namespace win {
  // statics //  ///////////////////////////////////////////////////////////////////////////////////////////////////// 
  
  WNDPROC CButton::prev;
  
  // constructors and operators //  //////////////////////////////////////////////////////////////////////////////////
  
  CButton::CButton(CWindow* parent, CString text, int hints)
  : CButton(parent, text, AUTO, hints) {
    std::cout << "win::CButton::CButton(parent, text, hints)::" << this << std::endl;
  }
  
  CButton::CButton(CWindow* parent, CString text, const win::SShape& shape/*=AUTO*/, int hints/*=EHint::NONE*/)  
  : CControl(), mText(text) {
    std::cout << "win::CButton::CButton(parent, text, shape, hints)::" << this << std::endl;
    init(parent, shape, hints);
  }
  
  CButton::~CButton() {
    std::cout << "win::CButton::CButton()::" << this << std::endl;
  }
  
  // main metthods //  ///////////////////////////////////////////////////////////////////////////////////////////////
  
  bool CButton::init(CWindow* parent, const SShape& shape, int hints) {
    std::cout << "win::CButton::init()::" << this << ":" << mHandle << ":" << mId << std::endl;
  
    // dont want to do
    if (mInited) return mInited;
    // set as initialized, so it doesn't enter this logic twice
    mInited = CControl::init(parent, shape, hints);

    if (mParent == nullptr) {
      ::MessageBox(NULL, "[CButton] No parent no button!!", "Error", 0);
      return false;
    }

    // @todo Consider replacing "Button" with e regular (customizable) (registerable) window class

    mHandle = ::CreateWindowEx(
      0,                                   // DWORD  dwExStyle
      WC_BUTTON,                            // LPCSTR lpClassName
      mText.c_str(),                       // LPCSTR lpWindowName
      WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, // | BS_NOTIFY, // styles: BS_OWNERDRAW
      mShape.x, mShape.y,                  // int, int x, y
      mShape.w, mShape.h,                  // int, int w, h
      (HWND)(*mParent),                    // HWND hWndParent // parent handle
      NULL,                                // HMENU hMenu // or (for non-top-level) child-window id (16bit)
      NULL,/*(HINSTANCE)(*uix::app)*/      // HINSTANCE hInstance // ::GetWindowLong((HWND)(*mParent), GWL_HINSTANCE);
      this                                 // LPVOID lpParam // 
    );

    if (mHandle == NULL) {
      std::cout << "[CButton] RegisterClassEx failed!" << std::endl;
      ::MessageBox(NULL, "[CButton] CreateWindowEx failed!", "Error", 0);
      return false;
    }  // @todo trigger error event

    prev = (WNDPROC) ::SetWindowLongPtr(mHandle, GWLP_WNDPROC,  (LONG_PTR)(&proc)); // (this) requires:
    /* LONG_PTR = */ ::SetWindowLongPtr(mHandle, GWLP_USERDATA, (LONG_PTR)(this));

    ::SendMessage(mHandle, CM_INIT, 0, 0);
  
    ::SetDefaultFont(mHandle);
    
    return mInited;
  }
  
  // static metthods //  /////////////////////////////////////////////////////////////////////////////////////////////
  
  LRESULT CALLBACK CButton::proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) { // (void*, uint, uint*, long*)
    switch (uMsg) {
    //case WM_NCCREATE: // not fired cause ::SetWindowLongPtr is after ::CreateWindowEx
    //case WM_CREATE:   // not fired cause ::SetWindowLongPtr is after ::CreateWindowEx
    //case WM_MOUSEHOVER:
    //case WM_MOUSELEAVE: // requires ::TrackMouseEvent(TRACKMOUSEEVENT)
    //case WM_MOUSEMOVE:  
    //case WM_SETCURSOR: {
    //   CButton* pButton = reinterpret_cast<CButton*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
    //   std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pButton  << ":B:WM_SETCURSOR:" << HIWORD(wParam) << ":" << LOWORD(wParam) << ":" << lParam << std::endl;
    //   (LOWORD(lParam) == HTCLIENT) && ::SetCursor(::LoadCursor(NULL, IDC_ARROW));
    //   return 0;
    // }
      case WM_LBUTTONDOWN: {
        CWindow* pButton = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pButton  << ":B:WM_LBUTTONDOWN:" << wParam << " x=" << LOWORD(lParam) << " y=" << HIWORD(lParam) << std::endl;
  
        _BREAK_(!pButton);
  
        auto pEvent       = new CMouseEvent(EEvent::LBUTTONDOWN, pButton);
        pEvent->mClientX  = GET_X_LPARAM(lParam);
        pEvent->mClientY  = GET_Y_LPARAM(lParam);
        pEvent->mModifier = (EModifier)(wParam);
        
        if (pButton->handle(pEvent)) {_DELETE_(pEvent);}
        
        break;
      }
      default: break;
    }
    return ::CallWindowProc(CButton::prev, hWnd,  uMsg, wParam, lParam); // at the end of BtnProc()
  }
}
