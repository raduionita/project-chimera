#include "win/CFrame.hpp"

namespace win {
  // constructors and operators //  //////////////////////////////////////////////////////////////////////////////////
  
  CFrame::CFrame(int hints) 
  : CFrame(nullptr, "", AUTO, hints) {
    std::cout << "win::CFrame::CFrame(hints)::" << this << std::endl;
  }
  
  CFrame::CFrame(const SShape& shape, int hints/*=EHint::WINDOW*/) 
  : CFrame(nullptr, "", shape, hints) {
    std::cout << "win::CFrame::CFrame(shape, hints)::" << this << std::endl;
  }
  
  CFrame::CFrame(const CString& title,const SShape& shape/*=AUTO*/, int hints/*=EHint::WINDOW*/) 
  : CFrame(nullptr, title, shape, hints) {
    std::cout << "win::CFrame::CFrame(title, shape, hints)::" << this << std::endl;
  }
  
  CFrame::CFrame(CWindow* parent, const win::CString& title/*=""*/, const SShape& shape/*=AUTO*/, int hints/*=EHint::WINDOW*/) 
  : CWindow(), mTitle{title} {
    std::cout << "win::CFrame::CFrame(parent, title, shape, hints)::" << this << std::endl;
    init(parent, shape, hints | EHint::WINDOW);
  }
  
  CFrame::~CFrame() {
    std::cout << "win::CFrame::~CFrame()::" << this << std::endl;
  }
  
  // main methods //  ////////////////////////////////////////////////////////////////////////////////////////////////
    
  bool CFrame::init(CWindow* parent, const CString& title, const SShape& shape, int hints/*=EHint::WINDOW*/) {
    mTitle = title;
    return CFrame::init(parent, shape, hints);
  }
  
  bool CFrame::init(CWindow* parent, const SShape& shape, int hints/*=EHint::WINDOW*/) {
    std::cout << "win::CFrame::init()::" << this << ":" << mHandle << ":" << mId << std::endl;
  
    // set as initialized, so it doesn't enter this logic twice
    if (mInited) return mInited; 
    
    mInited = CWindow::init(parent, shape, hints | EHint::WINDOW);
    
    // @todo Move this // WNDCLASSEX is common to most windows - no need for new WNDCLASSEX for every window
    WNDCLASSEX wndcls = {
      sizeof(WNDCLASSEX),                  // UINT      // cbSize        // struct size  
      CS_HREDRAW | CS_VREDRAW,             // UINT      // style
      CWindow::proc,                       // WNDPROC   // lpfnWndProc   // uix::CWidget::proc
      0,                                   // int       // cbClsExtra    // no extra bytes after the window class
      0,                                   // int       // cbWndExtra    // structure or the window instance
      NULL,/*(HINSTANCE)(*uix::app)*/      // HINSTANCE // hInstance     // to identify the dll that loads this module 
      ::LoadIcon(NULL, IDI_APPLICATION),   // HICON     // hIcon
      ::LoadCursor(NULL, IDC_ARROW),       // HCURSOR   // hCursor
      (HBRUSH)NULL_BRUSH,                  // HBRUSH    // hbrBackground
      NULL,                                // LPCTSTR   // lpszMenuName  // no menu
      name().c_str(),                   // LPCTSTR   // lpszClassName
      ::LoadIcon(NULL, IDI_APPLICATION)    // HICON     // hIconSm
    };
    
    // @todo trigger error event
    if (!::RegisterClassEx(&wndcls)) {
      std::cout << "[CFrame] RegisterClassEx failed!" << std::endl;
      ::MessageBox(NULL, "[CFrame] RegisterClassEx failed!", "Error", MB_OK);
      return false;
    }
    
    // default window styles
    DWORD dwExStyle = 0;
    DWORD dwStyle   = 0;
//  dwStyle |= mHints & EHint::BORDER   ? WS_BORDER      : 0;
    dwStyle |= mHints & EHint::TITLE    ? WS_CAPTION                 : 0;
    dwStyle |= mHints & EHint::FRAME    ? WS_THICKFRAME | WS_SIZEBOX : 0;
    dwStyle |= mHints & EHint::SYSMENU  ? WS_SYSMENU                 : 0;
    dwStyle |= mHints & EHint::MINBOX   ? WS_MINIMIZEBOX             : 0;
    dwStyle |= mHints & EHint::MAXBOX   ? WS_MAXIMIZEBOX             : 0;
    dwStyle |= mHints & EHint::HSCROLL  ? WS_HSCROLL                 : 0;
    dwStyle |= mHints & EHint::VSCROLL  ? WS_VSCROLL                 : 0;
//  dwStyle |= mHints & EHint::MINIMIZE ? WS_MINIMIZE                : 0;
//  dwStyle |= mHints & EHint::MAXIMIZE ? WS_MAXIMIZE                : 0;
//  dwStyle |= mHints & EHint::VISIBLE  ? WS_VISIBLE                 : 0; // show immediatlly
    dwStyle |= WS_CLIPCHILDREN;   // (dont draw on child area)
    
    // create window/handle
    mHandle = ::CreateWindowEx(
      dwExStyle,                                          // DWORD // ex. style (0 = default)
      wndcls.lpszClassName,                               // LPCSTR window class name
      mTitle.c_str(),                                     // LPCSTR window title name
      dwStyle,                                            // DWORD // style
      CW_USEDEFAULT, CW_USEDEFAULT,                       // (x, y) 
      CW_USEDEFAULT, CW_USEDEFAULT,                       // (width, height)
      mParent ? (HWND)(*mParent) : NULL,                  // HWND parent handle
      NULL,                                               // HMENU menu handle
      wndcls.hInstance,                                   // HINSTANCE application handle
      this                                                // LPVOID additional app data (@see WM_CREATE)
    );
    
    // what if there were probles
    if (mHandle == NULL) {
      ::MessageBox(NULL, "[CFrame] CreateWindowEx failed!", "Error", MB_OK);
      return false;
    } // @todo trigger error event

    // add class pointer to handle's user-data // @see CWindow::proc() 
    ::SetWindowLongPtr(mHandle, GWLP_USERDATA, (LONG_PTR)(this));
    // reset icon handle 
  //::SetWindowLongPtr(mHandle, GCLP_HICON, ); set icon OR ::SendMessage(mHandle, (UINT)WM_SETICON, ICON_BIG, (LPARAM)icon);
    // reset default window styles
    ::SetWindowLong(mHandle, GWL_STYLE,   dwStyle);
    ::SetWindowLong(mHandle, GWL_EXSTYLE, dwExStyle);
    
    // move|size only if not auto shape 
    (mHints & EHint::AUTOXY) || move(mShape.x, mShape.y);
    (mHints & EHint::AUTOWH) || size(mShape.w, mShape.h);
    // try to center window if the hint was set
    (mHints & EHint::CENTERED) && center();
    // set window max|min states
    (mHints & EHint::MAXIMIZE) && maximize();
    (mHints & EHint::MINIMIZE) && minimize();
    // set window visibility state
    (mHints & EHint::VISIBLE) && show();
    
    // debug // enumerates the children of this window (handle)
    ::EnumChildWindows(mHandle, [] (HWND hChild, LPARAM) -> BOOL {
      std::cout << hChild << "::child" << std::endl;
      return TRUE;
    } , 0);
  
    // trigger child class init event handler
    ::SendMessage(mHandle, CM_INIT, 0, 0);
    // done
    return mInited;
  }
  
  // secondary methods //  ///////////////////////////////////////////////////////////////////////////////////////////
}
