#include <win/CEvent.hpp>
#include "win/CWindow.hpp"

namespace win {
  // constructors and operators //  //////////////////////////////////////////////////////////////////////////////////
  
  CWindow::~CWindow() {
    std::cout << "uix::CWindow::~CWindow()::" << this << std::endl;
    free();
  }
  
  CWindow::CWindow(const CWindow& that) {
    std::cout << "win::CWindow::CWindow(const CWindow&)::" << this << std::endl;
    mHandle = that.mHandle;
    mParent = that.mParent;
    mInited = that.mInited;
    mState  = that.mState;
  }
  
  CWindow& CWindow::operator =(const CWindow& that) {
    std::cout << "win::CWindow::operator =(const CWindow&)::" << this << std::endl;
    if (this != &that) {
      CObject::operator =(that);
      // continue
      mHandle = that.mHandle;
      mParent = that.mParent;
      mInited = that.mInited;
      mState  = that.mState;
    }
    return *this;
  }
  
  CWindow::operator HWND() {
    return mHandle;
  }
  
  CWindow::operator const HWND() const {
    return mHandle;
  }
  
  // main metthods //  ///////////////////////////////////////////////////////////////////////////////////////////////
  
  bool CWindow::init(CWindow* parent, const SShape& sShape, int nHints) {
    std::cout << "win::CWindow::init()::" << this << std::endl;
  
    if (mInited) return mInited;
    
    mParent = parent;
    mShape  = sShape;
    mHints  = nHints;
    mHints |= mShape.x  == AUTO ? EHint::AUTOX : 0;
    mHints |= mShape.y  == AUTO ? EHint::AUTOY : 0;
    mHints |= mShape.w  == AUTO ? EHint::AUTOW : 0;
    mHints |= mShape.h  == AUTO ? EHint::AUTOH : 0;
    
    return true;
  }
  
  bool CWindow::free() { // can not be overriden
    // @todo Move unregister class to a WndClassManager
    std::cout << "win::CWindow::free()::" << this << std::endl;
    // let custom window do something
    onFree();
    // delete children
    std::for_each(mChildren.begin(), mChildren.end(), [](CWindow*& pChild){ delete pChild; pChild = nullptr; });
    // release 
    ::ReleaseDC(mHandle, ::GetDC(mHandle));
    // delete hadnle
    ::DestroyWindow(mHandle);
    // unregister
    ::UnregisterClass(name().c_str(), NULL/*(HINSTANCE)(*uix::app)*/);
    // clear everything
    mHandle = NULL;
    mInited = false;
    return !mInited;
  }
  
  bool CWindow::show(bool show/*=true*/) {
    std::cout << "win::CWindow::show("<< show <<")::" << this << ":" << mId << std::endl;
    // show window, only if mInited
    return mInited && ::ShowWindow(mHandle, show?SW_SHOW:SW_HIDE); // && (bool)::UpdateWindow(mHandle);
    // ::InvalidateRect(mHandle, NULL, FALSE);
    
    // @todo show the children
  }
  
  bool CWindow::hide(bool hide/* = true*/) {
    std::cout << "win::CWindow::hide("<< hide <<")::" << this << ":" << mId << std::endl;
    // show window, only if mInited
    return mInited && ::ShowWindow(mHandle, hide?SW_HIDE:SW_SHOW); // && (bool)::UpdateWindow(mHandle);
    // @todo hide the children
  }
  
  bool CWindow::move(int x, int y) {
    std::cout << "win::CWindow::move(" << x << "," << y << ")::" << this << ":" << mId << " " << mState << std::endl;
    if (!mInited) return false;
    // need the styles for correct window shape adjustment
    DWORD dwExStyle = (DWORD)::GetWindowLong(mHandle, GWL_EXSTYLE);
    DWORD dwStyle   = (DWORD)::GetWindowLong(mHandle, GWL_STYLE);
    RECT sRect      = {x, y, 0, 0};
    // compute adjusted shape based on window styles
    ::AdjustWindowRectEx(&sRect, dwStyle, FALSE, dwExStyle);
    // use the values
    x = sRect.left;
    // set position & size | BUT not if window in maximized state
    return !(mState & EState::MAXIMIZED) && (::SetWindowPos(mHandle, NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE));
  }
  
  bool CWindow::size(int w, int h) {
    std::cout << "win::CWindow::size(" << w << "," << h << ")::" << this << ":" << mId << std::endl;
    if (!mInited) return false;
    // need the styles for correct window shape adjustment
    DWORD dwExStyle = (DWORD)::GetWindowLong(mHandle, GWL_EXSTYLE);
    DWORD dwStyle   = (DWORD)::GetWindowLong(mHandle, GWL_STYLE);
    HWND  hParent   = hasParent() ? (HWND)(getParent()) : ::GetDesktopWindow();
    RECT  sPRect    = {0};
    RECT  sWRect    = {0, 0, w, h};
    // compute adjusted shape based on window styles
    ::GetClientRect(hParent, &sPRect); // client coords (no header)
    ::AdjustWindowRectEx(&sWRect, dwStyle, FALSE, dwExStyle);
    // use the values
    w = sWRect.right - sWRect.left; h = sWRect.bottom - sWRect.top;
    // set position & size | BUT not if window in maximized state
    return !(mState & EState::MAXIMIZED) && (::SetWindowPos(mHandle, NULL, 0, 0, w, h, SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE));
  }
  
  SSize CWindow::size() const {
    RECT sRect = {};
    ::GetClientRect(mHandle, &sRect);
    return {sRect.right, sRect.bottom};
  }
  
  bool CWindow::shape(int x, int y, int w, int h) {
    std::cout << "win::CWindow::shape(" << x << "," << y << "," << w << "," << h << ")::" << this << ":" << mId << std::endl;
    if (!mInited)  return false;
    // need the styles for correct window shape adjustment
    DWORD dwExStyle = (DWORD)::GetWindowLong(mHandle, GWL_EXSTYLE);
    DWORD dwStyle   = (DWORD)::GetWindowLong(mHandle, GWL_STYLE);
    RECT sRect      = {x, y, w, h};
    // compute adjusted shape based on window styles
    ::AdjustWindowRectEx(&sRect, dwStyle, FALSE, dwExStyle);
    // use these new values
    x = sRect.left; y = sRect.top; w = sRect.right; h = sRect.bottom;
    // set position & size | BUT not if window in maximized state
    return !(mState & EState::MAXIMIZED) && (::SetWindowPos(mHandle, NULL, x, y, w, h, SWP_NOZORDER | SWP_NOACTIVATE));
  }
  
  SShape CWindow::shape() const {
    RECT sRect;
    ::GetClientRect(mHandle, &sRect); // w, h
    ::MapWindowPoints(mHandle, (HWND)(*mParent), (LPPOINT)(&sRect), 2);
    return {sRect.left, sRect.top, sRect.right - sRect.left, sRect.bottom - sRect.top}; 
  }
  
  bool CWindow::center() {
    std::cout << "win::CWindow::center()::" << this << ":" << mId;
    
    _RETURN_(!mInited,false);
    
    HWND hWnd = mParent == nullptr ? ::GetDesktopWindow() : mParent->mHandle;
    RECT sPRect, sWRect;
    SPoint sPoint;
    ::GetClientRect(hWnd, &sPRect); // client coords (no header)
    ::GetClientRect(mHandle, &sWRect);
    //::GetWindowRect(mHandle, &sRect) // screen coords

    sPoint.x = (sPRect.right/2)  - (sWRect.right/2);
    sPoint.y = (sPRect.bottom/2) - (sWRect.bottom/2);

    // std::cout << " point=" << sPoint << std::endl;
    
    // move to new positions
    return move(sPoint.x, sPoint.y);
  }
  
  bool CWindow::maximize() {
    std::cout << "win::CWindow::maximize()::" << this << ":" << mId << std::endl;
    if (mInited) {
      (mState |= EState::MAXIMIZED) && ::ShowWindow(mHandle, SW_MAXIMIZE);
    }
  }
  
  bool CWindow::minimize() {
    std::cout << "win::CWindow::minimize()::" << this << ":" << mId << std::endl;
    if (mInited) {
      (mState |= EState::MINIMIZED) && ::ShowWindow(mHandle, SW_MINIMIZE);
    }
  }
  
  bool CWindow::pack() {
    // @todo: for each child pack
    // @todo: eliminate this's empty space by reading children shapes
    // @todo: update mShape
  
    return true;
  }
  
  bool CWindow::front() {
    return (bool)::BringWindowToTop(mHandle);
  }
  
  // event handlers //  //////////////////////////////////////////////////////////////////////////////////////////////
  
  void CWindow::onInit() {
    
  }
  
  void CWindow::onFree() {
    
  }
  
  // secondary methods //  ///////////////////////////////////////////////////////////////////////////////////////////
  
  CTooltip* CWindow::tooltip(const CString& text) {
    delete mTooltip;
    // @todo finish tooltip
    // mTooltip = new CTooltip(text);
    // mTooltip->text(text);
    return mTooltip;
  }
  
  CStyle* CWindow::getStyle() const {
    return mStyle;
  }
  
  bool    CWindow::setStyle(CStyle* pStyle) {
    delete mStyle;
    mStyle = pStyle;
    return mStyle != nullptr;
  }
  
  bool CWindow::setLayout(CLayout* pLayout) { mLayout = pLayout; return mLayout->layout(this); }
  
  bool CWindow::setParent(CWindow* pParent) { mParent = pParent; return hasParent(); }
  
  
  HDC CWindow::hdc() const { return ::GetDC(mHandle); }
  
  HWND CWindow::hwnd() { return mHandle; }
  
  inline CString CWindow::name() const {
    return (T("winCWindow") + T(mId));
  }
  
  void CWindow::child(CWindow* pChild) {
    std::cout << "win::CWindow::child()::" << this << std::endl;
    mChildren.push_back(pChild);
  }
  
  int CWindow::hints() const {
    return mHints;
  }
  
  // static methods //  //////////////////////////////////////////////////////////////////////////////////////////////
  
  CWindow* CWindow::find(const CString& name) {
    CWindow* found = nullptr;
    HWND hWnd = ::FindWindow(NULL, name.c_str());
    found = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
    return found;
  }
  
  // special methods //  /////////////////////////////////////////////////////////////////////////////////////////////
  
  LRESULT CALLBACK CWindow::proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) { // (void*, uint, uint*, long*)
    // @todo: new event on each propagation w/ mOriginal event field
    switch (uMsg) {
      case WM_NCCREATE: { // non-client (frame) create
        // !!! pWindow NOT available
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << 0 << ":W:WM_NCCREATE:" << wParam << ":" << lParam << std::endl;
        break;
      }
      case WM_CREATE: { // called on ::CreateWindow()
        // !!! pWindow NOT available
        // use this if you want to access CWindow during WM_CREATE
        // added CWindow pointer as user data, to be retrieved on other events
        // CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
        // CWindow* pWindow = reinterpret_cast<CWindow*>(pCreate->lpCreateParams);
        // ::SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)(pWindow));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << 0 << ":W:WM_CREATE:" << wParam << ":" << lParam << std::endl;
        return 0; // return 0=OK -1=Fail
      }
      case WM_NOTIFY: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_NOTIFY:" << wParam << ":" << lParam << std::endl;
        LPNMHDR sNMHDR = (LPNMHDR)lParam;
        switch (sNMHDR->code) {
          case TCN_SELCHANGE: {
            CWindow* pTabbed = reinterpret_cast<CWindow*>(::GetWindowLongPtr(sNMHDR->hwndFrom, GWLP_USERDATA));
            // @see TabCtrl_GetCurSel(hWnd);
            int iPage = (int)::SendMessage(sNMHDR->hwndFrom, TCM_GETCURSEL, 0, 0);
            std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pTabbed  << ":T:TCN_SELCHANGE:" << "page=" << iPage << std::endl;
            ::SendMessage(sNMHDR->hwndFrom, CM_TABCHANGE, 0, LPARAM(iPage));
            return 0;
          }
          default: break;
        }
        break;
      }
      case WM_INITDIALOG: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_INITDIALOG:" << wParam << ":" << lParam << std::endl;
        break;
      }
      case CM_INIT: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:CM_INIT:" << wParam << ":" << lParam << std::endl;
        return 0;
      }
      case WM_CLOSE: { // called on [x] or window menu [Close] // triggers: WM_DESTROY
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_CLOSE:" << wParam << ":" << lParam << std::endl;
        
        auto pEvent = new CCloseEvent(pWindow);
        
        bool bHandled = pWindow->handle(pEvent);
        
        bool bExiting = !pWindow->hasParent();
        
        if (bExiting) ::PostQuitMessage(0); // sends WM_QUIT message to the loop - indicating that it should be stopped
        
        if (bHandled) {_DELETE_(pEvent); return 0;}// should no reach if ::PostQuitMessage()
        
        break;
      }
      case WM_ACTIVATE: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_ACTIVATE:" << wParam << ":" << lParam << std::endl;
        break;
      }
      case WM_DESTROY: { // called on window destroy (after WM_CLOSE) (this can't be stopped) // do cleanup
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_DESTROY:" << wParam << ":" << lParam << std::endl;
        break;
      }
      case WM_SETFOCUS: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_SETFOCUS:" << wParam << ":" << lParam << std::endl;
        
        auto pEvent = new CEvent(EEvent::FOCUS, pWindow);
        
        if (pWindow->handle(pEvent)) {_DELETE_(pEvent); return 0;}
        
        break;
      }
      case WM_KILLFOCUS: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_KILLFOCUS:" << wParam << ":" << lParam << std::endl;
        break;
      }
      case WM_SHOWWINDOW: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_SHOWWINDOW:" << wParam << ":" << lParam << std::endl;
        
        _BREAK_(!pWindow);
  
        CEvent* pEvent = new CEvent(EEvent::SHOW, pWindow);
  
        if (pWindow->handle(pEvent)) {_DELETE_(pEvent); return 0;}
        
        // wParam: TRUE  (show)
        //         FALSE (hide)
        // lParam: 4 SW_OTHERUNZOOM   (uncovered 'cause a window was maximize or minimize)
        //         2 SW_OTHERZOOM     (covered by another that was maximized)
        //         1 SW_PARENTCLOSING (parent is being minimized)
        //         0 SW_PARENTOPENING (parent is being maximized)
        break;
      }
    //case WM_DRAWITEM: 
        // wParam : ID of the control that sent the message; 0 for menu
        // lParam : pointer to DRAWITEMSTRUCT
      case WM_COMMAND: {  // menu selection
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_COMMAND:" << HIWORD(wParam) << ":" << (HWND)(lParam) << std::endl;
    
        auto pEvent = new CCommandEvent(EEvent::COMMAND, pWindow);
        pEvent->mControl = reinterpret_cast<CControl*>(::GetWindowLongPtr((HWND)(lParam), GWLP_USERDATA));
        pEvent->mState   = HIWORD(wParam);
  
        bool bTriggered   = pWindow->handle(pEvent);
  
        while (pEvent->doPropagation() && pWindow->hasParent()) {
          pWindow    = pWindow->getParent();
          bTriggered = pWindow->handle(pEvent) && bTriggered;
        }
  
        if (bTriggered) {_DELETE_(pEvent); return 0;}
        
        // bool bHandled = false;
        // bool bIsNull  = false;
        // CCommandEvent* pEvent = new CCommandEvent(HIWORD(wParam));
        // pEvent->mControl = pButton;
        // pEvent->mTarget  = pWindow;
        // do {
        //   bIsNull  = pWindow == nullptr;
        //   bHandled = bIsNull || pWindow->onCommand(pEvent);
        //   pWindow  = !bIsNull ? pWindow->mParent : nullptr;
        // } while (!bHandled);
        // delete pEvent;
    
        // HIWORD(wParam) : 0 BN_CLICKED                  // clicked
        //                  5 BN_DBLCLK BN_DOUBLECLICKED  // double clck
        //                  4 BN_DISABLE                  // is disabled
        //                  1 BN_PUSHED BN_HILITE         // pushed  | button down!?
        //                  2 BN_UNPUSHED BN_UNHILITE     // release | button up!?
        //                  1 BN_PAINT                    // button should be painter
        //                  6 BN_SETFOCUS                 // keyboard focus
        //                  7 BN_KILLFOCUS                // left keyboard focus
        // LOWORD(wParam) : button id
        // lParam         : button hwnd
        break;
      }
    //case WM_MOVING: {
      //  CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
      //  std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_MOVING:" << wParam << ":" << lParam << std::endl;
      //}
      case WM_MOVE: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_MOVE:" << " x=" << LOWORD(lParam) << " y=" << HIWORD(lParam) << std::endl;
        // lParam: x: (int)(short) LOWORD(lParam)
        //         y: (int)(short) HIWORD(lParam)
        // wParam (no used)
      }
    //case WM_SIZING: {   // while size has changed
        // CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        // std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow  << ":W:WM_SIZING:" << wParam << ":" << lParam << std::endl;
        // @todo
        // CResizeEvent* pEvent = new CResizeEvent;
        // pWindow->onSizing(pEvent);
        // delete pEvent;
    
        // wParam: 8 WMSZ_BOTTOMRIGHT (edge of the window being sized)
        //         7 WMSZ_BOTTOMLEFT
        //         6 WMSZ_BOTTOM
        //         5 WMSZ_TOPRIGHT
        //         4 WMSZ_TOPLEFT
        //         3 WMSZ_TOP
        //         2 WMSZ_RIGHT
        //         1 WMSZ_LEFT
        // lParam: LRECT (w/ screen coord of the drag rect) (change this rect to change drag rect)
        // break;
      // }
      case WM_SIZE: {     // after size has changed
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_SIZE:" << wParam << " w=" << LOWORD(lParam) << " h=" << HIWORD(lParam) << std::endl;
        
        _BREAK_(!pWindow);
        
        // set window's state
        EState eState   = (wParam == SIZE_MAXSHOW) ? EState::MAXIMIZED : (wParam == SIZE_MINIMIZED ? EState::MINIMIZED : EState::_STATE_);
        pWindow->mState = (pWindow->mState & ~EState::MAXIMIZED & ~EState::MINIMIZED) | eState; // remove max/min flags
        
        // trigger layout recalc on resize
        pWindow->hasLayout() && pWindow->getLayout()->layout(pWindow);
        
        auto pEvent        = new CResizeEvent(pWindow);
        pEvent->mWidth     = static_cast<int>(LOWORD(lParam));
        pEvent->mHeight    = static_cast<int>(HIWORD(lParam));
        pEvent->mState     = eState;
        
        if (pWindow->handle(pEvent)) {_DELETE_(pEvent); return 0;}
        
        // wParam: 4 SIZE_MAXHIDE   to all popup when other window is maximized
        //         3 SIZE_MAXIMIZED the window has been maximized
        //         2 SIZE_MAXSHOW   to all popup when other window has been restored
        //         1 SIZE_MINIMIZED the window has been minimized
        //         0 SIZE_RESOTRED  resized (but not minimized or maximized)
        // LOWORD(lParam): width  (client area)
        // HIWORD(lParam): height (client area)
        break;
      }
      case WM_MOUSEACTIVATE: { // use w/ WM_SETFOCUS
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_MOUSEACTIVATE:" << wParam << ":" << lParam << std::endl;
        UNREFERENCED_PARAMETER(lParam);
        
        /*HWND hPrev=*/::SetFocus(hWnd);
        
        // wParam: handle to the top-level window being activated
        // lParam: NOT USED
        return 0;
      }
    //case WM_MOUSEHOVER:
    //case WM_MOUSELEAVE: // requires ::TrackMouseEvent(TRACKMOUSEEVENT)
      case WM_LBUTTONDOWN: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_LBUTTONDOWN" << ":" << GET_X_LPARAM(lParam) << "x" << GET_Y_LPARAM(lParam) << std::endl;
  
        _BREAK_(!pWindow);
  
        auto pEvent       = new CMouseEvent(EEvent::LBUTTONDOWN, pWindow);
        pEvent->mClientX  = GET_X_LPARAM(lParam);
        pEvent->mClientY  = GET_Y_LPARAM(lParam);
        pEvent->mModifier = (EModifier)(wParam);
  
        bool bTriggered   = pWindow->handle(pEvent);
  
        while (pEvent->doPropagation() && pWindow->hasParent()) {
          pWindow    = pWindow->getParent();
          bTriggered = pWindow->handle(pEvent) && bTriggered;
        }
  
        if (bTriggered) {_DELETE_(pEvent); return 0;}
  
        // wParam: 0x0002 MK_RBUTTON  (virtual keys)
        //         0x0004 MK_SHIFT
        //         0x0008 MK_CONTROL
        //         0x0010 MK_MBUTTON
        //         0x0020 MK_XBUTTON1
        //         0x0040 MK_XBUTTON2
        // LOWORD(lParam): x mouse position (reltive to the upper left conner of the client area)
        // HIWORD(lParam): y mouse position
        break;
      }
    //case WM_LBUTTONUP:
    //case WM_LBUTTONDBLCLK:
    //case WM_RBUTTONUP: 
      // x = GET_X_LPARAM(lParam) // LOWORD(lParam)
      // y = GET_Y_LPARAM(lParam) // HIWORD(lParam)
      // wParam & MK_CONTROL // MK_SHIFT
      case WM_KEYDOWN: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_KEYDOWN" << ":" << (char)(wParam) << ":" << lParam << std::endl;
        
        // HWND hFocused = ::GetFocus();        // get handle to current keyboard focused window
        // HWND hActive  = ::GetActiveWindow(); // get handle to current active window
        
        auto pEvent     = new CKeyEvent(EEvent::KEYDOWN, pWindow);
        pEvent->mKey    = static_cast<char>(wParam);
  
        bool bTriggered = pWindow->handle(pEvent);
  
        while (pEvent->doPropagation() && pWindow->hasParent()) {
          pWindow    = pWindow->getParent();
          bTriggered = pWindow->handle(pEvent) && bTriggered;
        }
  
        if (bTriggered) {_DELETE_(pEvent); return 0;}
  
        // wParam: virtual key code 
        // lParam: 00-15 bits: repeat count of the current key (user holds key pressed)
        //         16-23 bits: scan code (OEM)
        //            24 bit : extended key? (right ALT, CTRL) (for 101,102 key keyboard)
        //         25-28 bits: reserved (DO NOT USE)
        //            29 bit : context code (0 for WM_KEYDOWN)
        //            30 bit : prev key state (1 down, 0 up) (1 if down was already pressed)
        //            31 bit : transition state (0 for WM_KEYDOWN)
        // MSG sMsg; ::TranslateMessage(&sMsg);
        break;
      }
    //case WM_KEYUP: 
      // wParam: virtual key code 
      // lParam: 00-15 bits: repeat count (1 for WM_KEYUP)
      //         16-23 bits: scan code (OEM)
      //            24 bit : extended key? (right ALT, CTRL) (for 101,102 key keyboard)
      //         25-28 bits: reserved (DO NOT USE)
      //            29 bit : context code (0 for WM_KEYUP)
      //            30 bit : prev key state (1 for WM_KEYUP)
      //            31 bit : transition state (1 for WM_KEYUP)
      // return 0; if message was processed
      case WM_ERASEBKGND: {    // when window bg redrawn (ex on BeginPaint)
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_ERASEBKGND:" << wParam << std::endl;
        UNREFERENCED_PARAMETER(lParam); // worn compiler that this is unused
        break;
      }
      case WM_NCPAINT: {     // non-client (area) paint // paint your own frame, border, titlebar
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_NCPAINT:" << wParam << ":" << lParam << std::endl;
        break;
      }
      case WM_PAINT: {
        CWindow* pWindow = reinterpret_cast<CWindow*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
        std::cout << std::left << std::setw(8) << hWnd << ":" << std::setw(9) << pWindow << ":W:WM_PAINT:" << wParam << ":" << lParam << std::endl;
        UNREFERENCED_PARAMETER(lParam);
        UNREFERENCED_PARAMETER(wParam);
        // onDraw()
        // return 0; // if the program handled this message
  
        PAINTSTRUCT sPS;
        HDC         hDC;
        SSize sSize = pWindow->size();
  
        
        
        auto aCallbacks = pWindow->mCallbacks[EEvent::PAINT];
        bool bTriggered = aCallbacks.size() != 0;
  
        if (!bTriggered) { /* HDC hDC = ::BeginPaint((HWND)(*pWindow), &sPS); */ }
        
        for (auto it = aCallbacks.begin(); it != aCallbacks.end(); ++it) {
          // (*it)(pEvent);
        }
        
        if (bTriggered) { /*::EndPaint((HWND)(*pWindow), &sPS); */ }
        
        break;
      }
      default: break;
    }
    return ::DefWindowProc(hWnd, uMsg, wParam, lParam); // "For all message I did not handle above, do nothing!"
  }
}
