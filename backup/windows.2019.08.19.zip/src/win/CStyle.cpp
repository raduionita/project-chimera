#include "win/CStyle.hpp"

namespace win {
  CStyle::CStyle() {
    std::cout << "win::CStyle::CStyle()::" << this << ":" << mId << std::endl;
  }
  
  CStyle::~CStyle() {
    std::cout << "win::CStyle::~CStyle()::" << this << ":" << mId << std::endl;
  }
  
  CStyle::CStyle(const CStyle& that) {
    
  }
  
  CStyle& CStyle::operator =(const CStyle& that) {
    if (&that == this) { return *this; }
    
    
  }
}
