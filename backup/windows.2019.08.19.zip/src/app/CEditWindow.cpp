#include <win/COGLContext.hpp>
#include "app/CEditWindow.hpp"

namespace app {
  CEditWindow::CEditWindow() : CFrame("window", {10, 10, 320, 240}, win::EHint::CENTERED | win::EHint::VISIBLE) {
    std::cout << "app::CEditWindow::CEditWindow()::" << this << std::endl;
    onInit();
  }
  
  CEditWindow::~CEditWindow() {
    std::cout << "app::CEditWindow::CEditWindow()::" << this << std::endl;
  }
  
  // event hamdlers //////////////////////////////////////////////////////////////////////////////////////////////////
  
  void CEditWindow::onInit() { // @see CEditWindow::CEditWindow()
    std::cout << "app::CEditWindow::onInit()::" << this << std::endl;
    
    win::CPanel*  pPanel1  = new win::CPanel(this, win::EHint::VISIBLE);
    win::CButton* pButton1 = new win::CButton(pPanel1, "1", { 0, 0, 20, 20});
    win::CPanel*  pPanel2  = new win::CPanel(this, {10, 10, 50, 60}, win::EHint::VISIBLE);
    win::CButton* pButton2 = new win::CButton(pPanel2, "2", { 0, 0, 20, 20});
    win::CPanel*  pPanel3  = new win::CPanel(this, {10, 10, 50, 60}, win::EHint::VISIBLE);
    win::CButton* pButton3 = new win::CButton(pPanel3, "3", { 0, 0, 20, 20});
    win::CPanel*  pPanel4  = new win::CPanel(this, {10, 10, 50, 60}, win::EHint::VISIBLE);
    win::CButton* pButton4 = new win::CButton(pPanel4, "4", { 0, 0, 20, 20});
  
    win::CBoxLayout* pVLayout = new win::CBoxLayout(win::EHint::VERTICAL);
    win::CBoxLayout* pHLayout = new win::CBoxLayout(win::EHint::HORIZONTAL);
    
    pVLayout->add(pPanel1, win::EHint::EXPAND);
    pVLayout->add(pHLayout);
      pHLayout->add(pPanel4, win::EHint::EXPAND);
      pHLayout->add(pPanel2, win::EHint::EXPAND);
    pVLayout->add(pPanel3, win::EHint::EXPAND);
    
    setLayout(pVLayout);
    
    // needed for on paint - so I don't have to create weird paint obj inside paint handler method
    
    attach(pPanel2,  win::EEvent::RESIZE,      &CEditWindow::onResize);
    attach(pPanel2,  win::EEvent::COMMAND,     &CEditWindow::onCommand);
    attach(this,     win::EEvent::COMMAND,     &CEditWindow::onCommand);
    attach(pButton2, win::EEvent::LBUTTONDOWN, &CEditWindow::onButtonDown);
    
    // mStyle->setBackground(CBrush(CColor(UIX_COL_WND_BG)));
    // mStyle->setBorder(CPen(1, CPen::SOLID, UIX_COL_WND_BORDER));
  }
  
  void CEditWindow::onShow(win::CEvent*) {
    std::cout << "app::CEditWindow::onShow()::" << this << std::endl;
  }
  
  void CEditWindow::onButtonDown(win::CMouseEvent* e){
    std::cout << "app::CEditWindow::onButtonDown()::" << e->mTarget << std::endl;
  }
  
  void CEditWindow::onFocus(win::CEvent* e) {
    std::cout << "app::CEditWindow::onFocus()::" << e->mTarget << std::endl;
  }
  
  void CEditWindow::onKeyDown(win::CKeyEvent* e) {
    std::cout << "app::CEditWindow::onKeyDown()::" << e->mTarget << " " << e->mKey << std::endl;
  }
  
  void CEditWindow::onResize(win::CResizeEvent* e) {
    std::cout << "app::CEditWindow::onResize()::" << e->mTarget << " state=" << e->mState << std::endl;
  }
  
  void CEditWindow::onCommand(win::CCommandEvent* e) {
    std::cout << "app::CEditWindow::onCommand()::" << this << " " << e->mTarget << " " << e->mControl << " state=" << e->mState << std::endl;
  }
}

// @todo: styles
