#include "app/CApplication.hpp"

namespace app {
  
  // constructor & destructors ///////////////////////////////////////////////////////////////////////////////////////
  
  CApplication::CApplication() : win::CApplication() {
    std::cout << "app::CApplication::CApplication()" << std::endl;
  }
  
  // event handlers //////////////////////////////////////////////////////////////////////////////////////////////////
  
  void CApplication::onInit() {
    std::cout << "app::CApplication::onInit()" << std::endl;
  
    mEditWindow = new CEditWindow;
    // mLoop.onTick([]()->void { });
    
    // @todo init new loop here or on construct
  }
  
  void CApplication::onIdle() {
    //std::cout << "app::CApplication::onIdle()" << std::endl;
    
    
    
  }
  
  void CApplication::onFree() {
    std::cout << "app::CApplication::onFree()" << std::endl;
    //delete mEditWindow; mEditWindow = nullptr;
  }
}
