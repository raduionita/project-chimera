#include "sys/CFolder.hpp"

namespace sys {
  CFolder::CFolder() { }
  
  CFolder::~CFolder() { }
  
  std::filesystem::recursive_directory_iterator CFolder::riterate() const {
    return std::filesystem::recursive_directory_iterator(mPath);
  }
}
