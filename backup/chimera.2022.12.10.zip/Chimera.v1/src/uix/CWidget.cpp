#include "uix/CWidget.hpp"

namespace uix { }

// @todo: on default size draw widget using parent inner size
