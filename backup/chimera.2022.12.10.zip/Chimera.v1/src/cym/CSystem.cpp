#include "cym/CSystem.hpp"

namespace cym {
  CSystem::CSystem() {
    
  }
}
