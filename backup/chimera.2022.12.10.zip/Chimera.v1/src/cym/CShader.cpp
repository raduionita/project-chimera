#include "cym/CShader.hpp"
#include "cym/CRenderSystem.hpp"
#include "glm/CMatrix.hpp"
#include "sys/CException.hpp"

#include <fstream>
#include <cassert>
#include <vector>
#include <iterator>
#include <string>
#include <istream>
#include <algorithm>

namespace cym {
  CShader::CShader(const cym::TIdentifier<cym::CShader>& tID/*=""*/) : cym::TResource<cym::CShader>(tID) {
    SYS_LOG_NFO("cym::CShader::CShader(cym::TIdentifier<>&)::" << this);
  }
  
  CShader::~CShader() {
    SYS_LOG_NFO("cym::CShader::~CShader()::" << this);
    GLCALL(::glDeleteProgram(mID));
  }
  
  void CShader::bind(bool state) const {
    SYS_LOG_DBG("cym::CShader::bind(bool)::" << this);
    GLCALL(::glUseProgram(state ? mID : 0)); 
  }
  
  GLint CShader::uniform(const sys::string& name) {
    auto it = mUniforms.find(name);
    if (it != mUniforms.end()) {
      return it->second;
    }
    return GL_NOT_FOUND;
  }
  
  void CShader::uniform(const sys::string& name, float x) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniform1f(loc, x));
    }
    // @todo: there should be a warn here if not found
  }
  
  void CShader::uniform(const sys::string& name, float x, float y) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniform2f(loc, x,y));
    }
    // @todo: there should be a warn here if not found
  }
  
  void CShader::uniform(const sys::string& name, float x, float y, float z) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniform3f(loc, x,y,z));
    }
    // @todo: there should be a warn here if not found
  }
  
  void CShader::uniform(const sys::string& name, float x, float y, float z, float w) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniform4f(loc, x,y,z,w));
    }
    // @todo: there should be a warn here if not found
  }
  
  void CShader::uniform(const sys::string& name, const cym::PTexture& tex) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      tex->bind();
      GLCALL(::glUniform1i(loc, tex->getSlot()));
    } else {
      log::wrn << "cym::CShader::uniform(CString&,PTexture&)::" << this << " Uniform NOT found!" << log::end;
    }
    // @todo: there should be a warn here if not found
  }
  
  void CShader::uniform(const sys::string& name, const glm::vec3& v) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniform3fv(loc, 1, (const float*)(v)));
    }
  }
  
  void CShader::uniform(const sys::string& name, const sys::vector<glm::vec3>& vs) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniform3fv(loc, vs.size(), (const float*)(vs.data())));
    }
  }
  
  void CShader::uniform(const sys::string& name, const glm::mat4& M) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniformMatrix4fv(loc, 1, false, (const float*)(M)));
    }
  }
  
  void CShader::uniform(const sys::string& name, const sys::vector<glm::mat4>& Ms) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniformMatrix4fv(loc, Ms.size(), false, (const float*)(Ms.data())));
    }
  }
  
  void CShader::sampler(const sys::string& name, GLuint i) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      GLCALL(::glUniform1i(loc, i));
    }
    // @todo: there should be a warn here if not found
  }
  
  void CShader::sampler(const sys::string& name, const cym::PTexture& tex) {
    GLint loc = uniform(name);
    if (loc != GL_NOT_FOUND) {
      tex->bind();
      GLCALL(::glUniform1i(loc, tex->getSlot()));
    } else {
      log::wrn << "cym::CShader::sampler(CString&,PTexture&)::" << this << " Uniform NOT found!" << log::end;
    }
    // @todo: there should be a warn here if not found
  }
  
  // manager /////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  CShaderManager::CShaderManager()  { 
    SYS_LOG_NFO("cym::CShaderManager::CShaderManager()"); 
  }
  
  CShaderManager::~CShaderManager() { 
    SYS_LOG_NFO("cym::CShaderManager::~CShaderManager()"); 
  }
  
  void CShaderManager::boot(const sys::path& tPath/*={}*/) { 
    SYS_LOG_DBG("cym::CShaderManager::boot(sys::path&)");
    static auto& self {CShaderManager::getSingleton()};
    // remember root folder
    self.mFolder = tPath.string();
    
    // if (!cym::CRenderSystem::hasBooted())
    //   throw sys::exception("cym::CShaderManager::boot() AFTER cym::CRenderSystem::boot()", __FILE__, __LINE__);

    CShaderManager::load(cym::null{});

    for (const auto& tEntry : std::filesystem::recursive_directory_iterator{tPath}) {
      if (tEntry.is_regular_file()) {
        std::cout << tEntry.path().string() << std::endl;
        CShaderManager::load(tEntry.path());
      }
    }
    
// tree-like structure => find the closest match
  // @see CShaderManager::find(TIdentifier)
    
// @TODO [scope:shadow] [mode:map]    [phase:shadow] shader
// @TODO [scope:shadow] [mode:volume] [phase:shadow] shader

// @TODO [scope:select] shader

// @TODO [scope:render] [mode:forward] [phase:color] [group:tool]  [type:grid]                     shader
// @TODO [scope:render] [mode:forward] [phase:color] [group:tool]  [type:gizmo]                    shader
// @TODO [scope:render] [mode:forward] [phase:color] [group:scene] [type:geometry]                 ubershader
// @TODO [scope:render] [mode:forward] [phase:color] [group:scene] [type:geometry] [flavor:custom] ubershader
// @TODO [scope:render] [mode:forward] [phase:color] [group:scene] [type:emitter]                  ubershader
// @TODO [scope:render] [mode:forward] [phase:color] [group:debug] [type:shape]                    shader
// @TODO [scope:render] [mode:forward] [phase:color] [group:debug] [type:quad]     [flavor:icon]   shader

// @TODO [scope:render] [mode:deferred] [phase:buffer] [group:tool]  [type:grid]                   shader
// @TODO [scope:render] [mode:deferred] [phase:buffer] [group:tool]  [type:gizmo]                  shader
// @TODO [scope:render] [mode:deferred] [phase:buffer] [group:scene] [type:geometry]               ubershader
// @TODO [scope:render] [mode:deferred] [phase:buffer] [group:scene] [type:emitter]                ubershader
// @TODO [scope:render] [mode:deferred] [phase:buffer] [group:debug] [type:cuboid]                 shader

// @TODO [scope:render] [mode:deferred] [phase:occlusion] shader
// @TODO [scope:render] [mode:deferred] [phase:light]     shader

// @TODO [scope:output] [mode:final] shader
// @TODO [scope:output] [mode:debug] [phase:debug] [group:buffer] [type:?] shader // other fbos

// @TODO [scope:update] [mode:forward] [phase:color] [group:scene] [type:emitter]                  shader

  }
  
  cym::PShader CShaderManager::bind(const cym::TIdentifier<cym::CShader>& tId/*={}*/) { 
    SYS_LOG_NFO("cym::CShaderManager::bind(cym::TIdentifier<cym::CShader>&)"); // tId=" << tId.getString());
    static auto& self {cym::CShaderManager::getSingleton()};
    
    if (tId != self.mBound->getIdentifier()) {
      self.mBound = cym::CShaderManager::find(tId);
      
  // @TODO bind only if not already bound 
  
      std::cout << "found:" << self.mBound->getIdentifier().getString() << std::endl;
      
      self.mBound->bind(true);
    }
    
    return self.mBound;
  }
  
  void CShaderManager::save(cym::PShader pShader) {
    SYS_LOG_NFO("cym::CShaderManager::save(PShader)");
    static auto& self {cym::CShaderManager::getSingleton()};
    self.mShaders.insert(std::pair(pShader->getIdentifier(), pShader));
  }
  
  cym::PShader CShaderManager::find(const cym::TIdentifier<cym::CShader>& tId) {
    SYS_LOG_NFO("cym::CShaderManager::find(cym::TIdentifier<cym::CShader>&)"); // tId=" << tId.getString());
    static auto& self {cym::CShaderManager::getSingleton()};
    // start w/ null shader
    cym::PShader pShader {self.mShaders.begin()->second};
    // try to find the right shader....
    for (auto it = std::next(self.mShaders.begin()); it != self.mShaders.end(); ++it) {
      // std::cout << it->first.getString() << std::endl;
      // null shader
      if ((tId.hasScope()) && (it->first.getScope() == tId.getScope())) {                           // scope: render|update|output
        if (!it->first.hasMode()) { // is there a shader at this level? cache it
          pShader = it->second;
        } else if ((tId.hasMode()) && (it->first.getMode() == tId.getMode())) {                     // mode: forward|deferred|final|debug
          if (!it->first.hasPhase()) { // has next == (same as) == mode is last 
            pShader = it->second;
          } else if ((tId.hasPhase()) && (it->first.getPhase() == tId.getPhase())) {                // phase: color|buffer|occlusion|debug
            if (!it->first.hasGroup()) { // has next
              pShader = it->second;
            } else if ((tId.hasGroup()) && (it->first.getGroup() == tId.getGroup())) {              // group: tool|scene|buffer|debug
              if (!it->first.hasType()) {
                pShader = it->second;
              } else if ((tId.hasType()) && (it->first.getType() == tId.getType())) {               // type: geometry|emitter|cuboid
                if (!it->first.hasFlavor()) {
                  pShader = it->second;
                } else if ((tId.hasFlavor()) && (it->first.getFlavor() == tId.getFlavor())) {       // flavor: cusstom|icon
                  pShader = it->second;
                }
              }
            }
          }
        }
      }
    }
    sys::throw_if(pShader == nullptr, "PShader cannot be nullptr", __FILE__,__LINE__);
    return pShader;
  }
  
  cym::PShader CShaderManager::load(PShaderLoader pLoader, bool bSearch/*=true*/) {
    SYS_LOG_DBG("cym::CShaderManager::load(PShaderLoader,bool)");
    static auto& self {CShaderManager::getSingleton()};
    // process CShaderLoader into CShader 
    if (pLoader) {
      PShader     pShader;
      const auto& tId {pLoader->getIdentifier()};
      // if externaly loaded: try to find it 
      if (bSearch && sys::find(/*needle*/tId,/*haystack*/self.mShaders,/*destination*/pShader)) {
        // do nothing
      } else {
        
// @TODO move special (custom) hlsl tags (@shader, @include, @feature) inside HLSL codec
        
        // new shader
        pShader = new CShader{tId};
        // load shader (set code)
        pLoader->load(pShader);
        // load
        auto& rStream   = pLoader->mStream;
        auto& rID       = pShader->mID;
        auto& rUniforms = pShader->mUniforms;
        auto& rType     = pShader->mType;
// @TODO replace w/ exception
        assert(rStream.good() && "cannot open shader file");
        // temps
        sys::string                            line;
        sys::table<GLenum, SSource>            sources;
        static sys::table<GLenum, EShader>     etypes {{GL_VERTEX_SHADER,EShader::VERTEX},{GL_FRAGMENT_SHADER,EShader::FRAGMENT},{GL_GEOMETRY_SHADER,EShader::GEOMETRY},{GL_TESS_CONTROL_SHADER,EShader::TESSCTRL},{GL_TESS_EVALUATION_SHADER,EShader::TESSEVAL},{GL_COMPUTE_SHADER,EShader::COMPUTE},};
        static sys::table<GLenum, sys::string> stypes {{GL_VERTEX_SHADER,"GL_VERTEX_SHADER"},{GL_FRAGMENT_SHADER,"GL_FRAGMENT_SHADER"},{GL_GEOMETRY_SHADER,"GL_GEOMETRY_SHADER"},{GL_TESS_CONTROL_SHADER,"GL_TESS_CONTROL_SHADER"},{GL_TESS_EVALUATION_SHADER,"GL_TESS_EVALUATION_SHADER"},{GL_COMPUTE_SHADER,"GL_COMPUTE_SHADER"}};
        GLenum                                 curr   {GL_NONE};
        // start reading (line by line)
        while (std::getline(rStream, line)) {
          // custom tags
          if (line[0] == '@') {
            if (line.find("@shader") == 0) {
              for (auto& [type, name] : stypes) {
                auto s = sizeof("@shader");
                auto p = line.find(name);
                if (line.find(name) != std::string::npos) {
                  curr = type;
                  sources[type].name   = name;
                  sources[type].type   = type;
                  sources[type].shader = GL_ZERO;
                  // found, no need to search for the other types
                  break;
                } else {
                  // @todo: insert warning here
                }
              }
            } else { // if (line.find("@include") == 0) {
              SYS_LOG_DBG("cym::CShaderManager::load(PShaderLoader,bool)" << "[HLSL] " << line);
              // @todo: include shader fragment
            } 
          // regular glsl code
          } else {
            sources[curr].code += line + '\n';
          }
        }
        // program id
        GLCALL(::gxCreateProgram(&rID));
        // compile
        for (auto& [type, source] : sources) {
          GLuint&     shader = source.shader;
          const char* code   = source.code.c_str();
          GLCALL(::gxCreateShader(type, &shader));
          GLCALL(::glShaderSource(shader, 1, &code, NULL));
          GLCALL(::glCompileShader(shader));
          GLint status = GL_FALSE;
          GLCALL(::glGetShaderiv(shader, GL_COMPILE_STATUS, &status));
          if (status == GL_FALSE) {
            GLint loglen = 0;
            GLCALL(::glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &loglen));
            char* error = new char[loglen + 1];
            GLCALL(::glGetShaderInfoLog(shader, loglen, &loglen, error));
            error[loglen] = '\0';
            // cleanup
            GLCALL(::glDeleteProgram(rID));
            GLCALL(::glDeleteShader(shader));
            // @todo: replace w/ throw exception
            // @todo: this error reporting doesn't work well
            SYS_LOG_ERR("cym::CShaderManager::load(PShaderLoader,bool)" << "ERROR:" << error);
            std::cout << error << std::endl;
            assert(false);
          }
          // add types
          rType |= etypes[source.type];
          // attach
          GLCALL(::glAttachShader(rID, shader));
        }
        // link & validate
        GLCALL(::glLinkProgram(rID));
        GLCALL(::glValidateProgram(rID));
        // clear
        for (auto& [type, source] : sources) {
          GLCALL(::glDetachShader(rID, source.shader));
          GLCALL(::glDeleteShader(source.shader));
        }
        // check
        GLint status = GL_FALSE;
        GLCALL(::glGetProgramiv(rID, GL_LINK_STATUS, &status));
        if (status == GL_FALSE) {
          GLint loglen;
          GLCALL(::glGetProgramiv(rID, GL_INFO_LOG_LENGTH, &loglen));
          GLchar* error = new GLchar[loglen + 1];
          GLCALL(::glGetProgramInfoLog(rID, loglen, &loglen, error));
          error[loglen] = '\0';
          // cleanup
          GLCALL(::glDeleteProgram(rID));
          // @todo: replace w/ throw exception
          SYS_LOG_ERR("cym::CShaderManager::load(PShaderLoader,bool)" << "ERROR:" << error);
          assert(false);
        }
        // find all uniforms
        int cnt = -1;
        GLCALL(::glGetProgramiv(rID, GL_ACTIVE_UNIFORMS, &cnt));
        for (int i = 0; i < cnt; i++) {
          GLint  len = -1, num = -1;
          GLenum typ = GL_ZERO;
          GLchar str[100];
          GLCALL(::glGetActiveUniform(rID, (GLuint)(i), sizeof(str)-1, &len, &num, &typ, str));
          str[len] = 0; // add null terminator '\0'
          GLint loc = GL_NOT_FOUND;
          GLCALL(::gxGetUniformLocation(rID, str, &loc));
          // add to cached uniforms
          rUniforms.insert(std::move(std::pair(std::string{str}, loc)));
        }
        // persist
        CShaderManager::save(pShader);
        // update state
        pShader->mState = CResource::EState::READY;
      }
      // done, return shader
      return pShader;
    } else {
// @TODO return null shader
      return nullptr;
    }
  }

  // loaders /////////////////////////////////////////////////////////////////////////////////////////////////////////

  cym::TIdentifier<CShader> TShaderLoader<sys::path>::identify(const sys::path& tPath) {
    // temps
    auto& tFolder {cym::CShaderManager::getFolder()};
    auto  tString {tPath.string()};
    auto  tFound  {tString.find(tFolder)};
    // part of the internal shaders, use folder structure as identifier
    if (tFound != sys::string::npos) {
      
      auto tStart {tFound+tFolder.size()+1};
      auto tEnd   {tString.find_last_of('\\')};
      auto tCount {tEnd-tStart};
      
      // std::cout << "TShaderLoader<sys::file>::identify(sys::file&) substr=" << tString.substr(tStart, tCount) << std::endl;
      
      auto tTags = sys::split(tString.substr(tStart, tCount), std::regex{R"(\\)"});
      
      // for (auto tag : tTags) 
      //   std::cout << "tag:" << tag << std::endl;
      
      return {tTags};
    }
    return {tPath.stem().string()}; 
  }
  
  void TShaderLoader<sys::path>::load(cym::PShader) {
    sys::path& rPath   = getPath();
    auto&      rStream = getStream();
    
    SYS_LOG_NFO("cym::TShaderLoader<sys::path>::load(PShader)::" << this << " PATH:" << rPath.string());
    
    std::ifstream ifs{rPath,std::ifstream::in|std::ifstream::binary};
    
    sys::throw_if(!ifs.good(), sys::string("Cannot open file `") + rPath.string() + "`",__FILE__,__LINE__); // + rFile.path());
    
    rStream << ifs.rdbuf();
  }
  
  void TShaderLoader<cym::null>::load(PShader) {
    SYS_LOG_NFO("cym::TShaderLoader<cym::null>::load(PShader)::" << this);
    
    auto& rStream = getStream();
    
    rStream << "@shader GL_VERTEX_SHADER\n"
                 "#version 330 core\n"
                 "layout (location = 0) in vec4 a_vPosition;\n"
                 "uniform mat4 u_mPVM;\n"
                 "void main() { gl_Position = u_mPVM * a_vPosition; }\n"
               "@shader GL_FRAGMENT_SHADER\n"
                 "#version 330 core\n"
                 "uniform vec3 u_vColor = vec3(0.8,0.8,0.8);\n"
                 "layout (location = 0) out vec4 f_vColor;\n"
                 "void main() { f_vColor = vec4(u_vColor,1.0); }";
  }
}

// @TODO: isTessellated => GL_PATCHES

// @TODO CShaderManager::find(HINT | HINT | HINT | HINT)
  // check if the current one matches and return
  // loop through all shaders and find best match
  // else return a debug shader
  
// @TODO CShader::bind(CMaterial)
// @TODO CShader::bind(CGeometry)...
  // load uniforms into shader

  

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
