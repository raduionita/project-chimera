#include "cym/CProgram.hpp"

namespace cym {
  CProgram::CProgram() {
    
  }
  
  CProgram::~CProgram() {
    
  }
}
