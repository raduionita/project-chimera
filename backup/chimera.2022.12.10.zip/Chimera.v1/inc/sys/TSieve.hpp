#ifndef __sys_tsieve_hpp__
#define __sys_tsieve_hpp__

#include "sys/sys.hpp"

namespace sys {
  template<typename K, typename T> class TSieve;
  
  template<typename K, typename T> class TSieve {
    protected:
      K                             mName;  // ""
      T                             mData;  // null shader
      K                             mType;  // "scope"
      sys::vector<sys::TSieve<K,T>> mNodes;  // (render,update,output,shadow)
    public: // ctor
      TSieve(const K& t = {}, const K& n = {}) { }
      virtual ~TSieve() = default;
    public: // actions
      
      void push(const K& n, const T& d) {
        
      }
  };
  
  template<typename K, typename T> using sieve = sys::TSieve<K,T>; 
}

#endif //__sys_tsieve_hpp__
