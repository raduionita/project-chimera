#ifndef __sys_cfolder_hpp__
#define __sys_cfolder_hpp__

#include "sys/sys.hpp"

#include <filesystem>

namespace sys {
  class CFolder {
    protected:
      sys::string mPath;
    public:
      CFolder();
      CFolder(const sys::string&  fpath);
      CFolder(const char*         fpath);
      CFolder(sys::string&&       fpath);
      CFolder(char*&&             fpath);
      CFolder(const sys::CFolder&);
      virtual ~CFolder();
    public:
      inline bool operator ==(bool state) { return state ? !mPath.empty() : mPath.empty(); }
      inline bool operator  !()           { return mPath.empty(); }
    public: // cast operatorS
      inline      operator bool() const { return !mPath.empty(); }
    public:
      std::filesystem::recursive_directory_iterator riterate() const;
  };
}

#endif //__sys_cfolder_hpp__
