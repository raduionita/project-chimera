#ifndef __alg_hpp__
#define __alg_hpp__

namespace alg {
  // @see http://www.cse.yorku.ca/~oz/hash.html
  
  unsigned long djb2(unsigned char* str) {
    unsigned long h {5381};
    int c;
    while ((c = *str++))
      h = ((h << 5) + h) + c; // hash = (hash * 33) + c;
    return h;
  }
  
  unsigned long sdbm(unsigned char* str) {
    unsigned long h {0};
    int c;
    while ((c = *str++))
        h = c + (h << 6) + (h << 16) - h;
    return h;
  }
  
  
  unsigned long lose(unsigned char* str) {
    unsigned int h {0};
    int c;
    while ((c = *str++))
      h += c;
    return h;
  }
  
  unsigned long hash(unsigned char* str, unsigned long(*func)(unsigned char*) = djb2) {
    return func(str);
  }
}


#endif //__alg_hpp__
