#ifndef __app_ccontroller_hpp__
#define __app_ccontroller_hpp__

#include "cym/CController.hpp"

namespace app {
  class CController : public cym::CController {
      
  };
}

#endif //__app_ccontroller_hpp__
