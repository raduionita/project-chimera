#ifndef __app_cgamewindow_hpp__
#define __app_cgamewindow_hpp__

#include "app.hpp"
#include "uix/CCanvas.hpp"

namespace app {
  class CGameWindow : public CCanvas {
      
  };
}

#endif //__app_cgamewindow_hpp__
