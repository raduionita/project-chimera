#ifndef __app_cinputmanager_hpp__
#define __app_cinputmanager_hpp__

namespace app {
  class CInputManager {
      
  };
}

#endif //__app_cinputmanager_hpp__
