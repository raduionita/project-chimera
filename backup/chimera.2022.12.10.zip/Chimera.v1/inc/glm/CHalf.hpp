#ifndef __glm_chalf_hpp__
#define __glm_chalf_hpp__

#include "glm/glm.hpp"


#define HALF_SIGN_SHIFT                 (15)
#define HALF_EXP_SHIFT                  (10)
#define HALF_MANT_SHIFT                 (0)

#define HALF_SIGN_MASK                  (0x8000)
#define HALF_EXP_MASK                   (0x7C00)
#define HALF_MANT_MASK                  (0x03FF)

#define HALF_POS_INFINITY               (0x7C00)
#define HALF_NEG_INFINITY               (0xFC00)

#define GET_HALF_SIGN_BIT(x)            ((x) >> HALF_SIGN_SHIFT)
#define GET_HALF_EXP_BITS(x)            (((x) >> HALF_EXP_SHIFT) & 0x1F)
#define GET_HALF_MANT_BITS(x)           ((x) & HALF_MANT_MASK)

#define SET_HALF_SIGN_BIT(x,dest)       ((dest) = ((((x) << HALF_SIGN_SHIFT) & HALF_SIGN_MASK) | ( (dest) & ( HALF_EXP_MASK  | HALF_MANT_MASK ))))
#define SET_HALF_EXP_BITS(x,dest)       ((dest) = ((((x) << HALF_EXP_SHIFT)  & HALF_EXP_MASK)  | ( (dest) & ( HALF_SIGN_MASK | HALF_MANT_MASK ))))
#define SET_HALF_MANT_BITS(x,dest)      ((dest) = ((((x) << HALF_MANT_SHIFT) & HALF_MANT_MASK) | ( (dest) & ( HALF_SIGN_MASK | HALF_EXP_MASK ))))

//
// FLOAT32 Helpers
//

#define SINGLE_SIGN_SHIFT               (31)
#define SINGLE_EXP_SHIFT                (23)
#define SINGLE_MANT_SHIFT               (0)

#define SINGLE_SIGN_MASK                (0x80000000)
#define SINGLE_EXP_MASK                 (0x7F800000)
#define SINGLE_MANT_MASK                (0x007FFFFF)

#define SINGLE_POS_INFINITY             (0x7F800000)
#define SINGLE_NEG_INFINITY             (0xFF800000)

#define GET_SINGLE_SIGN_BIT(x)          ((x) >> SINGLE_SIGN_SHIFT)
#define GET_SINGLE_EXP_BITS(x)          (((x) >> SINGLE_EXP_SHIFT) & 0xFF)
#define GET_SINGLE_MANT_BITS(x)         ((x) & SINGLE_MANT_MASK)

#define SET_SINGLE_SIGN_BIT(x,dest)     ((dest) = ((((x) << SINGLE_SIGN_SHIFT) & SINGLE_SIGN_MASK) | ( (dest) & ( SINGLE_EXP_MASK  | SINGLE_MANT_MASK ))))
#define SET_SINGLE_EXP_BITS(x,dest)     ((dest) = ((((x) << SINGLE_EXP_SHIFT)  & SINGLE_EXP_MASK)  | ( (dest) & ( SINGLE_SIGN_MASK | SINGLE_MANT_MASK ))))
#define SET_SINGLE_MANT_BITS(x,dest)    ((dest) = ((((x) << SINGLE_MANT_SHIFT) & SINGLE_MANT_MASK) | ( (dest) & ( SINGLE_SIGN_MASK | SINGLE_EXP_MASK ))))


// @see https://github.com/ramenhut/half/blob/master/half.cpp
//  
//           Address+0  Address+1  Address+2  Address+3
// Contents  SEEE EEEE  EMMM MMMM  MMMM MMMM  MMMM MMMM
//
// S sign bit = 1 (neg) 0 (pos)
// E exponent (w/ 127 offset)
// M 24bit mantissa (stored in 24bits)
//
// @example (-12.5)
// 	         Address+0  Address+1  Address+2  Address+3
// Contents  0xC1       0x48       0x00       0x00
// Format    SEEEEEEE   EMMMMMMM   MMMMMMMM   MMMMMMMM
// Binary    11000001   01001000   00000000   00000000
// Hex       C1         48         00         00
namespace glm {
  class CHalf {
    private:
      glm::ushort mHalf;
    public: // ctors
      CHalf() : mHalf{0} { }
      CHalf(const CHalf& rhs)      : mHalf{rhs.mHalf} { }
      CHalf(const glm::ushort rhs) : mHalf{rhs} { }
      CHalf(const float rhs) { *this = rhs; }
      ~CHalf() { }
    public: // operators
      CHalf& operator =(const CHalf& rhs) { mHalf = rhs.mHalf; return *this; }
      CHalf& operator =(const float rhs) { (*this) = toHalf(rhs); }
    public: // casts
      operator float() { return toFloat(*this); }
      
    public: // tools
      CHalf toHalf(float rhs) {
        // quick exit
        if (0.f == rhs) {
          return CHalf{};
        } else if (-0.f == rhs) {
          return CHalf{(glm::ushort)(0x8000)};
        }
        // begin
        CHalf    hOutput;
        uint32_t uInput = *reinterpret_cast<uint32_t*>(&rhs);
        
        uint32_t uSignBit  = GET_SINGLE_SIGN_BIT(uInput);
        uint32_t uMantBits = GET_SINGLE_MANT_BITS(uInput) >> 13;
        int32_t  iExpBits  = GET_SINGLE_EXP_BITS(uInput);
        
        if (0 == iExpBits) {
          // de-normalize
          SET_HALF_SIGN_BIT(uSignBit, hOutput.mHalf);
          SET_HALF_EXP_BITS(0, hOutput.mHalf);
          SET_HALF_MANT_BITS(uMantBits, hOutput.mHalf);
        } else if (0xFF == iExpBits) {
          if (0 == uMantBits) {
            // infinity
            hOutput.mHalf = (uSignBit ? HALF_NEG_INFINITY : HALF_POS_INFINITY);
          } else {
            // S/Q NaN
            SET_HALF_SIGN_BIT(uSignBit, hOutput.mHalf);
            SET_HALF_EXP_BITS(0x1F, hOutput.mHalf);
            SET_HALF_MANT_BITS(uMantBits, hOutput.mHalf);
          }
        } else {
          // normalized
          int32_t iExponent = iExpBits - 127 + 15;
          
          if      (iExponent < 0)  iExponent = 0;
          else if (iExponent > 31) iExponent = 31;
  
          SET_HALF_SIGN_BIT(uSignBit, hOutput.mHalf);
          SET_HALF_EXP_BITS(iExponent, hOutput.mHalf);
          SET_HALF_MANT_BITS(uMantBits, hOutput.mHalf);
        }
        
        return hOutput;
      }
      
      float toFloat(const CHalf& rhs) {
        // 2bytes = 16bits -> 4bytes = 32bits 
        float     fOutput {0};
        uint32_t* uOutput {reinterpret_cast<uint32_t*>(&fOutput)};
        
        if (     0 == rhs.mHalf) return  0.f; //
        if (0x8000 == rhs.mHalf) return -0.f; // 0x8000 = 32768 = 65536/2
        
        uint32_t uHalfSignBit  = GET_HALF_SIGN_BIT(rhs.mHalf);
        uint32_t uHalfMantBits = GET_HALF_MANT_BITS(rhs.mHalf) << 13;
        int32_t  iHalfExpBits  = GET_HALF_EXP_BITS(rhs.mHalf);
        
        if (0 == iHalfExpBits) {
          // de-normalize
          SET_SINGLE_SIGN_BIT(uHalfSignBit, *uOutput);
          SET_SINGLE_EXP_BITS(0, *uOutput);
          SET_SINGLE_MANT_BITS(uHalfMantBits, *uOutput);
        } else if (0x1F == iHalfExpBits) {
          if (0 == uHalfMantBits) {
            // to infinity
            *uOutput = (uHalfSignBit ? SINGLE_NEG_INFINITY : SINGLE_POS_INFINITY);
          } else {
            // S/Q NaN
            SET_SINGLE_SIGN_BIT(uHalfSignBit, *uOutput);
            SET_SINGLE_EXP_BITS(0xFF, *uOutput);
            SET_SINGLE_MANT_BITS(uHalfMantBits, *uOutput);
          }
        } else {
          // normalized
          SET_SINGLE_SIGN_BIT(uHalfSignBit, *uOutput);
          SET_SINGLE_EXP_BITS((iHalfExpBits - 15) + 127, *uOutput);
          SET_SINGLE_MANT_BITS(uHalfMantBits, *uOutput);
        }
        
        return fOutput;
      }
  };
}

#endif //__glm_chalf_hpp__
