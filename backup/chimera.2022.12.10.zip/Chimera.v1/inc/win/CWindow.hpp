#ifndef __win_cwindow_hpp__
#define __win_cwindow_hpp__

#include "win/win.hpp"

namespace win {
  class CWindow {
      
  };
}

#endif //__win_cwindow_hpp__
