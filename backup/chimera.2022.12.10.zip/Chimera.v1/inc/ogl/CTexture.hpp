#ifndef __ogl_ctexture_hpp__
#define __ogl_ctexture_hpp__

#include "ogl/ogl.hpp"
#include "ogl/CObject.hpp"

namespace ogl {
  class CTexture : public ogl::CObject {
      
  };
}

#endif //__ogl_ctexture_hpp__
