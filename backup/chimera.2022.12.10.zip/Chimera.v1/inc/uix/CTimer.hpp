#ifndef __uix_ctimer_hpp__
#define __uix_ctimer_hpp__

#include <sys/CTimer.hpp>

namespace uix {
  class CTimer : CTimer {
      
  };
}

#endif //__uix_ctimer_hpp__
