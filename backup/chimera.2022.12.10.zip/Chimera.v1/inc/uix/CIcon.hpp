#ifndef __uix_cicon_hpp__
#define __uix_cicon_hpp__

#include "CGdio.hpp" 

namespace uix {
  class CIcon {
    public:
      CIcon() { }
      virtual ~CIcon() { }
  };
}

#endif //__uix_cicon_hpp__
