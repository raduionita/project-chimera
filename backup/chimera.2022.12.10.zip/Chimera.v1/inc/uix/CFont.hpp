#ifndef __uix_cfont_hpp__
#define __uix_cfont_hpp__

#include "CGdio.hpp" 

namespace uix {
  class CFont {
      
  };
}

#endif //__uix_cfont_hpp__
