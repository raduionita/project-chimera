#ifndef __uix_ctitlebar_hpp__
#define __uix_ctitlebar_hpp__

#include "CWidget.hpp"

namespace uix {
  class CTitlebar : public CWidget {
      
  };
}

#endif //__uix_ctitlebar_hpp__
