#ifndef __uix_ccursor_hpp__
#define __uix_ccursor_hpp__

#include "CGdio.hpp" 

namespace uix {
  class CCursor {
      
  };
}

#endif //__uix_ccursor_hpp__
