#ifndef __cym_canimation_hpp__
#define __cym_canimation_hpp__

#include "cym/cym.hpp"
#include "cym/CSkeleton.hpp"

namespace cym {
  class CFrame {
      
  };
  
  class CAnimation {
    protected:
      CSkelet mSkelet;
  };
}

#endif //__cym_canimation_hpp__
