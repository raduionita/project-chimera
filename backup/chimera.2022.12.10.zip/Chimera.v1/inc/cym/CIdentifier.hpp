#ifndef __cym_cidentifier_hpp__
#define __cym_cidentifier_hpp__

#include "cym/cym.hpp"

namespace cym {
  class CIdentifier;
  
  // identifier //////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CIdentifier {
    protected:
      sys::string mString{""};
    public:
      inline CIdentifier() { };
      inline CIdentifier(const sys::string& tString) : mString{tString} { };
      inline CIdentifier(const char* tString) : mString{sys::string{tString}} { };
      ~CIdentifier() = default;
    public:
      inline CIdentifier& operator =(const sys::string& tString) { mString = tString; return *this; }
      inline CIdentifier& operator =(const char* tString) { mString = sys::string{tString}; return *this; }
    public:
      inline bool operator ==(const cym::CIdentifier& rhs) const { return rhs.getString() == getString(); }
      inline bool operator !=(const cym::CIdentifier& rhs) const { return rhs.getString() != getString(); }
      inline bool operator ==(const sys::string& rhs) const      { return rhs == getString(); }
      inline bool operator !=(const sys::string& rhs) const      { return rhs != getString(); }
    public: // operators
      inline bool operator <(const CIdentifier& rhs) const { return getString() < rhs.getString(); }
    public: // cast
      inline operator       sys::string() const { return getString(); }
      inline operator const sys::string() const { return getString(); }
    public: // getter
      inline const sys::string& getString() const                     { return mString; }
      inline void               setString(const sys::string& tString) { mString = tString; }
  };
  
  template<typename T> class TIdentifier : public CIdentifier {
    public:
      using CIdentifier::CIdentifier;
  };
}

#endif //__cym_cidentifier_hpp__
