#ifndef __cym_canimable_hpp__
#define __cym_canimable_hpp__

namespace cym { 
  class CAnimable {
      
  };
  
  // some meshes
  // needed/interacts w/ CAnimation
}

#endif //__cym_canimable_hpp__
