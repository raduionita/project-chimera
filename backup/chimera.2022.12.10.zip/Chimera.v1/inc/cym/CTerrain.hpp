#ifndef __cym_cterrain_hpp__
#define __cym_cterrain_hpp__

namespace cym {
  class CTerrain {
      
  };
}

#endif //__cym_cterrain_hpp__
