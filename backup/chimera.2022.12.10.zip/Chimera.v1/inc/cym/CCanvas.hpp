#ifndef __cym_ccanvas_hpp__
#define __cym_ccanvas_hpp__

namespace cym {
  class CCanvas {
      // @todo: receives image/data/rendering/drawing from the renderer
  };
}

#endif //__cym_ccanvas_hpp__
