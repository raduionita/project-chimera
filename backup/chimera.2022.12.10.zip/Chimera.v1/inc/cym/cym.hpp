#ifndef __cym_hpp__
#define __cym_hpp__

#include "sys/sys.hpp"
#include "sys/TPointer.hpp"
#include "sys/CLogger.hpp"
#include "sys/CTimer.hpp"
#include "ogl/ogl.hpp"
#include "glm/glm.hpp"
#include "glm/CVector.hpp"

#undef FAR
#undef NEAR

// @todo: ogl vs d3d vs vlk
#if defined(USE_DIRECTX_DRIVER) 
  #define DTEXTURE d3d::CTexture
#elif defined(USE_VULKAN_DRIVER)
  #define DTEXTURE vlk::CTexture
#else // USE_OPENGL_DRIVER
  #define DTEXTURE ogl::CTexture
#endif // ifdef

namespace cym {
  class CCore;
  class CRenderSystem;
  class CSystem;
    class CConsole;    // a system that outputs all posted messages, also sends messages (like commands)
    // cinematics      // a system that sends messages like rotate(object)+move(camera)
    // replay/recorder // a system that records messages to be played back
  class CScene;
  class CMessage;
  class CMessenger;    // threading: should decide on which thread a CSystem should process a message
  class CRenderer;
  class CCamera;
  class CLight;
  class CColor;
  class CGeometryBuffer;
  class CGeometryInput;
  class CMesh;
  class CParticle;
  class CCluster; // a group of CGeometry, CParticle...
  class CInstance;
  class CResource;
    class CGeometry; // a group of CMesh
    class CTexture;
    class CChannel;
    class CMaterial;
    class CAnimation;
    class CShader;
    class CSkeleton; //-on
  class CResourceLoader;
    class CGeometryLoader;
    class CMeshLoader;
    class CMaterialLoader;
    class CTextureLoader;
  class CResourceManager;
    class CTextureManager;
    class CGeometryManager;
    class CShaderManager;
  class CObject;
    class CTexture;
    class CBuffer;
      class CDataBuffer;
        class CVertexBuffer;
        class CIndexBuffer;
  class CVertexArray;
  class CVertexLayout;
  class CUniform;
  class CFile;
  class CCodecManager;
  class CCodec;
    class CTextureCodec;
      class CDDSCodec;
      class CTGACodec;
      class CPNGCodec;
      class CJPGCodec;
      class CKTXCodec;
    class CGeometryCodec;
      class CDAECodec;
      class COBJCodec;
      class CMD5Codec;

  class CDrawable;
  class CDrawcall;
      
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  using PShaderManager = cym::CShaderManager;
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  using log = sys::log;
  
  using byte   = sys::byte;
  using ubyte  = sys::ubyte;
  using tiny   = sys::tiny;
  using utiny  = sys::utiny;
  using ushort = sys::ushort;
  using uint   = sys::uint;
  using ulong  = sys::ulong;
  
  using CString     = sys::CString;
  template<typename V> using CSet    = sys::CSet<V>;
  template<typename K, typename V> using CMap  = sys::CMap<K,V>;
  template<typename V> using CVector = sys::CVector<V>;
  
  using string = sys::string;
  using rgb    = glm::vec3;
  using rgba   = glm::vec4;
  using color  = glm::vec4;
  
  union pixel { union rgb { sys::uint rgba; struct { sys::ubyte r, g, b, a; }; }; union bgr { sys::uint bgra; struct { sys::ubyte b, g, r, a; }; }; };
  
  const glm::vec3 RED   {glm::vec3{1.f,0.f,0.f}};
  const glm::vec3 GREEN {glm::vec3{0.f,1.f,0.f}};
  const glm::vec3 BLUE  {glm::vec3{0.f,0.f,1.f}};
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  enum class EPolymode { POINT = 0b001, WIRE = 0b010, SOLID = 0b100, };
  
  enum class ECulling { NONE, CLOCKWISE, CW = CLOCKWISE, COUNTERCLOCKWISE, CCW = COUNTERCLOCKWISE, };
  
  enum class EAnimation { LINEAR = 0, EASE_IN, EASE_OUT, EASE_IN_OUT, BOUNCE, ELASTIC };
  
  enum class EPrimitive { TRIANGLES = GL_TRIANGLES, TRIANGLE_STRIP, TRIANGLE_FAN, TRIANGLE_ADJACENCY, LINES = GL_LINES, LINE_STRIP, LINE_LOOP, LINE_ADJACENCY, POINTS = GL_POINTS };
  
  enum class EType { };

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  enum Key {
    NONE,
    A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,
    K0, K1, K2, K3, K4, K5, K6, K7, K8, K9,
    F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
    UP, DOWN, LEFT, RIGHT,
    SPACE, TAB, SHIFT, CTRL, INS, DEL, HOME, END, PGUP, PGDN,
    BACK, ESCAPE, RETURN, ENTER, PAUSE, SCROLL,
    NP0, NP1, NP2, NP3, NP4, NP5, NP6, NP7, NP8, NP9,
    NP_MUL, NP_DIV, NP_ADD, NP_SUB, NP_DECIMAL, PERIOD,
    EQUALS, COMMA, MINUS,
    OEM_1, OEM_2, OEM_3, OEM_4, OEM_5, OEM_6, OEM_7, OEM_8,
    CAPS_LOCK, ENUM_END
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  struct null { };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  inline void fps(uint& nFPS) { 
    static auto tTimer {sys::CTimer::start()};
    const  auto tElapsed {tTimer.elapsed()};
    tTimer.reset();
    nFPS = 1000 / (tElapsed > 0 ? tElapsed : 1);
  }
  
  inline std::size_t sizeOf(GLenum type) {
    switch(type) {
      case GL_DOUBLE:
        return sizeof(double);
      case GL_UNSIGNED_INT:
      case GL_INT:
      case GL_FLOAT:
        return sizeof(int);
      case GL_UNSIGNED_SHORT:
      case GL_SHORT:
        return sizeof(short);
      case GL_UNSIGNED_BYTE:  
      case GL_BYTE:
        return sizeof(char);
      default:
        return 0;
    }
  }
  
  
// @TODO inline glm::vec4 rgba(glm::float r, glm::float g, glm::float b, glm::float a) { return glm::vec4{r,g,b,a}; }
// @TODO inline glm::vec4 rgba(glm::uint r, glm::uint g, glm::uint b, glm::uint a) { return cym::rgba((float)(r)/255.f, ...)
}

#endif //__cym_hpp__
