#ifndef __cym_cdrawable_hpp__
#define __cym_cdrawable_hpp__

#include "cym/cym.hpp"
#include "cym/CVertexArray.hpp"
#include "cym/CDataBuffer.hpp"

namespace cym {
  class CDrawtask;
  class CDrawcall;
  class CDrawable;
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
// @TODO this should return a drawcall w/ all the info needed
  
  class CDrawtask {
    public:
      bool            mHidden    {false};
      cym::uint       mInstances {1};
      cym::EPrimitive mPrimitive {cym::EPrimitive::TRIANGLES};
      cym::CDrawcall& mDrawcall;
    public:
      inline CDrawtask(cym::CDrawcall& tDrawcall) : mDrawcall{tDrawcall} { }
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CDrawcall {
      cym::PVertexArray mVAO;
      cym::PIndexBuffer mIBO;
      
      GLenum mFrontFace   {GL_CCW};
      GLenum mPolygonMode {GL_TRIANGLES};
      GLenum mCullFace    {GL_BACK};
    public:
      sys::vector<cym::CDrawtask> mDrawtasks;
  };
  
  class CDrawable {
    public:
      virtual void draw() { };
      virtual CDrawcall getDrawcall() { return CDrawcall{}; }
  };
  
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CDebugcall {
    public:
      sys::vector<cym::CDrawtask> mDrawtasks;
  };
  
  class CDebugable {
      
  };
}

#endif //__cym_cdrawable_hpp__

