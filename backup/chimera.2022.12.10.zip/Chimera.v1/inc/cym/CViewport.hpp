#ifndef __cym_cviewport_hpp__
#define __cym_cviewport_hpp__

namespace cym {
  class CViewport { 
      // @todo: a window needs to extend this class if u wanna render something to a window
  };
}

#endif //__cym_cviewport_hpp__
