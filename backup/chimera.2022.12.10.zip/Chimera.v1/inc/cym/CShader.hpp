#ifndef __cym_cshader_hpp__
#define __cym_cshader_hpp__

#include "cym/cym.hpp"
#include "cym/CObject.hpp"
#include "cym/CResource.hpp"
#include "cym/CIdentifier.hpp"
#include "cym/CTexture.hpp"
#include "glm/glm.hpp"
#include "sys/CFile.hpp"
#include "sys/CFolder.hpp"

namespace cym {
  class CShader; typedef sys::ptr<cym::CShader> PShader;
  class CShaderLoader; template<typename T> class TShaderLoader; typedef sys::ptr<cym::CShaderLoader> PShaderLoader;
  class CShaderManager;
  
  template<> class TIdentifier<CShader>; typedef TIdentifier<cym::CShader> CShaderIdentifier;
  
  enum EShader : cym::uint {
      //NONE      = 0b0000'0000,
    VERTEX    = 0b00000010,
    GEOMETRY  = 0b00000100,
    TESSCTRL  = 0b00001000,
    TESSEVAL  = 0b00010000,
    FRAGMENT  = 0b00100000,
    COMPUTE   = 0b01000000,
  };
  
  // identifier //////////////////////////////////////////////////////////////////////////////////////////////////////
  
  template<> class TIdentifier<cym::CShader> : public cym::CIdentifier {
    public:
      enum ELevel : int { NONE = -1, SCOPE = 0, MODE, PHASE, GROUP, TYPE, FLAVOR = 5 };
    protected:
    //sys::string               mString;
      sys::array<sys::string,6> mLevels;
      ELevel                    mLast {ELevel::NONE};
    public: // ctor
      using CIdentifier::CIdentifier;
      inline TIdentifier() { toString(); }
      inline TIdentifier(const sys::array<std::string,6>& tLevels) : mLevels{tLevels} { toString();  }
      inline TIdentifier(const sys::vector<std::string>& tTags) { for (int i = 0, l = tTags.size(); (i < 6) && (i < l); i++) { mLevels[i] = tTags[i]; } toString(); toLast(); }
      inline TIdentifier(const sys::string& s, const sys::string& m="", const sys::string& p="", const sys::string& g="", const sys::string& t="", const sys::string& f="") : mLevels{s,m,p,g,t,f,} { toString(); toLast(); }
    //inline CShaderIdentifier(const sys::string tValue) { parse that string into: scope,mode,phase,group.. }
    public:
      inline bool               operator ==(const TIdentifier& rhs) const { return rhs.getString() == getString(); };
      inline bool               operator !=(const TIdentifier& rhs) const { return rhs.getString() != getString(); };
      inline const sys::string& operator [](const int i) const            { assert(i < 6); return mLevels[i]; }
    protected:
      inline void toString() { setString(sys::string{"shader#s:"}.append(mLevels[SCOPE]).append(".m:").append(mLevels[MODE]).append(".p:").append(mLevels[PHASE]).append(".g:").append(mLevels[GROUP]).append(".t:").append(mLevels[TYPE]).append(".f:").append(mLevels[FLAVOR])); }
      inline void toLast() { for (int i = 0; i < 6; i++) { if (mLevels[i].empty() || mLevels[i].size() == 0) break; mLast = (ELevel)(i); } }
    public: // setters & getters
      inline const bool         hasScope()  const { return mLast > ELevel::NONE; }
      inline const sys::string& getScope()  const { return mLevels[SCOPE]; }
      inline const bool         hasMode()   const { return mLast > ELevel::SCOPE; }
      inline const sys::string& getMode()   const { return mLevels[MODE]; }
      inline const bool         hasPhase()  const { return mLast > ELevel::MODE; }
      inline const sys::string& getPhase()  const { return mLevels[PHASE]; }
      inline const bool         hasGroup()  const { return mLast > ELevel::PHASE; }
      inline const sys::string& getGroup()  const { return mLevels[GROUP]; }
      inline const bool         hasType()   const { return mLast > ELevel::GROUP; }
      inline const sys::string& getType()   const { return mLevels[TYPE]; }
      inline const bool         hasFlavor() const { return mLast > ELevel::TYPE; }
      inline const sys::string& getFlavor() const { return mLevels[FLAVOR]; }
      inline void               setScope(const sys::string& tScope) { mLevels[SCOPE] = tScope; toString(); toLast(); }
      inline ELevel             getLast()   const { return mLast; }
  };
  
  // resources ///////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CShader : public cym::TResource<cym::CShader>, public cym::CObject {
      friend class CUniform;
      friend class CShaderLoader;
      friend class CShaderManager;
      friend class CRenderSystem;
    public:
      using EType = EShader;
    protected:
      GLint                         mType {0};
      sys::table<sys::string,GLint> mUniforms;
      bool                          mTessalated {false};
    public:
      CShader(const cym::TIdentifier<cym::CShader>& ="");
      ~CShader();
    public:
      inline bool isTessellated() const { return mTessalated; }
    public:
      // virtual void bind(CRenderer, CDrawable or CDrawcall);
      // bind(CLight) ?!
      
      void bind(bool state = true) const override;
      // uniforms
      GLint uniform(const sys::string& name);
      void  uniform(const sys::string& name, float x);
      void  uniform(const sys::string& name, float x, float y);
      void  uniform(const sys::string& name, float x, float y, float z);
      void  uniform(const sys::string& name, float x, float y, float z, float w);
      void  uniform(const sys::string& name, const cym::PTexture&);
      void  uniform(const sys::string& name, const glm::vec3& v);
      void  uniform(const sys::string& name, const sys::vector<glm::vec3>& vs);
      void  uniform(const sys::string& name, const glm::mat4& M);
      void  uniform(const sys::string& name, const sys::vector<glm::mat4>& Ms);
      void  sampler(const sys::string& name, GLuint);
      void  sampler(const sys::string& name, const cym::PTexture&);
  };
  
  // loaders /////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CShaderLoader : public cym::TResourceLoader<cym::CShader> {
      friend class CShader;
      friend class CShaderManager;
    protected:
      struct SSource {
        std::string       name;
        GLenum            type;
        GLuint            shader;
        std::string       code;
      };
    protected:
      std::stringstream mStream;
    public:
      using cym::TResourceLoader<cym::CShader>::TResourceLoader;
    public:
      template<typename T, typename... Args> inline static cym::TIdentifier<CShader> identify(const T& tSource, Args&&... args) { return TShaderLoader<T>::identify(tSource, std::forward<Args>(args)...); }
    public:
      inline virtual void load(cym::PShader) { SYS_LOG_NFO("cym::CShaderLoader::load(PShader)::" << this); }
    public:
      inline std::stringstream& getStream() { return mStream; }
  };
  
  template<typename T> class TShaderLoader : public cym::CShaderLoader { 
    public:
      template<typename S, typename... Args> inline static cym::TIdentifier<CShader> identify(const S& tSource, Args&&... args) { throw sys::exception("cym::TShaderLoader<T>::identify(S&,Args&&) NOT implemented!",__FILE__,__LINE__); /*return {};*/ }
  };
  
  template<> class TShaderLoader<sys::path> : public cym::CShaderLoader {
    protected:
      sys::path mPath;
    public:
      using cym::CShaderLoader::CShaderLoader;
      inline TShaderLoader(const sys::path& tPath) : CShaderLoader(identify(tPath)), mPath{tPath} { };
    public:
      static cym::TIdentifier<cym::CShader> identify(const sys::path& tPath);
    public:
      virtual void load(cym::PShader) override;
    public:
      inline sys::path& getPath() { return mPath; }
  };
  
  template<> class TShaderLoader<sys::string> : public cym::CShaderLoader {
    protected:
      sys::string mSource;
    public:
      using cym::CShaderLoader::CShaderLoader;
      inline TShaderLoader(const sys::string& tSource, const cym::TIdentifier<cym::CShader>& tId) : CShaderLoader(identify(tSource,tId)), mSource{tSource} { };
    public:
      inline static cym::TIdentifier<cym::CShader> identify(const sys::string& tSource, const cym::TIdentifier<cym::CShader>& tId) { return tId; }
    public:
      virtual void load(cym::PShader) override;
    public:
      inline sys::string& getSource() { return mSource; }
  };
  
  template<> class TShaderLoader<cym::null> : public cym::CShaderLoader {
    public:
      using cym::CShaderLoader::CShaderLoader;
      inline TShaderLoader(const cym::null& n) : CShaderLoader(identify(n)) { }
    public:
      inline static cym::TIdentifier<CShader> identify(const cym::null& n) { return {}; }
    public:
      virtual void load(PShader) override;
  };
  
  // manager /////////////////////////////////////////////////////////////////////////////////////////////////////////
      
  class CShaderManager : public cym::TResourceManager<cym::CShader>, public sys::TSingleton<cym::CShaderManager> {
      friend class cym::CShader;
      friend class cym::CShaderLoader;
      friend class sys::TSingleton<CShaderManager>;
      using SSource = cym::CShaderLoader::SSource;
    protected:
      sys::string                                           mFolder; // "../../res/shaders"
      cym::PShader                                          mBound;
      sys::map<cym::TIdentifier<cym::CShader>,cym::PShader> mShaders; // map<id,shader> shaders
    protected:
      CShaderManager();
      ~CShaderManager();
    public:
      static const sys::string& getFolder() { return cym::CShaderManager::getSingleton().mFolder; }
    public:
      /* boot up shader manager */
      static void boot(const sys::path& = {"../../res/shaders"});
      /* save shader */
      static void save(cym::PShader);
      /* find shader using hints */
      static cym::PShader find(const cym::TIdentifier<cym::CShader>&);
      /* find & bind shader using identifier */
      static cym::PShader bind(const cym::TIdentifier<cym::CShader>&);
      /* load PShader using a CShaderLoader */
      static cym::PShader load(cym::PShaderLoader pLoader, bool bSearch = true);
      /* load PGeometry using a TGeometryLoader */
      template<typename T> inline static cym::PShader load(sys::ptr<cym::TShaderLoader<T>> pLoader, bool bSearch = true) { return cym::CShaderManager::load(cym::PShaderLoader{pLoader},bSearch); }
      /* load shader and remember it */
      template<typename T, typename... Args> static cym::PShader load(const T& tSource, Args&&... args) {
        static auto& self {CShaderManager::getSingleton()};
        PShader    pShader;
        const auto tId {CShaderLoader::identify(tSource,std::forward<Args>(args)...)};
        // logs
        SYS_LOG_NFO("cym::CShaderManager::load(T&,Args&&) iId=" << tId.getString());
        // find shader by id
        if (!sys::find(/*needle*/tId, /*haystack*/self.mShaders, /*destination*/pShader)) {
          PShaderLoader tLoader{new TShaderLoader<T>{tSource}};
          // this will return an null shader imediatly
          pShader = CShaderManager::load(tLoader, false);
        } 
        // found / return shader
        return pShader;
      }
    public:
      inline static void uniform(const sys::string& name, float x) { cym::CShaderManager::getSingleton().mBound->uniform(name,x); }
      inline static void uniform(const sys::string& name, float x, float y) { cym::CShaderManager::getSingleton().mBound->uniform(name,x,y); }
      inline static void uniform(const sys::string& name, float x, float y, float z) { cym::CShaderManager::getSingleton().mBound->uniform(name,x,y,z); }
      inline static void uniform(const sys::string& name, float x, float y, float z, float w) { cym::CShaderManager::getSingleton().mBound->uniform(name,x,y,z,w); }
      inline static void uniform(const sys::string& name, const glm::mat4& M) { cym::CShaderManager::getSingleton().mBound->uniform(name,M); }
      inline static void uniform(const sys::string& name, const sys::vector<glm::mat4>& Ms) { cym::CShaderManager::getSingleton().mBound->uniform(name,Ms); }
      inline static void uniform(const sys::string& name, const glm::vec3& v) { cym::CShaderManager::getSingleton().mBound->uniform(name,v); }
      inline static void uniform(const sys::string& name, const sys::vector<glm::vec3>& vs) { cym::CShaderManager::getSingleton().mBound->uniform(name,vs); }
  };  
}

#endif //__cym_cshader_hpp__

// @TODO shader manager

// rendering:
  // wireframe
  // 2 sided (back and face)
  // faced (no normal smoothing)
  
// SCOPE:
  // shadow
    // bind shadow fbo
  
  // [forward] color
    // bind output fbo
  
  // [deferred] gbuffer
   // bind geometry fbo
  
  // [deffered] occlusion
    // bind output fbo
    // attach geometry fbo
  
  // [deferred] lighting 
    // bind output fbo
    // attach geometry fbo
    // attach occlussion fbo
    
  
  // output
    // bind 0 fbo
    // attach output fbo 
  
  
  
  


// shaders:
  // null (no color)

  // grid (specific)
  // gizmo (specific)
  // selector (specific)
  
  // debug (frustum,aabb...)
  
  // shadow (fbo/tex)
    // volume / map
    // single / instanced
    // fixed / animated
    
  // geometry:color
    // single / instaced (instances)                       => from loader
    // fixed / animated (animation)                        => from loader 
    // normal / parallax (normal)                          => from renderer
    // flat / gouraud(vertex phong) / phong / blinn-phong /  / lambert / torrance / oren nayar / ward => from renderer
    
  // emitter
    // 
    
  // occlusion + occlusion blur
  
  // motion blur

// combos:
  // shadow:
    // single + fixed    + shadow:map
    // single + fixed    + shadow:volume
    // single + animated + shadow:map
    // single + animated + shadow:volume

  // selector
    // 

  // grid:
    // grid
    
  // color/forward: // TODO tree-like storage structure?! where branches are leed to variations in the shader
    // single    + fixed    + shaded:phong + normal:no
    // single    + fixed    + shaded:phong + normal:map
    // single    + fixed    + shaded:phong + normal:map + parallax:map
    // single    + fixed    + shaded:phong + normal:map + parallax:no  + specular:map   + diffuse:map
    // single    + fixed    + shaded:phong + normal:map + parallax:no  + specular:color + diffuse:map
    // single    + animated + shaded:blinn 
    // single    + animated + shaded:blinn + normal:map
    // instanced + fixed    + shaded:blinn 
    // instanced + fixed    + shaded:blinn + normal:map 
    // instanced + animated + shaded:blinn 
    // instanced + animated + shaded:blinn + normal:map 
    
  // debug:wireframe
    // wireframe + single    + fixed 
    // wireframe + single    + animated 
    // wireframe + instanced + fixed 
    // wireframe + instanced + animated 

  // debug:normals
    // normals + single + fixed
    // normals + single + animated
  
  // debug:cage/aabb & frustum
    // shape:cuboid + positions_from_uniforms 
    
  // debug:icon
    // shape:quad + facing_camera + diffuse_map
