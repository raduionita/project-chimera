#ifndef __cym_cvolume_hpp__
#define __cym_cvolume_hpp__

namespace cym {
  class CVolume {
    public:
      class CChunk {
          
      };
    public:
      class CSurface {
          
      };
  };
}

#endif //__cym_cvolume_hpp__
