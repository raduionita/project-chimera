#ifndef __cym_cevent_hpp__
#define __cym_cevent_hpp__

namespace cym {
  class CEvent {
      // FRAME_EVENT
  };
}

#endif //__cym_cevent_hpp__
