#ifndef __cym_cframebuffer_hpp__
#define __cym_cframebuffer_hpp__

#include "cym/cym.hpp"
#include "cym/CObject.hpp"
#include "cym/CTexture.hpp"

namespace cym {
  class CFramebuffer : public CObject {
      
  };
  
  class CShadowbuffer : public CObject {
      
  };
}

#endif //__cym_cframebuffer_hpp__
