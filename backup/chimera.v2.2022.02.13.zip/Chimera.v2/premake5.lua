workspace "Chimera"
  architecture "x64"
  
  configurations 
  {
    "Debug",
    "Release",
    "Dist"
  }
  
  outputdir = "%{cfg.buildcfg}-%{cfg.system}-%{cfg.architecture}"
  
  project "Chimera"
    location "."
    
    kind "SharedLib"
    language "C++"
    
    targetDir ("bin/" .. outputdir .. "/%{prj.name}")
    objDir ("obj/" .. outputdir .. "/%{prj.name}")


    files
    {
      "%{prj.name}/src/**.hpp" 
      "%{prj.name}/src/**.cpp" 
    }
    
    includedirs 
    {
      "%{prj.name}/vendor/some_third_party_lib"
    }
    
    filter "system:windows"
      cppdialiect "C++17"
      staticruntime "On"
      systemversion "latest"
      
      defines
      {
        "CYM_PLATFORM_WINDOWS",
      }
      
      postbuildcommands
      {
        ("{COPY} %{cfg.buildtarget.relpath} ../bin/" .. outputdir .. "/who_needs_it")
      }
      
    filter "configuration:Debug"
      defines "CYM_DEBUG"
      symbols "On"
      
    filter "configuration:Release"
      defines "CYM_RELEASE"
      optimize "On"
      
    filter "configuration:Dist"
      defines "CYM_DIST"
      optimize "On"
      
    filter { "system:windows", "configuration:Release" }
      buildoptions "/MT"
      
    project "App"
      location "App"
      kind "ConsoleApp"
      language "C++"
      
      targetdir......
      objdir.....
      
      includedirs
      {
        "cym"
      }
      
      links 
      {
        "Chimera"
      }
      
      
 -- premake5.exe vs2017 
      
      
      