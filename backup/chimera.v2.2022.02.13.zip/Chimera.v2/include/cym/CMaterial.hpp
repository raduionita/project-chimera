#include "ngn/ngn.hpp"
#include "ngn/CTexture.hpp"
#include "ngn/CResource.hpp"

namespace cym::ngn {
  class CChannel { };
  class CMaterial { };
  
  class CMaterialLoader { };
  class CChannelLoader { };
  
}