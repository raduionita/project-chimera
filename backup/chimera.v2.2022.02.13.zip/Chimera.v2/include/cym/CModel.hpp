#include "ngn/ngn.hpp"
#include "ngn/CResource.hpp"

namespace cym::ngn {
  class CMesh { };
  
  class CModel : public ngn::CResource {
    protected:
      std::string                                 mName;
      std::map<std::string, sys::TPointer<CMesh>> mMeshes;
    public:
      static CModelManager* getManager() { return CModelManager::getSingleton(); }
  };
  
  class IModel : public ngn::TInstance<CModel> {
    protected:
      std::map<std::string, sys::TPointer<IMesh>> mMeshes;
    public:
      IModel(sys::TPointer<CModel> pModel) : TInstance(pModel) {
        for (auto&& [tName, tMesh] : pModel->mMeshes) 
          mMeshes[tName] = new IMesh{tMesh};
      } 
    public:
      CModel& getModel() { return mInstance; }
  };
 
  
  class CMeshLoader { 
    protected:
      ngn::CMaterialLoader        material;
      struct { uint start, end; } range;
      
  };
  class CModelLoader : public CResourceLoader { 
    public:
      template<typename T> static TModelLoader<T> from(const T& src);
  };
  
  template<typename T> class TModelLoader : public CModelLoader { };
 
  template<> class TModelLoader<sys::CFile> : public CModelLoader {
      struct STexture { std::string file; };
      struct SChannel { STexture texture; ngn::rgba color; float value; }
      struct SMaterial { std::map<std::string, SChannel> channels; };
      struct SMesh { SMaterial material };
    protected:
      ngn::CGeometry                                    mGeometry;
      std::map<std::string, sys::TPointer<CMeshLoader>> mMeshes;
    public:
      static const std::string& genName(const sys::CFile& tFile) { return tFile.path(); }
    public:
      const std::string& getName() const { return genName(mFile); }
      void load(const sys::CFile& tFile) {
        // @todo: open file
        // @todo: extract from file data into this structure
      }
  };
  
  class CMeshManager : public sys::TSingleton<CMeshManager> {
    public:
      static sys::TPointer<CMesh> load(sys::TPointr<CMeshLoader> pLoader) {
        sys::TPointer<CMesh> pMesh = new CMesh{pLoader->getName()};
        
        pLoader->load();
        
        sys::TPointer<CMaterial> pMaterial = CMaterialManager::load(pLoader->material);
        
        pMesh->mMaterial = pMaterial;
        pMesh->mRange = {pLoader->range.start, pLoader->range.end - pLoader->range.start};
        
        return pMesh;
      }
  };
  
  class CModelManager : public ngn::CResourceManager, public sys::TSingleton<CModelManager> {
    private: 
      std::map<std::string, sys::TPointer<CModel>> mModels;
    public:
      static void                  save(CModel*&& pModel);
      static void                  save(sys::TPointer<CModel> pModel);
    public:
      static sys::TPointer<CModel> find(const std:string& name);
    public:
      static sys::TPointer<CModel> load(sys::TPointer<CModelLoader> pLoader) {
        sys::TPointer<CModel> pModel = new CModel{pLoader->getName()};
        
        sys::async([tModel, tLoader](){
        
          tLoader->load();
          
          for (auto&& [sMesh, tMesh] : tLoader->mMeshes) {
            
            sys::TPointer<CMesh> pMesh = CMeshManager::load(tMesh); // ?!?!?!
            pMesh->mParent = pModel;
            tModel->mMeshes[sMesh] = pMesh; // or ->addMesh(sys::TPointer<CMesh>);
          }
          
          tModel->load(tLoader);
          
          CModelManager::save(tModel);
          
        }, sys::EAsync::SPAWN);
        
        
        return pModel;
      }
      static sys::TPointer<IModel> load(const sys::CFile& tFile) {
        
        sys::TPointer<IModel> iModel = new IModel;
        sys::TPointer<CModel> tModel;
        const std::string&    tName  = CModelLoader::name(tFile);
        
        if ((tModel = CModelManager::find(tName)) {
          *iModel = tModel;
        } else {
          sys::TPointer<TModelLoader<sys::CFile>> tLoader = CModelLoader::from(tFile);
          
          /* sys::TPointer<CModel> */             tModel  = CModelManager::load(tLoader);
          
          *iModel = tModel; // @todo: needs some sort of lazy activation // on read check if can load
        }
        
        return iModel;
      }
  };
}

int main() {
  auto pModel = CModelLoader::load("path/to/model.ext");
}