#ifndef _uix_cstylemanager_
#define _uix_cstylemanager_

#include <uix/uix.hpp>

namespace uix
{
  class CStyle;

  class CStyleManager : public core::CClass
  { 
    friend class CStyle;
  
    protected:
    std::vector<uix::CStyle*> mStyles;
    
    public:
    CStyleManager();
    ~CStyleManager();
    
    CStyleManager& operator +=(CStyle*);
    CStyleManager& operator -=(CStyle*);
    CStyle*        operator [](size_t);
    
    public:
    void    addStyle(CStyle*);
    void    delStyle(CStyle*);
  };
}

#include <uix/CStyle.hpp>

#endif // _uix_cstylemanager_

 
