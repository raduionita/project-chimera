#ifndef _uix_cbutton_
#define _uix_cbutton_

#include <uix/CWidget.hpp>

namespace uix
{
  using namespace core;

  class CButton : public CWidget
  {
    protected:
    std::string mCaption;

    public:
    CButton(int, CWidget* parent, const CString&, const SShape& shape = AUTO, int hints = EHint::NONE);
    CButton(     CWidget* parent, const CString&, const SShape& shape = AUTO, int hints = EHint::NONE);
    virtual ~CButton();
    
    public:
    bool init();
    
    protected:
    static WNDPROC          prev;
    static LRESULT CALLBACK proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    
    EType getType() const;
  };
}

#endif // _uix_cbutton_
