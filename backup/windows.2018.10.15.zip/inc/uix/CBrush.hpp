#ifndef _uix_cbrush_
#define _uix_cbrush_

#include <uix/uix.hpp>
#include <uix/CObject.hpp>

namespace uix
{
  class CBrush : public CObject
  {
    enum EType
    {
      SOLID   = 1,
      HATCH   = 2,
      PATTERN = 3,
    };

    private:
    HBRUSH   mHandle;
    EType    mType;
    
    int      mHatch;
    CColor   mColor; // RGB -> COLORREF -> DWORD
    HBITMAP  mBitmap;

    public:
    CBrush(COLORREF lColor = RGB(255, 255, 255))
    : CObject(), mHandle(NULL), mType(EType::SOLID), mHatch(0), mColor(lColor), mBitmap(NULL)
    {
      std::cout << "uix::CBrush::CBrush(lColor)::" << this << std::endl;
    }
    
    CBrush(const CColor& oColor)
    : CObject(), mHandle(NULL), mType(EType::SOLID), mHatch(0), mColor(oColor), mBitmap(NULL)
    {
      std::cout << "uix::CBrush::CBrush(oColor)::" << this << std::endl;
    }

    CBrush(int iHatch, COLORREF lColor) 
    : CObject(), mHandle(NULL), mType(EType::HATCH), mHatch(iHatch), mColor(lColor), mBitmap(NULL)
    {
      std::cout << "uix::CBrush::CBrush(iHatch, lColor)::" << this << std::endl;
    }

    CBrush(HBITMAP hBitmap) 
    : CObject(), mHandle(NULL), mType(EType::PATTERN), mHatch(0), mColor(0), mBitmap(hBitmap)
    {
      std::cout << "uix::CBrush::CBrush(hBitmap)::" << this << std::endl;
    }

    CBrush(const CBrush& that)
    : CObject(), mHandle(NULL), mType(that.mType), mHatch(that.mHatch), mColor(that.mColor), mBitmap(that.mBitmap)
    {
      std::cout << "uix::CBrush::CBrush(brush)::" << this << std::endl;
    }

    ~CBrush()
    {
      std::cout << "uix::CBrush::~CBrush()::" << this << std::endl;
      free();
    }

    CBrush& operator =(const CBrush& that)
    {
      if(this != &that) {
        free();
        //mHandle = that.mHandle;
        mHatch  = that.mHatch;
        mColor  = that.mColor;
        mBitmap = that.mBitmap;
        mType   = that.mType;
      }
      return *this;
    }

    operator HBRUSH()
    {
      init();
      return mHandle;
    }
    
    public:
    bool init()
    {
      if (mHandle != NULL) return true;
      
      switch(mType)
      { 
        case EType::SOLID:   { mHandle = ::CreateSolidBrush(mColor);         break; }
        case EType::HATCH:   { mHandle = ::CreateHatchBrush(mHatch, mColor); break; }
        case EType::PATTERN: { mHandle = ::CreatePatternBrush(mBitmap);      break; }
      }
      
      std::cout << "uix::CBrush::init()" << std::endl;
      return (mHandle != NULL);
    }
    
    bool free()
    {
      if (mHandle != NULL) {
        ::DeleteObject(mHandle);
        mHandle = NULL;
      }
      return true;
    }
  };
}

#endif // _uix_cbrush_
