#ifndef uix_cobjectmanager_
#define uix_cobjectmanager_

#include <uix/uix.hpp>

namespace uix
{
  class CObject;

  class CObjectManager : public core::CClass
  {
    private:
    std::vector<CObject*> mObjects;
    bool                  mInited;
    
    public:
    CObjectManager();
    ~CObjectManager();
    
    CObjectManager& operator +=(CObject*);
    CObjectManager& operator -=(CObject*);
  };
}

#endif // uix_cobjectmanager_
