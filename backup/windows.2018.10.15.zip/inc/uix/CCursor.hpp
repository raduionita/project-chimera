#ifndef _uix_ccursor_
#define _uix_ccursor_

#include <uix/uix.hpp>
#include <uix/CObject.hpp>

namespace uix
{
  class CCursor : public CObject
  {
  
  };
}

#endif // _uix_ccursor_
