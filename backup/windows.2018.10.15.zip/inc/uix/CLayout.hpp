#ifndef _uix_clayout_
#define _uix_clayout_

#include <uix/uix.hpp>
#include <uix/CObject.hpp>

namespace uix
{
  class CWidget;
  class CFrame;
  class CResizeEvent;

  class CLayout : public CObject
  {
    friend class CFrame;
  
    protected:
    bool                  mInited;
    CFrame*               mParent;
    
    std::vector<CWidget*> mWidgets;
    std::vector<CLayout*> mLayouts;
    
    SShape                mShape;
    SRect                 mPadding;
    int                   mHints;

    public:
    CLayout();
    
    CLayout& operator +=(CWidget*);
    
    virtual void init();
    virtual void pack();
    
    void addWidget(CWidget*);
    void addLayout(CLayout*);
    
    void setShape(const SShape&);
    void setPadding(const SRect&);
    void setParent(CFrame*);
  
    virtual bool onSizing(CResizeEvent*);
    virtual bool onResize(CResizeEvent*);
  };

  class CGridLayout : public CLayout
  {
    friend class CFrame;
    
    protected:
    size_t mRows;
    size_t mCols;
    size_t mGap;

    public:
    CGridLayout(size_t rows, size_t cols, size_t gap = 0);
    ~CGridLayout();
    
    public:
    void addWidget(CWidget* element, size_t pos);
    void addWidget(CWidget* element, size_t c, size_t r);

//  size_t getSize() const; // get current occupied size
//  size_t getCapacity() const; // get max size

    void init();
    void pack();
  };

  class CBoxLayout : public CLayout
  { 
    friend class CFrame;
    
    public:
    CBoxLayout();
    ~CBoxLayout();
    
    public:
    void init();
    void pack();
  };  

  class CVBoxLayout : public CBoxLayout
  {
    friend class CFrame;
    
    protected:
    size_t mGap;
    
    public:
    CVBoxLayout(size_t gap = 0);
    ~CVBoxLayout();
    
    public:
    void init();
    void pack();
    
    void setGap(size_t);
  };
  
  class CHBoxLayout : public CBoxLayout
  {
    friend class CFrame;
    
    protected:
    size_t mGap;
    
    public:
    CHBoxLayout(size_t gap = 0);
    ~CHBoxLayout();
    
    public:
    void init();
    void pack();
    
    void setGap(size_t);
  };
};

#endif // _uix_clayout_
