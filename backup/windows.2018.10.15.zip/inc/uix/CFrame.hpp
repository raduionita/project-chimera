#ifndef _uix_cframe_
#define _uix_cframe_

#include <uix/uix.hpp>
#include <uix/CWidget.hpp>

namespace uix
{
  class CLayout;
  class CResizeEvent;

  class CFrame : public CWidget
  {
    protected:
    CLayout*              mLayout;

    public:
    CFrame(int, CWidget* parent, const SShape& shape = AUTO, int hints = EHint::NONE);
    CFrame(     CWidget* parent, const SShape& shape = AUTO, int hints = EHint::NONE);
    ~CFrame();

    public:
    void     setLayout(CLayout*);
    CLayout* getLayout();
    bool     hasLayout() const;
    
    void pack();
    
    virtual bool onSizing(CResizeEvent*);
    virtual bool onResize(CResizeEvent*);
  };
}

#endif // _uix_cframe_
