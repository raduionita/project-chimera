#ifndef _uix_cobject_
#define _uix_cobject_

#include <uix/uix.hpp>

namespace uix
{
  class CObjectManger;

  class CObject : public core::CClass
  {
    friend class CObjectManger;
  
    public:
    const int mId;

    public:
    CObject(int id = ANY);
    virtual ~CObject(); // virtual is a MUST!
    
    CObject(const CObject&);
    
    CObject& operator =(const CObject&);
    
    operator       int();
    operator const int();
    
    private:
    static const int nextId(int id = ANY);
  };
}

#include <uix/CApplication.hpp>

#endif // _uix_cobject_
