#ifndef _uix_capplication_
#define _uix_capplication_

#include <core/CApplication.hpp>

#include <uix/uix.hpp>
#include <uix/CModule.hpp>

extern std::string GetLastErrorString();

namespace uix
{
  class CObject;
  class CStyleManager;
  class CClassManager;
  class CWidgetManager;
  class CEventManager;
  class CObjectManager;

  class CApplication : public core::CApplication, public uix::CModule
  {
    friend class CObject;
    
    public:
    CStyleManager*   mStyleManager;
    CClassManager*   mClassManager;
    CWidgetManager*  mWidgetManager;
    CEventManager*   mEventManager;
    CObjectManager*  mObjectManager;

    public:
    CApplication();
    virtual ~CApplication();

    private:
    bool init();
    bool free();

    public:
    int  run();
    void quit();
    
    CWidgetManager* getWidgetManager();
  };
  
  extern CApplication* app;
}

#define DECLARE_HANDLER(object, method) [object] (uix::CEvent* pEvent) { object->method(pEvent); }

#define DECLARE_APPLICATION(cls)                                                                                       \
INT WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)                        \
{                                                                                                                      \
  auto app   = new cls;                                                                                                \
  INT result = app->run();                                                                                             \
  delete app;                                                                                                          \
  return result;                                                                                                       \
}                                                                                                                     //

#endif // _uix_capplication_
