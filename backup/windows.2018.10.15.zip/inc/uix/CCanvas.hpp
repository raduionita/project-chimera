#ifndef _uix_ccanvas_
#define _uix_ccanvas_

#include <uix/uix.hpp>
#include <uix/CWidget.hpp>

namespace uix
{
  class CCanvas : public CWidget
  {
    protected:
    CContext* mContext;
  
    public:
    CCanvas(int id, CWidget* parent, CContext* context = nullptr) 
    : CWidget(id, parent), mContext(context)
    {
      // ...
    }
    
    CCanvas(CWidget* parent, CContext* context = nullptr) 
    : CCanvas(ANY, parent, context)
    {
      // ...
    }
    
    public:
    bool init()
    {
      HDC     hDC = ::GetDC(mHandle);
      
      static PIXELFORMATDESCRIPTOR pfd = {
        sizeof(PIXELFORMATDESCRIPTOR), // .nSize WORD
        1,                             // .nVersion WORD
        PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_SUPPORT_COMPOSITION | PFD_DOUBLEBUFFER, // window + opengl + double buffering // .dwFlags DWORD
        PFD_TYPE_RGBA,                 // RGBA format // .iPixelType BYTE
        32,                            // color depth // .cColorBits BYTE (8, 16, 24, 32)
        0 , 0, 0, 0, 0, 0,             // ignored // .cRedBits .cRedShift .cGreenBits .cGreenShift .cBlueBits .cBlueShift BYTE
        0, 0,                          // no alpha buffer|shift // .cAlphaBits .cAlphaShift BYTE
        0,                             // no accum buffer // .cAccumBits BYTE
        0, 0, 0, 0,                    // ignored // .cAccumRedBits .cAccumGreenBits .cAccumBlueBits .cAccumAlphaBits BYTE
        16,                            // 16bit depth // .cDepthBits BYTE
        0,                             // no stencil // .cStencilBits BYTE
        0,                             // no aux // .cAuxBuffers BYTE
        PFD_MAIN_PLANE,                // main layer // .iLayerType BYTE
        0,                             // reserved // .bReserved BYTE
        0, 0, 0                        // ignored // .dwLayerMask .dwVisibleMask .dwDamageMask DWORD
      };
      
      INT pf = ::ChoosePixelFormat(hDC, &pfd);
      
      ::SetPixelFormat(hDC, pf, &pfd);
      
      
      // move to context
      if(version.major < 3)
        HGLRC   hRC = ::wglCreateContext(hDC);
      else
        int attribs[] = { WGL_CONTEXT_MAJOR_VERSION, 3, WGL_CONTEXT_MINOR_VERSION 3, WGL_CONTEXT_PROFILE_MASK_ARB, WGL_CONTEXT_CORE_PROFILE_BIT_ARB, 0, 0};
        HGLRC   hRC = ::wglCreateContextAttribs(hDC, 0, attribs);
      
      
      
      WINBOOL bOK = ::wglMakeCurrent(hDC, hRC);
      
      ::ShowWindow(HWND, SW_SHOW);
      ::SetForegroundWindow(HWND);
      ::SetFocus(HWND);
      
      // WS_EX_APPWINDOW & WS_POPUP
      ::ShowCursor(FALSE); // on fullscreen
      
      // init gl here
      // log opengl extensions here
      
      
      
      
      
      
      
      ::wglMakeCurrent(NULL, NULL); // release
      ::wglDeleteContext(HGLRC);    // destroy
      ::ReleaseDC(HWND, HDC);
      
      
      mInited = true;
      return mInited;
    }
    
    virtual void onPaint(CPaintEvent*/*pEvent*/)
    {
      // BitBlt()
    }
  };
}

#endif // _uix_ccanvas_
