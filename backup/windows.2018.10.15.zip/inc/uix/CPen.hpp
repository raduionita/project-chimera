#ifndef _uix_cpen_
#define _uix_cpen_

#include <uix/uix.hpp>
#include <uix/CObject.hpp>
#include <uix/CColor.hpp>

namespace uix
{
  class CPen : public CObject
  {
    public:
    enum EType
    {
      SOLID      = PS_SOLID,     // 0
      DASH       = PS_DASH,      // 1
      DOT        = PS_DOT,       // 2
      DASHDOT    = PS_DASHDOT,   // 3
      DASHDOTDOT = PS_DASHDOTDOT // 4
    };
  
    private:
    HPEN   mHandle;
    
    public:
    size_t const mSize;
    EType  const mType;
    CColor const mColor;
    
    public:
    CPen() : CObject(), mHandle(NULL), mSize(12), mType(EType::SOLID), mColor(CColor(RGB(0, 0, 0)))
    {
      std::cout << "uix::CPen::CPen()::" << this << std::endl;
    }
    
    CPen(size_t size, EType type, CColor color) : CObject(), mSize(size), mType(type), mColor(color)
    {
      std::cout << "uix::CPen::CPen(size, type, color)::" << this << std::endl;
      init();
    }
    
    CPen(const CPen& that) : CObject(), mSize(that.mSize), mType(that.mType), mColor(that.mColor)
    {
      std::cout << "uix::CPen::CPen(pen)::" << this << std::endl;
      ::DeleteObject(mHandle);
      init();
    }
    
    ~CPen()
    {
      std::cout << "uix::CPen::~CPen()::" << this << std::endl;
      ::DeleteObject(mHandle);
      mHandle = NULL;
    }
    
    CPen& operator = (const CPen& that)
    {
      if(this != &that)
      {
        const_cast<size_t&>(mSize)  = that.mSize;
        const_cast<EType&>(mType)   = that.mType;
        const_cast<CColor&>(mColor) = that.mColor;
        
        ::DeleteObject(mHandle);
        init();
      }
      return *this;
    }
  
    operator HPEN()
    {
      return mHandle;
    }
    
    operator HPEN() const
    {
      return mHandle;
    }
    
    protected:
    bool init()
    {
      mHandle = ::CreatePen(mType, mSize, (COLORREF)mColor);
      return true;
    }
  };
}

#endif // _uix_cpen_
