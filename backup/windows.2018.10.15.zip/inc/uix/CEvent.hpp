#ifndef _uix_cevent_
#define _uix_cevent_

#include <uix/uix.hpp>

namespace uix
{
  class CWidget;

  class CEvent : public core::CClass
  {
    public:
    EEvent   mType;
    CWidget* mTarget;
    
    public:
    CEvent(EEvent eType = EEvent::_EVENT_) : mType(eType), mTarget(nullptr)
    {
      // ...
    }
  };
  
  class CCommandEvent : public CEvent
  {
    public:
    int      mState;
    CWidget* mControl;
    
    public:
    CCommandEvent(int state) : CEvent(EEvent::COMMAND), mState(state), mControl(nullptr)
    {
      // ...
    }
  };

  class CMouseEvent : public CEvent
  {
    public:
    int       mClientX;
    int       mClientY;
    int       mOriginX;
    int       mOriginY;
    EModifier mModifier;
    
    public:
    CMouseEvent(EEvent eType) : CEvent(eType), mClientX(0), mClientY(0), mOriginX(0), mOriginY(0), mModifier(EModifier::_MODIIER_)
    {
      // ...
    }
  };

  class CPaintEvent : public CEvent
  {
    using CEvent::CEvent;
    
    public:
    CPaintEvent() : CEvent(EEvent::PAINT) { }
  };

  class CResizeEvent : public CEvent
  {
    using CEvent::CEvent;
    
    public:
    int mWidth;
    int mHeight;
    
    public:
    CResizeEvent() : CEvent(EEvent::RESIZE), mWidth(0), mHeight(0) { }
  };

  class CKeyEvent : public CEvent
  {
    public:
    int mKey;
    
    public:
    CKeyEvent(EEvent eType, int nKey) : CEvent(eType), mKey(nKey) { }
  };
}

#endif // _uix_cevent_
