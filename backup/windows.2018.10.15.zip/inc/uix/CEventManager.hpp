#ifndef _uix_ceventmanager_
#define _uix_ceventmanager_

#include <uix/uix.hpp>
#include <uix/CEvent.hpp>

namespace uix
{
  class CEvent;
  class CWidget;

  class CEventManager : public core::CClass
  {
    /*
    typedef std::function<void(CEvent*)> callback_t;
    
    private:
    std::map<int, std::pair<CWidget*, EEvent>> mHandlers;
    std::vector<callback_t>                    mCallbacks;
    */
    
    public:
    CEventManager()
    {
      std::cout << "uix::CEventManager::CEventManager()" << std::endl;
    }
    
    ~CEventManager()
    {
      std::cout << "uix::CEventManager::~CEventManager()" << std::endl;
    }
    
    /*
    void connect(CWidget* pWidget, EEvent eEvent, callback_t&& cCallback)
    {
      std::cout << "uix::CEventManager::connect()" << std::endl;
      mCallbacks.push_back(std::move(cCallback));
      size_t nIndex = mCallbacks.size() - 1;
      mHandlers.insert(std::make_pair(nIndex, std::make_pair(pWidget, eEvent)));
    }
    
    void release(CWidget*, EEvent)
    {
      std::cout << "uix::CEventManager::release()" << std::endl;
    }
    */
    
    template <class T>
    void trigger(T* pEvent)
    {
      std::cout << "uix::CEventManager::trigger()" << std::endl;
      
      // pEvent->
      
      /*
      for(auto it = mHandlers.begin(); it != mHandlers.end(); ++it)
      {
        if(it->second.first == pEvent->mWidget && it->second.second == pEvent->mType)
        {
          callback_t& cCallack = mCallbacks[it->first];
          cCallack(pEvent);
          delete pEvent;
          break;
        }
      }
      */
    }
  };
}

#endif // _uix_ceventmanager_
