#ifndef _uix_cfont_
#define _uix_cfont_

#include <uix/uix.hpp>
#include <uix/CObject.hpp>
#include <uix/CColor.hpp>

namespace uix
{
  class CFont : public CObject
  {
    public:
    enum EWeight
    {
      NORMAL   = FW_NORMAL,
      SEMIBOLD = FW_SEMIBOLD,
      BOLD     = FW_BOLD,
      LIGHT    = FW_LIGHT,
    };
  
    private:
    HFONT mHandle;
    
    public:
    size_t   mSize;
    CString  mFamily;
    EWeight  mWeight;
    CColor   mColor;
    
    public:
    CFont() 
    : CObject(), mHandle(NULL), mSize(12), mFamily("Segoe UI"), mWeight(EWeight::NORMAL), mColor(RGB(255, 255, 255))
    {
      std::cout << "uix::CFont::CFont()::" << this << std::endl;
    }
    
    CFont(size_t size, CString family, EWeight weight, CColor color = RGB(255, 255, 255)) 
    : CObject(), mHandle(NULL), mSize(size), mFamily(family), mWeight(weight), mColor(color)
    {
      std::cout << "uix::CFont::CFont(size, family, weight)::" << this << std::endl;
    }
    
    CFont(const CFont& that) 
    : CObject(), mHandle(NULL), mSize(that.mSize), mFamily(that.mFamily), mWeight(that.mWeight), mColor(that.mColor)
    {
      std::cout << "uix::CPen::CPen(font)::" << this << std::endl;
    }
    
    ~CFont()
    {
      std::cout << "uix::CFont::~CFont()::" << this << std::endl;
      free();
    }
    
    CFont& operator =(const CFont& that)
    {
      if (this != &that)
      {
        free();
        //mHandle = that.mHandle;
        mSize   = that.mSize;
        mFamily = that.mFamily;
        mWeight = that.mWeight;
        mColor  = that.mColor;
      }
      return *this;
    }
  
    operator HFONT()
    {
      init();
      return mHandle;
    }
    
    public:
    bool init()
    {
      if (mHandle != NULL) return true;
      
      int nHeight = -::MulDiv(mSize, ::GetDeviceCaps(::GetDC(NULL), LOGPIXELSY), 72);
      mHandle = ::CreateFont(nHeight, 0,0,0, mWeight,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,VARIABLE_PITCH, mFamily.c_str());
      
      std::cout << "uix::CFont::init() nHeight=" << nHeight << "&mSize=" << mSize << std::endl;
      return (mHandle != NULL);
    }
    
    bool free()
    {
      if (mHandle != NULL) {
        ::DeleteObject(mHandle);
        mHandle = NULL;
      }
      return true;
    }
    
    size_t getSize()
    {
      return mSize;
    }
    
    CString& getFamily()
    {
      return mFamily;
    }
    
    EWeight getWeight()
    {
      return mWeight;
    }
    
    CColor& getColor()
    {
      return mColor;
    }
  };
}

#endif // _uix_cfont_
