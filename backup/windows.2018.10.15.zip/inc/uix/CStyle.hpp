#ifndef _uix_cstyle_
#define _uix_cstyle_

#include <uix/uix.hpp>
#include <uix/CColor.hpp>
#include <uix/CBrush.hpp>
#include <uix/CPen.hpp>
#include <uix/CFont.hpp>
#include <uix/CCursor.hpp>
#include <uix/CIcon.hpp>

namespace uix
{
  class CStyle : public core::CClass
  {
    private:
    CBrush   mBackground;
    CPen     mBorder;
    CColor   mColor;
    CFont    mFont;
    CCursor  mCursor;
    CIcon    mIcon;

    public:
    CStyle();
    CStyle(const CStyle& that);
    ~CStyle();
    
    CStyle& operator =(const CStyle& that);
    CStyle& operator ()(const CStyle& that);
    
    public:
    void     setBackground(const CBrush&);
    void     setColor(const CColor&);
    void     setBorder(const CPen&);
    void     setFont(const CFont&);
    void     setCursor(const CCursor&);
    void     setIcon(const CIcon&);
    
    CBrush&  getBackground();
    CColor&  getColor();
    CPen&    getBorder();
    CFont&   getFont();
    CCursor& getCursor();
    CIcon&   getIcon();
  };
}

#include <uix/CStyleManager.hpp>

#endif // _uix_cstyle_

 
