#ifndef _uix_CPanel_
#define _uix_CPanel_

#include <uix/uix.hpp>
#include <uix/CFrame.hpp>

namespace uix
{
  class CPanel : public CFrame
  {
    public:
    CPanel(int, CWidget*, const SShape& shape = AUTO, int hints = EHint::CHILD);
    CPanel(     CWidget*, const SShape& shape = AUTO, int hints = EHint::CHILD);
    virtual ~CPanel();

    public:
    bool init();
  };
}

#endif // _uix_CPanel_
