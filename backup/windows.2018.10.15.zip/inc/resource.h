#ifndef _app_resource_
#define _app_resource_

#define ID_PAN_TOP    7331
#define ID_BTN_QUIT   1337
#define ID_PAN_BOTTOM 666

#define UIX_COL_DEF_BG      RGB(  0,   0,   0)
#define UIX_COL_DEF_BORDER  RGB( 90,  90,  90)

#define UIX_COL_WND_BORDER  RGB(  5,   5,   5)
#define UIX_COL_WND_BG      RGB( 40,  40,  40)
#define UIX_COL_PNL_BORDER  RGB( 75,  75,  75)
#define UIX_COL_PNL_BG      RGB( 55,  55,  55)
#define UIX_COL_BTN_BORDER  RGB( 90,  90,  90)
#define UIX_COL_BTN_BG      RGB( 45,  45,  45)

#define UIX_SZE_WND_BORDER 1
#define UIX_TYP_WND_BORDER PS_SOLID
#define UIX_SZE_PNL_BORDER 1
#define UIX_TYP_PNL_BORDER PS_SOLID
#define UIX_SZE_BTN_BORDER 1
#define UIX_TYP_BTN_BORDER PS_SOLID

#define UIX_POS_WND_DEFAULT_X  10
#define UIX_POS_WND_DEFAULT_Y  10
#define UIX_SZE_WND_DEFAULT_W 320
#define UIX_SZE_WND_DEFAULT_H 240

#endif // _app_resource_
