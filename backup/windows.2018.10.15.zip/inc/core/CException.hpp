#ifndef _core_cexception_
#define _core_cexception_

#include <core/core.hpp>

#include <exception>
#include <string>

namespace core
{
  class CException : public std::exception
  {
    protected:
    std::string mMessage;

    public:
    CException(const std::string& message) : std::exception(), mMessage(message)
    {
      // do nothing
    }
    
    CException(const std::string& message, const char* file, int line) : std::exception()
    {
      mMessage.append(file);
      mMessage.append(":");
      mMessage.append(std::to_string(line));
      mMessage.append(" ");
      mMessage.append(message);
    }
    
    virtual ~CException()
    {
      // do nothing
    }

    public:
    const char* what() const _GLIBCXX_USE_NOEXCEPT
    {
      return mMessage.c_str();
    }
    
    const char* getMessage() const _GLIBCXX_USE_NOEXCEPT
    {
      return what();
    }
  };
}

#endif // _core_cexception_
