#ifndef _core_
#define _core_

#include <string>

namespace core
{
  typedef char           byte;
  typedef unsigned char  ubyte;
  typedef unsigned short ushort;
  typedef unsigned int   uint;

  typedef std::string    CString;

  class CClass
  {
    public:
    CClass() { }
    virtual ~CClass() { }
  };
}

#endif // _core_
