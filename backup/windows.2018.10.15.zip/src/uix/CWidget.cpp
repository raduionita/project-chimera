#include <uix/CWidget.hpp>
#include <uix/CModule.hpp>
#include <uix/CEventManager.hpp>
#include <uix/CWidgetManager.hpp>

namespace uix
{
  CWidget::CWidget(int id, CWidget* parent/*=nullptr*/, const SShape& shape/*=AUTO*/, int hints/*=NONE*/)
  : CObject(id), mHandle(NULL), mInited(false), mParent(parent), mShape(shape), mHints(hints), mState(EState::_STATE_), mStyle(new CStyle)
  {
    std::cout << "uix::CWidget::CWidget(id, parent, shape)::" << this << std::endl;
    if (mParent != nullptr) mParent->addChild(this);
    
    bool bAutoHeight = (mShape.h == AUTO);
    bool bAutoWidth  = (mShape.w == AUTO);
    mHints  |= (bAutoHeight ? EHint::AUTOHEIGHT : EHint::NONE);
    mHints  |= (bAutoWidth  ? EHint::AUTOWIDTH  : EHint::NONE);
    mShape.x = (mShape.x == AUTO ? ZERO : mShape.x);
    mShape.y = (mShape.y == AUTO ? ZERO : mShape.y);
    mShape.h = (bAutoHeight ? ZERO : mShape.h);
    mShape.w = (bAutoWidth  ? ZERO : mShape.w);
    
    (*uix::app->getWidgetManager()) += this;
  }
  
  CWidget::CWidget(CWidget* parent/*=nullptr*/, const SShape& shape/*=AUTO*/, int hints/*=NONE*/)
  : CWidget(ANY, parent, shape, hints)
  {
    std::cout << "uix::CWidget::CWidget(parent, shape)::" << this << std::endl;
  }

  CWidget::CWidget(const CWidget& that) 
  : CObject(that)
  {
    mHandle = that.mHandle;
    mParent = that.mParent;
    mInited = that.mInited;
    mShape  = that.mShape;
    mStyle  = that.mStyle;
    mHints  = that.mHints;
    mState  = that.mState;
  }

  CWidget::~CWidget()
  {
    std::cout << "uix::CWidget::~CWidget()::" << this << std::endl;
    free();
    (*uix::app->mWidgetManager) -= this;
  }
  
  CWidget& CWidget::operator =(const CWidget& that)
  {
    if(this != &that)
    {
      CObject::operator =(that);
      // continue
      mHandle = that.mHandle;
      mParent = that.mParent;
      mInited = that.mInited;
      mShape  = that.mShape;
      mStyle  = that.mStyle;
      mHints  = that.mHints;
      mState  = that.mState;
    }
    return *this;
  }

  CWidget::operator HWND()
  {
    return mHandle;
  }

  
  
  bool CWidget::init()
  {
    if (!mInited) {
      std::cout << "uix::CWidget::init()::" << this << ":" << mHandle << ":" << mId << std::endl;
      
      mStyle->setBackground(CBrush(RGB(30, 30, 30)));
      mStyle->setFont(CFont(9, "Segoe UI", CFont::NORMAL, CColor(255, 255, 255)));
      
      mInited = true;
    }
    return mInited;
  }
  
  bool CWidget::free()
  {
    std::cout << "uix::CWidget::free()::" << this << std::endl;
    // @todo Move onFree() this to CModule::free() or CWidget::proc() - WinProc
    onFree(); 
    ::DestroyWindow(mHandle);
    mHandle = NULL;
    mInited = false;
    return mInited;
  }
  
  bool CWidget::show()
  {
    std::cout << "uix::CWidget::show()::" << this << ":" << mId << std::endl;
    
    // mInited is changed by init
    mInited || init();
    
    mInited && (bool)::ShowWindow(mHandle, SW_SHOW); // && (bool)::UpdateWindow(mHandle);
    // ::InvalidateRect(mHandle, NULL, FALSE);
    
    return mInited;
  }

  bool CWidget::hide()
  {
    if(mInited)
      ::ShowWindow(mHandle, SW_HIDE);
    return mInited;
  }

  bool CWidget::resize(int w, int h)
  {
    mShape.w = w; 
    mShape.h = h;
    std::cout << "uix::CWidget::resize(" << w << "," << h << ")::" << this << ":" << mId;
    if (mHandle != NULL) {
      RECT sClient, sWindow;
      ::GetClientRect(mHandle, &sClient);
      ::GetWindowRect(mHandle, &sWindow);
      POINT sDiff;
      sDiff.x = (sWindow.right - sWindow.left) - sClient.right;
      sDiff.y = (sWindow.bottom - sWindow.top) - sClient.bottom;
      // compensate for border & frame
      std::cout << " d.x=" << sDiff.x << " d.y=" << sDiff.y << std::endl;
      return (bool)(::SetWindowPos(mHandle, NULL, 0, 0, w + sDiff.x, h + sDiff.y, SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE));
    }
    std::cout << std::endl;
    return false;
  }

  bool CWidget::move(int x, int y)
  {
    mShape.x = x; 
    mShape.y = y;
    std::cout << "uix::CWidget::move(" << x << "," << y << ")::" << this << ":" << mId << std::endl;
    if (mHandle != NULL) {
      return (bool)(::SetWindowPos(mHandle, NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE));
    }
    return false;
  }

  bool CWidget::focus()
  {
    if (mHandle != NULL) ::SetActiveWindow(mHandle);
    return true;
  }

  bool CWidget::fullscreen(bool bEnable = true)
  {
    // @todo finish this
    static WINDOWPLACEMENT wpPrev = { sizeof(WINDOWPLACEMENT) };
    DWORD dwStyle = ::GetWindowLong(mHandle, GWL_STYLE);
    if(dwStyle & WS_OVERLAPPEDWINDOW)
    {
      MONITORINFO mi = { sizeof(MONITORINFO) };
      if(::GetWindowPlacement(mHandle, &wpPrev) && ::GetMonitorInfo(::MonitorFromWindow(mHandle, MONITOR_DEFAULTTOPRIMARY), &mi))
      {
        ::SetWindowLong(mHandle, GWL_STYLE, dwStyle & ~WS_OVERLAPPEDWINDOW);
        ::SetWindowPos(mHandle, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
      }
    }
    else
    {
      ::SetWindowLong(mHandle, GWL_STYLE, dwStyle | WS_OVERLAPPEDWINDOW);
      ::SetWindowPos(mHandle, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
    }
    
    
    /* OR */
    
    if(bEnable)
      return (bool)(::SetWindowPos(mHandle, HWND_TOPMOST, 0, 0, ::GetSystemMetrics(SM_CXSCREEN), ::GetSystemMetrics(SM_CYSCREEN), SWP_SHOWWINDOW));
    else 
      return (bool)(::SetWindowPos(mHandle, NULL, mShape.x, mShape.y, mShape.w, mShape.h, SWP_SHOWWINDOW | SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE)); 
      
    
    // may need ::AdjustWindowRectEx()
    
    return true;
  }
  
  bool CWidget::center()
  {
    HWND hWnd = mParent == nullptr ? ::GetDesktopWindow() : mParent->mHandle;
    RECT sRect;
    ::GetClientRect(hWnd, &sRect);
    
    mShape.x = (sRect.right/2)  - (mShape.w/2);
    mShape.y = (sRect.bottom/2) - (mShape.h/2);
    
    if (mInited) {
      move(mShape.x, mShape.y);
    }
    
    return true;
  }
  
  bool CWidget::is(int hints)
  {
    return (bool)(mHints & hints);
  }
  
  
  void CWidget::setStyle(CStyle* pStyle)
  {
    // mStyle = &(*pStyle)(*mStyle);
    mStyle = pStyle;
  }
  
  CStyle* CWidget::getStyle() const
  {
    return mStyle;
  }
  
  void CWidget::setParent(CWidget* pParent)
  {
    mParent = pParent;
    ::SetParent(mHandle, pParent->mHandle);
  }
  
  CWidget* CWidget::getParent() const 
  {
    return mParent;
  }

  bool CWidget::hasParent() const
  {
    return mParent != nullptr;
  }

  void CWidget::addChild(CWidget* pChild)
  {
    mChildren.push_back(pChild);
  }
  
  CWidget* CWidget::getChild(int id)
  {
    for (CWidget*& pChild : mChildren) {
      if (pChild != nullptr && pChild->mId == id) {
        return pChild;
      }
    }
    throw uix::CException("Child not found!", __FILE__, __LINE__);
  }
  
  
  void CWidget::onInit()
  {
    std::cout << "uix::CWidget::onInit()::" << this << ":" << mId << std::endl;
  };

  void CWidget::onFree()
  {
    std::cout << "uix::CWidget::onFree()::" << this << ":" << mId << std::endl;
  };
  
  bool CWidget::onCommand(uix::CCommandEvent*)  { return false; }
  
  bool CWidget::onButtonDown(uix::CMouseEvent*) { return false; }
  
  bool CWidget::onButtonUp(uix::CMouseEvent*)   { return false; }
  
  bool CWidget::onClick(uix::CMouseEvent*)      { return false; }
  
  bool CWidget::onSizing(uix::CResizeEvent*)    { return false; }
  
  bool CWidget::onResize(uix::CResizeEvent*)    { return false; }
  
  bool CWidget::onPaint(uix::CPaintEvent*)      { return false; }
  
  bool CWidget::onKeyDown(uix::CKeyEvent*)      { return false; }
  
  bool CWidget::onKeyUp(uix::CKeyEvent*)        { return false; }
  
  bool CWidget::onKeyPress(uix::CKeyEvent*)     { return false; }
  
  
  
  LRESULT CALLBACK CWidget::proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) // (void*, uint, uint*, long*)
  {
    CWidget* pWidget = reinterpret_cast<CWidget*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
    if (pWidget == nullptr) return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
  
    switch (uMsg) {
      case WM_NCCREATE: { // non-client (frame) create
        std::cout << hWnd << ":W:WM_NCCREATE" << std::endl;
        break;
      }
      case WM_CREATE: { // called on ::CreateWindow()
        // use this if you want to access CWidget during WM_CREATE
        // added CWidget pointer as user data, to be retrieved on other events
        // CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
        // CWidget* pWidget = reinterpret_cast<CWidget*>(pCreate->lpCreateParams);
        // ::SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)(pWidget));
        std::cout << hWnd << ":W:WM_CREATE:" << wParam << ":" << lParam  << std::endl;
        return 0; // return 0=OK -1=Fail
      }
      case WM_CLOSE: { // called on [x] or window menu [Close] // triggers WM_DESTROY
        std::cout << hWnd << ":W:WM_CLOSE" << std::endl;
        ::PostQuitMessage(0); // sends WM_QUIT message to the loop - indicating that it should be stopped
        break;
      }
      case WM_ACTIVATE:
        std::cout << hWnd << ":W:WM_ACTIVATE" << std::endl;
      break;
      case WM_DESTROY: // called on window destroy (after WM_CLOSE) (this can't be stopped) // do cleanup
        std::cout << hWnd << ":W:WM_DESTROY" << std::endl;
      break;
      case WM_SETFOCUS:
        std::cout << hWnd << ":W:WM_SETFOCUS" << std::endl;
      break;
      case WM_KILLFOCUS:
        std::cout << hWnd << ":W:WM_KILLFOCUS" << std::endl;
      break;
      case WM_SHOWWINDOW:
        std::cout << hWnd << ":W:WM_SHOWWINDOW" << std::endl;
      break;
      case WM_DRAWITEM: { // owner-drawn button. combo-box, list-box or menu
        // wParam : ID of the control that sent the message; 0 for menu
        // lParam : pointer to DRAWITEMSTRUCT
        
        PDRAWITEMSTRUCT pDIS = (PDRAWITEMSTRUCT)lParam;
        HWND hItem = pDIS->hwndItem;
        CWidget* pButton = reinterpret_cast<CWidget*>(::GetWindowLongPtr(hItem, GWLP_USERDATA));
        
        std::cout << hWnd << ":W:WM_DRAWITEM::" << pWidget << ":" << HIWORD(wParam) << ":" << LOWORD(wParam) << "::" << pButton;
        
        if (pDIS->itemState & ODS_DEFAULT)      std::cout << ":ODS_DEFAULT";
        if (pDIS->itemState & ODS_DISABLED)     std::cout << ":ODS_DISABLED";
        if (pDIS->itemState & ODS_FOCUS)        std::cout << ":ODS_FOCUS";
        if (pDIS->itemState & ODS_GRAYED)       std::cout << ":ODS_GRAYED";
        if (pDIS->itemState & ODS_INACTIVE)     std::cout << ":ODS_INACTIVE";
        if (pDIS->itemState & ODS_SELECTED)     std::cout << ":ODS_SELECTED";
        if (pDIS->itemState & ODS_CHECKED)      std::cout << ":ODS_CHECKED";
        if (pDIS->itemState & ODS_COMBOBOXEDIT) std::cout << ":ODS_COMBOBOXEDIT";
        if (pDIS->itemState & ODS_HOTLIGHT)     std::cout << ":ODS_HOTLIGHT";
        if (pDIS->itemState & ODS_NOFOCUSRECT)  std::cout << ":ODS_NOFOCUSRECT";
        
        if (pDIS->itemAction & ODA_DRAWENTIRE)  std::cout << ":ODA_DRAWENTIRE";
        if (pDIS->itemAction & ODA_FOCUS)       std::cout << ":ODA_FOCUS";
        if (pDIS->itemAction & ODA_SELECT)      std::cout << ":ODA_SELECT";
        std::cout << std::endl;
        
        ::InvalidateRect((HWND)(*pButton), NULL, TRUE);
        // ::DrawEdge()
        break;
      }
      case WM_COMMAND: {  // menu selection
        CWidget* pButton = reinterpret_cast<CWidget*>(::GetWindowLongPtr((HWND)lParam, GWLP_USERDATA));
        
        std::cout << hWnd << ":W:WM_COMMAND::" << pWidget << ":" << HIWORD(wParam) << ":" << LOWORD(wParam) << ":" << lParam << std::endl;
        
        bool bHandled = false;
        bool bIsNull  = false;
        CCommandEvent* pEvent = new CCommandEvent(HIWORD(wParam));
        pEvent->mControl = pButton;
        pEvent->mTarget  = pWidget;
        do {
          bIsNull  = pWidget == nullptr;
          bHandled = bIsNull || pWidget->onCommand(pEvent);
          pWidget  = !bIsNull ? pWidget->mParent : nullptr;
        } while (!bHandled);
        delete pEvent;
        
        // HIWORD(wParam) : 0 BN_CLICKED                  // clicked
        //                  5 BN_DBLCLK BN_DOUBLECLICKED  // double clck
        //                  4 BN_DISABLE                  // is disabled
        //                  1 BN_PUSHED BN_HILITE         // pushed  | button down!?
        //                  2 BN_UNPUSHED BN_UNHILITE     // release | button up!?
        //                  1 BN_PAINT                    // button should be painter
        //                  6 BN_SETFOCUS                 // keyboard focus
        //                  7 BN_KILLFOCUS                // left keyboard focus
        // LOWORD(wParam) : button id
        // lParam : button hwnd
        break;
      }
      case WM_MOVING: {
        std::cout << hWnd << ":W:WM_MOVING::" << pWidget << ":" << wParam << std::endl;
      }
      case WM_MOVE: {
        std::cout << hWnd << ":W:WM_MOVE::" << pWidget << ":" << wParam << std::endl;
      }
      case WM_SIZING: {   // while size has changed
        std::cout << hWnd << ":W:WM_SIZING::" << pWidget << ":" << wParam << std::endl;
        CResizeEvent* pEvent = new CResizeEvent;
        pWidget->onSizing(pEvent);
        delete pEvent;
        // wParam: 8 WMSZ_BOTTOMRIGHT (edge of the window being sized)
        //         7 WMSZ_BOTTOMLEFT
        //         6 WMSZ_BOTTOM
        //         5 WMSZ_TOPRIGHT
        //         4 WMSZ_TOPLEFT
        //         3 WMSZ_TOP
        //         2 WMSZ_RIGHT
        //         1 WMSZ_LEFT
        // lParam: LRECT (w/ screen coord of the drag rect) (change this rect to change drag rect)
        break;
      }
      case WM_SIZE: {     // after size has changed
        std::cout << hWnd << ":W:WM_SIZE::" << pWidget << ":" << wParam << " w=" << LOWORD(lParam) << " h=" << HIWORD(lParam) << std::endl;
      
        CResizeEvent* pEvent = new CResizeEvent;
        pEvent->mTarget   = pWidget;
        pEvent->mWidth    = static_cast<int>(LOWORD(lParam));
        pEvent->mHeight   = static_cast<int>(HIWORD(lParam));
        pWidget->mShape.w = (pWidget->mShape.w == AUTO) ? AUTO : pEvent->mWidth;
        pWidget->mShape.h = (pWidget->mShape.h == AUTO) ? AUTO : pEvent->mHeight;
        pWidget->onResize(pEvent);
        delete pEvent;
        // wParam: 4 SIZE_MAXHIDE   to all popup when other window is maximized
        //         3 SIZE_MAXIMIZED the window has been maximized
        //         2 SIZE_MAXSHOW   to all pupup when other window has been restored
        //         1 SIZE_MINIMIZED the window has been minimized
        //         0 SIZE_RESOTRED  resized (but not minimized or maximized)
        // LOWORD(lParam): width  (client area)
        // HIWORD(lParam): height (client area)
        break;
      }
      //case WM_MOUSEHOVER:
      //case WM_MOUSELEAVE: // requires ::TrackMouseEvent(TRACKMOUSEEVENT)
      case WM_LBUTTONDOWN: {
        std::cout << hWnd << ":W:WM_LBUTTONDOWN::" << pWidget << ":" << wParam << ":x="<< LOWORD(lParam) << ":y=" << HIWORD(lParam) << std::endl;
        
        bool bHandled       = false;
        bool bIsNull        = false;
        CMouseEvent* pEvent = new CMouseEvent(EEvent::LBUTTONDOWN);
        pEvent->mClientX    = GET_X_LPARAM(lParam);
        pEvent->mClientY    = GET_Y_LPARAM(lParam);
        pEvent->mOriginX    = pWidget->mShape.x + pEvent->mClientX;
        pEvent->mOriginY    = pWidget->mShape.y + pEvent->mClientY;
        pEvent->mTarget     = pWidget;
        do {
          bIsNull  = pWidget == nullptr;
          bHandled = bIsNull || pWidget->onButtonDown(pEvent);
          if (!bIsNull) pWidget->mState |= EState::PUSHED; // add pushed
          // try parent widget
          pWidget  = !bIsNull ? pWidget->mParent : nullptr;
        } while (!bHandled);
        delete pEvent;
        break;  
        // wParam: 0x0002 MK_RBUTTON  (virtual keys)
        //         0x0004 MK_SHIFT
        //         0x0008 MK_CONTROL
        //         0x0010 MK_MBUTTON
        //         0x0020 MK_XBUTTON1
        //         0x0040 MK_XBUTTON2
        // LOWORD(lParam): x mouse position (reltive to the upper left conner of the client area)
        // HIWORD(lParam): y mouse position
      }
      case WM_LBUTTONUP: {
        std::cout << hWnd << ":W:WM_LBUTTONUP::" << pWidget << ":" << wParam << ":x="<< LOWORD(lParam) << ":y=" << HIWORD(lParam) << std::endl;
        
        bool bHandled       = false;
        bool bIsNull        = false;
        CMouseEvent* pEvent = new CMouseEvent(EEvent::LBUTTONUP);
        pEvent->mClientX    = GET_X_LPARAM(lParam);
        pEvent->mClientY    = GET_Y_LPARAM(lParam);
        pEvent->mOriginX    = pWidget->mShape.x + pEvent->mClientX;
        pEvent->mOriginY    = pWidget->mShape.y + pEvent->mClientY;
        pEvent->mModifier   = (EModifier)(wParam);
        pEvent->mTarget     = pWidget;
        do {
          bIsNull  = pWidget == nullptr;
          bHandled = bIsNull || pWidget->onButtonUp(pEvent);
          bool bPushed    = !bIsNull && (bool)(pWidget->mState & EState::PUSHED); // is pushed
          if (bIsNull) pWidget->mState &= ~EState::PUSHED; // remove pushed
          bHandled = bPushed && pWidget->onClick(pEvent);
          // try parent widget
          pWidget  = !bIsNull ? pWidget->mParent : nullptr;
        } while (!bHandled);
        // try to trigger click
        pEvent->mType = EEvent::CLICK;
        delete pEvent;
        // @todo Trigger click event
        // @todo Clear all other m_down states here
        
        // x = GET_X_LPARAM(lParam) // LOWORD(lParam)
        // y = GET_Y_LPARAM(lParam) // HIWORD(lParam)
        // wParam & MK_CONTROL // MK_SHIFT
      }
      //case WM_LBUTTONDBLCLK
      //case WM_RBUTTONUP
      case WM_KEYDOWN: {
        std::cout << hWnd << ":W:WM_KEYDOWN::" << pWidget << ":" << wParam << ":" << lParam << std::endl;
        break;
        // HWND hFocused = ::GetFocus(void);        // get handle to current keyboard focused window
        // HWND hActive  = ::GetActiveWindow(void); // get handle to current active window
        
        // wParam: virtual key code 
        // lParam: 00-15 bits: repeat count of the current key (user holds key pressed)
        //         16-23 bits: scan code (OEM)
        //            24 bit : extended key? (right ALT, CTRL) (for 101,102 key keyboard)
        //         25-28 bits: reserved (DO NOT USE)
        //            29 bit : context code (0 for WM_KEYDOWN)
        //            30 bit : prev key state (1 down, 0 up) (1 if down was already pressed)
        //            31 bit : transition state (0 for WM_KEYDOWN)
        // return 0; if message was processed
      };
      case WM_KEYUP: {
        std::cout << hWnd << ":W:WM_KEYUP::" << pWidget << ":" << wParam << ":" << (lParam & 0x00FF0000) << std::endl;
        break;
        // wParam: virtual key code 
        // lParam: 00-15 bits: repeat count (1 for WM_KEYUP)
        //         16-23 bits: scan code (OEM)
        //            24 bit : extended key? (right ALT, CTRL) (for 101,102 key keyboard)
        //         25-28 bits: reserved (DO NOT USE)
        //            29 bit : context code (0 for WM_KEYUP)
        //            30 bit : prev key state (1 for WM_KEYUP)
        //            31 bit : transition state (1 for WM_KEYUP)
        // return 0; if message was processed
      }
      //case WM_NOTIFY:      // sent by common control to parent when an event has occurred
      case WM_ERASEBKGND: {    // when window bg redrawn (ex on BeginPaint)
        std::cout << hWnd << ":W:WM_ERASEBKGND::" << pWidget << ":" << pWidget->mId << std::endl;
        UNREFERENCED_PARAMETER(lParam); // worn compiler that this is unused
        break;
      }
      case WM_NCPAINT: { // non-client (area) paint // paint your own frame, border, titlebar
        break; // disabled
        //::DefWindowProc(hWnd, uMsg, wParam, lParam);
        std::cout << hWnd << ":W:WM_NCPAINT::" << pWidget;
        
        RECT   sRect;
        HDC    hDC        = ::GetDCEx(hWnd, (HRGN)(wParam), DCX_WINDOW|DCX_CACHE|DCX_INTERSECTRGN|DCX_LOCKWINDOWUPDATE);
        /* WINBOOL bOk = */ ::GetWindowRect(hWnd, &sRect);
        HBRUSH hThisBrush = ::CreateSolidBrush(RGB(255, 0, 0));
        HPEN   hThisPen   = ::CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
        ::SelectObject(hDC, hThisBrush);
        ::SelectObject(hDC, hThisPen);
        ::Rectangle(hDC, 0, 0, sRect.right-sRect.left, sRect.bottom-sRect.top);
        ::DeleteObject(hThisBrush);
        ::DeleteObject(hThisPen);
        ::ReleaseDC(hWnd, hDC);
        
        std::cout << " l=" << sRect.left << " t=" << sRect.top << " r=" << sRect.right << " b=" << sRect.bottom << std::endl;
        //::RedrawWindow(hWnd, &sRect, (HRGN)(wParam), RDW_UPDATENOW);
        return 0; // prevent default draw 
      }
      case WM_PAINT: {
        std::cout << hWnd << ":W:WM_PAINT::" << pWidget << ":" << pWidget->mId << std::endl;
        UNREFERENCED_PARAMETER(lParam); 
        UNREFERENCED_PARAMETER(wParam); 
        
        PAINTSTRUCT sPS;
        HDC         hDC = ::BeginPaint(hWnd, &sPS);
        RECT        sRect;
        // select brush & pen
        HBRUSH hThisBrush = (HBRUSH)(pWidget->getStyle()->getBackground()); // ::GetStockObject(NULL_BRUSH) for no fill Rectangle
        HPEN   hThisPen   =   (HPEN)(pWidget->getStyle()->getBorder());     // PS_NULL for Rectangle w/ no border
        HBRUSH hPrevBrush = (HBRUSH)(::SelectObject(hDC, hThisBrush));
        HPEN   hPrevPen   =   (HPEN)(::SelectObject(hDC, hThisPen));
        ::GetClientRect(hWnd, &sRect);
        // ::SetMapMode(hDC, MM_ANISOTROPIC)
        // ::SetWindowExtEx(hDC, 100, 100, NULL)
        // ::SetViewportExtEx(hDC, sRect.right, sRect.bottom, NULL);
        ::Rectangle(hDC, sRect.left, sRect.top, sRect.right, sRect.bottom); // draw a rectangle outlined (pen) & filled (brush)
        // restore previous brush (don't delete here, gets deleted by CObjectManager)
        ::SelectObject(hDC, hPrevBrush);
        ::SelectObject(hDC, hPrevPen);
        // trigger paint event
        auto pEvent = new CPaintEvent;
        pEvent->mTarget = pWidget;
        pWidget->onPaint(pEvent);
        delete pEvent;
        // done
        ::EndPaint(hWnd, &sPS);
        
        // if   res == true  return 0
        // else res == false break
        // wParam & lParam = NOT USED
        
        // ::BitBlt() // or something similar to copy from renderer to here
        break;
      }
    }
    
    return ::DefWindowProc(hWnd, uMsg, wParam, lParam); // "For all message I did not handle above, do nothing!"
  }
}
