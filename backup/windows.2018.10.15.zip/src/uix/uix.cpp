#include <uix/uix.hpp>

namespace uix
{
  CString T(const char* text)
  {
    return CString(text);
  }

  CString T(int num)
  {
    return std::to_string(num);
  }
}
