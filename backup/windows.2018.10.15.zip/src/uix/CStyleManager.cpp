#include <uix/CStyleManager.hpp>

#include <algorithm>

namespace uix
{
  CStyleManager::CStyleManager()
  {
    std::cout << "uix::CStyleManager::CStyleManager()" << std::endl;
/*
    CStyle* pDialog    = new CStyle(*pWidget);

    CStyle* pCheckbox  = new CStyle(*pButton);
    CStyle* pRadiobox  = new CStyle(*pButton);
    CStyle* pEdit      = new CStyle(*pWidget);
    CStyle* pCombobox  = new CStyle(*pWidget);   // <select>
    CStyle* pListbox   = new CStyle(*pCombobox); // <select multiple>
    CStyle* pScrollbar = new CStyle(*pWidget);
*/
  }

  CStyleManager::~CStyleManager()
  {
    std::cout << "uix::CStyleManager::~CStyleManager()" << std::endl;
    
    for(CStyle* pStyle : mStyles)
    {
      delete pStyle;
      pStyle = nullptr;
    }
  }
  
  CStyleManager& CStyleManager::operator +=(CStyle* pStyle)
  {
    for(CStyle*& pLeft : mStyles)
    {
      if(pLeft == nullptr)
      {
        pLeft = pStyle;
        return *this;
      }
    }
    mStyles.push_back(pStyle);
    return *this;
  }
  
  CStyleManager& CStyleManager::operator -=(CStyle* pStyle)
  {
    for(size_t i = 0, l = mStyles.size(), h = l / 2; i < l; i++)
    {
      if(i > h)
        break;
    
      CStyle*& pLeft  = mStyles[i];
      CStyle*& pRight = mStyles[l-1-i];
      if(pLeft == pStyle)
      {
        pLeft = nullptr;
        break;
      } 
      else if(pRight == pStyle) 
      {
        pLeft = nullptr;
        break;
      }
    }
    return *this;
  }

  void CStyleManager::addStyle(CStyle* pStyle)
  {
    // add to first open spece
  }
  
  void CStyleManager::delStyle(CStyle* pStyle)
  {
    // mark as nullptr
    // if at the end, consider shrinking the container
  }
}
