#include <uix/CApplication.hpp>
#include <uix/CStyleManager.hpp>
#include <uix/CClassManager.hpp>
#include <uix/CEventManager.hpp>
#include <uix/CWidgetManager.hpp>
#include <uix/CObjectManager.hpp>

std::string GetLastErrorString()
{
  DWORD errid = ::GetLastError();
  if (errid == 0)
    return std::string();

  LPSTR buffer = nullptr;
  size_t size = ::FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                               NULL, errid, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPSTR)&buffer, 0, NULL);

  std::string errmsg(buffer, size);
  ::LocalFree(buffer);
  return errmsg;
}

namespace uix
{
  CApplication* app = nullptr;

  CApplication::CApplication() 
  : core::CApplication(), CModule()
  {
    std::cout << "uix::CApplication::CApplication()::" << this << std::endl;
    uix::app = this;
    mStyleManager  = nullptr;
    mClassManager  = nullptr;
    mEventManager  = nullptr;
    mWidgetManager = nullptr;
    mObjectManager = nullptr;
  }

  CApplication::~CApplication()
  {
    std::cout << "uix::CApplication::~CApplication()" << std::endl;
  }

  bool CApplication::init()
  {
    std::cout << "uix::CApplication::init()" << std::endl;
    
    mStyleManager    = new CStyleManager;
    mClassManager    = new CClassManager;
    mEventManager    = new CEventManager;
    mWidgetManager   = new CWidgetManager;
    mObjectManager   = new CObjectManager;
    
    return CModule::init();
  }

  bool CApplication::free()
  {
    std::cout << "uix::CApplication::free()" << std::endl;
    mRunning = false;
    
    delete mStyleManager;
    delete mClassManager;
    delete mWidgetManager;
    delete mEventManager;
    delete mObjectManager;
    
    return CModule::free();
  }

  int CApplication::run()
  {
    std::cout << "uix::CApplication::run()" << std::endl;

    mRunning = init();

    MSG msg;
    while(mRunning)
    {
      // prevent message clogging (using if)
      while(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE) == TRUE)
      {
        if((mRunning = (msg.message != WM_QUIT)) == false)
          break;
        ::TranslateMessage(&msg);
        ::DispatchMessage(&msg);
      }

      /* OR
      if(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)
      {
        if(msg.message == WM_QUIT)
        {
          break;
        }
        else
        {
          onIdle()
        }
      }
      */

      onIdle(); // game loop
    }

    free();

    return (int)(msg.wParam);
  }

  void CApplication::quit()
  {
    ::PostQuitMessage(0);
  }

  CWidgetManager* CApplication::getWidgetManager()
  {
    return mWidgetManager;
  }
}

/*
// multithread
  // main thread loop
  // while(::GetMessage(&msg, NULL, 0, 0)
  // {
  //   ::TransalateMessage($msg);
  //   ::DispatchMessage($msg);
  // }
  // return (int) msg.wParam;

  // glthread = std::thread(runthread, this)

  // runthread()
  // {
  //   ::wglMakeCurrent(DC, RC); // set RC
  //   while(true)
  //   {
  //     draw();
  //     SwapBuffers();
  //   }
  //   ::wglMakeCurrent(0, 0); // unset RC
  // }
*/
