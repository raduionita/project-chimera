#include <uix/CWidgetManager.hpp>
#include <uix/CWidget.hpp>
#include <uix/CException.hpp>

namespace uix
{
  CWidgetManager::CNode::CNode(CWidget* pWidget/* = nullptr*/, CNode* pNext/* = nullptr*/)
  : mWidget(pWidget), mNext(pNext), mChild(nullptr)
  {
    // ...
  }

  CWidgetManager::CNode::~CNode()
  {
    delete mNext;
    mNext = nullptr;
    delete mChild;
    mChild = nullptr;
  }
    
  CWidgetManager::CWidgetManager() 
  : mRoot(new CNode)
  {
    std::cout << "uix::CWidgetManager::CWidgetManager()" << std::endl;
  }
  
  CWidgetManager::~CWidgetManager()
  {
    std::cout << "uix::CWidgetManager::~CWidgetManager()" << std::endl;
    delete mRoot;
  }
  
  CWidgetManager& CWidgetManager::operator +=(CWidget* pWidget)
  {
    std::cout << "uix::CWidgetManager::operator +=(pWidget)::" << pWidget << ":" << pWidget->mId << std::endl;
    this->insert(pWidget);
    return *this;
  }
  
  CWidgetManager& CWidgetManager::operator -=(CWidget* pWidget)
  {  
    std::cout << "uix::CWidgetManager::operator -=(pWidget)::" << pWidget << ":" << pWidget->mId << std::endl;
    this->remove(pWidget);
    return *this;
  }
  
  void CWidgetManager::travel(const std::function<void(CNode* pNode)>&)
  {
    // ...
  }
  
  void CWidgetManager::insert(CWidget* pWidget)
  {  
    // if root condition - widgets with no parent are top level windows
    if (pWidget->mParent == nullptr) {
      // insert new node at root level
      mRoot->mChild = (new CNode(pWidget, mRoot->mChild)); // main window
      return;
    }
    // need stack to remember where we are - the cpu does something similar during recursion
    std::stack<CNode*> aStack;
    CNode* pThis  = mRoot; // root = null = os
    CNode* pCurr;
    // not much different then a goto:
    while (true) {
      bool bRestart = false; 
      // if no children then advance (no children to check)
      pThis = pThis->mChild ? pThis : pThis->mNext;
      // check children vs parent first
      pCurr = pThis->mChild;
      while (pCurr) { // != nullptr
        // check if child has desired payload - escape condition
        if (pCurr->mWidget == pWidget->mParent) {
          // insert node in front of all the children
          pCurr->mChild = (new CNode(pWidget, pCurr->mChild)); // push front
          return;
        }
        // advance through the chain
        pCurr = pCurr->mNext;
      }
      // re root to check the child's children
      pCurr = pThis->mChild;
      while (pCurr) {
        // only if this->child node has children
        if (pCurr->mChild) {
          // stack next node - to be popped later
          if (pCurr->mNext) { 
            aStack.push(pCurr->mNext);
          }
          // set child as new root
          pThis = pCurr;
          bRestart = true;
          break;
        }
        pCurr = pCurr->mNext; // next
      }
      // restart with child as new root
      if (bRestart) {
        continue;
      }
      // pop from stack - get the next child from the previous node
      if (!aStack.empty()) {
        pThis = aStack.top();
        aStack.pop();
        continue;
      }
      // this should never be reached! - need some code in operator -=
      throw CException(uix::T("Cound not register Widget ") + std::to_string(pWidget->mId) + uix::T(" with Widget Manager!"));
    }
  }
  
  void CWidgetManager::remove(CWidget* pWidget)
  {
//    std::stack<CNode*> aStack;
//    CNode* pThis = mRoot->mChild;
//    CNode* pCurr; // start from 1st child (1st/main window)
    
    // loop until found (then exit method)
    
//    while (true) {
//      bool bRestart = false;
//      
//      
//      
//      
//      
//      
//      
//      // if found, remove node
//      if (pCurr->mWidget == pWidget) {
//        // keep the next one in the chain
//        if (pParent->mChild == pCurr) {
//          pParent->mChild = pCurr->mNext;
//        } else {
//          pPrev->mNext = pCurr->mNext;
//        }
//        // prevent deleting next in the chain
//        pCurr->mNext = nullptr; // !!! ALL children WILL be DELETED
//        // delete node
//        delete pCurr;
//        // we're done
//        return;
//      }
//      
//      
//      
//    }
    
    
    
    
    
    
    
    
    
    
//    
//    while (true) {
//      std::cout << "    " << pCurr->mWidget->mId << std::endl;
//      bool bRestart = false;
//      // if found, remove node
//      if (pCurr->mWidget == pWidget) {
//        // keep the next one in the chain
//        if (pThis->mChild == pCurr) {
//          pThis->mChild = pCurr->mNext;
//        } else {
//          pPrev->mNext = pCurr->mNext;
//        }
//        // prevent deleting next in the chain
//        pCurr->mNext = nullptr; // !!! ALL children WILL be DELETED
//        // delete node
//        delete pCurr;
//        // we're done
//        return;
//      }
//      // start with current's children
//      if (pCurr->mChild) {
//        // remember the next one in the chain
//        if (pCurr->mNext) {
//          aStack.push(pCurr->mNext);
//        }
//        // restart from child
//        pCurr = pCurr->mChild;
//        bRestart = true;
//      }
//      // back to top using 
//      if (bRestart) {
//        continue;
//      }
//      // pop one from the stack, 
//      if (!aStack.empty()) {
//        // these all are mNext nodes
//        pCurr = aStack.top();
//        aStack.pop();
//        continue;
//      }
//      // this should never be reched
//      throw CException(uix::T("Trying to remove an un-managed Widget ") + std::to_string(pWidget->mId));
//    }
  }
  // structure: tree + linked list
  //           O                     O (node)
  //          /
  //         /                       O
  //        O--O--O                 /  (node w/ children)
  //       /
  //      /                       O--O (node w/ siblings)
  //     O--O--O
  //    /     /
  //   /     /
  //  O     O--O

  std::vector<CWidget*> getChildren(CWidget* pParent)
  {
    std::vector<CWidget*> aResult;
    
    return aResult;
  }
}
