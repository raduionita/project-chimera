#ifndef _uix_
#define _uix_

#include <core/core.hpp>

#include <windows.h>
#include <windowsx.h>
#include <winuser.h>
#include <commctrl.h>

#include <iostream>
#include <initializer_list>
#include <cassert>
#include <vector>
#include <map>
#include <algorithm>
#include <cmath>
#include <functional>
#include <stack>
#include <atomic>

#include <resource.h>

// default shapes
#ifndef UIX_DEFAULT_WINDOW_X
  #define UIX_DEFAULT_WINDOW_X       10
#endif // UIX_DEFAULT_WINDOW_X
#ifndef UIX_DEFAULT_WINDOW_Y
  #define UIX_DEFAULT_WINDOW_Y       10
#endif // UIX_DEFAULT_WINDOW_Y
#ifndef UIX_DEFAULT_WINDOW_WIDTH
  #define UIX_DEFAULT_WINDOW_WIDTH  320
#endif // DEFAULT_WINDOW_WIDTH
#ifndef UIX_DEFAULT_WINDOW_HEIGHT
  #define UIX_DEFAULT_WINDOW_HEIGHT 240
#endif // DEFAULT_WINDOW_HEIGHT

// default styles
#ifndef UIX_SZE_WND_BORDER
  #define UIX_SZE_WND_BORDER  1
#endif // UIX_SZE_WND_BORDER
#ifndef UIX_SZE_PNL_BORDER
  #define UIX_SZE_PNL_BORDER  1
#endif // UIX_SZE_PNL_BORDER
#ifndef UIX_SZE_BTN_BORDER
  #define UIX_SZE_BTN_BORDER  1
#endif // UIX_SZE_BTN_BORDER

#ifndef UIX_TYP_WND_BORDER
  #define UIX_TYP_WND_BORDER  PS_SOLID
#endif // UIX_SZE_WND_BORDER
#ifndef UIX_TYP_PNL_BORDER
  #define UIX_TYP_PNL_BORDER  PS_SOLID
#endif // UIX_SZE_PNL_BORDER
#ifndef UIX_TYP_BTN_BORDER
  #define UIX_TYP_BTN_BORDER  PS_SOLID
#endif // UIX_SZE_BTN_BORDER

#ifndef UIX_COL_WND_BORDER
  #define UIX_COL_WND_BORDER  RGB( 70,  70,  70)
#endif // UIX_COL_WND_BORDER
#ifndef UIX_COL_WND_BG
  #define UIX_COL_WND_BG      RGB( 30,  30,  30)
#endif // UIX_COL_WND_BG
#ifndef UIX_COL_PNL_BORDER
  #define UIX_COL_PNL_BORDER  RGB( 70,  70,  90)
#endif // UIX_COL_PNL_BORDER
#ifndef UIX_COL_PNL_BG
  #define UIX_COL_PNL_BG      RGB( 45,  45,  45)
#endif // UIX_COL_PNL_BG
#ifndef UIX_COL_BTN_BORDER  
  #define UIX_COL_BTN_BORDER  RGB( 90,  90,  90)
#endif // UIX_COL_BTN_BORDER
#ifndef UIX_COL_BTN_BG      
  #define UIX_COL_BTN_BG      RGB( 45,  45,  45)
#endif // UIX_COL_BTN_BG

namespace uix
{
  using namespace core;
  
  const int ANY  =     -1;
  const int AUTO = -32768;
  const int ZERO =      0;
  const int EMPTY =     0;
  const int FULL =     -1;
  
  typedef int id_t;

  typedef struct SPoint {
    SPoint(int v = 0) : x(v), y(v) { }
    SPoint(int x, int y) : x(x), y(y) { }
    int x;
    int y;
  } SPoint;

  typedef struct SRect {
    SRect(int v = 0) : l(v), t(v), r(v), b(v) { }
    SRect(int l, int t, int r, int b) : l(l), t(t), r(r), b(b) { }
    int l;
    int t;
    int r;
    int b;
  } SRect;

  typedef struct SSize {
    SSize(int v = 0) : w(v), h(v) { }
    SSize(int w, int h) : w(w), h(h) { }
    int w;
    int h;
  } SSize;

  typedef struct SShape {
    union { struct { int x; int y; }; SPoint xy; };
    union { struct { int w; int h; }; SSize  wh; };
    SShape(int v = 0) : x(v), y(v), w(v), h(v) { }
    SShape(int x, int y, int w, int h) : x(x), y(y), w(w), h(h) { }
    SShape(const SPoint& p, int w, int h) : x(p.x), y(p.y), w(w), h(h) { }
    SShape(int x, int y, const SSize& s) : x(x), y(y), w(s.w), h(s.h) { }
    SShape(const SPoint& p, const SSize& s) : x(p.x), y(p.y), w(s.w), h(s.h) { }
    SShape(const SPoint& p) : x(p.x), y(p.y), w(AUTO), h(AUTO) { }
    SShape(const SSize& s) : x(AUTO), y(AUTO), w(s.w), h(s.h) { }
    operator RECT() { RECT rect = {x, y, x + w, y + h}; return rect; }
    bool operator ==(int v) { return v == x && v == y && v == w && v == h; }
  } SShape;

  typedef SPoint P;
  typedef SRect  R;
  typedef SSize  S;
  typedef SShape G;

  extern CString T(const char* text);
  extern CString T(int num);

  enum EHint
  {
    NONE       = 0b00000000000000000000000000000000, // FRAMELESS
    BORDER     = 0b00000000000000000000000000000001, // WS_BORDER
    TITLE      = 0b00000000000000000000000000000010, // WS_CAPTION + WS_BORDER
    HSCROLL    = 0b00000000000000000000000000000100,
    VSCROLL    = 0b00000000000000000000000000001000,
    FRAME      = 0b00000000000000000000000000010000, // WS_THICKFRAME (resizing border)
    CHILD      = 0b00000000000000000000000000100000,
    GROUP      = 0b00000000000000000000000001000000,
    SYSMENU    = 0b00000000000000000000000010000010, // WS_SYSMENU
    MINIMIZE   = 0b00000000000000000000000100000000,
    MAXIMIZE   = 0b00000000000000000000001000000000,
    SIZER      = 0b00000000000000000000010000000000,
    VISIBLE    = 0b00000000000000000000100000000000,
    HIDDEN     = 0b00000000000000000001000000000000,
    FRAMELESS  = NONE | VISIBLE,             // NONE
    WINDOW     = VISIBLE | BORDER | TITLE | FRAME | SYSMENU | MINIMIZE | MAXIMIZE | SIZER, // WS_OVERLAPPEDWINDOW
#undef ABSOLUTE
#undef RELATIVE
    ABSOLUTE   = 0b00000000000000000010000000000000,
    RELATIVE   = 0b00000000000000000100000000000000,
#define ABSOLUTE 1
#define RELATIVE 2
    LEFT       = 0b00000000000000001000000000000000,
    RIGHT      = 0b00000000000000010000000000000000,
    TOP        = 0b00000000000000100000000000000000,
    BOTTOM     = 0b00000000000001000000000000000000,
    EXPAND     = 0b00000000000010000000000000000000,
    VERTICAL   = 0b00000000000100000000000000000000,
    HORIZONTAL = 0b00000000001000000000000000000000,
    CENTER     = 0b00000000010000000000000000000000,
    AUTOWIDTH  = 0b00000000100000000000000000000000,
    AUTOHEIGHT = 0b00000001000000000000000000000000,
    TOPLEVEL   = 0b00000010000000000000000000000000
  };

  enum EEvent
  {
    _EVENT_ = 0,
    COMMAND = 1,
    CLICK, // PRESS
    LCLICK,
    RCLICK, // CONTEXT (rhs vs lhs)
    LBUTTONUP,
    LBUTTONDOWN,
    RBUTTONDUP,
    RBUTTONDOWN,
    SCROLL,
    PAINT,
    SIZING,
    RESIZE,
    KEYDOWN,
    KEYUP,
    KEYPRESS
  };

  enum EState
  {
    _STATE_   = 0,
    PUSHED    = 0b00000001,
    FOCUSED   = 0b00000100,
    CHECKED   = 0b00010000,
  };
  
  enum EModifier
  {
    _MODIIER_ = 0,
    RBUTTON   = MK_RBUTTON,  //  2
    SHIFT     = MK_SHIFT,    //  4
    CONTROL   = MK_CONTROL,  //  8
    MBUTTON   = MK_MBUTTON,  // 10
    X1BUTTON  = MK_XBUTTON1, // 20
    X2BUTTON  = MK_XBUTTON2  // 40
  };
  
  enum class EWidget : uint
  {
    WIDGET    = 0b0000000000000001,
    STATIC    = 0b0000000000000011,
    WINDOW    = 0b0000000000000101,
    PANEL     = 0b0000000000001001,
    DIALOG    = 0b0000000000010001,
    BUTTON    = 0b0000000000100101,
    CHECKBOX  = 0b0000000001100001,
    RADIOBOX  = 0b0000000010100001,
    COMBOBOX  = 0b0000000100100001,
    EDIT      = 0b0000001000000001,
    LISTBOX   = 0b0000010000000001,
    SCROLLBAR = 0b0000100000000001
  };
}

#endif // _uix_
