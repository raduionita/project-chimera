#ifndef _uix_cwidget_
#define _uix_cwidget_

#include <uix/uix.hpp>
#include <uix/CObject.hpp>
#include <uix/CStyle.hpp>
#include <uix/CEventManager.hpp>

namespace uix
{
  class CModule;
  class CStyle;
  class CWidgetManager;

  class CWidget : public CObject
  {
    friend class CModule;
    friend class CWidgetManager;
    
    public:
    typedef EWidget EType;
    
    protected:
    HWND                  mHandle;
    bool                  mInited;
    
    public:
    CWidget*              mParent;
    std::vector<CWidget*> mChildren;
    SShape                mShape;
    int                   mHints;
    int                   mState;
    CStyle*               mStyle;

    public:
    CWidget(int, CWidget* parent, const SShape& shape = AUTO, int hints = EHint::NONE);
    CWidget(     CWidget* parent, const SShape& shape = AUTO, int hints = EHint::NONE);
    virtual ~CWidget();

    CWidget(const CWidget&);
    CWidget& operator =(const CWidget&);
    operator HWND();
    
    public:
    virtual bool init();
    bool         free();
    bool         show();
    bool         hide();
    bool         resize(int, int);
    bool         move(int, int);
    bool         focus();
    bool         fullscreen(bool);
    bool         center();
    bool         is(int);

    CWidget*     find(int);

    virtual void onInit();
    virtual void onFree();
    virtual bool onCommand(uix::CCommandEvent*);
    virtual bool onButtonDown(uix::CMouseEvent*);    virtual bool onButtonUp(uix::CMouseEvent*);
    virtual bool onClick(uix::CMouseEvent*);
    virtual bool onPaint(uix::CPaintEvent*);
    virtual bool onSizing(uix::CResizeEvent*);
    virtual bool onResize(uix::CResizeEvent*);
    virtual bool onKeyDown(uix::CKeyEvent*);
    virtual bool onKeyUp(uix::CKeyEvent*);
    virtual bool onKeyPress(uix::CKeyEvent*);
    
    HWND     getHandle() const;
    bool     isInited() const;
    void     setStyle(CStyle*);
    CStyle*  getStyle() const;
    void     setParent(CWidget*);
    CWidget* getParent() const;
    bool     hasParent() const;
    void     setShape(SShape);
    SShape   getShape() const;
    void     setHints(int);
    int      getHints() const;
    void     addChild(CWidget*);
    CWidget* getChild(int);
    
    protected:
    static LRESULT CALLBACK proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
  };
}

#endif // _uix_cwidget_
