#ifndef _uix_cwidgetmanager_
#define _uix_cwidgetmanager_

#include <uix/uix.hpp>

namespace uix
{
  class CWidget;
  
  class CWidgetManager : public core::CClass
  {
    class CNode : public core::CClass
    {
      public:
      CWidget* mWidget; // payload
      CNode*   mNext;   // next node in the current level (siblings to this one)
      CNode*   mChild;  // linked list (children nodes)
      
      public:
      CNode(CWidget* pWidget = nullptr, CNode* pNext = nullptr);
      ~CNode();
    };
    
    private:
    CNode* mRoot;
  
    public:
    CWidgetManager();
    ~CWidgetManager();
    
    CWidgetManager& operator +=(CWidget* pWidget);
    CWidgetManager& operator -=(CWidget* pWidget);
  
    public:
    void insert(CWidget* pWidget);
    void remove(CWidget* pWidget);
    void travel(const std::function<void(CNode*)>&);
  };
}

#endif // _uix_cwidgetmanager_
