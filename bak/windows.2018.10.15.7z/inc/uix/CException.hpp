#ifndef _uix_cexception_
#define _uix_cexception_

#include <uix/uix.hpp>
#include <core/CException.hpp>

namespace uix
{
  class CException : public core::CException
  {
    using core::CException::CException;
  };
}

#endif // _uix_cexception_
