#ifndef _uix_cicon_
#define _uix_cicon_

#include <uix/uix.hpp>
#include <uix/CObject.hpp>

namespace uix
{
  class CIcon : public CObject
  {
  
  };
}

#endif // _uix_cicon_
