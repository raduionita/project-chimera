#ifndef _uix_cmodule_
#define _uix_cmodule_

#include <uix/uix.hpp>
#include <uix/CException.hpp>

namespace uix
{
  class CObject;

  class CModule : public core::CClass
  {
    protected:
    HINSTANCE mHandle;
    bool      mInited;

    public:
    CModule();
    virtual ~CModule();
    CModule(const CModule&);
    CModule& operator =(const CModule&);
    operator HINSTANCE();

    protected:
    virtual bool init(); // @todo Register onInit event to be triggered during loop
    virtual bool free(); // @todo Register onFree event

    public:
    virtual void onInit();
    virtual void onFree();
    virtual void onIdle();
  };
}

#include <uix/CObject.hpp>

#endif // _uix_cmodule_
