#ifndef _uix_ccolor_
#define _uix_ccolor_

#include <uix/uix.hpp>

namespace uix
{
  class CColor : public core::CClass // demote to SColor
  {
    public:
    union {
      COLORREF rgb; 
      struct { BYTE r; BYTE g; BYTE b; BYTE a; };
    };
    
    public:
    CColor(COLORREF rgb = 0) : rgb(rgb)
    {
      // ...
    }
    
    CColor(BYTE r, BYTE g, BYTE b, BYTE a = 0) : rgb(RGB(r, g, b))
    {
      // ...
    }
    
    operator COLORREF ()
    {
      return rgb;
    }
    
    operator COLORREF () const
    {
      return rgb;
    }
  };
}

#endif // _uix_ccolor_
