#ifndef _uix_cwindow_
#define _uix_cwindow_

#include <uix/uix.hpp>
#include <uix/CStyle.hpp>
#include <uix/CFrame.hpp>

namespace uix
{
  using namespace core;

  class CWindow : public CFrame
  {
    typedef CFrame super;
    
    public:
    CString mCaption;

    public:
    CWindow(int, CWidget*, const CString&, const SShape& shape = AUTO, int hints = EHint::WINDOW);
    CWindow(     CWidget*, const CString&, const SShape& shape = AUTO, int hints = EHint::WINDOW);
    CWindow(               const CString&, const SShape& shape = AUTO, int hints = EHint::WINDOW);
    virtual ~CWindow();

    public:
    bool init();
    // bool update();
    // bool maximize();
    // bool minimize();
    // bool fullscreen();

    void setTitleBar();
    void setMenuBar();
    void setStatusBar();
    
    EType getType() const;
  };

  /*
  class CProgressBar : public CWidget
  {
    // on change -> ::SendMessage(mHandle, WM_PAINT, NULL, NULL);
  };

  class CMenuBar : public CEventHandler
  {

  };

  class CTitleBar : public CWidget
  {
    private:
    CLayout* mLayout; // default linear layout
  };

  class CStatusBar : public CWidget
  {
    // ...
  };
  */
}

#endif // _uix_cwindow_
