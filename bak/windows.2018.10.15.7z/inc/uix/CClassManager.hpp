#ifndef _uix_cclassmanager_
#define _uix_cclassmanager_

namespace uix
{
  class CClassManager : public core::CClass
  {
    
  };
}

#endif // _uix_cclassmanager_
