#ifndef _MATH_
#define _MATH_

#ifndef PRECISION
  #define PRECISION float
  #define real PRECISION
#endif // REAL

namespace math
{
//  template <typename T>
//  constexpr real operator"" _r(T value)
//  {
//    return real(value);
//  }
//  
//  const real PI     = 3.141592_r;
//  const real PIo180 = PI / 180.0_r;
//  
//  constexpr real operator"" _deg(real degrees) // return radias
//  {
//    return degrees * PIo180;
//  }
}

#endif // _MATH_
