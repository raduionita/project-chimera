#ifndef _core_capplication_
#define _core_capplication_

#include <core/core.hpp>

#include <iostream>

namespace core
{
  class CApplication : public core::CClass
  {
    protected:
    bool mRunning;

    public:
    static CApplication* sInstance;

    public:
    CApplication();
    ~CApplication();

    public:
    virtual int run();
  };
}

#endif // _core_capplication_
