#ifndef _app_cmainwindow_
#define _app_cmainwindow_

#include <uix/CWindow.hpp>
#include <uix/CButton.hpp>
#include <uix/CPanel.hpp>
#include <uix/CEvent.hpp>

namespace app
{
  class CMainWindow : public uix::CWindow
  {
    using uix::CWindow::CWindow;

    public:
    CMainWindow(const std::string&);

    public:
    void onInit();
    
    bool onClick(uix::CMouseEvent*);
    bool onCommand(uix::CCommandEvent*);
  };
}

#endif // _app_cmainwindow_
