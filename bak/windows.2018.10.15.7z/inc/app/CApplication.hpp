#ifndef _app_capplication_
#define _app_capplication_

#include <uix/CApplication.hpp>
#include <app/CMainWindow.hpp>

namespace app
{
  class CApplication : public uix::CApplication
  {
    public:
    void onInit();
  };
}

#endif // _app_capplication_
