#include <app/CApplication.hpp>

DECLARE_APPLICATION(app::CApplication)
