#include <core/CApplication.hpp>

namespace core
{
  CApplication* core::CApplication::sInstance = nullptr;

  CApplication::CApplication() : mRunning(false)
  {
    std::cout << "core::CApplication::CApplication()::" << this << std::endl;
    sInstance = this;
  }

  CApplication::~CApplication()
  {
    std::cout << "core::CApplication::~CApplication()" << std::endl;
  }

  int CApplication::run()
  {
    return 0;
  }
}
