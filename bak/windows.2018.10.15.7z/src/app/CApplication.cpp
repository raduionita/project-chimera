#include <app/CApplication.hpp>
#include <uix/CLayout.hpp>

namespace app
{
  void CApplication::onInit()
  {
    auto pMain  = new app::CMainWindow("Main Window");
    pMain->show();
  }
}
