#include <app/CMainWindow.hpp>
#include <uix/CLayout.hpp>

namespace app
{
  using namespace core;

  CMainWindow::CMainWindow(const CString& caption) : uix::CWindow(caption, uix::AUTO, uix::EHint::NONE|uix::EHint::CENTER)
  {
    std::cout << "app::CMainWindow::CMainWindow(caption)::" << this << ":" << mId << std::endl;
  }

  void CMainWindow::onInit()
  {
    auto pHBox1 = new uix::CHBoxLayout();
      pHBox1->setGap(5);
      pHBox1->setPadding({5, 5, 5, 5});
      auto pPan1 = new uix::CPanel(1111, this, uix::AUTO, uix::EHint::NONE);
        /*auto pBtn1 =*/new uix::CButton(555, pPan1, "Center", uix::S(80, 40), uix::EHint::CENTER);
      pHBox1->addWidget(pPan1);
      auto pVBox1 = new uix::CVBoxLayout();
        pVBox1->setGap(5);
        auto pPan2 = new uix::CPanel(7331, this, uix::AUTO);
          auto pVBox2 = new uix::CVBoxLayout();
            pVBox2->setGap(5);
            pVBox2->setPadding({5, 5, 5, 5});
            pVBox2->addWidget(new uix::CPanel(2222, pPan2, uix::AUTO));
            pVBox2->addWidget(new uix::CButton(999, pPan2, "Right", uix::S(60, 23), uix::EHint::RIGHT));
            pVBox2->addWidget(new uix::CPanel(3333, pPan2, uix::AUTO));
          pPan2->setLayout(pVBox2);
        pVBox1->addWidget(pPan2);
        pVBox1->addWidget(new uix::CButton(1337, this, "Quit", uix::S(120, 40), uix::EHint::CENTER));
        pVBox1->addWidget(new uix::CPanel(666, this, uix::AUTO, uix::EHint::RIGHT));
      pHBox1->addLayout(pVBox1);
    this->setLayout(pHBox1);
  }
  
  bool CMainWindow::onClick(uix::CMouseEvent* pEvent)
  {
    std::cout << "uix::CMainWindow::onClick()::" << pEvent->mTarget->mId << std::endl;
    
    uix::app->quit();
    
    return true;
  }

  bool CMainWindow::onCommand(uix::CCommandEvent* pEvent)
  {
    std::cout << "uix::CMainWindow::onCommand()::" << pEvent->mControl << std::endl;
    return true;
  }
}

/*
// widget class="CWindow|CDialog"
//   widget class="CTitleBar" // horizontal layout
//     widget button app|sys
//     widget text title
//     widget button _
//     widget button []
//     widget button x
//   widget class="CStatusBar" // horizontal layout
//     widget text
//   widget class="CPanel"
//     widget button next
//     widget progressbar
*/
