#include <uix/CObjectManager.hpp>
#include <uix/CObject.hpp>

namespace uix
{
  CObjectManager::CObjectManager()
  {
    std::cout << "uix::CObjectManager::CObjectManager()" << std::endl;
    mInited = true;
  }
  
  CObjectManager::~CObjectManager()
  {
    std::cout << "uix::CObjectManager::~CObjectManager()" << std::endl;
    mInited = false;
    
    for(CObject* pObject : mObjects)
    {
      delete pObject;
      pObject = nullptr;
    }
  }
  
  CObjectManager& CObjectManager::operator +=(CObject* pObject)
  {
    if(mInited == true)
    {
      mObjects.push_back(pObject);
    }
    return *this;
  }
  
  CObjectManager& CObjectManager::operator -=(CObject* pObject)
  {
    if(mInited == true)
    {
      auto it = std::find(mObjects.begin(), mObjects.end(), pObject);
      if(it != mObjects.end())
        mObjects.erase(it);
    }
    return *this;
  }
}
