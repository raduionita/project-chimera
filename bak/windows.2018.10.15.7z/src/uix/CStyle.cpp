#include <uix/CStyle.hpp>

namespace uix
{
  CStyle::CStyle()
  {
    std::cout << "uix::CStyle::CStyle()::" << this << std::endl;
    
    *(uix::app->mStyleManager) += this;
  }

  CStyle::CStyle(const CStyle& that)
  {
    std::cout << "uix::CStyle::CStyle(CStyle&)::" << this << std::endl;
    
    mBackground = that.mBackground;
    mColor      = that.mColor;
    mBorder     = that.mBorder;
    mFont       = that.mFont;
    mCursor     = that.mCursor;
    mIcon       = that.mIcon;
  }
  
  CStyle::~CStyle()
  {
    std::cout << "uix::CStyle::~CStyle()::" << this << std::endl;
    
    //delete mBackground;
    //delete mColor;
    //delete mBorder;
    //delete mFont;
    //delete mCursor;
    //delete mIcon;
    
    *(uix::app->mStyleManager) -= this;
  }
  
  CStyle& CStyle::operator =(const CStyle& that)
  {
    if(this != &that)
    {
      mBackground = that.mBackground;
      mColor      = that.mColor;
      mBorder     = that.mBorder;
      mFont       = that.mFont;
      mCursor     = that.mCursor;
      mIcon       = that.mIcon;
    }
    return *this;
  }

  void CStyle::setBackground(const CBrush& oBrush)
  {
    mBackground = oBrush;
  }
  
  void CStyle::setColor(const CColor& oColor)
  {
    mColor = oColor;
  }
  
  void CStyle::setBorder(const CPen& oPen)
  {
    mBorder = oPen;
  }
  
  void CStyle::setFont(const CFont& oFont)
  {
    mFont = oFont;
  }
  
  void CStyle::setCursor(const CCursor& oCursor)
  {
    mCursor = oCursor;
  }
  
  void CStyle::setIcon(const CIcon& oIcon)
  {
    mIcon = oIcon;
  }
  
  CBrush&  CStyle::getBackground()
  {
    return mBackground;
  }
  
  CColor&  CStyle::getColor()
  {
    return mColor;
  }
  
  CPen&    CStyle::getBorder()
  {
    return mBorder;
  }
  
  CFont&   CStyle::getFont()
  {
    return mFont;
  }
  
  CCursor& CStyle::getCursor()
  {
    return mCursor;
  }
  
  CIcon&   CStyle::getIcon()
  {
    return mIcon;
  }
}
