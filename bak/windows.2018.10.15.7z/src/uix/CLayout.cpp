#include <uix/CLayout.hpp>
#include <uix/CWidget.hpp>
#include <uix/CFrame.hpp>
#include <uix/CPanel.hpp>

namespace uix
{
  CLayout::CLayout() : mInited(false), mParent(nullptr), mShape(0), mPadding(0), mHints(EHint::NONE)
  {
    std::cout << "uix::CLayout::CLayout()" << std::endl;
  }

  bool CLayout::onResize(CResizeEvent* pEvent)
  {
    std::cout << "uix::CLayout::onResize(pEvent):w=" << pEvent->mTarget->mShape.w << ":h=" << pEvent->mTarget->mShape.h << "::" << pEvent->mTarget << std::endl;
    init();
    return true;
  }
  
  bool CLayout::onSizing(CResizeEvent*)
  {
    return true;
  }
  
  void CLayout::addWidget(CWidget* pWidget)
  {
    mWidgets.push_back(pWidget);
  }

  void CLayout::addLayout(CLayout* pLayout)
  {
    CFrame* pDummy = new CFrame(0, nullptr, AUTO, EHint::NONE);
    pDummy->setLayout(pLayout);
    
    mLayouts.push_back(pLayout);
    mWidgets.push_back(pDummy);
  }

  void CLayout::setShape(const SShape& sShape) { mShape = sShape; }

  void CLayout::setPadding(const SRect& sPadding) { mPadding = sPadding; } 
  
  void CLayout::setParent(CFrame* pFrame) { mParent = pFrame; }
  
  void CLayout::init()
  {
    for (CLayout* pLayout : mLayouts) {
      pLayout->init();
    }
    mInited = true;
  }
  
  void CLayout::pack()
  {
    mInited = true;
  }
  
  
  

  CGridLayout::CGridLayout(size_t rows, size_t cols, size_t gap) : CLayout(), mRows(rows), mCols(cols), mGap(gap)
  {
    std::cout << "uix::CGridLayout::CGridLayout()" << std::endl;
    mWidgets.resize(rows * cols, nullptr);
  }
  
  CGridLayout::~CGridLayout()
  {
    std::cout << "uix::CGridLayout::~CGridLayout()" << std::endl;
  }

  void CGridLayout::addWidget(CWidget* element, size_t pos)
  {
    assert(pos < mWidgets.size());
    mWidgets[pos] = element;
  }
  
  void CGridLayout::addWidget(CWidget* element, size_t c, size_t r)
  {
  /*
    assert(pos < mWidgets.size());
    mWidgets[pos] = element;
  */
  }
  
//void CGridLayout::addLayout(CWidget* element, size_t pos);

  void CGridLayout::init()
  {
//    int xoff = (mGap*(mCols-1)/mCols);
//    int yoff = (mGap*(mRows-1)/mRows);
//    
//    int x, y, w, h;
//  
//    SSize sCellSize((pFrame->mShape.w/mCols) - xoff, (pFrame->mShape.h/mRows) - yoff);
//    
//    for(size_t i = 0, r = 0, c = 0; i < mWidgets.size(); i++) {
//      r = i / mCols;
//      c = i % mCols;
//      
//      CWidget* pElement = mWidgets[i];
//      if(pElement != nullptr) {
//      //x = pElement->mShape.x == 0 ? 0           : pElement->mShape.x;
//      //y = pElement->mShape.y == 0 ? 0           : pElement->mShape.y;
//        w = pElement->mShape.w == 0 ? sCellSize.w : pElement->mShape.w;
//        h = pElement->mShape.h == 0 ? sCellSize.h : pElement->mShape.h;
//        
//        x += c * (mGap + sCellSize.w);
//        y += r * (mGap + sCellSize.h);
//        
//        pElement->move(x, y);
//        pElement->resize(w, h);
//      }
//    }
//    
    // sub-layout init
    CLayout::init();
  }
  
  void CGridLayout::pack()
  {
    return;
  /*
    CWidget* pParent  = nullptr;
    CWidget* pElement = nullptr;
    int xoffsets[mCols] = {0};
    int xtemp = 0;
    
    // x offsets
    for(size_t c = 0; c < mCols; c++)
    {
      for (size_t r = 0; r < mRows; r++)
      {
        pElement = mWidgets[r*c]; 
        
        // if pElement != nullptr
        
        xoffsets[c] = std::min(xoffsets[c], std::max(0, pElement->mXY.x));
       
        
        
        xoffsets[c+1] = 0;
      }
    }
    
    
    // position
    for(size_t i = 0, c = 0, r = 0; i < mWidgets.size(); i++)
    {
      r = i / mCols;
      c = i % mCols;
      pElement = mWidgets[i];
      pParent  = pElement->mParent;
      
      
      
      
      pElement->mXY.x += xoffsets[c];
      
      xoffsets[c] = xoffsets[c] < pElement->mXY.x ? xoffsets[c] : pElement->mXY.x;
      
      if((c + 1) < mCols)
      {
        xtemp         = xoffsets[c] + pElement->mXY.x + pElement->mWH.w;
        xoffsets[c+1] = xtemp > xoffsets[c+1] ? xtemp : xoffsets[c+1];
      }
    }
    
    // adjust/fix
    */
  }




  CBoxLayout::CBoxLayout() : CLayout()
  {
    std::cout << "uix::CBoxLayout::CBoxLayout()" << std::endl;
  }
  
  CBoxLayout::~CBoxLayout()
  {
    std::cout << "uix::CBoxLayout::~CBoxLayout()" << std::endl;
  }
  
  void CBoxLayout::init()
  {
    mShape.wh = mParent->is(EHint::TOPLEVEL) || mParent->hasParent() ? 0 : mParent->mShape.wh;
    
    std::cout << "  uix::CBoxLayout::init() " << "x=" << mShape.x << ":y=" << mShape.y << ":w=" << mShape.w << ":h=" << mShape.h << "::" << mParent << ":" << mParent->mId << std::endl;    
    size_t i = 0;
    size_t iTotalCount = mWidgets.size();
    
    int nTotalWidth  = mParent->mShape.w - (mPadding.l + mPadding.r);
    int nTotalHeight = mParent->mShape.h - (mPadding.t + mPadding.b);    
    int x = mPadding.l, y = mPadding.t, w, h, m;
    for (i = 0; i < iTotalCount; i++) {
      CWidget*& pElement = mWidgets[i];
      if ((pElement != nullptr)) {
        w  = (pElement->mHints & EHint::AUTOWIDTH)  ? mParent->mShape.w : pElement->mShape.w;
        h  = (pElement->mHints & EHint::AUTOHEIGHT) ? mParent->mShape.h : pElement->mShape.h;
        
        m  = mPadding.l + nTotalWidth/2 - w/2;
        x  = (pElement->mHints & EHint::CENTER) && (pElement->mHints & EHint::AUTOHEIGHT) ? m : x;
        m  = mPadding.t + nTotalHeight/2 - h/2;
        y  = (pElement->mHints & EHint::CENTER) && (pElement->mHints & EHint::AUTOWIDTH)  ? m : y;
        
        std::cout << "    " << pElement->mId << " resize: w=" << w << ", h=" << h << std::endl;
        std::cout << "    " << pElement->mId << " move  : x=" << x << ", y=" << y << std::endl;
        
        pElement->resize(w, h);
        pElement->move(x, y);
      }
    }
    
    // sub-layout init
    CLayout::init();
  }
  
  void CBoxLayout::pack()
  {
    // ...
  }




  CVBoxLayout::CVBoxLayout(size_t gap) : CBoxLayout(), mGap(gap)
  {
    std::cout << "uix::CVBoxLayout::CVBoxLayout(gap)" << std::endl;
  }

  CVBoxLayout::~CVBoxLayout()
  {
    std::cout << "uix::CVBoxLayout::~CVBoxLayout()" << std::endl;
  }
  
  void CVBoxLayout::setGap(size_t gap) { mGap = gap; }
  
  void CVBoxLayout::init()
  {
    // synced with parent shape // @see ::addLayout()
    mShape = mParent->is(EHint::TOPLEVEL) || mParent->hasParent() ? 0 : mParent->mShape;
    
    std::cout << "  uix::CVBoxLayout::init() " << "x=" << mShape.x << ":y=" << mShape.y << ":w=" << mShape.w << ":h=" << mShape.h << "::" << mParent << ":" << mParent->mId << std::endl;
    
    size_t i = 0;
    size_t iTotalCount = mWidgets.size();
    size_t iAutoCount  = iTotalCount;
    
    int nTotalWidth  = mParent->mShape.w - (mPadding.l + mPadding.r);
    int nTotalHeight = mParent->mShape.h - (mPadding.t + mPadding.b);
    int nAutoHeight  = nTotalHeight;
    
    for (i = 0; i < iTotalCount; i++) {
      CWidget* pElement = mWidgets[i];
      if ((pElement != nullptr) && !(pElement->mHints & AUTOHEIGHT)) {
        nAutoHeight -= pElement->mShape.h;
        iAutoCount--;
      }
    }
    
    SSize sSegment(nTotalWidth, (nAutoHeight - ((iTotalCount-1) * mGap))/iAutoCount);
    
    int x = mPadding.l, y = (mPadding.t + mShape.y), w, h, m;
    for (i = 0; i < iTotalCount; i++) {
      CWidget*& pElement = mWidgets[i];
      if ((pElement != nullptr)) {
        w  = (pElement->mHints & EHint::AUTOWIDTH)  ? sSegment.w : pElement->mShape.w;
        h  = (pElement->mHints & EHint::AUTOHEIGHT) ? sSegment.h : pElement->mShape.h;
        
        m  = mPadding.l + nTotalWidth/2 - w/2;
        x  = (pElement->mShape.x == ZERO)           ? mPadding.l : pElement->mShape.x; // left as default
        x  = (pElement->mHints & EHint::RIGHT)      ? mParent->mShape.w - mPadding.r - pElement->mShape.w : x;
        x  = (pElement->mHints & EHint::AUTOWIDTH)  ? mPadding.l : x;
        x  = (pElement->mHints & EHint::CENTER)     ? m : x;
        x += mShape.x;
        
        std::cout << "    " << pElement->mId << " resize: w=" << w << ", h=" << h << std::endl;
        std::cout << "    " << pElement->mId << " move  : x=" << x << ", y=" << y << std::endl;
        
        pElement->resize(w, h);
        pElement->move(x, y);
        
        y += ((pElement->mHints & EHint::AUTOHEIGHT) ? sSegment.h : pElement->mShape.h) + mGap;
      }
    }
    
    // sub-layout init
    CLayout::init();
  }
  
  void CVBoxLayout::pack()
  {
    // ...
    //::GetTextExtentPoint32(hDC, LPCSTR, INT, LPSIZE);
  }




  CHBoxLayout::CHBoxLayout(size_t gap) : CBoxLayout(), mGap(gap)
  {
    std::cout << "uix::CHBoxLayout::CHBoxLayout(gap)" << std::endl;
  }
  
  CHBoxLayout::~CHBoxLayout()
  {
    std::cout << "uix::CHBoxLayout::~CHBoxLayout()" << std::endl;
  }
  
  void CHBoxLayout::setGap(size_t gap) { mGap = gap; }
  
  void CHBoxLayout::init()
  {
    // synced with parent shape // @see ::addLayout()
    mShape = mParent->is(EHint::TOPLEVEL) || mParent->hasParent() ? 0 : mParent->mShape;
    
    std::cout << "  uix::CHBoxLayout::init() " << "x=" << mShape.x << ":y=" << mShape.y << ":w=" << mShape.w << ":h=" << mShape.h << "::" << mParent << ":" << mParent->mId << std::endl;
    
    size_t iTotalCount = mWidgets.size();
    size_t iAutoCount  = iTotalCount;
    size_t i = 0;
    
    int nTotalWidth  = mParent->mShape.w - (mPadding.l + mPadding.r);
    int nTotalHeight = mParent->mShape.h - (mPadding.t + mPadding.b);
    int nAutoWidth   = nTotalWidth; 
    
    for (i = 0; i < iTotalCount; i++) {
      CWidget* pElement = mWidgets[i];
      // if not auto, remove from auto total width
      if ((pElement != nullptr) && !(pElement->mHints & EHint::AUTOWIDTH)) {
        nAutoWidth -= pElement->mShape.w;
        iAutoCount--;
      }
    }
    
    SSize sSegment((nAutoWidth - ((iTotalCount-1) * mGap))/iAutoCount, nTotalHeight);
    
    int x = (mPadding.l + mShape.x), y = mPadding.t, w, h, m; // element x offset by parent x
    for (i = 0; i < iTotalCount; i++) {
      CWidget*& pElement = mWidgets[i];
      if ((pElement != nullptr)) {
        w  = (pElement->mHints & EHint::AUTOWIDTH)  ? sSegment.w : pElement->mShape.w;
        h  = (pElement->mHints & EHint::AUTOHEIGHT) ? sSegment.h : pElement->mShape.h;

        m  = mPadding.t + nTotalHeight/2 - h/2;
        y  = (pElement->mShape.y == ZERO)           ? m : pElement->mShape.y;
        y  = (pElement->mHints & EHint::BOTTOM)     ? mShape.h - mPadding.b - pElement->mShape.h : y;
        y  = (pElement->mHints & EHint::TOP)        ? mPadding.t                                 : y;
        y  = (pElement->mHints & EHint::AUTOHEIGHT) ? m : y;
        y  = (pElement->mHints & EHint::CENTER)     ? m : y;
        y += mShape.y;
        
        std::cout << "    " << pElement->mId << " resize: w=" << w << ", h=" << h << std::endl;
        std::cout << "    " << pElement->mId << " move  : x=" << x << ", y=" << y << std::endl;
        
        // apply changes
        pElement->resize(w, h); // signal resize
        pElement->move(x, y);   // signal move/reposition
        
        // next x
        x += mGap + ((pElement->mHints & EHint::AUTOWIDTH) ? sSegment.w : pElement->mShape.w);
      }
    }
    
    // sub-layout init
    CLayout::init();
  }
  
  void CHBoxLayout::pack()
  {
    // ...
  }
}
