#include <uix/CButton.hpp>
#include <uix/CEventManager.hpp>
#include <uix/CStyle.hpp>

namespace uix
{
  CButton::CButton(int id, CWidget* parent, const CString& caption, const SShape& shape/*=AUTO*/, int hints/*=NONE*/)
  : CWidget(id, parent, shape, hints), mCaption(caption)
  {
    std::cout << "uix::CButton::CButton(id, parent, " << caption << ", shape)::" << this << std::endl;
  }
  
  CButton::CButton(CWidget* parent, const CString& caption, const SShape& shape/*=AUTO*/, int hints/*=NONE*/)
  : CButton(ANY, parent, caption, shape, hints)
  {
    std::cout << "uix::CButton::CButton(parent, " << caption << ", shape)::Ionita" << this << std::endl;
  }

  CButton::~CButton()
  {
    std::cout << "uix::CButton::~CButton()::" << this << std::endl;
  }

  CWidget::EType CButton::getType() const
  {
    return CWidget::EType::BUTTON;
  }
  
  bool CButton::init()
  {
    if (mInited == false && mHandle == NULL) {
      CWidget::init();
    
      if (mParent == nullptr) {
        ::MessageBox(NULL, "[CButton] No parent no button!!", "Error", 0);
        return false;
      }

      // @todo Consider replacing "Button" with e regular (customizable) (registerable) window class
      
      mHandle = ::CreateWindowEx(
        0,                                                 // ex styles
        "Button",
        mCaption.c_str(),
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_OWNERDRAW | BS_NOTIFY, // styles: BS_OWNERDRAW
        mShape.x, mShape.y,
        mShape.w, mShape.h,
        (HWND)(*mParent),                                  // HWND parent handle
        reinterpret_cast<HMENU>(mId),                      // HMENU or (for non-top-level) child-window id (16bit)
        (HINSTANCE)(*uix::app),
        NULL);

      if (mHandle == NULL) {
        std::cout << ::GetLastErrorString() << std::endl;
        // @todo trigger error event
        ::MessageBox(NULL, "[CButton] CreateWindowEx failed!", "Error", 0);
        return false;
      }

      prev = (WNDPROC) ::SetWindowLongPtr(mHandle, GWLP_WNDPROC,  (LONG_PTR)(&proc)); // (this) requires:
      /* LONG_PTR = */ ::SetWindowLongPtr(mHandle, GWLP_USERDATA, (LONG_PTR)(this)); 
      
      //::SetWindowLongPtr() // changes at the window level 
      //::SetClassLongPtr()  // changes at the class level
      
      // @todo why is this deactivated in <commctrl.h>
      // ::SetWindowSubClass(mHandle, &proc, 1, 0); // (HWND hWnd, SUBCLASSPROC pfnSubclass, UINT_PTR uIdSubclass, DWORD_PTR dwRefData)
      
      { // init button style
        mStyle->setBackground(CBrush(CColor(UIX_COL_BTN_BG)));
        mStyle->setBorder(CPen(UIX_SZE_BTN_BORDER, CPen::SOLID, CColor(UIX_COL_BTN_BORDER)));
      }
      
      onInit();
      
      mInited = true;
    }
    
    return mInited;
  }

  LRESULT CALLBACK CButton::proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)  // (void*, uint, uint*, long*)
  {
    CButton* pButton = reinterpret_cast<CButton*>(::GetWindowLongPtr(hWnd, GWLP_USERDATA));
    
    switch (uMsg) {
      //case WM_NCCREATE: // not fired cause ::SetWindowLongPtr is after ::CreateWindowEx
      //case WM_CREATE:   // not fired cause ::SetWindowLongPtr is after ::CreateWindowEx
      //case WM_MOUSEHOVER:
      //case WM_MOUSELEAVE: // requires ::TrackMouseEvent(TRACKMOUSEEVENT)
      case WM_MOUSEMOVE: {
        std::cout << hWnd << ":B:WM_MOUSEMOVE:" << HIWORD(wParam) << ":" << LOWORD(wParam) << ":" << lParam << std::endl;
        break;
      }
      case WM_SETCURSOR: {
        std::cout << hWnd << ":B:WM_SETCURSOR::" << pButton << ":" << HIWORD(wParam) << ":" << LOWORD(wParam) << ":" << lParam << std::endl;
        if(LOWORD(lParam) == HTCLIENT)
          ::SetCursor(::LoadCursor(NULL, IDC_ARROW));
        return 0;
        break;
      }
      case WM_LBUTTONDOWN: {
        std::cout << hWnd << ":B:WM_LBUTTONDOWN::" << pButton << ":" << wParam << ":x="<< LOWORD(lParam) << ":y=" << HIWORD(lParam) << std::endl;
        CWidget* pWidget = reinterpret_cast<CWidget*>(pButton);
        
        bool bHandled       = false;
        bool bIsNull        = false;
        CMouseEvent* pEvent = new CMouseEvent(EEvent::LBUTTONDOWN);
        pEvent->mClientX    = GET_X_LPARAM(lParam);
        pEvent->mClientY    = GET_Y_LPARAM(lParam);
        pEvent->mOriginX    = pWidget->mShape.x + pEvent->mClientX;
        pEvent->mOriginY    = pWidget->mShape.y + pEvent->mClientY;
        pEvent->mTarget     = pWidget;
        do {
          bIsNull  = pWidget == nullptr;
          bHandled = bIsNull || pWidget->onButtonDown(pEvent);
          if (!bIsNull) pWidget->mState |= EState::PUSHED; // add pushed
          // try parent widget
          pWidget  = !bIsNull ? pWidget->mParent : nullptr;
        } while (!bHandled);
        delete pEvent;
        break;  
        // x = GET_X_LPARAM(lParam) // LOWORD(lParam)
        // y = GET_Y_LPARAM(lParam) // HIWORD(lParam)
        // wParam & MK_CONTROL // MK_SHIFT
      }
      case WM_LBUTTONUP: {
        std::cout << hWnd << ":B:WM_LBUTTONUP::" << pButton << ":" << wParam << ":x="<< LOWORD(lParam) << ":y=" << HIWORD(lParam) << std::endl;
        CWidget* pWidget = reinterpret_cast<CWidget*>(pButton);
        
        bool bHandled       = false;
        bool bIsNull        = false;
        CMouseEvent* pEvent = new CMouseEvent(EEvent::LBUTTONUP);
        pEvent->mClientX    = GET_X_LPARAM(lParam);
        pEvent->mClientY    = GET_Y_LPARAM(lParam);
        pEvent->mOriginX    = pWidget->mShape.x + pEvent->mClientX;
        pEvent->mOriginY    = pWidget->mShape.y + pEvent->mClientY;
        pEvent->mModifier   = (EModifier)(wParam);
        pEvent->mTarget     = pWidget;
        do {
          bIsNull  = pWidget == nullptr;
          bHandled = bIsNull || pWidget->onButtonUp(pEvent);
          bool bPushed    = !bIsNull && (bool)(pWidget->mState & EState::PUSHED); // is pushed
          if (bIsNull) pWidget->mState &= ~EState::PUSHED; // remove pushed
          bHandled = bPushed && pWidget->onClick(pEvent);
          // try parent widget
          pWidget  = !bIsNull ? pWidget->mParent : nullptr;
        } while (!bHandled);
        // try to trigger click
        pEvent->mType = EEvent::CLICK;
        delete pEvent;
        break;
      }
      case WM_ERASEBKGND: {
        std::cout << hWnd << ":B:WM_ERASEBKGND::" << pButton << ":" << pButton->mId << std::endl;
        UNREFERENCED_PARAMETER(lParam); // worn compiler that this is unused
        break;
      };
      case WM_NCPAINT: {
        break;
        std::cout << hWnd << ":B:WM_NCPAINT::" << pButton << ":" << pButton->mId << std::endl;
      };
      case WM_PAINT: {
        std::cout << hWnd << ":B:WM_PAINT::" << pButton << ":" << pButton->mId << std::endl;
        UNREFERENCED_PARAMETER(wParam); // worn compiler that this is unused
        UNREFERENCED_PARAMETER(lParam); // worn compiler that this is unused
        // coordonates are relative to the drawing area (widget) NOT the parent
        PAINTSTRUCT sPS;
        HDC         hDC = ::BeginPaint(hWnd, &sPS);
        //::MoveToEx(hDC, 0, 0, NULL);
        //::LineTo(hDC, 50, 50);           // from (100, 100) -> (150, 150)
        //::MoveToEx(hDC, 100, 100, NULL); // move to (200, 200)
        //::LineTo(hDC, 150, 100);         // from (200, 200) -> (300, 200)
        
        { // drawing w/ transparency
          // HBITMAP hBmp = create or load
          // HDC hMemDC = ::CreateCompatibleDC(hDC); // create dc
          // ::SelectObject(hMemDC, (HBITMAP) hBmp); // select bitmap in new dc
          // BLENDFUNCTION sBlend = {AC_SRC_OVER, 0, 127, 0};
          // ::AlphaBlend(hDC, 0, 0, 100, 64, hMemDC, 0, 100, 64, sBlend)
          // ::Delete(hMemDC);
          // ::DeleteObject((HBITMAP) hBmp);
        }
        
        // @todo TRY: if pButton has onPaint execute it and ignore this draw
        
        // get the correct button size // in case mShape is AUTO
        RECT sRect;
        // select brush & pen
        HBRUSH hThisBrush = (HBRUSH)(pButton->getStyle()->getBackground());
        HPEN   hThisPen   =   (HPEN)(pButton->getStyle()->getBorder());
        HBRUSH hPrevBrush = (HBRUSH)::SelectObject(hDC, hThisBrush);
        HPEN   hPrevPen   =   (HPEN)::SelectObject(hDC, hThisPen);
        //::GetWindowRect((HWND)(*pButton), &sRect); // client + border + caption
        ::GetClientRect(hWnd, &sRect);
        int w = sRect.right  - sRect.left;
        int h = sRect.bottom - sRect.top;
        ::Rectangle(hDC, 0, 0, w, h); 
        sRect = {0, 0, w, h};
        HFONT hFont = (HFONT)(pButton->getStyle()->getFont());
        ::SelectObject(hDC, hFont);
        ::SetBkMode(hDC, TRANSPARENT);
        ::SetTextColor(hDC, (COLORREF)(pButton->getStyle()->getFont().getColor()));
        ::DrawText(hDC, pButton->mCaption.c_str(), -1, &sRect, DT_SINGLELINE|DT_CENTER|DT_VCENTER); // DT_BOTTOM|TOP|LEFT|RIGHT
        // restore (but not delete, deleted by destructor)
        ::SelectObject(hDC, hPrevBrush);
        ::SelectObject(hDC, hPrevPen);
        //::TextOut(hDC, 0, 0, "TEST", 4);
        //::FillRect(hDC, RECT*, HBRUSH);
        //::Ellipse(hDC, 40, 55, 48, 65);
        
        //POINT points[3] = {{5, 10}, {25, 30}, {15, 20}};
        //::Polygon(hDC, points, 3);
        
        //HPEN   hBluePen     = ::CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
        //HBRUSH hPurpleBrush = ::CreateSolidBrush(RGB(255, 0, 255));
        //HPEN   hPrevPen     = ::SelectObject(hDC, hBluePen);
        //HBRUSH hPrevBrush   = ::SelectObject(hDC, hPurpleBrush);
          // draw here
        //::SelectObject(hDC, hPrevBrush); // restore
        //::DeleteObject(hPurpleBrush)     // delete
        ::EndPaint(hWnd, &sPS);
        return 0;
      }
    }
    
    return ::CallWindowProc(CButton::prev, hWnd,  uMsg, wParam, lParam); // at the end of BtnProc()
  }
  
  WNDPROC CButton::prev;
}

// group box
  // BS_GROUPBOX (eye candy) before 1st radio
  // WS_GROUP (on the first radio button)
  // WS_CHILD | WS_VISIBLE (all radios)
  // BS_AUTORADIOBUTTON
  // BS_AUTOCHECKBOX
  // (HMENU)(IDC_CHK123..)
  // hWnd parent on all
  // WS_GROUP (to start a second group)
