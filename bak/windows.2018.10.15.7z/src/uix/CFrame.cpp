#include <uix/CFrame.hpp>
#include <uix/CLayout.hpp>

namespace uix
{
  CFrame::CFrame(int id, CWidget* parent, const SShape& shape/*=AUTO*/, int hints/*=NONE*/)
  : CWidget(id, parent, shape, hints), mLayout(nullptr)
  {
    std::cout << "uix::CFrame::CFrame(id, parent, shape)::" << this << std::endl;
  }
  
  CFrame::CFrame(CWidget* parent, const SShape& shape/*=AUTO*/, int hints/*=NONE*/)
  : CFrame(ANY, parent, shape, hints)
  {
    std::cout << "uix::CFrame::CFrame(parent, shape)::" << this << std::endl;
  }

  CFrame::~CFrame()
  {
    std::cout << "uix::CFrame::~CFrame()::" << this << std::endl;
  }

  void CFrame::setLayout(CLayout* pLayout)
  {
    mLayout = pLayout;
    pLayout->setParent(this);
  }
  
  bool CFrame::hasLayout() const
  {
    return mLayout != nullptr;
  }
  
  CLayout* CFrame::getLayout()
  {
    return mLayout;
  }

  void CFrame::pack()
  {
    mLayout->pack();
  }

  bool CFrame::onSizing(uix::CResizeEvent* pEvent)
  { 
    return mLayout != nullptr && mLayout->onSizing(pEvent); 
  }
  
  bool CFrame::onResize(uix::CResizeEvent* pEvent)
  { 
    return mLayout != nullptr && mLayout->onResize(pEvent); 
  }
}
