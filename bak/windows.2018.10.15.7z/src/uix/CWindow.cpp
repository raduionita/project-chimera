#include <uix/CWindow.hpp>
#include <uix/CApplication.hpp>
#include <uix/CLayout.hpp>

/*
BUTTON
COMBOBOX
EDIT
LISTBOX
MDICLIENT
SCROLLBAR
STATIC
*/

namespace uix // acme { gui { win, unx, osx } }
{
  CWindow::CWindow(int id, CWidget* parent, const CString& caption, const SShape& shape/*=AUTO*/, int hints/*=WINDOW*/)
  : CFrame(id, parent, shape, hints|EHint::TOPLEVEL), mCaption(caption)
  {
    std::cout << "uix::CWindow::CWindow(id, parent, caption, shape)::" << this << std::endl; 
    mShape.w = (mHints & EHint::AUTOWIDTH  ? UIX_DEFAULT_WINDOW_WIDTH  : mShape.w);
    mShape.h = (mHints & EHint::AUTOHEIGHT ? UIX_DEFAULT_WINDOW_HEIGHT : mShape.h);
    mShape.x = (mShape.x == ZERO ? UIX_DEFAULT_WINDOW_X : mShape.x);
    mShape.y = (mShape.y == ZERO ? UIX_DEFAULT_WINDOW_Y : mShape.y);
  }
  
  CWindow::CWindow(CWidget* parent, const CString& caption, const SShape& shape/*=AUTO*/, int hints/*=WINDOW*/)
  : CWindow(ANY, parent, caption, shape, hints)
  {
    std::cout << "uix::CWindow::CWindow(parent, caption, shape)::" << this << std::endl;
  }

  CWindow::CWindow(const CString& caption, const SShape& shape/*=AUTO*/, int hints/*=WINDOW*/)
  : CWindow(ANY, nullptr, caption, shape, hints)
  {
    std::cout << "uix::CWindow::CWindow(caption, shape)::" << this << std::endl;
  }

  CWindow::~CWindow()
  {
    std::cout << "uix::CWindow::~CWindow()::" << this << std::endl;
    // @todo Move unregister class to a WndClassManager
    ::UnregisterClass((T("uixCWindow") + T(mId)).c_str(), (HINSTANCE)(*uix::app));
  }

  CWidget::EType CWindow::getType() const
  {
    return CWidget::EType::WINDOW;
  }
  
  bool CWindow::init() 
  { 
    if (!mInited) {
      // parent init first
      CWidget::init();

      // @todo Move this // WNDCLASSEX is common to most windows - no need for new WNDCLASSEX for every window
      WNDCLASSEX wndclass = {
        sizeof(WNDCLASSEX),                  // UINT      // cbSize        // struct size  
        CS_HREDRAW | CS_VREDRAW,             // UINT      // style
        proc,                                // WNDPROC   // lpfnWndProc   // uix::CWidget::proc
        0,                                   // int       // cbClsExtra    // no extra bytes after the window class
        0,                                   // int       // cbWndExtra    // structure or the window instance
        (HINSTANCE)(*uix::app),              // HINSTANCE // hInstance
        ::LoadIcon(NULL, IDI_APPLICATION),   // HICON     // hIcon
        ::LoadCursor(NULL, IDC_ARROW),       // HCURSOR   // hCursor
        NULL,                                // HBRUSH    // hbrBackground
        NULL,                                // LPCTSTR   // lpszMenuName  // no menu
        (T("uixCWindow") + T(mId)).c_str(),  // LPCTSTR   // lpszClassName
        ::LoadIcon(NULL, IDI_APPLICATION)    // HICON     // hIconSm
      };

      if (!::RegisterClassEx(&wndclass))  {
        // @todo trigger error event
        ::MessageBox(NULL, "[CWindow] RegisterClassEx failed!", "Error", MB_OK);
        return false;
      }

      DWORD dwStyle   = 0;
      DWORD dwExStyle = 0;
      
      //dwStyle |= mHints & EHint::BORDER   ? WS_BORDER      : 0;
      dwStyle |= mHints & EHint::TITLE    ? WS_CAPTION     : 0;
      dwStyle |= mHints & EHint::FRAME    ? WS_THICKFRAME | WS_SIZEBOX : 0;
      dwStyle |= mHints & EHint::SYSMENU  ? WS_SYSMENU     : 0;
      dwStyle |= mHints & EHint::MINIMIZE ? WS_MINIMIZEBOX : 0;
      dwStyle |= mHints & EHint::MAXIMIZE ? WS_MAXIMIZEBOX : 0;
      dwStyle |= mHints & EHint::HSCROLL  ? WS_HSCROLL     : 0;
      dwStyle |= mHints & EHint::VSCROLL  ? WS_VSCROLL     : 0;
      dwStyle |= mHints & EHint::FRAME    ? 0 : WS_VISIBLE; // w/o this the layout gets screwed (a bad size message is sent)
      dwStyle |= WS_CLIPCHILDREN;
      
      RECT sRect = {0, 0, mShape.w, mShape.h};
      ::AdjustWindowRectEx(&sRect, dwStyle, FALSE, dwExStyle); // adjust window to required
      
      if (mHints & EHint::CENTER) { this->center(); } // center
      
      mHandle = ::CreateWindowEx(
        dwExStyle,                   // DWORD // ex. style (0 = default)
        wndclass.lpszClassName,      // LPCSTR window class name
        mCaption.c_str(),            // LPCSTR window title name
        dwStyle,                     // DWORD // style
        mShape.x,                 mShape.y,                 // (x, y)
        sRect.right - sRect.left, sRect.bottom - sRect.top, // (width, height)
        hasParent() ? (HWND)(*mParent) : NULL, // HWND parent handle
        NULL,                        // HMENU menu handle
        wndclass.hInstance,          // HINSTANCE application handle
        NULL);                       // LPVOID additional app data

      if (mHandle == NULL) {
        // @todo trigger error event
        ::MessageBox(NULL, "[CWindow] CreateWindowEx failed!", "Error", MB_OK);
        return false;
      }
      
      ::SetWindowLong(mHandle, GWL_STYLE,   dwStyle);  // WS_CLIPCHILDREN (dont draw on child area) 
      ::SetWindowLong(mHandle, GWL_EXSTYLE, dwExStyle);
      ::SetWindowLongPtr(mHandle, GWLP_USERDATA, (LONG_PTR)(this));
      // ::SetWindowLongPtr(mHandle, GCLP_HICON, ); set icon OR ::SendMessage(mHandle, (UINT)WM_SETICON, ICON_BIG, (LPARAM)icon);
      
      // BOOL ::GetWindowRect(HWND, LPRECT); // get window position size...
      // INT  ::GetSystemMetrics(SM_CXSIZEFRAME); // SW_CXVSCROLL SM_CYHSCROLL
      
      { // init window style
        mStyle->setBackground(CBrush(CColor(UIX_COL_WND_BG)));
        mStyle->setBorder(CPen(1, CPen::SOLID, UIX_COL_WND_BORDER));
      }
      
      onInit();
      
      // if there is no layout use box-layout
      if (!hasLayout()) {
        setLayout(new CBoxLayout); // DON'T set directly
        for (CWidget*& pChild : mChildren) mLayout->addWidget(pChild);
      }

      // init layout
      if (hasLayout()) mLayout->init();
      // init all children
      for (CWidget*& pChild : mChildren) pChild->init();
      
      ::EnumChildWindows(mHandle, [] (HWND hChild, LPARAM) -> BOOL {
        std::cout << hChild << std::endl;
        return TRUE;
      } , 0);
      
      mInited = true;
    }
    
    return mInited;
  }
}










