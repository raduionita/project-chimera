#include <uix/CModule.hpp>

namespace uix
{
  CModule::CModule() : mHandle(NULL), mInited(false)
  {
    std::cout << "uix::CModule::CModule()::" << this << std::endl;
    mHandle = ::GetModuleHandle(NULL); // LPCSTR // (NULL == .exe instance) // module name (if called from a dll)
  }

  CModule::CModule(const CModule& that)
  {
    mHandle = that.mHandle;
    mInited = that.mInited;
  }

  CModule& CModule::operator =(const CModule& that)
  {
    if(this != &that)
    {
      mHandle = that.mHandle;
      mInited = that.mInited;
    }
    return *this;
  }

  CModule::~CModule()
  {
    std::cout << "uix::CModule::~CModule()" << std::endl;
    mHandle = NULL;
    mInited = false;
  }

  CModule::operator HINSTANCE()
  {
    return mHandle;
  }

  // @todo Register onInit event to be triggered during loop
  bool CModule::init()
  {
    if(mInited == false)
    {
      std::cout << "uix::CModule::init()" << std::endl;

      mInited = true;

      onInit();
    }
    return mInited;
  }

  // @todo Register onFree event
  bool CModule::free()
  {
    if(mInited == true)
    {
      std::cout << "uix::CModule::free()" << std::endl;

      mInited = false;

      onFree();
    }
    return true;
  }
  
  void CModule::onInit()
  {
    std::cout << "uix::CModule::onInit()" << std::endl;
  }

  void CModule::onFree()
  {
    std::cout << "uix::CModule::onFree()" << std::endl;
  }

  void CModule::onIdle()
  {
    std::cout << "uix::CModule::onIdle()" << std::endl;
  }
}
