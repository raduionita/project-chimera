#include <uix/CPanel.hpp>
#include <uix/CLayout.hpp>

namespace uix
{
  CPanel::CPanel(int id, CWidget* parent, const SShape& shape/*=AUTO*/, int hints/*=CHILD*/)
  : CFrame(id, parent, shape, hints)
  {
    std::cout << "uix::CPanel::CPanel(id, parent, shape)::" << this << std::endl;
  }

  CPanel::CPanel(CWidget* parent, const SShape& shape/*=AUTO*/, int hints/*=CHILD*/)
  : CPanel(ANY, parent, shape, hints)
  {
    std::cout << "uix::CPanel::CPanel(parent, shape)::" << this << std::endl;
  }

  CPanel::~CPanel()
  {
    std::cout << "uix::CPanel::~CPanel()::" << this << std::endl;
    // @todo Move unregister class to a WndClassManager
    ::UnregisterClass((T("uixCPanel") + T(mId)).c_str(), (HINSTANCE)(*uix::app));
  }

  bool CPanel::init()
  {
    // @todo if parent inited the init else wait

    if (mInited == false && mParent != nullptr) {
      // parent init
      CFrame::init();
      
      // @todo Move this // WNDCLASSEX is common to most windows - no need for new WNDCLASSEX for every window     
      WNDCLASSEX wndclass = {
        sizeof(WNDCLASSEX),                  // UINT      // cbSize        // struct size  
        CS_HREDRAW | CS_VREDRAW,             // UINT      // style
        proc,                                // WNDPROC   // lpfnWndProc   // uix::CWidget::proc
        0,                                   // int       // cbClsExtra    // no extra bytes after the window class
        0,                                   // int       // cbWndExtra    // structure or the window instance
        (HINSTANCE)(*uix::app),              // HINSTANCE // hInstance
        ::LoadIcon(NULL, IDI_APPLICATION),   // HICON     // hIcon
        ::LoadCursor(NULL, IDC_ARROW),       // HCURSOR   // hCursor
        NULL,                                // HBRUSH    // hbrBackground
        NULL,                                // LPCTSTR   // lpszMenuName  // no menu
        (T("uixCPanel") + T(mId)).c_str(),   // LPCTSTR   // lpszClassName
        ::LoadIcon(NULL, IDI_APPLICATION)    // HICON     // hIconSm
      };

      if (!::RegisterClassEx(&wndclass)) {
        // @todo trigger error event
        ::MessageBox(NULL, "[CPanel] RegisterClassEx failed!", "Error", 0);
        std::cout << "uix::CPanel::init()::" << this << ":" << mId << std::endl;
        return false;
      }

      DWORD dwStyle   = 0;
      DWORD dwExStyle = 0;
      
      //dwStyle |= mHints & EHint::BORDER   ? WS_BORDER      : 0;
      dwStyle |= mHints & EHint::FRAME    ? WS_THICKFRAME | WS_SIZEBOX | WS_CAPTION | WS_BORDER: 0;
      dwStyle |= mHints & EHint::HSCROLL  ? WS_HSCROLL     : 0;
      dwStyle |= mHints & EHint::VSCROLL  ? WS_VSCROLL     : 0;
      dwStyle |= WS_VISIBLE;
      dwStyle |= WS_CHILD;
      dwStyle |= WS_CLIPCHILDREN;
      
      //dwExStyle |= WS_EX_TRANSPARENT;
      
      RECT sRect = {0, 0, mShape.w, mShape.h};
      ::AdjustWindowRectEx(&sRect, dwStyle, FALSE, dwExStyle);
      
      mHandle = ::CreateWindowEx(
        dwExStyle,                  // DWORD // ex. style (0 = default)
        wndclass.lpszClassName,     // LPCSTR window class name
        "uixCPanel",                // LPCSTR window title name
        dwStyle,                    // DWORD // style
        mShape.x,                 mShape.y,                 // (x, y)
        sRect.right - sRect.left, sRect.bottom - sRect.top, // (width, height)
        (HWND)(*mParent),           // HWND parent handle
        NULL,                       // HMENU menu handle
        wndclass.hInstance,         // HINSTANCE application handle
        NULL);                      // LPVOID additional app data

      if (mHandle == NULL) {
        // @todo trigger error event
        ::MessageBox(NULL, "[CPanel] CreateWindowEx failed!", "Error", 0);
        return false;
      }
    
      ::SetWindowLong(mHandle, GWL_STYLE,   dwStyle);
      ::SetWindowLong(mHandle, GWL_EXSTYLE, dwExStyle);
      ::SetWindowLongPtr(mHandle, GWLP_USERDATA, (LONG_PTR)(this));
      
      { // init panel style
        mStyle->setBackground(CBrush(CColor(UIX_COL_PNL_BG)));
        mStyle->setBorder(CPen(UIX_SZE_PNL_BORDER, CPen::SOLID, CColor(UIX_COL_PNL_BORDER)));
      }
      
      onInit();

      // init layout
      if (hasLayout()) mLayout->init();
      // init all children
      for (CWidget*& pChild : mChildren) pChild->init();
      
      mInited = true;
    }
    
    return mInited;
  }
}
