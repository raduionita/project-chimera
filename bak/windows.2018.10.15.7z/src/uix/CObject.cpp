#include <uix/CObject.hpp>
#include <uix/CObjectManager.hpp>

namespace uix
{
  CObject::CObject(int id/* = -1*/)
  : mId(CObject::nextId(id))
  {
    std::cout << "uix::CObject::CObject()::" << mId << "::" << this << std::endl;
    *(uix::app->mObjectManager) += this;
  }

  CObject::~CObject()
  {
    std::cout << "uix::CObject::~CObject()::" << mId << "::" << this << std::endl;
    *(uix::app->mObjectManager) -= this;
  }

  CObject::CObject(const CObject& that)
  : mId(that.mId)
  {
    // ...
  }
  
  CObject& CObject::operator =(const CObject& that)
  {
    if(this != &that)
    {
      // @todo Not sure about this
      const_cast<int&>(mId) = that.mId;
    }
    return *this;
  }
  
  CObject::operator int()
  {
    return mId;
  }
  
  CObject::operator const int()
  {
    return mId;
  }
  
  const int CObject::nextId(int id)
  {
    // @todo This should be atomic
    static int cnt = 0;
    id = id == ANY ? ++cnt : id;
    return id;
  }
}
