#include "../inc/main.hpp"
#include "../inc/sys.hpp"
#include "../inc/app.hpp"

int main(int argc, char** argv)
{
  sys::CFileLoggerStrategy fout(sys::CFile("logs/application.log"));
  sys::log.setStrategy(&fout);
  
  app::APP = new app::COGLDev45AmbientOcclusionApp;
  app::APP->run(argc, argv);
  delete app::APP;
  return 0;
}

  
  // rendering strategies:
  //   forward
  //   deffered
  
  // rendering passes:
  //   geometry - CGeometryFramebuffer - gbuffer
  //   shadow   - CShadowFramebuffer
  
  //   lighting (ambient + diffuse)
  //   wireframe
  //   normals
  
  // options
  //   motion blur: outputs color + motion
  //   shadow
  //   deffered || forward
  //   single || instanced
  
  // post-processing
  //   motion blur: inputs color + motion
  
  // lighting shader: deffered = pass_through.vs + lighting_deffered.fs
  // lighting shader: forward  = lighting_forward.vs + lighting_forward.fs
  
  ////////////////////////////////////////////////////////
  
  
  
  // CRenderEngine
    // CDefferedRenderer
      // build geometry framebuffer
        // option: single vs instanced
      // build shadow framebuffer(s)
        // option: single vs instanced
      // build ambinet occlussion framebuffer
        // option: single vs instanced
      // build selector framebuffer + selector(pick pixel)
        // option: single vs instanced
      // build render framebuffer
        // option: lighting: pass_both(deafult) vs pass_diffuse vs pass_ambient
        // option: shadow_map vs shadow_volume vs no_shadow(default)
        // option: single(default) vs instanced
        // option: selector vs noselector(default)
        // option: motionblur vs no_motionblur(default)
      // build debug 
        // wireframe pass
        // normals pass
        // icons pass
      // build postprocess
        // option: motion blur pass + motion blur blur
        // ffax
    // CForwardRenderer
  
  // pRenderEngine->setCamera(pScene->getCamera());
  // pRenderEngine->addOption(CRenderEngine::ESettings::DEFFERED);
  // pRenderEngine->addOption(CRenderEngine::ESettings::DEBUG);   // wireframe | wireframe + color | color
  // pRenderEngine->addOption(ogl::tag::NOSHADOW);
  // pRenderEngine->addDrawable(pModelEntity->getDrawable(), pModelEntity->getDescriptor() + ogl::tag::WIREFRAME);
  // pRenderEngine->addLight(pLightEntity->getLight(), pLightEnity->getDescriptor());
  // pRenderEngine->addDrawable(pLightEntity->getDrawable(), pLightEnity->getDescriptor() + ogl::tag::DEBUG);
  // pRenderEngine->addDrawable(pEventEntity->getDrawable(), pEventEntity->getDescriptor() + ogl::tag::DEBUG);
  // pRenderEngine->setCamera(pCameraEntity->getCamera());
  // pRenderEngine->render();
  
  
  
  
  
  
  
  
  
  ////////////////////////////////////////////////////////
  
  // pAudioEngine->play(pSomething);
  
  // pPhysicsEngine->evaluate(); // collision, gravity, forces
  
  // pNetworkEngine->send(); // communicates with a server or other client
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
