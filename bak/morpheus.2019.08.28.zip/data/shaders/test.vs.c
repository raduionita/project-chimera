#define TEST()         \
"                      \
  #version 420 core \n \
  void main(void) {    \
                       \
  }                    \
"
