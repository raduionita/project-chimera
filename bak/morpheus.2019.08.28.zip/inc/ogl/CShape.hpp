#ifndef __cshape_hpp__
#define __cshape_hpp__

namespace ogl
{
  class CShape
  {
    friend class CObject;
    
    public:
    std::string  mName;
    CBufferRange mVertexBufferRange;
    CBufferRange mIndexBufferRange;
    CMaterial*   mMaterial; //@TODO ptr::smart<CMaterial*> mMaterial;
    
    public:
    CShape() : mMaterial(nullptr)
    {
      sys::info << "ogl::CShape::CShape()" << sys::endl;
    }
    
    CShape(const CBufferRange& oVertexBufferRange, const CBufferRange& oIndexBufferRange, CMaterial* oMaterial)
    : mVertexBufferRange(oVertexBufferRange), mIndexBufferRange(oIndexBufferRange), mMaterial(oMaterial)
    {
      sys::info << "ogl::CShape::CShape(CBufferRange, CBufferRange, CMaterial)" << sys::endl;
    }
    
    CShape(const CShape& that)
    {
      mName              = that.mName;
      mVertexBufferRange = that.mVertexBufferRange;
      mIndexBufferRange  = that.mIndexBufferRange;
      if(mMaterial)
        delete mMaterial;
      mMaterial = that.mMaterial;
    }
    
    virtual ~CShape()
    {
      sys::info << "ogl::CShape::~CShape()" << sys::endl;
      if(mMaterial)
        delete mMaterial;
    }
    
    CShape& operator = (const CShape& that)
    {
      if(this != &that)
      {
        mName              = that.mName;
        mVertexBufferRange = that.mVertexBufferRange;
        mVertexBufferRange = that.mIndexBufferRange;
        if(mMaterial)
          delete mMaterial;
        mMaterial = that.mMaterial;
      }
      return *this;
    }
    
    public:
    CBufferRange getVertexBufferRange() const
    {
      return mVertexBufferRange;
    }
    
    CBufferRange getIndexBufferRange() const
    {
      return mIndexBufferRange;
    }
    
    CMaterial* getMaterial() const
    {
      return mMaterial;
    }
    
    void setMaterial(CMaterial* material)
    {
      if(mMaterial)
        delete mMaterial;
      mMaterial = material;
    }
    
    
    std::string getName() const
    {
      return mName;
    }
    
    void setName(const std::string& name)
    {
      mName = name;
    }
  
    void setVertexBufferRange(CBufferRange oBufferRange)
    {
      mVertexBufferRange = oBufferRange;
    }
    
    void setIndexBufferRange(CBufferRange oBufferRange)
    {
      mIndexBufferRange = oBufferRange;
    }  
    
    void setVertexBufferRange(size_t position, size_t length, GLenum type = GL_FLOAT)
    {
      mVertexBufferRange = CBufferRange(position, length, type);
    }
    
    void setIndexBufferRange(size_t position, size_t length, GLenum type = GL_UNSIGNED_SHORT)
    {
      mIndexBufferRange = CBufferRange(position, length, type);
    }
  };
}

#endif // __cshape_hpp__
