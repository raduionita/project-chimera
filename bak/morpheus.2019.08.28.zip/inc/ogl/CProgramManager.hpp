#ifndef __ogl_cprogrammanager_hpp__
#define __ogl_cprogrammanager_hpp__

#include <map>

namespace ogl
{
  class CProgramManager : public sys::CSingleton<CProgramManager>
  {
    friend class sys::CSingleton<CProgramManager>;
    friend class ogl::CProgram;
    
    protected:
    std::map<ogl::CProgram*, sys::CDescriptor> mPrograms;
    
    ogl::CProgram* mCurrent;

    protected:
    CProgramManager() : mCurrent(nullptr)
    {
      
    }
    
    virtual ~CProgramManager()
    {
      sys::info << "ogl::CProgramManager::~CProgramManager()" << sys::endl;
      for(auto it = mPrograms.begin(); it != mPrograms.end(); ++it)
        delete it->first;
      mPrograms.clear();
    }
    
    public:
    ogl::CProgram* getProgram(const sys::CDescriptor& oDesciptor)
    {
      for(auto it = mPrograms.begin(); it != mPrograms.end(); ++it)
        if(it->second == oDesciptor)
          return enable(it->first);
      throw EXCEPTION << "Program not found for: " << oDesciptor;
    }
    
    ogl::CProgram* getProgram(const sys::CTag& tag)
    {
      //sys::info << "ogl::CProgramManager::getProgram(CTag)" << sys::endl;
    
      for(auto it = mPrograms.begin(); it != mPrograms.end(); ++it)
        if(it->second.hasTag(tag))
          return enable(it->first);
      
      throw EXCEPTION << "Program not found for: " << tag.getTagName();
    }
    
    std::vector<ogl::CProgram*> getPrograms(const sys::CTag& tag)
    {
      std::vector<ogl::CProgram*> out;
      for(auto it = mPrograms.begin(); it != mPrograms.end(); ++it)
        if(it->second.hasTag(tag))
          out.push_back(it->first);
      return out;
    }
    
    void addProgram(ogl::CProgram* pProgram, const sys::CDescriptor& oDesciptor)
    {
      if(mPrograms.find(pProgram) != mPrograms.end())
        throw EXCEPTION << "This program already exists. " << oDesciptor;
      mPrograms.insert(std::make_pair(pProgram, oDesciptor));
    }
  
    ogl::CProgram*& enable(CProgram* pProgram)
    {
      if(mCurrent != pProgram)
      {
        mCurrent = pProgram;
        glValidateProgram(*mCurrent);
        
        if(mCurrent->isLinked() == false)
          throw EXCEPTION << "Cannot enable a bad program!";
        
        glUseProgram(*mCurrent);
        sys::info << "ogl::CProgramManager::enable(CProgram*) > " << mPrograms[mCurrent] << " enabled" << sys::endl;
      }
      else 
      {
        sys::info << "ogl::CProgramManager::enable(CProgram*) > " << mPrograms[mCurrent] << " already linked" << sys::endl;
      }
      
      return mCurrent;
    }
    
    void disable()
    {
      mCurrent = nullptr;
      glUseProgram(0);
    }
  };
}

#endif // __ogl_cprogrammanager_hpp__
