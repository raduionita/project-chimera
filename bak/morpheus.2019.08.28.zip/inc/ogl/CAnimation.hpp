#ifndef __ogl_CANIMATION_HPP__
#define __ogl_CANIMATION_HPP__

namespace ogl
{
  class CAnimation
  {
    public:
    typedef struct {
      //math::mat4 transform;
      int        parent;
      math::vec3 position;
      math::quat rotation;
      math::vec3 scaling;  // not used yet
    } joint_t;
    typedef struct {
      joint_t* joints;
    } frame_t;
    typedef struct {
      joint_t* joints;
    } skeleton_t;      // similar to a single frame, may be should use only the one in CAnimable
    
    public:
    size_t   mNumJoints;
    size_t   mNumFrames;
    frame_t* mFrames;     // 
    size_t   mFrameRate;  // fps
    float    mDuration;   // seconds
    float    mTime;       // seconds - animation time
    
    skeleton_t* mSkeleton;
    
    public:
    CAnimation() 
    : mNumJoints(0), mNumFrames(0), mFrames(nullptr), mFrameRate(0), mDuration(0.0f), mTime(0.0f)
    {
      mSkeleton = new skeleton_t;
    }
    
    CAnimation(size_t numJoints, size_t numFrames)
    : mNumJoints(numJoints), mNumFrames(numFrames), mFrames(nullptr), mFrameRate(0), mDuration(0.0f), mTime(0.0f)
    {
      assert(numJoints > 1);
      assert(numFrames > 1);
    
      mSkeleton = new skeleton_t;
      mSkeleton->joints = new joint_t[mNumJoints];
      
      mFrames = new frame_t[mNumFrames];
      for(size_t fi = 0; fi < mNumFrames; ++fi)
        mFrames[fi].joints = new CAnimation::joint_t[mNumJoints];
    }
    
    virtual ~CAnimation()
    {
      for(size_t fi = 0; fi < mNumFrames; ++fi)
        delete [] mFrames[fi].joints;
      delete [] mFrames;
      delete [] mSkeleton->joints;
    }
    
    public:
    void update(float fDelta)
    {
      // using dt interpolate between 2 animation frames
      if(mNumFrames < 1) 
        return;
      
      // TODO: what is fDelta is very large(caused by long update)
      // should I remember current frame or let it jump to a frame according to the magnitude of fDelta
      // this works only for very small fDelta's
      
      mTime += fDelta;
      mTime  = math::wrap(mTime, 0.0f, mDuration); // mTime => [0, mDuration]
      
      float fFrameNum = mTime * mFrameRate;
      
      size_t fA = (uint)(std::floor(fFrameNum)) % mNumFrames; // maybe this should be replaced with current frame index
      size_t fB = (uint)(std::ceil(fFrameNum))  % mNumFrames; // 1,2,3..138,139,1,2,3..
      
      float t = std::fmod(mTime, mDuration) / mDuration; // ???
      
      frame_t* frameA = &mFrames[fA];
      frame_t* frameB = &mFrames[fB];
      
      // interpolate skeletions
      for(size_t ji = 0; ji < mNumJoints; ++ji)
      {
        joint_t* jointS = &mSkeleton->joints[ji];
        joint_t* jointA = &frameA->joints[ji];
        joint_t* jointB = &frameB->joints[ji];
        
        jointS->parent   = jointA->parent;  // is this used in any way?
        jointS->position = math::mix(jointA->position, jointB->position, t);
        jointS->rotation = math::slerp(jointA->rotation, jointB->rotation, t);
        // jointS->scaling  = math::mix(jointA->scaling, jointB->scaling, t);
        
        // transform = math::translate(jointS->position) * math::toMatrix(jointS->rotation); // * math::scale(jointS->scaling);
      }
    }
    
    void animate(CAnimatable* pAnimatable) // AAnimatable OR IAnimatable OR CSkinnable
    {
      for(size_t ji = 0; ji < mNumJoints; ++ji)
      {
        pAnimatable->mSkeleton->joints[ji].position = mSkeleton->joints[ji].position;
        pAnimatable->mSkeleton->joints[ji].rotation = mSkeleton->joints[ji].rotation;
      }
    }
  };
}

#endif // __ogl_CANIMATION_HPP__
