#ifndef __CShadowFramebuffer_hpp__
#define __CShadowFramebuffer_hpp__

namespace ogl
{
  class CShadowFramebuffer : public CFramebuffer
  {
    protected:
    GLuint mShadowMap;
    
    public:
    CShadowFramebuffer(uint width, uint height) : CFramebuffer(width, height), mShadowMap(0)
    {
      std::cout << "ogl::CShadowFramebuffer::CShadowFramebuffer()" << std::endl;
    
      glGenTextures(1, &mShadowMap);            // create texture for depth buffer
      glBindTexture(GL_TEXTURE_2D, mShadowMap);
      glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32, width, height, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
      //glTexStorage2D(GL_TEXTURE_2D, 1, GL_DEPTH_COMPONENT32, width, height);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);        // turn on tex comparison
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
      
      // GL_DEPTH_COMPONENT = 1xfloat
      // GL_RGBA = 4xfloat
      
      glGenFramebuffers(1, &mFBO); // create fbo
      glBindFramebuffer(GL_FRAMEBUFFER, mFBO);
      glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, mShadowMap, 0);
      //glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, mShadowMap, 0);
      
      std::cout << "> INFO: mFBO: " <<  mFBO << std::endl;
      std::cout << "> INFO: mShadowMap: " <<  mShadowMap << std::endl;
      
      glDrawBuffer(GL_NONE); // disable write to color buffer
      glReadBuffer(GL_NONE);
      
      GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
      if(status != GL_FRAMEBUFFER_COMPLETE)
        std::cerr << "> ERROR: fbo error, status: " << status << std::endl;
        
      glBindFramebuffer(GL_FRAMEBUFFER, 0);  
    }
    
    public:
    virtual void bind(GLenum unit = GL_NONE)
    {
      if(unit != GL_NONE)
      {
        std::cout << "ogl::CShadowFramebuffer::bind(unit)" << std::endl;
        glActiveTexture(unit);
        glBindTexture(GL_TEXTURE_2D, mShadowMap);
      }
      else
      {
        std::cout << "ogl::CShadowFramebuffer::bind()" << std::endl;
        glBindFramebuffer(GL_FRAMEBUFFER, mFBO);
        
        //GLenum draw_buffers[1] = { GL_DEPTH_ATTACHMENT };
        //glDrawBuffers(1, draw_buffers);
      }
    }
    
  };
}

#endif // __CShadowFramebuffer_hpp__
