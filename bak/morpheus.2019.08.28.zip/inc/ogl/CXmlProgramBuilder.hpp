#ifndef __ogl_cxmlprogrambuilder_hpp__
#define __ogl_cxmlprogrambuilder_hpp__

#include <fstream> // ifstream

#include <pugixml/pugixml.hpp>

#include "CProgram.hpp"
#include "CFileShaderBuilder.hpp"

namespace ogl
{
  class CXmlProgramBuilder : public CProgramBuilder
  {
    protected:
    typedef std::string               key_t;
    typedef std::string               type_t;
    typedef std::pair<key_t, type_t>  field_t;
    typedef std::vector<field_t>      fields_t;
    typedef std::map<key_t, fields_t> types_t;
    
    sys::CFile mFile;
  
    public:
    CProgram* build()
    {
      sys::info << "ogl::CXmlProgramBuilder::build() > " << mFile << sys::endl;
    
      if(mFile.isEmpty()) 
        throw EXCEPTION << "File not found, while trying to build scene from XML file!";
      
      pugi::xml_document doc;
      pugi::xml_parse_result result = doc.load_file(mFile.getFilePath().c_str());
      if(!result)
        throw EXCEPTION << mFile.getFileName() << " " << result.description();
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
      
      CProgram*              pProgram = nullptr;
      CShaderProgramBuilder* pBuilder = new CShaderProgramBuilder;
      
      {
        pugi::xml_node _program = doc.child("program");
        pugi::xml_node _tags    = _program.child("tags");
        parseTags(pBuilder, _tags);
        pugi::xml_node _shaders = _program.child("shaders");
        parseShaders(pBuilder, _shaders);
      }
      
      pProgram = pBuilder->build();
      
      _DELETE(pBuilder);
      
      return pProgram;
    }
    
    void setFile(const std::string& sFile)
    {
      mFile = std::move(sys::CFile(SHADERPATH + sFile));
    }
    
    void setFile(sys::CFile&& oFile)
    {
      mFile = std::move(oFile);
    }
  
    private:
    void parseTags(CShaderProgramBuilder*& pBuilder, const pugi::xml_node& _tags)
    {
      // use with CProgramManager to cache programs
    }
    
    void parseShaders(CShaderProgramBuilder*& pBuilder, const pugi::xml_node& _shaders)
    {
      for(pugi::xml_node _shader = _shaders.child("shader"); _shader; _shader = _shader.next_sibling("shader"))
      {
        pugi::xml_attribute _attr = _shader.attribute("type");
        if(!_attr)
          throw EXCEPTION << "<shader type=\"\"> attribute mandatory!";
        
        //sys::info << _shader.name() << " " << _attr.value() << sys::endl;
        
        GLenum type = findShaderType(_attr.value());
        
        CShader* pShader = nullptr;
        
        types_t types;
        
        // <structs> <uniforms> <subroutines> <outputs> <source>
        for(pugi::xml_node _node = _shader.first_child(); _node; _node = _node.next_sibling())
        {
          // sys::info << _node.name() << sys::endl;

          if(strncmp(_node.name(), "structs", 7) == 0)           // <structs>
          {
            continue;
            for(pugi::xml_node _struct = _node.first_child(); _struct; _struct = _struct.next_sibling()) // <struct>
            {
              pugi::xml_attribute _name    = _struct.attribute("name");    // name="NameOfStruct"
              pugi::xml_attribute _extends = _struct.attribute("extends"); // extends="NameOfStruct"
              if(!_name)
                throw EXCEPTION << "<struct name=\"\"> attribute mandatory!";
              
              const char* key = _name.value();
              //sys::info << _name.value();
              
              if(_extends)
              {
                //sys::info << " extends " << _extends.value();
                
                auto it = types.find(std::string(_extends.value()));
                if(it != types.end())
                {
                  fields_t& fields = it->second;
                  
                  for(size_t i = 0; i < fields.size(); ++i)
                    types[key].push_back(fields[i]);
                }
              }
              
              //sys::info << sys::endl;
              
              {
                pugi::xml_node _node = _struct.first_child(); // <fields>
                if(_node) // fields != nullptr
                {
                  for(pugi::xml_node _field = _node.first_child(); _field; _field = _field.next_sibling()) // <field>
                  {
                    pugi::xml_attribute _type  = _field.attribute("type");            // type="base_type"
                    pugi::xml_attribute _name  = _field.attribute("name");            // name="member_name"
                    // TODO: pugi::xml_attribute _value = _field->first_attribute("value", 5); // value="default_value"
                    if(!_type || !_name)
                      throw EXCEPTION << "<field type=\"\" name=\"\"> attributes mandatory!";
                    
                    //sys::info << "    " << _type.value() << " " << _name.value() << sys::endl;
                    
                    types[key].push_back(field_t(_name.value(), _type.value()));
                  }
                }
                else
                {
                  sys::info << "> WARNING: No fields for: " << _name.value() << sys::endl;
                }
              }
            }
          }
          else if(strncmp(_node.name(), "uniforms", 8) == 0)     // <uniforms>
          {
            continue;
            for(pugi::xml_node _uniform = _node.first_child(); _uniform; _uniform = _uniform.next_sibling())
            {
              pugi::xml_attribute _type = _uniform.attribute("type");
              pugi::xml_attribute _name = _uniform.attribute("name");
           // pugi::xml_attribute _binding = _uniform->first_attribute("binding", 7);
              if(!_type || !_name)
                throw EXCEPTION << "<uniform type=\"\" name=\"\"> attributes mandatory!";
              
              std::string uniform(_name.value());
              //sys::info << uniform << sys::endl;
              
              // TODO: recussion + arrays(& object arrays)
              
              // type: int uint float bool mat2 mat3 mat4 vec2 vec3 vec4 imat2 imat3 imat4 ivec2 ivec3 ivec4
              GLenum type = ogl::getTypeEnum(_type.value());
              if(type == GL_NONE) // data type: structs
              {
                uniform.append(".");
                auto it = types.find(_type.value());
                if(it != types.end())
                {
                  fields_t& fields = it->second;
                  for(size_t i = 0; i < fields.size(); ++i)
                  {
                    field_t& field = fields[i];
                    
                    type = ogl::getTypeEnum(field.second);
                    
                    if(type != GL_NONE)
                    {
                      //sys::info << "...." << field.second << " " << (uniform + field.first) << sys::endl;
                      
                      if(0 && uniform[uniform.size() - 2] == ']') // uniform is array
                      {
                        // parse array ... create an uniform for every element
                        // check array size agains MAX_VERTEX_UNIFORM_COMPONENTS = 512
                        
                        //size_t len = 0;
                        //scanf(uniform.c_str(), "%*s[%d]", &len);
                        //for(size_t i = 0; i < len; ++i)
                        //  pBuilder->addUniform(uniform.substr(0, uniform.find('[')-1) +"[+"+ i +"+]"+ field.first, new CUniform(type));
                      }
                      else // regular struct
                      {
                        pBuilder->addUniform(uniform + field.first, new CUniform(type));
                      }
                    }
                    else
                    {
                      throw EXCEPTION << " Type " << field.second << " not found!";
                    }
                  }
                }
                else
                {
                  throw EXCEPTION << " Type " << _type.value() << " not found!";
                }
              }
              else // data type: generic(int, uint, vec3, mat4...)
              {
                //sys::info << "...." << _type.value() << " " << uniform << sys::endl;
                pBuilder->addUniform(uniform, new CUniform(type));
              }
            }
          }
          else if(strncmp(_node.name(), "varyings", 8) == 0)     // <varyings>
          {
            continue;
            sys::info << sys::tab << "" << _node.name() << " Not implemented." << sys::endl;
          }
          else if(strncmp(_node.name(), "subroutines", 11) == 0) // <subroutines>
          {
            continue;
            sys::info << sys::tab << "" << _node.name() << " Not implemented." << sys::endl;
          }
          else if(strncmp(_node.name(), "outputs", 7) == 0)      // <outputs>
          {
            continue;
            sys::info << sys::tab << "" << _node.name() << " Not implemented." << sys::endl;
          }
          else if(strncmp(_node.name(), "source", 6) == 0)       // <source>
          {
            pugi::xml_attribute _type = _node.attribute("type");
            if(!_type)
              throw EXCEPTION << "<source type> attribute mandatory!";

            if(strncmp(_type.value(), "string", 6) == 0)
            {
              CSourceShaderBuilder* pBuilder = new ogl::CSourceShaderBuilder;
              pBuilder->setSource(_node.text().get());
              pBuilder->setType(type);
              pShader = pBuilder->build();
              _DELETE(pBuilder);
            }
            else // file
            {
              pugi::xml_node _file = _node.child("file");
              if(!_file)
                throw EXCEPTION << "<file src> node mandatory!";
              pugi::xml_attribute _src = _file.attribute("src");
              if(!_src)
                throw EXCEPTION << "<file src> attribute mandatory!";
              
              CFileShaderBuilder* pBuilder = new CFileShaderBuilder;
              pBuilder->setFile(_src.value()); // or use current folder
              pBuilder->setType(type);
              pShader = pBuilder->build();
              _DELETE(pBuilder);
            }
          }
        }

        pBuilder->addShader(pShader);
      }
    }

    GLenum findShaderType(const std::string& str)
    {
      CShader::EType type = CShader::EType::NONE;
      if(str == "vertex")
        type = CShader::EType::VERTEX;
      else if(str == "fragment")
        type = CShader::EType::FRAGMENT;
      else if(str == "geometry")
        type = CShader::EType::GEOMETRY;
      else if(str == "tess_control")
        type = CShader::EType::TESS_CONTROL;
      else if(str == "tess_evaluation")
        type = CShader::EType::TESS_EVALUATION;
      else 
        throw EXCEPTION << "Shader type " << str << " not defined!";
      return type;
    }
  };
}

#endif // __ogl_cxmlprogrambuilder_hpp__




































