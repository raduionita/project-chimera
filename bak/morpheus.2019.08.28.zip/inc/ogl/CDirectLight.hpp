#ifndef __cdirectlight_hpp__
#define __cdirectlight_hpp__

namespace ogl
{
  class CDirectLight : public CLight
  {
    public:
    math::vec3 mDirection;
    
    public:
    CDirectLight() : CLight(CLight::DIRECT), mDirection(math::Z)
    {
      float vertices[] = {
        -0.25f, 0.0f,   0.0f, 
         0.25f, 0.0f,   0.0f, 
          0.0f,-0.25f,  0.0f, 
          0.0f, 0.25f,  0.0f, 
          0.0f,  0.0f,-0.25f, 
          0.0f,  0.0f, 0.25f };
         
      glGenBuffers(1, &mVBO);
      glBindBuffer(GL_ARRAY_BUFFER, mVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
      
      glGenVertexArrays(1, &mVAO);
      glBindVertexArray(mVAO);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)((0) * sizeof(GLfloat)));
      glEnableVertexAttribArray(0);
    }
    
    virtual void setDirection(const math::vec3& direction)
    {
      mDirection = direction;
    }
    
    virtual math::vec3 getDirection() const
    {
      return mDirection;
    }
    
    virtual math::mat4 getM()
    {
      return math::translate(0.0f, 2.0f, 0.0f);
    }
  
    CDrawCommand* getDrawCommand()
    {
      return nullptr;
    }
  };
}

#endif // __cdirectlight_hpp__
