#ifndef __ctexture_hpp__
#define __ctexture_hpp__

#include <cassert>

namespace ogl
{
  class CTexture
  {
    friend class CTextureData;
  
    public:
    enum class EFiltering : GLbitfield
    {
      NONE        = 0x00000000, // 0
      NEAREST     = 0x00000001, // 1
      BILINEAR    = 0x00000002, // 2
      TRILINEAR   = 0x00000004, // 4
      ANISOTROPIC = 0x00000008  // 8
    };
    
    enum class EWrapping : GLbitfield
    {
      NONE            = 0x00000000, // 0
      CLAMP_TO_EDGE   = 0x00000010, // 16
      CLAMP_TO_BORDER = 0x00000020, // 32
      REPEAT          = 0x00000040, // 64
    };
    
    /* ECompareMode
//    enum class ECompareMode : ushort
//    {
//      COMPARE_REF_TO_TEXTURE = 0x0080,
//    };
//    
//    enum class ECompareFunc : ushort
//    {
//    
//    };
    */
    
    enum EScope : GLbitfield
    {
      NONE         = 0x00000000, //     0
      GENERIC      = 0x00000080, //   128
      DIFFUSE      = 0x00000100, //   256
      SPECULAR     = 0x00000200, //   512
      AMBIENT      = 0x00000400, //  1024 // for Ambient Occlusion!? // ask ENGINE
      EMISSIVE     = 0x00000800, //  2048 // self illumination
   // LUMINATION   = 0x00400000  //       // self illumination
      HEIGHT       = 0x00001000, //  4096
      NORMALS      = 0x00002000, //  8192
      SHININESS    = 0x00004000, // 16384
      OPACITY      = 0x00008000, // 32768
      DISPLACEMENT = 0x00010000, // 65556 // Height & Displacement... remove one of them
      LIGHTMAP     = 0x00020000, //       // ?! static lights
      REFLECTION   = 0x00040000, //       // ask ENGINE
   // REFRACTION   = 0x00040000, //       // ask ENGINE
      SHADOW       = 0x00080000, //       // ask ENGINE
      ENVIRONMENT  = 0x00100000  //       // ask ENGINE
   // FILTER       = 0x00200000  //       // for Color Filtering
    }; 
    
    // #define SCOPE_MASK 0x000FFF80
    
    enum class EType : GLbitfield
    {
      NONE    = 0x00000000, // 0x00,
      FLAT    = 0x00200000, // 0x01,
      CUBEMAP = 0x00400000, // 0x02,
      VOLUME  = 0x00800000  // 0x03
    };
    
    enum class EOptions : GLbitfield
    {
      NONE    = 0x00000000,
      MIPMAPS = 0x01000000,
    };
    
    protected:
    GLuint     mTexture;
    GLsizei    mWidth;
    GLsizei    mHeight;
    GLsizei    mDepth;
    GLsizei    mMipmaps;
    GLenum     mInternal;
    GLenum     mTarget;
    GLenum     mFormat;
    GLenum     mType;
    GLbitfield mOptions;
    
    // TODO: replace all the diferent constructors by the CTextureBuilder 
    // TODO: collapse internal & format into one 
    
    public:
    CTexture() 
    : mTexture(0), mWidth(0), mHeight(0), mDepth(1), mMipmaps(1), mInternal(GL_NONE), mTarget(GL_NONE), mFormat(GL_NONE), mType(GL_FLOAT), mOptions(0)
    {
      sys::info << "ogl::CTexture::CTexture()" << sys::endl;
      
      glBindTexture(GL_TEXTURE_2D, 0); // free previous texture
      glGenTextures(1, &mTexture);
      glBindTexture(GL_TEXTURE_2D, mTexture);
    }
    
    CTexture(GLenum target, GLenum internal, GLsizei width, GLsizei height, GLenum format, GLenum type)
    : mWidth(width), mHeight(height), mDepth(1), mMipmaps(1), mInternal(internal), mTarget(target), mFormat(format), mType(type), mOptions(0)
    {
      glBindTexture(GL_TEXTURE_2D, 0); // free previous texture
      sys::info << "ogl::CTexture::CTexture(target, internal, width, height, format, type)" << sys::endl;
      glGenTextures(1, &mTexture);
      glBindTexture(mTarget, mTexture);
      glTexImage2D(mTarget, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
    }
    
    CTexture(GLenum target, GLenum internal, GLsizei width, GLsizei height, GLenum format, GLenum type, GLbitfield options)
    : mWidth(width), mHeight(height), mDepth(1), mMipmaps(1), mInternal(internal), mTarget(target), mFormat(format), mType(type), mOptions(options)
    {
      sys::info << "ogl::CTexture::CTexture(target, internal, "<< width <<", "<< height <<", format, type, options)" << sys::endl;
      
      init();
    }
    
    CTexture(GLenum target, GLenum internal, GLsizei width, GLsizei height, GLenum format, GLenum type, EFiltering filtering)
    : mWidth(width), mHeight(height), mDepth(1), mMipmaps(1), mInternal(internal), mTarget(target), mFormat(format), mType(type), mOptions(0)
    {
      glBindTexture(GL_TEXTURE_2D, 0); // free previous texture
      
      sys::info << "ogl::CTexture::CTexture(target, internal, width, height, format, type, filtering)" << sys::endl;
      
      glGenTextures(1, &mTexture);
      glBindTexture(mTarget, mTexture);
      glTexImage2D(mTarget, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
      setFiltering(filtering);
    }
    
    CTexture(CTextureData pTextureData, GLsizei width, GLenum format, GLenum target)
    : mWidth(width), mHeight(1), mDepth(1), mMipmaps(1), mInternal(GL_NONE), mTarget(target), mFormat(format), mType(GL_FLOAT), mOptions(0)
    {
      glBindTexture(GL_TEXTURE_2D, 0); // free previous texture
      
      sys::info << "ogl::CTexture::CTexture(pTextureData, width, format, target)" << sys::endl;
      
      glGenTextures(1, &mTexture);
      glBindTexture(mTarget, mTexture);
      //@TODO for(ushort i = 0; i < mipmaps; i++)
      //@TODO if(pTextureData->mCompressed) ...
      glTexImage1D(mTarget, 0, mFormat, mWidth, 0, pTextureData.mFormat, pTextureData.mType, pTextureData.mData);
      setFiltering(CTexture::EFiltering::TRILINEAR);
      setWrapping(CTexture::EWrapping::CLAMP_TO_EDGE);
    }
    
    CTexture(CTextureData oTextureData, GLsizei width, GLsizei height, GLenum format, GLenum target)
    : mWidth(width), mHeight(height), mDepth(1), mMipmaps(1), mInternal(GL_NONE), mTarget(target), mFormat(format), mType(GL_FLOAT), mOptions(0)
    {
      glBindTexture(GL_TEXTURE_2D, 0); // free previous texture
      
      sys::info << "ogl::CTexture::CTexture(pTextureData, width, height, format, target) > " << "WxH: " << width << "x" << height << sys::endl; 
      
      glGenTextures(1, &mTexture);
      glBindTexture(mTarget, mTexture);
      //@TODO for(ushort i = 0; i < mipmaps; i++)
      //@TODO if(oTextureData->mCompressed) ...
      glTexImage2D(mTarget, 0, oTextureData.mFormat, mWidth, mHeight, 0, mFormat, oTextureData.mType, oTextureData.mData);
      setFiltering(CTexture::EFiltering::TRILINEAR);
      setWrapping(CTexture::EWrapping::CLAMP_TO_EDGE);
      glExitIfError();
    }
     
    CTexture(CTextureData oTextureData, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLenum target)
    : mWidth(width), mHeight(height), mDepth(depth), mMipmaps(1), mInternal(GL_NONE), mTarget(target), mFormat(format), mType(GL_FLOAT), mOptions(0)
    {
      glBindTexture(GL_TEXTURE_2D, 0); // free previous texture
      
      sys::info << "ogl::CTexture::CTexture(pTextureData, width, height, depth, format, target)" << sys::endl;
      
      glGenTextures(1, &mTexture);
      glBindTexture(mTarget, mTexture);
      glTexStorage3D(mTarget, oTextureData.mMipmaps, mFormat, mWidth, mHeight, mDepth);
      //@TODO for(ushort i = 0; i < mipmaps; i++)
      glTexSubImage3D(mTarget, oTextureData.mMipmaps, 0, 0, 0, mWidth, mHeight, mDepth, oTextureData.mFormat, oTextureData.mType, oTextureData.mData);
      setFiltering(CTexture::EFiltering::BILINEAR);
      setWrapping(CTexture::EWrapping::CLAMP_TO_EDGE);
    }
    
    //CTexture(GLsizeui width, GLint format);
    //CTexture(GLsizeui width, GLsizeui height, GLint format);
    //CTexture(GLsizeui width, GLsizeui height, GLsizeui depth, GLint format);
    //CTexture(CTextureData* pData);
    
    virtual ~CTexture()
    {
      sys::info << "ogl::CTexture::~CTexture()" << sys::endl;
      glDeleteTextures(1, &mTexture);
    }
    
    CTexture(const CTexture& that)
    {
      mWidth    = that.mWidth;
      mHeight   = that.mHeight;
      mDepth    = that.mDepth;
      mMipmaps  = that.mMipmaps;
      mInternal = that.mInternal;
      mTarget   = that.mTarget;
      mFormat   = that.mFormat;
      mType     = that.mType;
      mOptions  = that.mOptions;
      
      init();
    }
    
    CTexture& operator = (const CTexture& that)
    {
      if(this != &that)
      {
        glDeleteTextures(1, &mTexture);
        glBindTexture(that.mTarget, 0); // free previous texture
        glGenTextures(1, &mTexture);
        glBindTexture(that.mTarget, mTexture);
      
        mWidth    = that.mWidth;
        mHeight   = that.mHeight;
        mDepth    = that.mDepth;
        mMipmaps  = that.mMipmaps;
        mInternal = that.mInternal;
        mTarget   = that.mTarget;
        mFormat   = that.mFormat;
        mType     = that.mType;
        mOptions  = that.mOptions;
        
        init();
      }
      return *this;
    }
    
    operator GLuint () 
    {
      return mTexture;
    }
    
    private:
    void init()
    {
      
      glBindTexture(GL_TEXTURE_2D, 0); // free previous texture
      glGenTextures(1, &mTexture);
      glBindTexture(mTarget, mTexture);
      
      setFiltering(EFiltering(mOptions & 0x0000000F));
      setWrapping(EWrapping(mOptions & 0x00000070));
      
      if(mTarget == GL_TEXTURE_1D)
      {
        glTexImage1D(mTarget, 0, mInternal, mWidth, 0, mFormat, mType, NULL);
      }
      else if(mTarget == GL_TEXTURE_2D || mTarget == GL_TEXTURE_1D_ARRAY)
      {
        glTexImage2D(mTarget, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
      }
      else if(mTarget == GL_TEXTURE_CUBE_MAP)
      {
        assert(math::isPowerOf2(mHeight));
        assert(mWidth == mHeight);
      
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
        glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_X, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Y, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
        glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Z, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
        glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, mInternal, mWidth, mHeight, 0, mFormat, mType, NULL);
      }
      else if(mTarget == GL_TEXTURE_3D || mTarget == GL_TEXTURE_2D_ARRAY)
      {
        glTexImage3D(mTarget, 0, mInternal, mWidth, mHeight, mDepth, 0, mFormat, mType, NULL);
      }
      
      if(mOptions & EScope::SHADOW)
      {
        assert(math::isPowerOf2(mWidth));
        assert(math::isPowerOf2(mHeight));
        
        // this doesn't work for width, height != pow of 2
      
        glTexParameteri(mTarget, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
        glTexParameteri(mTarget, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
      }
      
      if(mOptions & EOptions::MIPMAPS)
      {
        glGenerateMipmap(mTarget);
      }
    
      glExitIfError();
    }
    
    public:
    GLsizei getWidth() const
    {
      return mWidth;
    }
    
    GLsizei getHeight() const
    {
      return mHeight;
    }
    
    GLsizei getDepth() const
    {
      return mDepth;
    }
    
    GLenum getFormat() const
    {
      return mInternal;
    }

    GLenum getTarget() const
    {
      return mTarget;
    }
    
    GLenum getType() const
    {
      return mType;
    }
    
    void setWidth(GLsizei width)
    {
      mWidth = width;
    }
    
    void setHeight(GLsizei height)
    {
      mHeight = height;
    }
    
    void setDepth(GLsizei depth)
    {
      mDepth = depth;
    }
    
    void setFormat(GLenum format)
    {
      mFormat = format;
    }   
    
    void setTarget(GLenum target)
    {
      mTarget = target;
    }
    
    void setFiltering(CTexture::EFiltering filtering)
    {
      // sys::info << "ogl::CTexture::setFiltering(CTexture::EFiltering)" << sys::endl;
      // sys::info << " > INFO: " << (GLbitfield)(filtering) << sys::endl;
      glBindTexture(mTarget, mTexture);
      
      switch(filtering)
      {
        case EFiltering::NEAREST:
          glTexParameteri(mTarget, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
          glTexParameteri(mTarget, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
          // sys::info << " > INFO: NEAREST" << sys::endl;
        break;
        default:
        case EFiltering::BILINEAR:
          glTexParameteri(mTarget, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
          glTexParameteri(mTarget, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
          // sys::info << " > INFO: BILINEAR" << sys::endl;
        break;
        case EFiltering::TRILINEAR:
          glTexParameteri(mTarget, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
          glTexParameteri(mTarget, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
          // sys::info << " > INFO: TRILINEAR" << sys::endl;
        break;
        case EFiltering::ANISOTROPIC:
          // sys::info << " > INFO: ANISOTROPIC" << sys::endl;
        break;
      }
    }
    
    void setWrapping(CTexture::EWrapping eWrapping)
    {
      glBindTexture(mTarget, mTexture);
      
      GLenum wrapping = GL_NONE;
      if(eWrapping | EWrapping::CLAMP_TO_EDGE)
        wrapping = GL_CLAMP_TO_EDGE;
      else if(eWrapping | EWrapping::CLAMP_TO_BORDER)
        wrapping = GL_CLAMP_TO_BORDER;
      else if(eWrapping | EWrapping::REPEAT)
        wrapping = GL_REPEAT;
      
      glTexParameteri(mTarget, GL_TEXTURE_WRAP_S, wrapping);
      if(mHeight > 1 || mTarget == GL_TEXTURE_2D || mTarget == GL_TEXTURE_1D_ARRAY)
        glTexParameteri(mTarget, GL_TEXTURE_WRAP_T, wrapping);
      if(mDepth > 1 || mTarget == GL_TEXTURE_3D || mTarget == GL_TEXTURE_CUBE_MAP || mTarget == GL_TEXTURE_2D_ARRAY)
        glTexParameteri(mTarget, GL_TEXTURE_WRAP_R, wrapping);
    }
    
    void genMipmaps()
    {
      glBindTexture(mTarget, mTexture);
      glGenerateMipmap(mTarget);
    }
    
    void bind()
    {
      glBindTexture(mTarget, mTexture);
    }
    
    void bind(GLenum unit)
    {
      glActiveTexture(unit); 
      // TODO: glActiveTexture may be unnecessary...maybe this should be inside material or controlled by the Renderer
      glBindTexture(mTarget, mTexture);
    }
    
    void unbind()
    {
      glBindTexture(mTarget, 0);
    }
    
    void unbind(GLenum unit)
    {
      glActiveTexture(unit);
      glBindTexture(mTarget, 0);
    }
    
    friend inline GLbitfield operator | (const CTexture::EWrapping&, const CTexture::EWrapping&);
    friend inline GLbitfield operator | (const CTexture::EScope&, const CTexture::EFiltering&);
    friend inline GLbitfield operator | (const CTexture::EFiltering&, const CTexture::EWrapping&);
    
    friend inline GLbitfield operator | (GLbitfield, const CTexture::EScope&);
    friend inline GLbitfield operator | (GLbitfield, const CTexture::EFiltering&);
    friend inline GLbitfield operator | (GLbitfield, const CTexture::EWrapping&);
    friend inline GLbitfield operator | (GLbitfield, const CTexture::EOptions&);
    
    
    friend inline GLbitfield operator & (GLbitfield, const CTexture::EScope&);
    friend inline GLbitfield operator & (GLbitfield, const CTexture::EFiltering&);
    friend inline GLbitfield operator & (GLbitfield, const CTexture::EWrapping&);
    friend inline GLbitfield operator & (GLbitfield, const CTexture::EOptions&);
  };
  
  class CStreamTexture : public CTexture
  {
    // TODO:...
    // this will block current rendering process and
    // trigger a new engine render - most likelly from
    // another point of view
    // use for reflections or env cube maps
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  inline GLbitfield operator | (const CTexture::EWrapping& lhs, const CTexture::EWrapping& rhs)
  {
    return (GLbitfield)((GLbitfield)(lhs) | (GLbitfield)(rhs));
  }  
  
  inline GLbitfield operator | (const CTexture::EScope& lhs, const CTexture::EFiltering& rhs)
  {
    return (GLbitfield)((GLbitfield)(lhs) | (GLbitfield)(rhs));
  }  
  
  inline GLbitfield operator | (const CTexture::EFiltering& lhs, const CTexture::EWrapping& rhs)
  {
    return (GLbitfield)((GLbitfield)(lhs) | (GLbitfield)(rhs));
  }
  
  
  inline GLbitfield operator | (GLbitfield lhs, const CTexture::EScope& rhs)
  {
    return (GLbitfield)((lhs) | (GLbitfield)(rhs));
  }
  
  inline GLbitfield operator | (GLbitfield lhs, const CTexture::EFiltering& rhs)
  {
    return (GLbitfield)((lhs) | (GLbitfield)(rhs));
  }
  
  inline GLbitfield operator | (GLbitfield lhs, const CTexture::EWrapping& rhs)
  {
    return (GLbitfield)((lhs) | (GLbitfield)(rhs));
  }  
  
  inline GLbitfield operator | (GLbitfield lhs, const CTexture::EOptions& rhs)
  {
    return (GLbitfield)((lhs) | (GLbitfield)(rhs));
  }  
  
  
  inline GLbitfield operator & (GLbitfield lhs, const CTexture::EScope& rhs)
  {
    return (GLbitfield)((lhs) & (GLbitfield)(rhs));
  }
  
  inline GLbitfield operator & (GLbitfield lhs, const CTexture::EFiltering& rhs)
  {
    return (GLbitfield)((lhs) & (GLbitfield)(rhs));
  }

  inline GLbitfield operator & (GLbitfield lhs, const CTexture::EWrapping& rhs)
  {
    return (GLbitfield)((lhs) & (GLbitfield)(rhs));
  }
  
  inline GLbitfield operator & (GLbitfield lhs, const CTexture::EOptions& rhs)
  {
    return (GLbitfield)((lhs) & (GLbitfield)(rhs));
  }
}

#endif // __ctexture_hpp__
