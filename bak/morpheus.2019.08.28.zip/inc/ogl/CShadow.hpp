#ifndef __ogl_cshadow_hpp__
#define __ogl_cshadow_hpp__

namespace ogl
{
  /**
   * TODD: Replace CShadow with CShadowFbo or CShadowFramebuffer - similary create CGeometryFramebuffer
   */
  class CShadow
  {
    protected:
    CFramebuffer* mFbo;
    
    public:
    ushort        mType;
    GLsizei       mWidth;
    GLsizei       mHeight;
    GLushort      mLayers;
  
    public:
    CShadow(ushort eType, GLsizei nWidth, GLsizei nHeight) : mFbo(nullptr), mType(eType), mWidth(nWidth), mHeight(nHeight), mLayers(1)
    {
      sys::info << "ogl::CShadow::CShadow(" << eType << ", " << nWidth << ", " << nHeight << ")" << sys::endl;
      CFramebufferBuilder* pFramebufferBuilder = CFramebufferBuilder::getInstance();
      pFramebufferBuilder->setWidth(nWidth);
      pFramebufferBuilder->setHeight(nHeight);
      pFramebufferBuilder->setTarget(GL_FRAMEBUFFER);
    
      if(mType == CLight::POINT) // use texture cube
      {
        mLayers = 6;
      
        //pFramebufferBuilder->addTexture(GL_DEPTH_ATTACHMENT, new CTexture(GL_TEXTURE_2D, GL_DEPTH_COMPONENT32, nWidth, nHeight, GL_DEPTH_COMPONENT, GL_FLOAT, CTexture::EScope::SHADOW | CTexture::EFiltering::BILINEAR | CTexture::EWrapping::CLAMP_TO_EDGE));
        
        pFramebufferBuilder->addTexture(GL_DEPTH_ATTACHMENT, new CTexture(GL_TEXTURE_CUBE_MAP, GL_DEPTH_COMPONENT24, nWidth, nHeight, GL_DEPTH_COMPONENT, GL_FLOAT, CTexture::EScope::SHADOW | CTexture::EFiltering::BILINEAR | CTexture::EWrapping::CLAMP_TO_EDGE));
        
        glDrawBuffer(GL_NONE); // disable write to color buffer
        glReadBuffer(GL_NONE); // disable read  from color buffer
        
        mFbo = pFramebufferBuilder->build();
      }
      else // CLight::DIRECT || CLight::SPOT
      {
        pFramebufferBuilder->addTexture(GL_DEPTH_ATTACHMENT, new CTexture(GL_TEXTURE_2D, GL_DEPTH_COMPONENT32, nWidth, nHeight, GL_DEPTH_COMPONENT, GL_FLOAT, CTexture::EScope::SHADOW | CTexture::EFiltering::BILINEAR | CTexture::EWrapping::CLAMP_TO_EDGE));
        
        glDrawBuffer(GL_NONE); // disable write to color buffer
        glReadBuffer(GL_NONE); // disable read  from color buffer
        
        mFbo = pFramebufferBuilder->build();
      }
      
      glDrawBuffer(GL_BACK);
      glReadBuffer(GL_BACK);
    }
    
    virtual ~CShadow()
    {
      sys::info << "ogl::CShadow::~CShadow()" << sys::endl;
      delete mFbo;
    }
  
    public:
    ushort getType() const
    {
      return mType;
    }
    
    GLushort getLayers() const
    {
      return mLayers;
    }
    
    public:
    void bind(GLenum eFace = GL_NONE)
    {
      mFbo->bind(GL_DRAW_FRAMEBUFFER);
      
      if(eFace != GL_NONE)
        glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, eFace, *(mFbo->getTexture(GL_DEPTH_ATTACHMENT)), 0);
      
      glExitIfError();
    }
    
    CTexture* read(GLenum attachement)
    {
      return mFbo->getTexture(attachement);
    }
    
    void clear(GLbitfield buffer)
    {
      mFbo->clear(buffer);
    }
    
    CTexture* getTexture(GLenum attachement)
    {
      return mFbo->getTexture(attachement);
    }
  };
  
  class CShadowManager : public sys::CSingleton<CShadowManager>
  {
    friend class sys::CSingleton<CShadowManager>;
    
    protected:
    std::map<CLight*, CShadow*> mShadows;
    
    public:
    CShadowManager()
    {
      sys::info << "ogl::CShadowManager::CShadowManager() " << sys::endl;
    }
    
    virtual ~CShadowManager()
    {
      sys::info << "ogl::CShadowManager::~CShadowManager() " << sys::endl;
    }
    
    public:
    CShadow* getShadow(CLight* pLight)
    {
      sys::info << "ogl::CShadowManager::getShadow(CLight*) > type: " << pLight->getType();
    
      auto it = mShadows.find(pLight);
      if(it != mShadows.end())
      {
        sys::info << " - found " << sys::endl;
        return it->second;
      }
      
      sys::info << " - new " << sys::endl;
      
      CShadow* pShadow = new CShadow(pLight->getType(), 512, 512);
      mShadows[pLight] = pShadow;
      
      return pShadow;
    }
  };
}

#endif // __ogl_cshadow_hpp__
