#ifndef __ogl_cdeferredrenderer_hpp__
#define __ogl_cdeferredrenderer_hpp__

namespace ogl
{
  class CDeferredRenderer // : public CRenderer
  {
    protected:
    GLsizeui mWidth;
    GLsizeui mHeight;
    
    CCamera* mCamera;
    
    CFramebuffer* mOutputFramebuffer;
    CFramebuffer* mGeometryFramebuffer;
    CFramebuffer* mOcclusionFramebuffer;
    
    std::map<ogl::CLight*,  sys::CDescriptor> mLights;
    std::map<ogl::CObject*, sys::CDescriptor> mObjects;

    CTexture* mNoise;

    public:
    CDeferredRenderer(GLsizeui nWidth, GLsizeui nHeight)
    {
      sys::info << "ogl::CDeferredRenderer::CDeferredRenderer()" << sys::endl;
      
      mWidth  = nWidth;
      mHeight = nHeight;
      
      mCamera = nullptr;
      
      mOutputFramebuffer    = nullptr;
      mGeometryFramebuffer  = nullptr;
      mOcclusionFramebuffer = nullptr;
      
      //sys::ptr<CTexture> pSrc = pTextureManager->newTexture(320, 240, CTexture::RGBA32F | CTexture::BILINEAR | CTexture::CLAMP2EDGE);
      //sys::ptr<CTexture> pCpy = pTextureManager->newTexture(pSrc, CTexture::CLONE);
      
      { // output fbo
        CFramebufferBuilder* pBuilder = new CFramebufferBuilder;
        pBuilder->setWidth(nWidth);
        pBuilder->setHeight(nHeight);
        pBuilder->setTarget(CFramebuffer::DRAW);
        pBuilder->addTexture(OGL_ATTACHEMENT_COLOR, new CTexture(GL_TEXTURE_2D, GL_RGBA32F, mWidth, mHeight, GL_RGBA, GL_FLOAT, CTexture::EFiltering::BILINEAR | CTexture::EWrapping::CLAMP_TO_EDGE));
        mOutputFramebuffer = pBuilder->build();
        glExitIfError();
        delete pBuilder;
      }
      { // geometry fbo
        // GL_RGB32F allowes the fbo to store values outside the [0, 1] range
        CFramebufferBuilder* pBuilder = new CFramebufferBuilder;
        pBuilder->setWidth(nWidth);
        pBuilder->setHeight(nHeight);
        pBuilder->setTarget(CFramebuffer::DRAW);
        pBuilder->addTexture(OGL_ATTACHEMENT_DEPTH,   new CTexture(GL_TEXTURE_2D, GL_DEPTH_COMPONENT, mWidth, mHeight, GL_DEPTH_COMPONENT, GL_FLOAT, CTexture::EFiltering::BILINEAR));
        pBuilder->addTexture(OGL_ATTACHEMENT_COLOR,   new CTexture(GL_TEXTURE_2D, GL_RGB,    mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::BILINEAR));
        pBuilder->addTexture(OGL_ATTACHEMENT_NORMALS, new CTexture(GL_TEXTURE_2D, GL_RGB32F, mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::BILINEAR));
        mGeometryFramebuffer = pBuilder->build();
        glExitIfError();
        delete pBuilder;
        
        // TODO:...
        // pBuilder->setWidth(nWidth)->setHeight(mHeight);
        // pBuilder->addAttachment(CFramebufferBuilder::NORMALS, GL_RGB32F);
        // pBuilder->addAttachment(CFramebufferBuilder::COLOR, GL_RGB32F);
        // pBuilder->addAttachment(CFramebufferBuilder::DEPTH);
        // mGeometryFramebuffer = pBuilder->build();
      }
      { // ambient occlussion fbo
        CFramebufferBuilder* pBuilder = new CFramebufferBuilder;
        pBuilder->setWidth(nWidth);
        pBuilder->setHeight(nHeight);
        pBuilder->setTarget(CFramebuffer::BOTH);
        pBuilder->addTexture(OGL_ATTACHEMENT_COLOR, new CTexture(GL_TEXTURE_2D, GL_R32F, mWidth, mHeight, GL_RED, GL_FLOAT, CTexture::EFiltering::NEAREST | CTexture::EWrapping::CLAMP_TO_EDGE));
        mOcclusionFramebuffer = pBuilder->build();
        glExitIfError();
        delete pBuilder;
      }
    
      mNoise = nullptr;
    }
    
    virtual ~CDeferredRenderer()
    {
      sys::info << "ogl::CDeferredRenderer::~CDeferredRenderer()" << sys::endl;
      
      delete mOutputFramebuffer;
      delete mGeometryFramebuffer;
      delete mOcclusionFramebuffer;
      
      delete mNoise;
    }
    
    public:
    void render()
    {
      sys::info << "ogl::CDeferredRenderer::render()" << sys::endl;
      
      CProgram*        pProgram        = nullptr;
      CProgramManager* pProgramManager = CProgramManager::getInstance();
      CShadowManager*  pShadowManager  = CShadowManager::getInstance();
      
      glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      glClearDepthf(1.0f);
      glDepthRange(0.0f, 1.0f);
      
      // TODO: OpenGL State Manager: https://www.opengl.org/discussion_boards/archive/index.php/t-148964.html
      
      { /* shadow/depth buffers */
        sys::info << sys::tab << "shadow buffers" << sys::endl;
        
        glEnable(GL_CULL_FACE);  // enable face culling
        glCullFace(GL_FRONT);    // cull front face for shadow rendering
        glFrontFace(GL_CCW);     // conter-clockwise winding
        
        glEnable(GL_DEPTH_TEST); // do depth test - no depth = no shadows
        glClearDepthf(1.0f);     // clear to 1.0 - max dist from screen
        glDepthFunc(GL_LEQUAL);  // pass if new depth is <= buffer depth
        glDepthMask(GL_TRUE);    // enable depth buffer for writting
        
        glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
        
        glExitIfError();
        
        static const struct {
          GLenum     eTarget;
          math::vec3 vDirection;
          math::vec3 vUp;
        } oPointLightConfigs[6] = {
          // face, direction, up
          { GL_TEXTURE_CUBE_MAP_POSITIVE_X, math::vec3( 1.0f, 0.0, 0.0f), math::vec3(0.0f, 1.0f, 0.0f) },
          { GL_TEXTURE_CUBE_MAP_NEGATIVE_X, math::vec3(-1.0f, 0.0, 0.0f), math::vec3(0.0f, 1.0f, 0.0f) },
          { GL_TEXTURE_CUBE_MAP_POSITIVE_Y, math::vec3( 0.0f,-1.0, 0.0f), math::vec3(0.0f, 0.0f, 1.0f) },
          { GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, math::vec3( 0.0f, 1.0, 0.0f), math::vec3(0.0f, 0.0f,-1.0f) },
          { GL_TEXTURE_CUBE_MAP_POSITIVE_Z, math::vec3( 0.0f, 0.0, 1.0f), math::vec3(0.0f, 1.0f, 0.0f) },
          { GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, math::vec3( 0.0f, 0.0,-1.0f), math::vec3(0.0f, 1.0f, 0.0f) }
        };
        
        for(auto it = mLights.begin(); it != mLights.end(); ++it)
        {
          ogl::CLight* const& pLight      = it->first;
          sys::CDescriptor&   oDescriptor = it->second;
          
          sys::info << sys::tab << "type " << pLight->getType() << " light" << sys::endl;
          
          if(oDescriptor.hasTag(ogl::tags::NOSHADOW) == true) // only shadow casting lights
            return;
            
          CShadow* pShadow = pShadowManager->getShadow(pLight);
          
          glExitIfError();
          
          for(ushort i = 0, nLayers = pShadow->getLayers(); i < nLayers; ++i) // 6 for point, 1 for spot & direct
          {
            sys::info << sys::tab << "layer " << i << sys::endl;
          
            if(nLayers == 1)
              pShadow->bind();                              // bind shadow fbo for writing
            else // if point light
              pShadow->bind(oPointLightConfigs[i].eTarget); // bind(target)
              // pShadowFramebuffer->bind(pLight->getConfig(i).getTarget());
           
            // TODO: maybe these should be inside bind() & unbind() functions
            glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);       // mask-of color rendering
            glDrawBuffer(GL_NONE);                                     // disable write to color buffer
            glReadBuffer(GL_NONE);                                     // disable read  from color buffer

            pShadow->clear(CFramebuffer::DEPTH | CFramebuffer::COLOR); // clear shadow fbo depth buffer
            
            glExitIfError();
            
            for(auto it = mObjects.begin(); it != mObjects.end(); ++it)
            {
              ogl::CObject* const& pObject     = it->first;
              sys::CDescriptor&    oDescriptor = it->second;
        
              if(oDescriptor.hasTag(ogl::tags::NOSHADOW) == true) // only shadow casting objects
                return;
                
              // TODO: merge draw_command & draw_strategy
              CDrawCommand*  pDrawCommand  = pObject->getDrawCommand();
              CDrawStrategy* pDrawStrategy = pObject->getDrawStrategy();

              // get program
              pProgram = pProgramManager->getProgram(ogl::tags::SHADOWMAP /*+ pDrawStrategy->getTag()*/);
              
              pDrawCommand->mMode = pProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
              
              glExitIfError();
              
              { /* program setup */
                math::mat4 mM = pDrawCommand->mModelMatrix;
                math::mat4 mV;
                math::mat4 mP;
                
                switch(pLight->getType())
                {
                  case ogl::CLight::DIRECT:
                  {
                    ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
                    mV = math::lookat(-pDirectLight->mDirection, math::O , math::Y);
                    mP = math::ortho(-5.0f, +5.0f, -5.0f, +5.0f, -25.0f, +25.0f);
                  }
                  break;
                  case ogl::CLight::SPOT:
                  {
                    ogl::CSpotLight* pSpotLight = dynamic_cast<ogl::CSpotLight*>(pLight);
                    mV = math::lookat(pSpotLight->mPosition, pSpotLight->mDirection, math::Y);
                    mP = mCamera->getProjectionMatrix();
                  }
                  break;
                  case ogl::CLight::POINT:
                  {
                    ogl::CPointLight* pPointLight = dynamic_cast<ogl::CPointLight*>(pLight);
                    mV = math::lookat(pPointLight->mPosition, pPointLight->mPosition + oPointLightConfigs[i].vDirection, oPointLightConfigs[i].vUp);
                    mP = math::perspective(90.0f, 1.0f, mCamera->getNear(), mCamera->getFar()); // MUST BE 90.0f
                  }
                  break;
                }
                
                pProgram->set("u_mMVP", mP * mV * mM);
              }
              
              glExitIfError();
              
              { /* draw: shapes */
                // TODO: move this inside CDrawStrategy and have a bit(isVboBound?) and reset after the last command
                // moved inside inside first getDrawCommand()
                glBindVertexArray(pDrawCommand->mVAO);
                glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
                
                CDrawCommand* pFirstCommand = pDrawCommand;
                while(pDrawCommand != nullptr)
                {
                  pDrawStrategy->draw(pDrawCommand);
                  pDrawCommand = pDrawCommand->next();
                  // pDrawCommand->execute();
                }
                _DELETE(pFirstCommand);
              }
            }
          }
        }
        
        /* TODO: reset fbo, draw, read buffers & masks(color) */
        
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        
        glExitIfError();
      }
      
      { /* geometry buffer */
        sys::info << sys::tab << "geometry buffer" << sys::endl;
        
        glDisable(GL_CULL_FACE);
        glCullFace(GL_BACK);
        glFrontFace(GL_CCW);
        
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
        glDepthMask(GL_TRUE);
        
        mGeometryFramebuffer->bind(CFramebuffer::DRAW);
        
        glExitIfError();
        
        pProgram = pProgramManager->getProgram(ogl::tags::GEOMETRY + ogl::tags::DEFERRED + ogl::tags::SINGLE + ogl::tags::PARALLAX); // pDrawStrategy->getTag()
        
        pProgram->set("u_oCamera.vPosition", mCamera->getPosition());
        pProgram->set("u_mV", mCamera->getViewMatrix());
        pProgram->set("u_mP", mCamera->getProjectionMatrix());
        //pProgram->once("u_mVP", value); // only set once - get reset on program change
        
        glExitIfError();
        
        { /* draw: objects */
          for(auto it = mObjects.begin(); it != mObjects.end(); ++it)
          {
            sys::info << sys::tab << "draw object: " << it->second << sys::endl;
            
            ogl::CObject* pObject = it->first;
            
            CDrawCommand*  pDrawCommand  = pObject->getDrawCommand();
            CDrawStrategy* pDrawStrategy = pObject->getDrawStrategy();
            
            pDrawCommand->mMode = pProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
            
            /* set model matrix */
            pProgram->set("u_mM", pObject->getModelMatrix());
            
            { /* draw: shapes */
              /* TODO: move this inside CDrawStrategy and have a bit(isVboBound?) */
              glBindVertexArray(pDrawCommand->mVAO);
              glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // MUST
            
              CDrawCommand* pFirstCommand = pDrawCommand;
              while(pDrawCommand != nullptr)
              {
                // TODO: pProgram->setMaterial(pDrawCommand->mMaterial);
                pDrawCommand->mMaterial->bind(); // first bind, than set
                pProgram->set("u_oMaterial.iOptions", pDrawCommand->mMaterial->getOptions());
                
                pDrawStrategy->draw(pDrawCommand);
                
                pDrawCommand = pDrawCommand->next();
              }
              
              glBindBuffer(pFirstCommand->mTarget, 0);
              glBindVertexArray(0);
              glBindTexture(GL_TEXTURE_2D, 0);
              
              _DELETE(pFirstCommand);
            }
            
            glExitIfError();
          }
        }
        
        // pProgramManager->disable();
      }
      
      { /* ambient occlusion buffer */
        sys::info << sys::tab << "occlusion buffer" << sys::endl;
        
        mOcclusionFramebuffer->bind(CFramebuffer::DRAW);
        
        pProgram = pProgramManager->getProgram(ogl::tags::OCCLUSSION + ogl::tags::DEFERRED);
        
        //pProgram->set("u_fRadius", 0.15f);
        pProgram->set("u_mV", mCamera->getViewMatrix());
        pProgram->set("u_mP", mCamera->getProjectionMatrix());
        
        { /* random shit... load kernel */
          static bool bOnce = true;
          static const size_t nKernelSize = 64;
          static math::vec3   vKernel[nKernelSize];
          if(bOnce) 
          {
            bOnce = false;
            for(size_t i = 0; i < nKernelSize; ++i)
            {
              float fScale = (float)(i) / (float)(nKernelSize); // 1/64, 2/64, 3/64...
              math::vec3 v;
              v.x = ((float)rand() / RAND_MAX) * 2.0f - 1.0f;  // [ 0, 32767] / 32767 = 2 * [0, 1] = [0, 2] - 1 = [-1, 1]
              v.y = ((float)rand() / RAND_MAX) * 2.0f - 1.0f;  // [-1, 1]
              v.z = ((float)rand() / RAND_MAX);                // [ 0, 1]
              
              v = math::normalize(v);
              fScale = math::mix(0.1f, 1.0f, fScale * fScale); // lerp
              v *= fScale;
              
              vKernel[i] = v;
            }
          }
          pProgram->set("u_vKernel", nKernelSize, vKernel);
          
          if(mNoise == nullptr)
          {
            CNoiseTextureBuilder* pBuilder = new CNoiseTextureBuilder;
            pBuilder->setWidth(4);
            pBuilder->setHeight(4);
            pBuilder->setFormat(GL_RGB16F); // GL_RGB + GL_FLOAT
            pBuilder->setFiltering(CTexture::EFiltering::NEAREST);
            pBuilder->setWrapping(CTexture::EWrapping::REPEAT);
            pBuilder->setCallback([](math::vec3& color) -> void { 
              color.r = color.r * 2.0f - 1.0f; // [0, 32767] / 32767 = 2 * [0, 1] = [0, 2] - 1 = [-1, 1]
              color.g = color.g * 2.0f - 1.0f;
              color.b = 0.0f;
            });
            mNoise = pBuilder->build();
            delete pBuilder;
          }
          
          mNoise->bind(OGL_TEXTURE_NOISE2D);
        }
        
        mGeometryFramebuffer->read(OGL_ATTACHEMENT_DEPTH)->bind(OGL_TEXTURE_DEPTH);
        mGeometryFramebuffer->read(OGL_ATTACHEMENT_NORMALS)->bind(OGL_TEXTURE_NORMALS);
        
        glDrawFullscreenQuad();
      
        glBindTexture(GL_TEXTURE_2D, 0);
        
        glExitIfError();
      }
      
      { /* ao buffer blur pass */
        sys::info << sys::tab << "blur" << sys::endl;
        
        mOcclusionFramebuffer->bind(/* READ + DRAW */);
        
        pProgram = pProgramManager->getProgram(ogl::tags::POSTPROCESS + ogl::tags::BLUR);
        
        mOcclusionFramebuffer->copy(OGL_ATTACHEMENT_COLOR)->bind(OGL_TEXTURE_GENERIC);
        
        glDrawFullscreenQuad();
        
        glBindTexture(GL_TEXTURE_2D, 0);
      }
      
      { /* lighting pass */
        sys::info << sys::tab << "lighting pass" << sys::endl;
        
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_STENCIL_TEST);
        
        glEnable(GL_BLEND);
        glBlendEquation(GL_FUNC_ADD);
        glBlendFunc(GL_ONE, GL_ONE);
        
        glEnable(GL_CULL_FACE);
        glCullFace(GL_BACK);
        glFrontFace(GL_CCW);
        
        mOutputFramebuffer->bind(CFramebuffer::DRAW); // cleared ofter output
        
        pProgram = pProgramManager->getProgram(ogl::tags::LIGHTING + ogl::tags::DEFERRED + ogl::tags::OCCLUSSION);
        
        { /* program: set renderer, camera */
          /* TODO: delegate setting program stuff
              pProgram->set(*this);
              pProgram->set(mCamera);
              objects like CObject, CCamera, CRenderer, CLight become CUniform's and can be used to set the program */
          pProgram->set("oCamera.vPosition", mCamera->getPosition());
          pProgram->set("oCamera.mV",        mCamera->getViewMatrix());
          pProgram->set("oCamera.mP",        mCamera->getProjectionMatrix());
        }
        
        mGeometryFramebuffer->read(OGL_ATTACHEMENT_DEPTH)->bind(OGL_TEXTURE_DEPTH);
        mGeometryFramebuffer->read(OGL_ATTACHEMENT_NORMALS)->bind(OGL_TEXTURE_NORMALS);
        mGeometryFramebuffer->read(OGL_ATTACHEMENT_DIFFUSE)->bind(OGL_TEXTURE_DIFFUSE);
        
        mOcclusionFramebuffer->read(OGL_ATTACHEMENT_COLOR)->bind(OGL_TEXTURE_OCCLUSSION);
        
        { /* program: set lights */
          for(auto it = mLights.begin(); it != mLights.end(); ++it)
          {
            ogl::CLight*       pLight      = it->first;
            sys::CDescriptor&  oDescriptor = it->second;
            
            if(oDescriptor.hasTag(ogl::tags::NOSHADOW) == true) // only shadow casting lights
              continue;
            
            if(pLight->getType() != ogl::CLight::DIRECT)
              continue;
            
            // TODO: pProgram->set(pLight);
            switch(pLight->getType())
            {
              case ogl::CLight::DIRECT:
              {
                pShadowManager->getShadow(pLight)->read(GL_DEPTH_ATTACHMENT)->bind(OGL_TEXTURE_DIRECTSHADOW); // bind shadow texture
              
                ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
                math::mat4 mV = math::lookat(-pDirectLight->mDirection, math::O , math::Y);
                math::mat4 mP = math::ortho(-5.0f, +5.0f, -5.0f, +5.0f, -25.0f, +25.0f);
                
                pProgram->set("oDirectLight.vColor",            pDirectLight->mColor);
                pProgram->set("oDirectLight.vDirection",        pDirectLight->mDirection);
                pProgram->set("oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
                pProgram->set("oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
                pProgram->set("oDirectLight.mVP",               mP * mV);
              }
              break;
              case ogl::CLight::POINT:
              {
                ogl::CPointLight* pPointLight = dynamic_cast<ogl::CPointLight*>(pLight);
                
                pProgram->set("oPointLight.vColor",             pPointLight->mColor);
                pProgram->set("oPointLight.vPosition",          pPointLight->mPosition);
                pProgram->set("oPointLight.fAmbientIntensity",  pPointLight->mAmbientIntensity);
                pProgram->set("oPointLight.fDiffuseIntensity",  pPointLight->mDiffuseIntensity);
                pProgram->set("oPointLight.fK0",                pPointLight->mK0);
                pProgram->set("oPointLight.fK1",                pPointLight->mK1);
                pProgram->set("oPointLight.fK2",                pPointLight->mK2);
              }
              break;
              case ogl::CLight::SPOT:
              {
                ogl::CSpotLight* pSpotLight = dynamic_cast<ogl::CSpotLight*>(pLight);
                math::mat4 mV = math::lookat(pSpotLight->getPosition(), pSpotLight->getDirection(), math::Y);
                math::mat4 mP = math::perspective(90.0f, 1.0f, mCamera->getNear(), mCamera->getFar()); // MUST BE 90.0f
                                pProgram->set("oSpotLight.vPosition",         pSpotLight->mPosition);
                pProgram->set("oSpotLight.vDirection",        pSpotLight->mDirection);
                pProgram->set("oSpotLight.fCutoff",           pSpotLight->mCutoff);
                pProgram->set("oSpotLight.fAmbientIntensity", pSpotLight->mAmbientIntensity);
                pProgram->set("oSpotLight.fDiffuseIntensity", pSpotLight->mDiffuseIntensity);
                pProgram->set("oSpotLight.fK0",               pSpotLight->mK0);
                pProgram->set("oSpotLight.fK1",               pSpotLight->mK1);
                pProgram->set("oSpotLight.fK2",               pSpotLight->mK2);
                pProgram->set("oSpotLight.mVP",               mP * mV);
              }
              break;
            }
            
            glDrawFullscreenQuad();
            
            glBindTexture(GL_TEXTURE_2D, 0);
          }
        }
        
        glDisable(GL_BLEND);
        
        glBindTexture(GL_TEXTURE_2D, 0);
        
        glExitIfError();
      }
      
      if(0){ /* debug: normals */
        glLineWidth(0.5f);
        
        mOutputFramebuffer->bind(CFramebuffer::DRAW);
        
        pProgram = pProgramManager->getProgram(ogl::tags::DEBUG + ogl::tags::NORMALS);

        pProgram->set("u_mVP", mCamera->getProjectionMatrix() * mCamera->getViewMatrix());
        
        { /* draw: objects */
          for(auto it = mObjects.begin(); it != mObjects.end(); ++it)
          {
            sys::info << "> draw object: " << it->second << sys::endl;
            
            ogl::CObject* pObject = it->first;
            
            CDrawCommand*  pDrawCommand  = pObject->getDrawCommand();
            CDrawStrategy* pDrawStrategy = pObject->getDrawStrategy();
            
            pDrawCommand->mMode = GL_POINTS;
          
            pProgram->set("u_mM",  pObject->getModelMatrix());
            
            glBindVertexArray(pDrawCommand->mVAO);
            glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
            
            CDrawCommand* pFirstCommand = pDrawCommand;
            while(pDrawCommand != nullptr)
            {
              pDrawStrategy->draw(pDrawCommand);
              pDrawCommand = pDrawCommand->next();
            }
            
            glBindVertexArray(0);
            glBindBuffer(pFirstCommand->mTarget, 0);
          
            _DELETE(pFirstCommand);
            
          }
        }
      }
      
      { /* output pass - after post-processing */
        sys::info << sys::tab << "output" << sys::endl;
        
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_STENCIL_TEST);
        
        glEnable(GL_CULL_FACE);
        glCullFace(GL_BACK);
        glFrontFace(GL_CCW);
        
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glDrawBuffer(GL_BACK);
        glViewport(0, 0, mWidth, mHeight); // MUST
        glClear(GL_COLOR_BUFFER_BIT);
        
        pProgram = pProgramManager->getProgram(ogl::tags::OUTPUT + ogl::tags::DEFERRED + ogl::tags::TEXTURE);
        
        mOutputFramebuffer->read(OGL_ATTACHEMENT_COLOR)->bind(OGL_TEXTURE_GENERIC);
        
        glDrawFullscreenQuad();
        
        glBindTexture(GL_TEXTURE_2D, 0);
      }
      
      { /* clear */
        mOcclusionFramebuffer->bind(CFramebuffer::DRAW);
        mOcclusionFramebuffer->clear(CFramebuffer::COLOR);
        
        mOutputFramebuffer->bind(CFramebuffer::DRAW);
        mOutputFramebuffer->clear(CFramebuffer::COLOR);
        
        mGeometryFramebuffer->bind(CFramebuffer::DRAW);
        mGeometryFramebuffer->clear(CFramebuffer::COLOR | CFramebuffer::DEPTH);
        
        mObjects.clear();
        mLights.clear();
      }
      
      glExitIfError();
    }
    
    void setCamera(ogl::CCamera* pCamera)
    {
      sys::info << "ogl::CDeferredRenderer::setCamera(ogl::CCamera*)" << sys::endl;
      mCamera = pCamera;
    }
  
    void addLight(CLight* pLight, const sys::CDescriptor& oDescriptor)
    {
      mLights[pLight] = oDescriptor;
    }
  
    void addObject(CObject* pObject, const sys::CDescriptor& oDescriptor)
    {
      mObjects[pObject] = oDescriptor;
    }
  };
}

#endif // __ogl_cdeferredrenderer_hpp__
