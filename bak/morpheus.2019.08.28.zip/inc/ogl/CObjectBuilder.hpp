#ifndef __cobjectbuilder_hpp__
#define __cobjectbuilder_hpp__

namespace ogl
{
  class CObjectBuilder 
  {
    public:
    enum EOptions : GLbitfield
    {
      POSITIONS  = 0x0001,  //   1 | process positions into object
      TEXCOORDS  = 0x0002,  //   2 |
      NORMALS    = 0x0004,  //   4 |
      TANGENTS   = 0x0008,  //   8 | x04 + x08       | must have normals
      BINORMALS  = 0x0010,  //  16 | x04 + x08 + x10 | must have normals & tangents
      
      NORMALIZED = 0x0020,  //  32 | x01 + x20 | normalize position vectors | must have positions
      INVERTED   = 0x0040,  //  64 | x04 + x40 | invert normals | must have normals
      ADJACENCY  = 0x0080,  // 128 |
      FLATFACE   = 0x0100,  // 256 | flat face - for loaded meshes this will used default normals - otherwise compute face normals
      
      FLIPXY     = 0x0200,
      FLIPYZ     = 0x0400,
      FLIPXZ     = 0x0800,
    };
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    protected:
    GLbitfield     mOptions;
    CDrawStrategy* mDrawStrategy;
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public:
    CObjectBuilder() : mOptions(POSITIONS | TEXCOORDS | NORMALS), mDrawStrategy(nullptr)
    {
    
    }
    
    CObjectBuilder(GLbitfield options) : mOptions(options)
    {
    
    }
    
    virtual ~CObjectBuilder()
    {
      
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public:
    virtual inline void setOptions(GLbitfield options)
    {
      mOptions = options;
    }
    
    virtual inline void addOption(GLbitfield option)
    {
      mOptions |= option;
    }
    
    virtual inline bool hasOption(GLbitfield options)
    {
      return mOptions & options;
    }
    
    virtual void setDrawStrategy(CDrawStrategy* pDrawStrategy)
    {
      mDrawStrategy = pDrawStrategy;
    }
    
    virtual CObject* build(GLbitfield options)
    {
      mOptions = options;
      return build();
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public:
    virtual CObject* build() = 0;
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
//    friend GLbitfield operator |  (const CObjectBuilder::EOptions& lhs, const CObjectBuilder::EOptions& rhs);
//    
//    friend GLbitfield operator |  (const CObjectBuilder::EOptions& lhs, const GLbitfield& rhs);
//    
//    friend GLbitfield operator |  (const GLbitfield& lhs, const CObjectBuilder::EOptions& rhs);
//    
//    friend void operator |= (GLbitfield& lhs, const CObjectBuilder::EOptions& rhs);
  };
  
//  GLbitfield operator |  (const CObjectBuilder::EOptions& lhs, const CObjectBuilder::EOptions& rhs)
//  {
//    return (GLbitfield)(lhs) | (GLbitfield)(rhs);
//  }
//  
//  GLbitfield operator |  (const CObjectBuilder::EOptions& lhs, const GLbitfield& rhs)
//  {
//    return (GLbitfield)(lhs) | (rhs);
//  }  
//  
//  GLbitfield operator |  (const GLbitfield& lhs, const CObjectBuilder::EOptions& rhs)
//  {
//    return (lhs) | (GLbitfield)(rhs);
//  }
//  
//  void operator |= (GLbitfield& lhs, const CObjectBuilder::EOptions& rhs)
//  {
//    lhs |= (GLbitfield)(rhs);
//  }
}

#endif // __cobjectbuilder_hpp__
