#ifndef __cshaderprogrambuilder_hpp__
#define __cshaderprogrambuilder_hpp__

#include <vector>
#include <exception>
#include <functional>

namespace ogl
{
  class CRenderer;
  class CDrawCommand;

  class CProgramBuilder
  {
    public:
    std::map<std::string, CUniform*>               mUniforms;
    std::vector<std::string>                       mVaryings;
    std::function<void(CRenderer*, CDrawCommand*)> mCallback;
    bool                                           mTessellated;
    
    public:
    CProgramBuilder() : mTessellated(false)
    {
      sys::info << "ogl::CProgramBuilder::CProgramBuilder()" << sys::endl;
    }
    
    virtual ~CProgramBuilder()
    {
      sys::info << "ogl::CProgramBuilder::~CProgramBuilder()" << sys::endl;
    }
    
    public:
    virtual CProgram* build() = 0;
    
    void addUniform(const std::string& name, CUniform* pUniform)
    {
      sys::info << "ogl::CProgramBuilder::addUniform(" << name << ", pUniform)" << sys::endl;
      if(pUniform != nullptr)
        mUniforms.insert(std::make_pair(name, pUniform));
    }
    
    void addUniform(CUniform* pUniform)
    {
      throw EXCEPTION << "NOT IMPLEMENTED!";
    }
    
    void setCallback(const std::function<void(CRenderer*, CDrawCommand*)>& callback)
    {
      sys::info << "ogl::CProgramBuilder::setCallback(callback)" << sys::endl;
      mCallback = callback;
    }

    void addVarying(const std::string& varying)
    {
      mVaryings.push_back(varying);
    }
  };

  class CShaderProgramBuilder : public CProgramBuilder
  {
    protected:
    std::vector<CShader*>    mShaders;
    
    public:
    CShaderProgramBuilder() : CProgramBuilder()
    {
      sys::info << "ogl::CShaderProgramBuilder::CShaderProgramBuilder()" << sys::endl;
    }
    
    public:
    CProgram* build()
    {
      sys::info << "ogl::CShaderProgramBuilder::build()" << sys::endl;
      
      // glExitIfError();
        
      if(mShaders.size() <= 0)
        throw CException("No shaders attached!");
        //CErrorManager::triggerError(EErrorType::FATAL, "ogl::CFileShaderBuilder::build() > Type not defined!");
      
      GLuint program = glCreateProgram();
      
      for(auto pShader : mShaders)
        glAttachShader(program, *pShader);
      
      if(mVaryings.size() > 0)
      {
        const GLchar* varyings[mVaryings.size()];
        for(size_t i = 0; i < mVaryings.size(); i++)
          varyings[i] = mVaryings[i].c_str();
        glTransformFeedbackVaryings(program, mVaryings.size(), varyings, GL_INTERLEAVED_ATTRIBS);
      }
      
      GLboolean bLinked = GL_TRUE;
      glLinkProgram(program);
      
      GLint status = GL_FALSE;
      glGetProgramiv(program, GL_LINK_STATUS, &status);
      if(status == GL_FALSE)
      {
        GLint loglen;
        glGetProgramiv(program, GL_INFO_LOG_LENGTH, &loglen);
        GLchar* error = new GLchar[loglen + 1];
        glGetProgramInfoLog(program, loglen, NULL, error);
        error[loglen] = '\0';
        // triggerError()
        throw EXCEPTION << "Link error! " << error;
        _DELETE(error);
        bLinked = GL_FALSE;
      }
      
      for(auto pShader : mShaders)
        glDetachShader(program, *pShader);
      
      CProgram* pProgram = new CProgram(program, bLinked);
      
      if(pProgram->isLinked())
      {
        for(auto it = mUniforms.begin(); it != mUniforms.end(); ++it)
          delete it->second;
      
        /* old way of setting uniforms
        for(auto it = mUniforms.begin(); it != mUniforms.end(); ++it)
        {
          if(it->second != nullptr)
          {
            it->second->setProgram(pProgram);
            GLint location = glGetUniformLocation(program, it->first.c_str());
            if(location < 0)
              std::cerr << "> ERROR: Bad uniform name: " << it->first.c_str() << "!" << sys::endl;
            else
              it->second->setLocation(location);
            
            // DELETE uniform if not found
            
            //sys::info << sys::tab << "uniform: " << location << sys::endl;
            pProgram->addUniform(it->first.c_str(), it->second);
            //sys::info << sys::tab << "uniform:" << pProgram->getUniform(it->first)->getLocation() << sys::endl;
          }
        }
        */
        
        { // search for uniforms in compiled program
          int total = -1, len, num;
          GLenum type;
          glGetProgramiv(*pProgram, GL_ACTIVE_UNIFORMS, &total);
          for(int i = 0; i < total; ++i)
          {
            len = -1; num = -1;
            type = GL_ZERO;
            GLchar name[100];
            glGetActiveUniform(*pProgram, GLuint(i), sizeof(name)-1, &len, &num, &type, name);
            name[len] = '\0';
            GLuint location = glGetUniformLocation(*pProgram, name);
            
            std::string uniform(name);
            
            std::string::size_type pos = uniform.find('[');
            if(pos != std::string::npos)
              uniform = uniform.substr(0, pos);
            
            // sys::info << location << " " << type << " " << uniform << "[ as: " <<  << sys::endl;
            
            CUniform* pUniform = new CUniform(uniform, type);
            pUniform->setLocation(location);
            pUniform->setProgram(pProgram);
            pProgram->addUniform(uniform.c_str(), pUniform);
          }
        }
        
        pProgram->setCallback(mCallback);
        pProgram->setTessellated(mTessellated);
      }
      else
      {
        _DELETE(pProgram);
        throw EXCEPTION << "No link no uniforms!";
      }
      
      mShaders.clear();
      mUniforms.clear();
      mVaryings.clear();
      
      return pProgram;
    }
    
    void addShader(CShader* pShader)
    {
      if(pShader == nullptr)
        throw EXCEPTION << "Can not add a NULL shader!";
      
      sys::info << "ogl::CShaderProgramBuilder::addShader(pShader)" << sys::endl;
      mShaders.push_back(pShader);
      GLuint type = pShader->getType();
      if(type == GL_TESS_CONTROL_SHADER || type == GL_TESS_EVALUATION_SHADER)
        mTessellated = true;
    }
  };
}

#endif // __cshaderprogrambuilder_hpp__
