#ifndef __CBONE_HPP__
#define __CBONE_HPP__

namespace ogl
{
  class CBone
  {
    public:
    math::ivec4 mIDs;     // 4 = MAX_BONES_PER_VERTEX
    math::vec4  mWeights;
    
    public:
    CBone()
    {
    
    }
    
    virtual ~CBone()
    {
      
    }
  };
}

#endif // __CBONE_HPP__
