#ifndef __CPNGTEXTUREBUILDER_HPP__
#define __CPNGTEXTUREBUILDER_HPP__

#include <png/png.h>

namespace ogl
{
  class CPngTextureBuilder : public CTextureBuilder
  {
    public:
    CPngTextureBuilder() : CTextureBuilder()
    {
      sys::info << "ogl::CPngTextureBuilder::CPngTextureBuilder()" << sys::endl;
    }
    
    virtual ~CPngTextureBuilder()
    {
      sys::info << "ogl::CPngTextureBuilder::~CPngTextureBuilder()" << sys::endl;
    }
    
    protected:
    std::string mFile;
    
    public:
    void setFile(const std::string& file)
    {
      mFile.clear();
      mFile.append(TEXTUREPATH).append(file);
    }
    
    public:
    CTexture* build()
    {
      sys::info << "ogl::CDdsTextureBuilder::build() " << sys::endl;
      sys::info << "file: " << mFile << sys::endl;
      
      png_byte header[8];
      
      FILE* fp = fopen(mFile.c_str(), "rb");
      if(fp == NULL)
      {
        // perror(mFile.c_str()); // <cstdio>
        sys::warn << "Failed trying to read file." << sys::endl;
        return nullptr;
      }
      
      fread(header, 1, 8, fp);  // read header
      
      if(png_sig_cmp(header, 0, 8))
      {
        sys::warn << "This is not a PNG file. " << mFile << sys::endl;
        fclose(fp);
        return nullptr;
      }
      
      png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL); // 
      if(!png_ptr)
      {
        sys::warn << "png_create_read_struct() returned 0." << sys::endl;
        fclose(fp);
        return nullptr;
      }
      
      png_infop info_ptr = png_create_info_struct(png_ptr);  // create png info struct
      if(!info_ptr)
      {
        sys::warn << "png_create_info_struct() returned 0." << sys::endl;
        png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
        fclose(fp);
        return nullptr;
      }
      
      png_infop end_info = png_create_info_struct(png_ptr); // create png info struct
      if(!end_info)
      {
        sys::warn << "png_create_info_struct() returned 0." << sys::endl;
        png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
        fclose(fp);
        return nullptr;
      }
      
      if(setjmp(png_jmpbuf(png_ptr))) // if libpng encounters an error
      {
        sys::warn << "libpng error." << sys::endl;
        png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
        fclose(fp);
        return nullptr;
      }
      
      png_init_io(png_ptr, fp); // init png reading
      
      png_set_sig_bytes(png_ptr, 8); // let libpng know the 1st 8bytes have been read
      
      png_read_info(png_ptr, info_ptr); // read info data
      
      int bit_depth, color_type; //, bpp;
      png_uint_32 width, height;
      
      png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth, &color_type, NULL, NULL, NULL); // get info
      png_set_strip_16(png_ptr);
      png_set_packing(png_ptr);
      
      switch (color_type)
      {
        case PNG_COLOR_TYPE_GRAY:
        {
          png_set_expand_gray_1_2_4_to_8(png_ptr);
          png_set_gray_to_rgb(png_ptr);
          png_set_bgr(png_ptr);
          //bpp = 8;
          break;
        }
        case PNG_COLOR_TYPE_PALETTE:
        {
          png_set_palette_to_rgb(png_ptr);
          if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
            png_set_tRNS_to_alpha(png_ptr);
          else
            png_set_filler(png_ptr, 0xFF, PNG_FILLER_AFTER);
          png_set_bgr(png_ptr);
          //bpp = 24;
          break;
        }
        case PNG_COLOR_TYPE_GRAY_ALPHA:
        {
          png_set_gray_to_rgb(png_ptr);
          break;
        }
        case PNG_COLOR_TYPE_RGB:
        {
          png_set_bgr(png_ptr);
          png_set_filler(png_ptr, 0xFF, PNG_FILLER_AFTER);
          //bpp = 24;
          break;
        }
        case PNG_COLOR_TYPE_RGBA:
        {
          png_set_bgr(png_ptr);
          //bpp = 32;
          break;
        }
        default:
        {
          sys::warn << "Unknown PNG format." << sys::endl;
          png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
          fclose(fp);
          return nullptr;
        }
      }

      png_read_update_info(png_ptr, info_ptr); // update png info struct
      
      uint rowbytes = png_get_rowbytes(png_ptr, info_ptr);
      rowbytes += 3 - ((rowbytes - 1) % 4);
      
      png_byte* image_data = new png_byte[rowbytes * height];
      // image_data = (png_bytep) malloc(rowbytes * height); //  * sizeof(png_byte) + 15
      if(!image_data)
      {
        sys::warn << "Could not allocate memory for PNG data." << sys::endl;
        png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
        fclose(fp);
        return nullptr;
      }
      
      png_bytep* row_pointers = new png_bytep[height];
      // png_bytepp row_pointers = (png_bytepp) malloc(height * sizeof(png_bytep));
      if(!row_pointers)
      {
        sys::warn << "Could not allocate memory for PNG row pointers." << sys::endl;
        png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
        delete [] image_data;
        fclose(fp);
        return nullptr;
      }
      
      for(uint i = 0; i < height; ++i)
        row_pointers[height - 1 - i] = image_data + i * rowbytes;
        // memcpy(image_data + (rowbytes * (height - 1 - i)), row_pointers[i], rowbytes);
      
      png_read_image(png_ptr, row_pointers); // read image data
      
      // generate opengl texture
      CTexture* pTexture = new CTexture; //(CTextureData(image_data, GL_UNSIGNED_BYTE, GL_RGB), width, height, GL_RGB, GL_TEXTURE_2D);
      pTexture->setWidth(width);
      pTexture->setHeight(height);
      pTexture->setDepth(1);
      pTexture->setFormat(GL_RGB);
      pTexture->setTarget(GL_TEXTURE_2D);
      pTexture->bind();
      glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);
      pTexture->setFiltering(CTexture::EFiltering::TRILINEAR);
      glGenerateMipmap(GL_TEXTURE_2D);
      
      png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
      delete [] image_data;
      delete [] row_pointers;
      fclose(fp);
      
      return pTexture;
    }
  };
}

#endif // __CPNGTEXTUREBUILDER_HPP__
