#ifndef __cparticle_hpp__
#define __cparticle_hpp__

namespace ogl
{
  class CParticle
  {  
    public:
    static constexpr float LAUNCHER  = 0.0f;
    static constexpr float PRIMARY   = 1.0f;
    static constexpr float SECONDARY = 2.0f;
    static constexpr float TERTIARY  = 3.0f;
  
    public:
    float         mType;
    math::vec3    mPosition;
    math::vec3    mVelocity;
    float         mLifetime;
    
    CParticle() : mType(PRIMARY), mPosition(0.0f, 0.0f, 0.0f), mVelocity(0.0f, 0.0001f, 0.0f), mLifetime(0.0f)
    {
      
    }
  };
}

#endif // __cparticle_hpp__
