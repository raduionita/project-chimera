#ifndef __ogl_CMATERIALMANAGER_HPP__
#define __ogl_CMATERIALMANAGER_HPP__

namespace ogl
{
  class CMaterialManager : public sys::CSingleton<CMaterialManager>
  {
    friend class sys::CSingleton<CMaterialManager>;
    
    public:
    void bind(const CMaterial* pMaterial)
    {
      // reset texture unit 
      // bind each material
      
    }
  };
}

#endif // __ogl_CMATERIALMANAGER_HPP__
