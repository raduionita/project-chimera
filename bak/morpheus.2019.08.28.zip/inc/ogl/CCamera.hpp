#ifndef __ccamera_hpp__
#define __ccamera_hpp__

namespace ogl
{
  class CFrustum : public math::CShape
  {
    public:
    enum
    {
      _NEAR   = 0,
      _FAR    = 1,
      _LEFT   = 2,
      _RIGHT  = 3,
      _TOP    = 4,
      _BOTTOM = 5
    };
  
    public:
    CFrustum() : math::CShape(6)
    {
      
    }
    
    public:
    void addPlane(const math::CPlane& plane)
    {
      assert(mPlanes.size() < 6);
      mPlanes.push_back(plane);
    }
  };

  class CCamera
  {
    protected:
    math::vec3 mPosition;
    math::vec3 mUp;
    math::vec3 mLeft;
    math::vec3 mForward;
    
    math::quat mOrientation;
    math::mat4 mViewMatrix;
    math::mat4 mProjectionMatrix;
    
    float mFov;
    float mRatio;
    float mNear;
    float mFar;
    
    bool mDirty;
    
    public:
    CCamera() 
    : mPosition(0.0f, 0.0f, 0.0f), mUp(0.0f, 1.0f, 0.0f), mLeft(-1.0f, 0.0f, 0.0f), mForward(0.0f, 0.0f, 1.0f),
      mOrientation(1.0f, 0.0f, 0.0f, 0.0f), 
      mFov(45.0f), mRatio(1.33f), mNear(0.1f), mFar(1000.0f),
      mDirty(true)
    {
      sys::info << "ogl::CCamera::Camera()" << sys::endl;
      mProjectionMatrix = math::perspective(mFov, mRatio, mNear, mFar);
      roll(180.0f); //@FIX handedness fix
    }
    
    CCamera(const math::vec3& position) 
    : mPosition(0.0f, 0.0f, 0.0f), mUp(0.0f, 1.0f, 0.0f), mLeft(-1.0f, 0.0f, 0.0f), mForward(0.0f, 0.0f, 1.0f),
      mOrientation(1.0f, 0.0f, 0.0f, 0.0f), 
      mFov(45.0f), mRatio(1.33f), mNear(0.1f), mFar(1000.0f),
      mDirty(true)
    {
      sys::info << "ogl::CCamera::Camera(position)" << sys::endl;
      mProjectionMatrix = math::perspective(mFov, mRatio, mNear, mFar);
      roll(180.0f); // FIX handedness fix
      translateLocal(position.x, position.y * -1.0f, position.z);
    }
    
    CCamera(const math::vec3& position, const math::vec3& target) 
    : mPosition(0.0f, 0.0f, 0.0f), mUp(0.0f, 1.0f, 0.0f), mLeft(-1.0f, 0.0f, 0.0f),
      mOrientation(1.0f, 0.0f, 0.0f, 0.0f), 
      mFov(45.0f), mRatio(1.33f), mNear(0.1f), mFar(1000.0f),
      mDirty(true)
    {
      sys::info << "ogl::CCamera::Camera(position, target)" << sys::endl;
      mForward = math::normalize(target - position);
      mLeft    = math::cross(mForward, mUp);
      mUp      = math::cross(mLeft, mForward);
      mProjectionMatrix = math::perspective(mFov, mRatio, mNear, mFar);
      roll(180.0f); // FIX handedness fix
      translateLocal(position.x, position.y * -1.0f, position.z);
    }
    
    CCamera(float fov, float ratio, float near, float far) 
    : mPosition(0.0f, 0.0f, 0.0f), mUp(0.0f, 1.0f, 0.0f), mLeft(-1.0f, 0.0f, 0.0f), mForward(0.0f, 0.0f, 1.0f),
      mOrientation(1.0f, 0.0f, 0.0f, 0.0f),
      mFov(fov), mRatio(ratio), mNear(near), mFar(far),
      mDirty(true)
    {
      sys::info << "ogl::CCamera::Camera(" << fov << ", " << ratio << ", " << near << ", " << far << ")" << sys::endl;
      mProjectionMatrix = math::perspective(mFov, mRatio, mNear, mFar);
      roll(180.0f); //@FIX handedness fix
    }
    
    CCamera(float left, float right, float bottom, float top, float near, float far) 
    : mPosition(0.0f, 0.0f, 0.0f), mUp(0.0f, 1.0f, 0.0f), mLeft(-1.0f, 0.0f, 0.0f), mForward(0.0f, 0.0f, 1.0f),
      mOrientation(1.0f, 0.0f, 0.0f, 0.0f),
      mFov(0.0f), mRatio((right-left)/(top-bottom)), mNear(near), mFar(far),
      mDirty(true)
    {
      sys::info << "ogl::CCamera::Camera(left, right, bottom, top, near, far)" << sys::endl;
      mProjectionMatrix = math::ortho(left, right, bottom, top, near, far);
      roll(180.0f); //@FIX handedness fix
    }
    
    public:
    void dirty() // TODO: needs a better algorithm for deciding when to set dirty
    {
      mDirty = true;
      
      normalize();
    }
    
    void normalize()
    {
      mLeft.normalize();
      mUp.normalize();
      mForward.normalize();
      mOrientation.normalize();
      
      //if mForward is correct
      mLeft = math::cross(mForward, mUp);
      mUp   = math::cross(mLeft,mForward);
    }
    
    void zoom(float amount)
    {
      // TODO: set zoom & recalculate projection matrix
    }
    
   /**
    * Rotates camera around Z axis (forward direction) by angle radians.
    * @note              Use negative angle for counter-clockwise rotations 
    * @param deg float Roration in radians [-2PI, 2PI]
    */
    void roll(float deg)
    {
      math::quat Q(deg, mForward);
      
      mUp   = math::rotate(Q, mUp);
      mLeft = math::rotate(Q, mLeft);
      
      mOrientation = Q * mOrientation;
      
      dirty();
    }
    
   /**
    * Rotates camera around X axis (left direction) by angle radians.
    * @note              Use negative angle for counter-clockwise rotations 
    * @param deg float Roration in radians [-2PI, 2PI]
    */
    void pitch(float deg)
    {
      math::quat Q(deg, mLeft);
      
      mUp      = math::rotate(Q, mUp);
      mForward = math::rotate(Q, mForward);
      
      mOrientation = Q * mOrientation;
      
      dirty();
    }
    
   /**
    * Rotates camera around Y axis (up direction) by angle radians.
    * @note              Use negative angle for counter-clockwise rotations 
    * @param deg float Roration in radians [-2PI, 2PI]
    */
    void yaw(float deg)
    {
      math::quat Q(deg, mUp);
      
      // sys::info << Q << sys::endl;
      
      mLeft    = math::rotate(Q, mLeft);
      mForward = math::rotate(Q, mForward);
      
      mLeft.normalize();
      mForward.normalize();
      
      // sys::info << mLeft << sys::endl;
      // sys::info << mForward << sys::endl;
      // sys::info << sys::endl;
      
      mOrientation = Q * mOrientation;
      
      dirty();
    }
  
   /**
    * Rotate camera angle radians around axis -- camera local componets
    * @note              Use negative angle for counter-clockwise rotations 
    * @param angle float Rotation angle in radians
    * @param axis  vec3  Rotation axis using relative values
    */
    void rotate(float deg, const math::vec3& axis)
    {
      math::vec3 n = math::normalize(axis);
      math::quat Q(deg, n);
      
      mLeft    = math::rotate(Q, mLeft);
      mUp      = math::rotate(Q, mUp);
      mForward = math::rotate(Q, mForward);
      
      mOrientation = Q * mOrientation;
      
      dirty();
    }
    
    void translate(float x, float y, float z)
    {
      mPosition.x += x;
      mPosition.y += y;
      mPosition.z += z;
      
      dirty();
    }
    
    void translate(const math::vec3& v)
    {
      translate(v.x, v.y, v.z);
    }
    
    void translateLocal(float left, float up, float forward)
    {
      mPosition += left * mLeft;
      mPosition += up * mUp;
      mPosition += forward * mForward;
      
      dirty();
    }
    
    void translateLocal(const math::vec3& v)
    {
      translateLocal(v.x, v.y, v.z);
    }
    
    public:
    float getFov() const
    {
      return mFov;
    }
    
    void setFov(float fov)
    {
      mFov = fov;
    }
    
    float getRatio() const
    {
      return mRatio;
    }
    
    void setRatio(float ratio)
    {
      mRatio = ratio;
    }
    
    float getNear() const
    {
      return mNear;
    }
    
    void setNear(float near) 
    {
      mNear = near;
    }
    
    float getFar() const
    {
      return mFar;
    }
    
    void setFar(float far)
    {
      mFar = far;
    }
    
    math::vec3 getPosition() const
    {
      return mPosition;
    }
    
    void setPosition(float x, float y, float z)
    {
      mPosition = math::vec3(x, y, z);
    }    
    
    void setPosition(const math::vec3& position)
    {
      mPosition = position;
    }
    
    math::vec3 getUp() const
    {
      return mUp;
    }
    
    math::vec3 getLeft() const
    {
      return mLeft;
    }
    
    math::vec3 getForward() const
    {
      return mForward;
    }
    
    math::quat getOrientation() const
    {
      return mOrientation;
    }
    
    math::mat4 getViewMatrix()
    {
      // return math::lookat(mPosition, mForward, mUp);
      
      if(mDirty)
      {
        math::quat Q = mOrientation;
        Q.inverse();
        mViewMatrix = Q.asMatrix();
        
        math::vec3 v = -mPosition;
        math::mat4 m = mViewMatrix;
        mViewMatrix[3] = (m[0] * v[0]) + (m[1] * v[1]) + (m[2] * v[2]) + m[3];
        
        //@TODO: try to fix handedness
        // mViewMatrix[1][0] = -1.0f;
        
        mViewMatrix = math::scale(-1.0f) * mViewMatrix; //@FIX: Handedness fix
        
        //mViewMatrix *= math::rotate(180.0f, math::Y);
        
        mDirty = false;
      }
      
      return mViewMatrix;
    }
    
    math::mat4 getProjectionMatrix()
    {
      return mProjectionMatrix;
    }
    
    bool isDirty() const
    {
      return mDirty;
    }
    
    void setDirty(bool dirty)
    {
      mDirty = dirty;
    }
    
    CFrustum getFrustum() const
    {
      CFrustum frustum;
      
      float chalpha = 90.0f - (mFov / 2.0f); // complementary half alpha
      
      math::vec3 vLNormal = math::normalize(math::rotateY(-chalpha, mForward));
      math::vec3 vRNormal = math::normalize(math::rotateY(-chalpha, mForward));
      
      frustum.setPlane(CFrustum::_NEAR,   math::CPlane( mForward, (-mPosition).length() + mNear)); // P + d * mForward
      frustum.setPlane(CFrustum::_FAR,    math::CPlane(-mForward, (-mPosition).length() + mFar));
      frustum.setPlane(CFrustum::_LEFT,   math::CPlane(vLNormal, 0.0f));
      frustum.setPlane(CFrustum::_RIGHT,  math::CPlane(vRNormal, 0.0f));
      
      frustum.setPlane(CFrustum::_TOP,    math::CPlane(math::vec3(0.0f), 0.0f));
      frustum.setPlane(CFrustum::_BOTTOM, math::CPlane(math::vec3(0.0f), 0.0f));
      
      return frustum;
    }
  };
}

#endif // __ccamera_hpp__
