#ifndef __ogl_cdescriptor_hpp__
#define __ogl_cdescriptor_hpp__

namespace ogl
{
  class CDescriptor
  {
  
  };

  class CProgramDescriptor : public CDescriptor
  {
    protected:
    ERenderingScope   mRenderingScope;
    EDrawStrategyType mDrawStrategyType;
    EShadingMode      mShadingMode;
    ELightingPass     mLightingPass;
    GLbitfield        mRenderingOptions;
    
    public:
    CProgramDescriptor() 
    : CDescriptor(), 
      mRenderingScope(ERenderingScope::NONE), 
      mDrawStrategyType(EDrawStrategyType::NONE),
      mShadingMode(EShadingMode::NONE), 
      mLightingPass(ELightingPass::NONE),
      mRenderingOptions((uint)(ERenderingOptions::NONE))
    {
      
    }
    
    CProgramDescriptor& setRenderingScope(ogl::ERenderingScope value)
    {
      mRenderingScope = value;
      return *this;
    }
    
    CProgramDescriptor& setDrawStrategyType(ogl::EDrawStrategyType value)
    {
      mDrawStrategyType = value;
      return *this;
    }
    
    CProgramDescriptor& setShadingMode(ogl::EShadingMode value)
    {
      mShadingMode = value;
      return *this;
    }
    
    CProgramDescriptor& setLightingPass(ogl::ELightingPass value)
    {
      mLightingPass = value;
      return *this;
    }
    
    CProgramDescriptor& setRenderingOptions(uint value)
    {
      mRenderingOptions = value;
      return *this;
    }    
    
    CProgramDescriptor& setRenderingOptions(ERenderingOptions value)
    {
      mRenderingOptions = (GLbitfield)(value);
      return *this;
    }
    
    explicit operator uint () const
    {
      return 100000000 * (uint)(mRenderingScope) 
             + 1000000 * (uint)(mDrawStrategyType) 
               + 10000 * (uint)(mShadingMode) 
                 + 100 * (uint)(mLightingPass)
                   + 1 * (uint)(mRenderingOptions);
    }
    
    friend sys::CLogger& operator<<(sys::CLogger&, const CProgramDescriptor&);
  };
  
  GLbitfield operator | (ERenderingOptions lhs, ERenderingOptions rhs)
  {
    return (GLbitfield)(lhs) | (GLbitfield)(rhs);
  }
  
  GLbitfield operator | (GLbitfield lhs, ERenderingOptions rhs)
  {
    return (lhs) | (GLbitfield)(rhs);
  }
  
  sys::CLogger& operator << (sys::CLogger& out, const CProgramDescriptor& oProgramDesciptor)
  {
    out << "ogl::CProgramDescriptor: " << sys::endl;
    out << " > INFO: mRenderingScope   : " << (uint)(oProgramDesciptor.mRenderingScope) << sys::endl;
    out << " > INFO: mDrawStrategyType: " << (uint)(oProgramDesciptor.mDrawStrategyType) << sys::endl;
    out << " > INFO: mShadingMode     : " << (uint)(oProgramDesciptor.mShadingMode) << sys::endl;
    out << " > INFO: mLightingPass    : " << (uint)(oProgramDesciptor.mLightingPass) << sys::endl;
    out << " > INFO: mRenderingOptions: " << (uint)(oProgramDesciptor.mRenderingOptions);
    return out;
  }
}

#endif // __ogl_cdescriptor_hpp__
