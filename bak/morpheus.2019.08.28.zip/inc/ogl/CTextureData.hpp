#ifndef __ctexturedata_hpp__
#define __ctexturedata_hpp__

namespace ogl 
{
  class CTexture;
  
  class CTextureData
  {
    friend class CTexture;
  
    private:
    GLubyte* mData;
    GLenum   mFormat;
    GLenum   mType;
    bool     mCompressed;
    ushort   mMipmaps;
    ushort   mFaces;
  
    public:
    CTextureData()
    : mData(nullptr), mFormat(GL_NONE), mType(GL_NONE), mCompressed(false), mMipmaps(1), mFaces(1)
    {
      sys::info << "ogl::CTextureData::CTextureData()" << sys::endl;
    }
    
    CTextureData(GLubyte* data, GLenum format, GLenum type, bool compressed = false)
    : mData(data), mFormat(format), mType(type), mCompressed(compressed), mMipmaps(1), mFaces(1)
    {
      sys::info << "ogl::CTextureData::CTextureData(data, format, type)" << sys::endl;
    }
    
    CTextureData(GLubyte* data, GLenum format, GLenum type, ushort mipmaps, bool compressed = false) 
    : mData(data), mFormat(format), mType(type), mCompressed(compressed), mMipmaps(mipmaps), mFaces(1)
    {
      sys::info << "ogl::CTextureData::CTextureData(data, format, type, mipmaps)" << sys::endl;
    }
    
    CTextureData(GLubyte* data, GLenum format, GLenum type, ushort mipmaps, ushort faces, bool compressed = false) 
    : mData(data), mFormat(format), mType(type), mCompressed(compressed), mMipmaps(mipmaps), mFaces(faces)
    {
      sys::info << "ogl::CTextureData::CTextureData(data, format, type, mipmaps, faces)" << sys::endl;
    }
    
    CTextureData(const CTextureData& that)
    {
      sys::info << "ogl::CTextureData::CTextureData(CTextureData)" << sys::endl;
      mData        = that.mData;
      mFormat      = that.mFormat;
      mType        = that.mType;
      mCompressed  = that.mCompressed;
      mMipmaps     = that.mMipmaps;
      mFaces       = that.mFaces;
    }
    
    virtual ~CTextureData()
    {
      
    }
    
    CTextureData& operator = (const CTextureData& that)
    {
      sys::info << "ogl::CTextureData::operator=()" << sys::endl;
      if(this != &that)
      {
        // delete mData;
        mData        = that.mData;
        mFormat      = that.mFormat;
        mType        = that.mType;
        mCompressed  = that.mCompressed;
        mMipmaps     = that.mMipmaps;
        mFaces       = that.mFaces;
      }
      return *this;
    }
  };
}

#endif // __ctexturedata_hpp__
