#ifndef __OGL_CSKELETON_HPP__
#define __OGL_CSKELETON_HPP__

namespace ogl
{
  class CSkeleton
  {
    public:
    typedef struct {
      math::mat4 transform;
    } joint_t;
  
    public:
    size_t   mNumJoints;
    joint_t* mJoints;
    
    public:
    CSkeleton() : mNumJoints(0), mJoints(nullptr)
    {
      
    }
    
    CSkeleton(size_t numJoints) : mNumJoints(numJoints)
    {
      assert(numJoints > 0);
      mJoints = new joint_t[mNumJoints];
    }
    
    virtual ~CSkeleton()
    {
      delete [] mJoints;
    }
  };
}

#endif // __OGL_CSKELETON_HPP__
