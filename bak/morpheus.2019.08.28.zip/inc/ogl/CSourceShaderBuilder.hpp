#ifndef __ogl_csourceshaderbuilder_hpp__
#define __ogl_csourceshaderbuilder_hpp__

namespace ogl
{
  class CSourceShaderBuilder : public CShaderBuilder
  {
    protected:
    std::string mSource;
  
    public:
    CSourceShaderBuilder() : CShaderBuilder()
    {
      sys::info << "ogl::CSourceShaderBuilder::CSourceShaderBuilder()" << sys::endl;
    }
    
    virtual ~CSourceShaderBuilder()
    {
      sys::info << "ogl::CSourceShaderBuilder::~CSourceShaderBuilder()" << sys::endl;
    }
  
    public:
    CShader* build()
    {
      sys::info << "ogl::CSourceShaderBuilder::build()" << sys::endl;
      
      const char* data = mSource.c_str();
      //sys::info << data << sys::endl;
      GLuint shader = glCreateShader(mType);
      glShaderSource(shader, 1, &data, NULL);
      glCompileShader(shader);
      // _DELETE(mSource);
      
      GLint status = GL_FALSE;
      glGetShaderiv(shader, GL_COMPILE_STATUS, &status);
      if(status == GL_FALSE)
      {
        GLint loglen = 0;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &loglen);
        char* error = new char[loglen + 1];
        glGetShaderInfoLog(shader, loglen, NULL, error);
        error[loglen] = '\0';
        // triggerError()
        throw EXCEPTION << "Compile error. " << "\n" << error;
        _DELETE(error);
      }
      
      CShader* pShader = new CShader(mType, shader);
      
      mType = GL_NONE;
      mSource.clear();
      
      return pShader;
    }
    
    void setSource(const std::string& source)
    {
      mSource = source;
    }
    
    void setSource(std::string&& source)
    {
      mSource = std::move(source);
    }
  };
}

#endif // __ogl_csourceshaderbuilder_hpp__
