#ifndef __cmaterial_hpp__
#define __cmaterial_hpp__

#include <vector>

namespace ogl
{
  class CObject;

  class CMaterial
  {
    friend class CObject;
    
    enum EOptions
    {
      NONE         = 0x0000,
      MAP_DIFFUSE  = 0x0001,
      MAP_NORMAL   = 0x0002,
      MAP_HEIGHT   = 0x0004,
      MAP_SPECULAR = 0x0008,
    };
    
    protected:
    static CTexture* NOTFOUND;
    
    protected:
    GLbitfield                            mOptions;
    std::map<CTexture::EScope, CTexture*> mTextures;

    public:
    CMaterial() : mOptions(EOptions::NONE)
    {
      sys::info << "ogl::CMaterial::CMaterial()" << sys::endl;
      //mTextures[CTexture::EScope::NONE]    = CMaterial::getNotFound();
    }
    
    CMaterial(CTexture* diffuse) : mOptions(EOptions::MAP_DIFFUSE)
    {
      sys::info << "ogl::CMaterial::CMaterial(diffuse)" << sys::endl;
      //mTextures[CTexture::EScope::NONE]    = CMaterial::getNotFound();
      mTextures[CTexture::EScope::DIFFUSE] = diffuse;
    }
    
    CMaterial(const CMaterial& that)
    {
      for(auto it = mTextures.begin(); it != mTextures.end(); ++it)
      {
        delete it->second;
        it->second = nullptr;
        mTextures[it->first] = that.getTexture(it->first);
      }
      mOptions = that.mOptions;
    }
    
    virtual ~CMaterial()
    {
      sys::info << "ogl::CMaterial::~CMaterial()" << sys::endl;
      for(auto it = mTextures.begin(); it != mTextures.end(); ++it)
        delete it->second;
    }
    
    CMaterial& operator = (const CMaterial& that)
    {
      if(this != &that)
      {
        for(auto it = mTextures.begin(); it != mTextures.end(); ++it)
        {
          delete it->second;
          mTextures[it->first] = that.getTexture(it->first);
        }
        
        mOptions = that.mOptions;
      }
      return *this;
    }
    
    public:
    void bind(GLbitfield scopes = CTexture::EScope::NONE) 
    {
      mOptions = EOptions::NONE;
    
      for(auto it = mTextures.begin(); it != mTextures.end(); ++it)
      {
        const CTexture::EScope& eScope   = it->first;
        CTexture* const&        pTexture = it->second;
      
        //if(pTexture != nullptr && ((scopes & eScope) || scopes == CTexture::EScope::NONE))
      
        if(pTexture != nullptr)
        {
          GLenum unit = getUnit(eScope);
          pTexture->bind(unit);
          sys::info << "CMaterial::bind(GLbitfield) > tex: " << (GLuint)(*pTexture) << " scope: " << eScope << " unit: " << unit << sys::endl;
          
          switch(eScope)
          {
            case CTexture::EScope::DIFFUSE:  mOptions |= EOptions::MAP_DIFFUSE;  break;
            case CTexture::EScope::NORMALS:  mOptions |= EOptions::MAP_NORMAL;   break;
            case CTexture::EScope::HEIGHT:   mOptions |= EOptions::MAP_HEIGHT;   break;
            case CTexture::EScope::SPECULAR: mOptions |= EOptions::MAP_SPECULAR; break;
            default: break;
          }
        }
      }
    }
    
    void unbind() const
    {
      for(auto it = mTextures.begin(); it != mTextures.end(); ++it)
        if(it->second != nullptr)
          it->second->unbind();
    }
    
    void unbind(GLuint unit)
    {
      CTexture::EScope scope = getScope(unit);
      auto it = mTextures.find(scope);
      if(it != mTextures.end() && it->second != nullptr)
        it->second->unbind(unit);
      
      glExitIfError();
    }
    
    bool hasTexture(CTexture::EScope scope) const
    {
      return mTextures.find(scope) != mTextures.end();
    }
    
    CTexture* getTexture(CTexture::EScope scope) const
    {
      auto it = mTextures.find(scope);
      if(it != mTextures.end())
        return it->second;
      return CMaterial::NOTFOUND;
      // TODO: replace with a Null/Empty/NotFound Texture
    }
    
    void setTexture(CTexture::EScope scope, CTexture* texture)
    {
      auto it = mTextures.find(scope);
      if(it != mTextures.end()) 
      {
        delete it->second;
        it->second = texture;
      }
      else
      {
        mTextures[scope] = texture;
      }
    }
    
    GLint getOptions() const
    {
      return mOptions;
    }
    
    private:
    static GLenum getUnit(CTexture::EScope scope)
    {
      switch(scope)
      {
        default:
        case CTexture::EScope::NONE:         return GL_NONE;
        case CTexture::EScope::GENERIC:      return OGL_TEXTURE_GENERIC;
        case CTexture::EScope::DIFFUSE:      return OGL_TEXTURE_DIFFUSE;
        case CTexture::EScope::SPECULAR:     return OGL_TEXTURE_SPECULAR;
        case CTexture::EScope::NORMALS:      return OGL_TEXTURE_NORMALS;
        case CTexture::EScope::EMISSIVE:     return GL_TEXTURE4;
        case CTexture::EScope::HEIGHT:       return OGL_TEXTURE_HEIGHT;
        case CTexture::EScope::AMBIENT:      return GL_TEXTURE6;
        case CTexture::EScope::SHININESS:    return GL_TEXTURE7;
        case CTexture::EScope::OPACITY:      return GL_TEXTURE8;
        case CTexture::EScope::DISPLACEMENT: return GL_TEXTURE10;
        case CTexture::EScope::REFLECTION:   return GL_TEXTURE12;
        case CTexture::EScope::LIGHTMAP:     return GL_TEXTURE13;
      }
    }
    
    static CTexture::EScope getScope(GLuint unit)
    {
      switch(unit)
      {
        default:
        case GL_NONE:               return CTexture::EScope::NONE;
        case OGL_TEXTURE_GENERIC:   return CTexture::EScope::GENERIC;
        case OGL_TEXTURE_DIFFUSE:   return CTexture::EScope::DIFFUSE;
        case OGL_TEXTURE_SPECULAR:  return CTexture::EScope::SPECULAR;
        case OGL_TEXTURE_NORMALS:   return CTexture::EScope::NORMALS;
        case GL_TEXTURE4:           return CTexture::EScope::EMISSIVE;
        case OGL_TEXTURE_HEIGHT:    return CTexture::EScope::HEIGHT;
        case GL_TEXTURE6:           return CTexture::EScope::AMBIENT;
        case GL_TEXTURE7:           return CTexture::EScope::SHININESS;
        case GL_TEXTURE8:           return CTexture::EScope::OPACITY;
        case GL_TEXTURE10:          return CTexture::EScope::DISPLACEMENT;
        case GL_TEXTURE12:          return CTexture::EScope::REFLECTION;
        case GL_TEXTURE13:          return CTexture::EScope::LIGHTMAP;
      }
    }
  
    static CTexture* getNotFound()
    {
      if(CMaterial::NOTFOUND == nullptr)
      {
        CTextureBuilder* pTextureBuilder = new CTextureBuilder;
        CMaterial::NOTFOUND = pTextureBuilder->build();
        delete pTextureBuilder;
        glExitIfError();
      }
      return CMaterial::NOTFOUND;
    }
  };
  
  CTexture* CMaterial::NOTFOUND = nullptr;

//  class CChannel;
//    float      mAmount;
//  class CTextureChannel;
//    CTexture* mTexture;
//  class CColorChannel;
//    math::vec4 mColor;  
//    
//  class CDiffuseChannel;
//  class CSpecularChannel;
//  class CNormalChannel;
//  class CEmissionChannel;
//
//  class CShadingModel;
//    CDiffuseChannel* mDiffuseChannel;
//  class CFlatShadingModel;
//  class CGoraudShadingModel;
//  class CBlinnPhongShadingModel;
//  class COrenNayarShadingModel;
//  class CCookTorranceShadingModel;
//
//  class CMaterial;
//    CShadingModel* mShadingModel; // FLAT BLINN_PHONG(lambert) OREN_NAYAR COOK_TORRANCE
//    
//  class CMultiMaterial;
//    // std::vector<CMaterial*> mMaterials;
}

#endif // __cmaterial_hpp__
