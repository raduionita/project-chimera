#ifndef __cdrawable_hpp__
#define __cdrawable_hpp__

#include <vector>

namespace ogl
{ 
  class CBufferRange;
  class CMaterial;
  class CDrawable;
  class CRenderer;
  class CRenderPass;

  // TODO: combine CDrawCommand & CDrawStrategy into one

  class CDrawCommand
  {
    public:
    CDrawable*          mDrawable;
    GLuint              mVAO;
    std::vector<GLuint> mBuffers;
    GLenum              mTarget;
    GLenum              mMode;
    CBufferRange        mBufferRange;
    CMaterial*          mMaterial;
    math::mat4          mModelMatrix;
    CRenderer*          mRenderer;
    CRenderPass*        mRenderPass;
    CProgram*           mProgram;
    CDrawCommand*       mNext;
    
    public:
    CDrawCommand() : mDrawable(nullptr), mMaterial(nullptr), mRenderer(nullptr), mRenderPass(nullptr), mProgram(nullptr), mNext(nullptr)
    {
    
    }
    
    CDrawCommand(const CDrawCommand& that)
    {
      mDrawable    = that.mDrawable;
      mVAO         = that.mVAO;
      mBuffers     = that.mBuffers;
      mTarget      = that.mTarget;
      mMode        = that.mMode;
      mBufferRange = that.mBufferRange;
      mMaterial    = that.mMaterial;
      mNext        = that.mNext;
    }
    
    virtual ~CDrawCommand()
    {
      if(mNext)
        delete mNext;
    }
    
    CDrawCommand& operator = (const CDrawCommand& that)
    {
      if(this != & that)
      {
        mDrawable    = that.mDrawable;
        mVAO         = that.mVAO;
        mBuffers     = that.mBuffers;
        mTarget      = that.mTarget;
        mMode        = that.mMode;
        mBufferRange = that.mBufferRange;
        mMaterial    = that.mMaterial;
        mModelMatrix = that.mModelMatrix;
        mNext        = that.mNext;
      }
      return *this;
    }
  
    CDrawCommand* next()
    {
      if(mNext != nullptr)
      {
        mNext->mMode        = mMode;
        mNext->mRenderer    = mRenderer;
        mNext->mRenderPass  = mRenderPass;
        mNext->mProgram     = mProgram;
      }
      return mNext;
    }
  };
  
  class CIntancedDrawCommand : public CDrawCommand 
  {
    public:
    size_t      mInstances;
    math::mat4* mInstanceMatrices;
    
    public:
    CIntancedDrawCommand() : CDrawCommand(), mInstances(0), mInstanceMatrices(nullptr)
    {
    
    }
  };
  
  class CDrawStrategy
  {
    protected:
    EDrawStrategyType mType;
    
    public:
    CDrawStrategy() : mType(EDrawStrategyType::SINGLE)
    {
      sys::info << "ogl::CDrawStrategy::CDrawStrategy()" << sys::endl;
    }
    
    CDrawStrategy(EDrawStrategyType eType) : mType(eType)
    {
      sys::info << "ogl::CDrawStrategy::CDrawStrategy(eType)" << sys::endl;
    }
    
    virtual ~CDrawStrategy()
    {
      sys::info << "ogl::CDrawStrategy::~CDrawStrategy()" << sys::endl;
    }
    
    public:
    virtual void draw(const CDrawCommand* pDrawCommand)
    { 
      // sys::info << "ogl::CDrawStrategy::draw(CDrawCommand*)" << sys::endl;
      
      /* !!! MAKE SURE THAT mVAO & mTarget are bound !!! You always forget this, damn it !!! */
      
      if(pDrawCommand == nullptr)
      {
        throw EXCEPTION << "null draw command";
      }
      else if(pDrawCommand->mTarget == GL_ELEMENT_ARRAY_BUFFER)
      {
        glDrawElements(pDrawCommand->mMode,
                       pDrawCommand->mBufferRange.getLength(),
                       pDrawCommand->mBufferRange.getType(),
                       // TODO: (GLvoid*)(0)); // draw full mesh but with bad materials - try to fix this
                       (GLvoid*)(pDrawCommand->mBufferRange.getPosition() * getSizeOf(pDrawCommand->mBufferRange.getType())));
      }
      else if(pDrawCommand->mTarget == GL_ARRAY_BUFFER)
      {
        glDrawArrays(pDrawCommand->mMode,
                     pDrawCommand->mBufferRange.getPosition(),
                     pDrawCommand->mBufferRange.getLength());
      }
      else
      {
        // ERROR: Wrong buffer
        throw EXCEPTION << "Wrong buffer!";
      }
      
      glExitIfError();
    }
  
    EDrawStrategyType getType() const
    {
      return mType;
    }
  };
  
  class CInstancedDrawStrategy : public CDrawStrategy
  {
    protected:
    GLuint      mBuffer;
    size_t      mSize;
    math::mat4* mModelMatrices;
    
    public:
    CInstancedDrawStrategy(size_t size) : CDrawStrategy(EDrawStrategyType::INSTANCED), mSize(size)
    {
      sys::info << "ogl::CInstancedDrawStrategy::CInstancedDrawStrategy()" << sys::endl;
      mModelMatrices = new math::mat4[mSize];
      
      glGenBuffers(1, &mBuffer);
      glBindBuffer(GL_UNIFORM_BUFFER, mBuffer);
      glBufferData(GL_UNIFORM_BUFFER, mSize * sizeof(math::mat4), NULL, GL_DYNAMIC_DRAW);
      
      glExitIfError();
    }
    
    virtual ~CInstancedDrawStrategy()
    {
      sys::info << "ogl::CInstancedDrawStrategy::~CInstancedDrawStrategy()" << sys::endl;
      delete [] mModelMatrices;
      glDeleteBuffers(1, &mBuffer);
    }
    
    public:
    void setModelMatrix(size_t i, const math::mat4& modelMatrix)
    {
      assert(i >= 0);
      assert(i < mSize);
      
      mModelMatrices[i] = modelMatrix;
    }
    
    math::mat4 getModelMatrix(size_t i)
    {
      assert(i >= 0);
      assert(i < mSize);
      
      return mModelMatrices[i];
    }
    
    size_t getSize() const
    {
      return mSize;
    }
    
    virtual void draw(const CDrawCommand* pDrawCommand)
    {
      sys::info << "ogl::CInstancedDrawStrategy::draw(CDrawCommand*)" << sys::endl;
      
      // TODO: move this inside program callback
      glBindBufferBase(GL_UNIFORM_BUFFER, 0, mBuffer);
      math::mat4* pModelMatrices = reinterpret_cast<math::mat4*>(glMapBufferRange(GL_UNIFORM_BUFFER,
        0, mSize * sizeof(math::mat4), GL_MAP_WRITE_BIT | GL_MAP_INVALIDATE_BUFFER_BIT));
      for(size_t i = 0; i < mSize; ++i)         // read mModelMatrice write to buffer
        pModelMatrices[i] = mModelMatrices[i];
      glUnmapBuffer(GL_UNIFORM_BUFFER);
      
      if(pDrawCommand->mTarget == GL_ELEMENT_ARRAY_BUFFER)
      {
        glDrawElementsInstanced(pDrawCommand->mMode, pDrawCommand->mBufferRange.getLength(), pDrawCommand->mBufferRange.getType(), 
          (GLvoid*)(pDrawCommand->mBufferRange.getPosition() * getSizeOf(pDrawCommand->mBufferRange.getType())), mSize);
      }
      else if(pDrawCommand->mTarget == GL_ARRAY_BUFFER)
      {
        glDrawArraysInstanced(pDrawCommand->mMode, pDrawCommand->mBufferRange.getPosition(),
          pDrawCommand->mBufferRange.getLength(), mSize);
      }
      else
      {
        // ERROR: Wrong buffer
      }
      
      glExitIfError();
    }
  };

  class CDrawable
  {
    protected:
    CDrawStrategy* mDrawStrategy;
  
    public:
    CDrawable() : mDrawStrategy(nullptr)
    {
      sys::info << "ogl::CDrawable::CDrawable()" << sys::endl;
    }
    
    virtual ~CDrawable()
    {
      _DELETE(mDrawStrategy);
      sys::info << "ogl::CDrawable::~CDrawable()" << sys::endl;
    }
    
    public:
    virtual CDrawCommand*  getDrawCommand() = 0;
    
    virtual CDrawStrategy* getDrawStrategy() 
    {
      return mDrawStrategy;
    }
    
    virtual void setDrawStrategy(CDrawStrategy* pDrawStrategy)
    {
      _DELETE(mDrawStrategy);
      mDrawStrategy = pDrawStrategy;
    }
  };
}

#endif // __cdrawable_hpp__
