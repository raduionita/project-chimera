#ifndef __ogl__CMD5OBJECTBUILDER_HPP__
#define __ogl__CMD5OBJECTBUILDER_HPP__

namespace ogl
{
  class CMd5ObjectBuilder : public CObjectBuilder
  {
    protected:
    sys::CFile mFile;
    
    private:
    typedef struct {
      math::vec2 st;     // texcoords
      size_t     start;  // start weight
      size_t     count;  // weight count
    } vertex_t;
    typedef struct {
      uint index[3];
    } triangle_t;
    typedef struct {
      int        joint;
      float      bias;
      math::vec3 position;
    } weight_t;
    typedef struct {
      char       name[64];
      int        parent;
      math::vec3 position;
      math::quat rotation; // orientation
    } joint_t;
    typedef struct {
      vertex_t*   vertices;
      triangle_t* triangles;
      weight_t*   weights;
      size_t numVertices;
      size_t numTriangles;
      size_t numWeights;
      uint   indexOffset;
      char material[128];  // replace with char* or std::string
    } mesh_t;
    typedef struct {
      joint_t* joints;
      mesh_t*  meshes;
      size_t numJoints;
      size_t numMeshes;
      size_t numVertices;
      size_t numIndices;
    } model_t;
    
    typedef struct edge_t {
      ushort a;
      ushort b;
      edge_t(int _a, int _b) 
      {
        assert(_a != _b);
        if(_a < _b)
        {
          a = _a;
          b = _b;
        }
        else
        {
          a = _b;
          b = _a;
        }
      }
      
      bool operator < (const edge_t& edge) const
      {
        if(this->a < edge.a)
          return true;
        else if(this->a == edge.a)
          return this->b < edge.b;
        return false;
      }
    } edge_t;
    typedef struct neighbors_t {
      ushort first;
      ushort second;
      neighbors_t() : first(-1), second(-1) { }
    } neighbors_t;
    
    public:
    CObject* build()
    {
      sys::info << "ogl::CMd5ObjectBuilder::build()" << sys::endl;
      
      model_t* model = new model_t;
      buildModel(mFile, model);
      
      /* ********************************************************************************************************** */
      
      CObject* pObject = new CObject;
      pObject->setDrawStrategy(new CDrawStrategy);
      
      /* ********************************************************************************************************** */
      
      // create skeleton
      
      // pSkeleton = new CSkeleton;
      // pSkeleton->setRoot(new CBone()); using model->joints(0)
      // pObject->setSkeleton(pSkeleton);
      pObject->mSkeleton = new CAnimatable::skeleton_t;
      pObject->mSkeleton->numJoints = model->numJoints;
      pObject->mSkeleton->joints = new CAnimatable::joint_t[model->numJoints];
      pObject->mSkeleton->inverseTransforms = new math::mat4[model->numJoints];
      for(size_t ji = 0; ji < model->numJoints; ++ji)
      {
        strcpy(pObject->mSkeleton->joints[ji].name, model->joints[ji].name);
        pObject->mSkeleton->joints[ji].parent   = model->joints[ji].parent;
        pObject->mSkeleton->joints[ji].position = model->joints[ji].position;
        pObject->mSkeleton->joints[ji].rotation = model->joints[ji].rotation;
        
        math::mat4 inverseBindPose = math::translate(model->joints[ji].position) * math::toMatrix(model->joints[ji].rotation);
        inverseBindPose = math::inverse(inverseBindPose);
        pObject->mSkeleton->inverseTransforms[ji] = inverseBindPose;
      }
      
      /* ********************************************************************************************************** */
      
      pObject->mNumIndices  = hasOption(ADJACENCY) ? model->numIndices * 2 : model->numIndices;
      pObject->mNumVertices = model->numVertices;
      
      ushort*      indices     = new ushort[pObject->mNumIndices];        // INDEX_BUFFER_INDEX
      math::vec3*  positions   = new math::vec3[pObject->mNumVertices];   // POSITION_BUFFER_INDEX
      math::vec2*  texcoords   = new math::vec2[pObject->mNumVertices];   // TEXCOORD_BUFFER_INDEX
      math::vec3*  normals     = new math::vec3[pObject->mNumVertices];   // NORMAL_BUFFER_INDEX
      math::vec3*  tangents    = new math::vec3[pObject->mNumVertices];   // TANGENT_BUFFER_INDEX
      math::vec3*  binormals   = new math::vec3[pObject->mNumVertices];   // BINORMAL_BUFFER_INDEX
      math::ivec4* boneids     = new math::ivec4[pObject->mNumVertices];  // BONE_ID_BUFFER_INDEX
      math::vec4*  boneweights = new math::vec4[pObject->mNumVertices];   // BONE_WEIGHT_BUFFER_INDEX
      
      size_t mi = 0, vi = 0, ii = 0, ti = 0, ci = 0, pi = 0, i = 0, bi = 0;
      float fMax = 0.0f;
      size_t toffset = 0;
      
      // TODO: Check if this doesn't fuck up the animation!
      bool bInvertYZ = hasOption(CObjectBuilder::FLIPYZ);
      
      std::map<edge_t, neighbors_t> oEdgeMap;
      std::map<math::vec3, ushort>  oPositionMap;
      
      // build CObject CShape's and populate data(position, texcoords, normals..)
      for(mi = 0; mi < model->numMeshes; ++mi)
      {
        mesh_t* mesh = &model->meshes[mi];
        
        CShape* pShape = new CShape;
        pShape->setName(mesh->material);
      
        CBufferRange oVertexBufferRange;
        oVertexBufferRange.setType(GL_FLOAT);
        oVertexBufferRange.setPosition(pi);
        
        for(vi = 0; vi < mesh->numVertices; ++vi, ++pi) // build vertices
        {
          vertex_t& vertex = mesh->vertices[vi];
        
          for(ci = 0, bi = 0; ci < vertex.count; ++ci, ++bi)
          {
            const weight_t* weight = &mesh->weights[vertex.start + ci];
            const joint_t*  joint  = &model->joints[weight->joint];
            
            math::vec3 rotated = math::rotate(joint->rotation, weight->position);
            
            positions[pi][                0] += (joint->position[0] + rotated[0]) * weight->bias;
            positions[pi][bInvertYZ ? 2 : 1] += (joint->position[1] + rotated[1]) * weight->bias;
            positions[pi][bInvertYZ ? 1 : 2] += (joint->position[2] + rotated[2]) * weight->bias;
            
            boneids[pi][bi]     = weight->joint; // bi % 2 == 0 ? weight->joint : (boneids[pi][bi] << 16) | weight->joint;
            boneweights[pi][bi] = weight->bias;
          }
          texcoords[pi][0] = vertex.st[0];
          texcoords[pi][1] = vertex.st[1];
          
          fMax = std::max(fMax, positions[pi].x);
          fMax = std::max(fMax, positions[pi].y);
          fMax = std::max(fMax, positions[pi].z);
        }
        
        oVertexBufferRange.setLength(pi - oVertexBufferRange.getPosition());
        pShape->setVertexBufferRange(oVertexBufferRange);
        
        CBufferRange oIndexBufferRange;
        oIndexBufferRange.setType(GL_UNSIGNED_SHORT);
        oIndexBufferRange.setPosition(ii);
        
        if(hasOption(ADJACENCY)) // build unique faces
        {
          triangle_t* tcache = new triangle_t[mesh->numTriangles];
        
          for(ti = 0; ti < mesh->numTriangles; ++ti) // pass 1 - edges & neighbors
          {
            triangle_t* triangle = &mesh->triangles[ti];
            
            triangle_t unique;
            
            for(i = 0; i < 3; ++i) // for each vertex in triangle
            {
              ushort index = mesh->indexOffset + triangle->index[i];
              math::vec3& position = positions[index];
              
              auto it = oPositionMap.find(position);
              if(it != oPositionMap.end()) // found
                index = it->second;
              else
                oPositionMap[position] = index;
              
              unique.index[i] = index; // unique triangle index 0, 1, 2
            }
            
            tcache[ti] = unique;
            
            edge_t e1(unique.index[0], unique.index[1]);
            edge_t e2(unique.index[1], unique.index[2]);
            edge_t e3(unique.index[2], unique.index[0]);
            
            addNeighbor(oEdgeMap[e1], ti);
            addNeighbor(oEdgeMap[e2], ti);
            addNeighbor(oEdgeMap[e3], ti);
          }
          
          for(ti = 0; ti < mesh->numTriangles; ++ti) // pass 2 - build indices
          {
            const triangle_t* triangle = &tcache[ti];
            for(i = 0; i < 3; ++i)                                      // triangle = 3 edges
            {
              edge_t edge(triangle->index[i], triangle->index[(i+1) % 3]); // get edge
              
              neighbors_t neighbors = oEdgeMap[edge];                   // get edge neighbors
              
              ushort tj = getOther(neighbors, ti);                      // get the opposite triangle index 
              
              ushort index = RESTART_INDEX; // glPrimitiveRestartIndex(RESTART_INDEX)
              
              if(tj != RESTART_INDEX)
              {
                const triangle_t& opposite = tcache[tj];                // get opposite triangle(to the current edge)
                index = getOppositeIndex(opposite, edge);               // get opposite vertex index from the other tri.
              }
              else
              {
                index = triangle->index[(i + 2) % 3];
              }
              
              indices[ii+i*2+0] = triangle->index[i];                   // 0 2 4 // indices.push_back(triangle.index[i]);
              indices[ii+i*2+1] = index;                                // 1 3 5 // indices.push_back(index);
              
              // adjacent vertex index map 
              // @see silhouette_01.gs.glsl
              // 1 ----- 2 ----- 3 
              //  \     / \     /  
              //   \  e1   e2  /   
              //    \ /     \ /    
              //     0 -e3-- 4     
              //      \     /      
              //       \   /       
              //        \ /        
              //         5         
            }
            
            ii += 6;
          }
          
          delete [] tcache;
        }
        else
        {
          for(ti = 0; ti < mesh->numTriangles; ++ti) // build indices & normals
          {
            const triangle_t* triangle = &mesh->triangles[ti];
            
            ushort i0 = mesh->indexOffset + triangle->index[                0];
            ushort i1 = mesh->indexOffset + triangle->index[bInvertYZ ? 2 : 1];
            ushort i2 = mesh->indexOffset + triangle->index[bInvertYZ ? 1 : 2];
            
            // build indices
            indices[ii+0] = i0;
            indices[ii+1] = i1;
            indices[ii+2] = i2;

            // build tangents
            math::vec3& p0 = positions[i0];
            math::vec3& p1 = positions[i1];
            math::vec3& p2 = positions[i2];
            
            math::vec2& t0 = texcoords[i0];
            math::vec2& t1 = texcoords[i1];
            math::vec2& t2 = texcoords[i2];
            
            math::vec3 dp1(p1 - p0);
            math::vec3 dp2(p2 - p0);
            
            // TODO: fix normalization in a better way
            
            math::vec3 normal = math::normalize(math::cross(dp2, dp1));
            normals[i0] += normal; // avarage the normals
            normals[i0]  = math::normalize(normals[i0]);
            normals[i1] += normal;
            normals[i1]  = math::normalize(normals[i1]);
            normals[i2] += normal;
            normals[i2]  = math::normalize(normals[i2]);
            
            math::vec2 dt1 = t1 - t0;
            math::vec2 dt2 = t2 - t0;
            
            float r = 1.0f / (dt1.x * dt2.y - dt1.y * dt2.x);
            math::vec3 ta = (dp1 * dt2.y - dp2 * dt1.y) * r;    // tangent
            math::vec3 bi = (dp2 * dt1.x - dp1 * dt2.x) * r;    // binormal
            
            tangents[i0] = ta;
            tangents[i1] = ta;
            tangents[i2] = ta;
            
            binormals[i0] = bi;
            binormals[i1] = bi;
            binormals[i2] = bi;
            
            ii += 3;
          }
        }
        
        // TODO: tangent should be vec4, where .w is the handedness
        
        for(size_t i = 0; i < pObject->mNumVertices; ++i)
        {
          const math::vec3& n = normals[i];
          const math::vec3& t = tangents[i];
          const math::vec3& b = binormals[i];
          
          tangents[i] = math::normalize(t - n * math::dot(n, t));                 // orthogonalize(Gram-Schmidt)
          tangents[i] = (math::dot(math::cross(n, t), b) < 0.0f) ? t * -1.0f : t; // handedness
          // tangents[i].w = (math::dot(math::cross(n, t), b) < 0.0f) ? -1.0f : 1.0f;
          
        }

        toffset += mesh->numTriangles;
        
        oIndexBufferRange.setLength(ii - oIndexBufferRange.getPosition());
        pShape->setIndexBufferRange(oIndexBufferRange);
        
        CMaterial* pMaterial = new CMaterial;
        buildMaterial(getMaterialFile(mFile.getFilePath(), mesh->material), pMaterial);
        pShape->setMaterial(pMaterial);
        
        pObject->addShape(pShape);
      }
      
      if(hasOption(NORMALIZED)) // normalize mesh
      {
        pObject->scale(1.0f / fMax); // temporary solution...
        
        // TODO: normalization doesn't work with standard animation...you would have to normalize the animation too
        // for(vi = 0; vi < model->numVertices; ++vi)
        // {
        //   positions[vi] /= fMax;
        // }
      }
      
      //for(size_t i = 0; i < model->numIndices; i+=3)
      //  sys::info << "> " << indices[i+0] << " " << indices[i+1] << " " << indices[i+2] << sys::endl;
      
      sys::info << sys::tab << "indices: " << model->numIndices << sys::endl;
      sys::info << sys::tab << "vertices: " << model->numVertices << sys::endl;
      
      /* ********************************************************************************************************** */
      
      { // build buffers // TODO: move to a buildBuffers() method...
        pObject->mBuffers.resize(8, 0);
        
        if(hasOption(ADJACENCY))
        {
          pObject->setMode(GL_TRIANGLES_ADJACENCY);
        }
        else
        {
          pObject->setMode(GL_TRIANGLES);
        }
        
        // indices
        glGenBuffers(1, &(pObject->mBuffers[INDEX_BUFFER_INDEX]));
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pObject->mBuffers[INDEX_BUFFER_INDEX]);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, pObject->mNumIndices * sizeof(ushort), indices, GL_STATIC_DRAW);
        
        glGenVertexArrays(1, &(pObject->mVAO));
        glBindVertexArray(pObject->mVAO);
        
        // positions
        glGenBuffers(1, &(pObject->mBuffers[POSITION_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[POSITION_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), positions, GL_STATIC_DRAW);

        glVertexAttribPointer(POSITION_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (const GLvoid*)(0));
        glEnableVertexAttribArray(POSITION_ATTRIBUTE);
        
        // texcoords
        glGenBuffers(1, &(pObject->mBuffers[TEXCOORD_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[TEXCOORD_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec2), texcoords, GL_STATIC_DRAW);
        
        glVertexAttribPointer(TEXCOORD_ATTRIBUTE, 2, GL_FLOAT, GL_FALSE, sizeof(math::vec2), (const GLvoid*)(0));
        glEnableVertexAttribArray(TEXCOORD_ATTRIBUTE);
        
        // normals
        glGenBuffers(1, &(pObject->mBuffers[NORMAL_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[NORMAL_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), normals, GL_STATIC_DRAW);

        glVertexAttribPointer(NORMAL_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (const GLvoid*)(0));
        glEnableVertexAttribArray(NORMAL_ATTRIBUTE);
        
        // tangets
        glGenBuffers(1, &(pObject->mBuffers[TANGENT_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[TANGENT_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), tangents, GL_STATIC_DRAW);

        glVertexAttribPointer(TANGENT_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (const GLvoid*)(0));
        glEnableVertexAttribArray(TANGENT_ATTRIBUTE);
        
        // binormals
        // ...
        
        // bone ids
        glGenBuffers(1, &(pObject->mBuffers[BONE_ID_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[BONE_ID_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::ivec4), boneids, GL_STATIC_DRAW);

        glVertexAttribIPointer(BONE_ID_ATTRIBUTE, 4, GL_INT, sizeof(math::ivec4), (const GLvoid*)(0));
        glEnableVertexAttribArray(BONE_ID_ATTRIBUTE);
        
        // bone weights
        glGenBuffers(1, &(pObject->mBuffers[BONE_WEIGHT_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[BONE_WEIGHT_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec4), boneweights, GL_STATIC_DRAW);

        glVertexAttribPointer(BONE_WEIGHT_ATTRIBUTE, 4, GL_FLOAT, GL_FALSE, sizeof(math::vec4), (const GLvoid*)(0));
        glEnableVertexAttribArray(BONE_WEIGHT_ATTRIBUTE);
        
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
        
        glExitIfError();
      }
      
      /* ********************************************************************************************************** */
      
      { // clean up
        delete [] indices;
        delete [] positions;
        delete [] texcoords;
        delete [] normals;
        delete [] tangents;
        delete [] binormals;
        delete [] boneids;
        delete [] boneweights;
        
        freeModel(model);
      }
      
      return pObject;
    }

    void setFile(const std::string& sFile)
    {
      mFile = std::move(sys::CFile(sFile));
    }
    
    void setFile(sys::CFile&& oFile)
    {
      mFile = std::move(oFile);
    }
    
    protected:
    static void freeModel(model_t* model)
    {
      for(size_t i = 0; i < model->numMeshes; ++i)
      {
        mesh_t* mesh = &model->meshes[i];
        
        delete [] mesh->vertices;
        delete [] mesh->triangles;
        delete [] mesh->weights;
        // delete mesh;
      }

      delete [] model->joints;
      delete [] model->meshes;
      delete model;
    }
    
    static void buildModel(const sys::CFile& oFile, model_t* model)
    {
      if(oFile.isEmpty())
        throw EXCEPTION << "Builder requires a .md5mesh file.";
      
      FILE* fp = NULL;
      fp = fopen(std::string(MODELPATH).append(oFile.getFilePath()).c_str(), "rb");
      if(fp == NULL)
        throw EXCEPTION << "Can not open file " << oFile.getFileName();
      
      char line[512];
      int  version = 0;
      
      float  fval[6];
      uint   ival[3];
      
      size_t i = 0, j = 0;
      size_t vi = 0; // vertex index
      size_t ti = 0; // triangle index
      size_t wi = 0; // weight index
      size_t mi = 0; // mesh index
      
      uint   nMaxIndex    = 0;
      uint   nIndexOffset = 0;
      
      model->numJoints   = 0;
      model->numMeshes   = 0;
      model->numVertices = 0;
      model->numIndices  = 0;
      
      model->joints = nullptr;
      model->meshes = nullptr;
    
      while(!feof(fp))
      {
        fgets(line, sizeof(line), fp); // read next line
        
        if(line[0] =='\0' || line[0] =='#' || (line[0] =='/' && line[1] == '/') || line[0] == '\n')
          continue; 
        assert(line);
        
        if(sscanf(line, "MD5Version %d", &version) == 1 && version != 10)
        {
          fclose(fp);
          throw CException(std::string("ERROR: Bad model version.") + oFile.getFileName());
        }
        else if(sscanf(line, "numJoints %d", &model->numJoints) == 1 && model->numJoints > 0)
        {
          model->joints = new joint_t[model->numJoints]; // allocate memory for joints
        }
        else if(sscanf(line, "numMeshes %d", &model->numMeshes) == 1 && model->numMeshes > 0)
        {
          model->meshes = new mesh_t[model->numMeshes]; // allocate memory for meshes
        }
        else if(strncmp(line, "joints {", 8) == 0) // ==0 strings are the same
        {
          for(i = 0; i < model->numJoints; ++i)
          {
            joint_t* joint = &model->joints[i];
            
            fgets(line, sizeof(line), fp); // read next line
            
            if(sscanf(line, "%s %d ( %f %f %f ) ( %f %f %f )", 
              joint->name, &joint->parent, &fval[0], &fval[1], &fval[2], &fval[3], &fval[4], &fval[5]))
            {
              joint->position = math::vec3(fval[0], fval[1], fval[2]);
              joint->rotation = math::quat(math::vec3(fval[3], fval[4], fval[5]));
            }
          }
        }
        else if(strncmp(line, "mesh {", 6) == 0)
        {
          mesh_t* mesh = &model->meshes[mi];
          
          mesh->indexOffset = nIndexOffset;
          nMaxIndex = 0;
          
          while(line[0] != '}' && !feof(fp))
          {
            fgets(line, sizeof(line), fp); // read next line
            
            if(strstr(line, "shader ")) // return a pointer to the first occurence of "..." in line
            {
              size_t quotes = 0;
              for(i = 0, j = 0; i < sizeof(line) && quotes < 2; ++i) // copy shader w/o the quote marks
              {
                if(line[i] == '\"')
                  quotes++;
                if(quotes == 1 && line[i] != '\"')
                  mesh->material[j++] = line[i];
              }
              mesh->material[j] = '\0';
            }
            else if(sscanf(line, " numverts %d", &mesh->numVertices) == 1 && mesh->numVertices > 0)
            {
              mesh->vertices = new vertex_t[mesh->numVertices];   // allocate memory for vertices
            }
            else if(sscanf(line, " numtris %d", &mesh->numTriangles) == 1 && mesh->numTriangles > 0)
            {
              mesh->triangles = new triangle_t[mesh->numTriangles];
            }
            else if(sscanf(line, " numweights %d", &mesh->numWeights) == 1 && mesh->numWeights > 0)
            {
              mesh->weights = new weight_t[mesh->numWeights];
            }
            else if(sscanf(line, " vert %d ( %f %f ) %d %d", &vi, &fval[0], &fval[1], &ival[0], &ival[1]) == 5)
            {
              mesh->vertices[vi].st[0] = fval[0]; // texcoord
              mesh->vertices[vi].st[1] = fval[1];
              mesh->vertices[vi].start = ival[0];
              mesh->vertices[vi].count = ival[1];
              
              model->numVertices++;
              
              assert(ival[1] <= 4);           // only 4 bones/joints/weights per vertex supported
              assert(vi < mesh->numVertices);
            }
            else if(sscanf(line, " tri %d %d %d %d", &ti, &ival[0], &ival[1], &ival[2]) == 4)
            {
              mesh->triangles[ti].index[0] = ival[0]; // indices
              mesh->triangles[ti].index[1] = ival[1];
              mesh->triangles[ti].index[2] = ival[2];
              
              model->numIndices += 3;
              
              nMaxIndex = std::max(nMaxIndex, ival[0]);
              nMaxIndex = std::max(nMaxIndex, ival[1]);
              nMaxIndex = std::max(nMaxIndex, ival[2]);
              
              assert(ti < mesh->numTriangles);
            }
            else if(sscanf(line, " weight %d %d %f ( %f %f %f )", &wi, &ival[0], &fval[3], &fval[0], &fval[1], &fval[2]) == 6)
            {
              mesh->weights[wi].joint       = ival[0];
              mesh->weights[wi].bias        = fval[3];
              mesh->weights[wi].position[0] = fval[0];
              mesh->weights[wi].position[1] = fval[1];
              mesh->weights[wi].position[2] = fval[2];
              
              assert(wi < mesh->numWeights);
            }
          }
          
          assert(ti+1 == mesh->numTriangles);
          assert(wi+1 == mesh->numWeights);
          assert(vi+1 == mesh->numVertices);
          
          nIndexOffset += nMaxIndex + 1;
          mi++;
        }
      }
      
      assert(mi == model->numMeshes);
      
      fclose(fp);
    }
  
    static void buildMaterial(const sys::CFile& oFile, CMaterial* pMaterial)
    {
      //std::string mExt = oFile.getFileType();
      //if(mExt == "mtr")
      //{
        // parse material file
      //}
      //else
      //{
        // use dds,tga,png texture builders
        
        // if texture not found use notfound.dds
        // sys::info << oFile << sys::endl;
        ogl::CTgaTextureBuilder* pTextureBuilder = new ogl::CTgaTextureBuilder;
        pTextureBuilder->setFile(oFile.getFilePath().c_str());
        CTexture* pTexture = pTextureBuilder->build();
        pTexture->setFiltering(ogl::CTexture::EFiltering::TRILINEAR);
        pTexture->setWrapping(CTexture::EWrapping::CLAMP_TO_EDGE);
        pMaterial->setTexture(CTexture::EScope::DIFFUSE, pTexture);
        //pTexture->setWrapping(GL_CLAMP_TO_EDGE);
        
        delete pTextureBuilder;
      //}
    }
    
    static void buildTexure(const sys::CFile& oFile, CTexture* pTexture)
    {
      
    }
    
    static sys::CFile getMaterialFile(const std::string& oModel, const std::string& oMaterial)
    {
      std::string file = oMaterial.empty() ? "notfound.tga" : oMaterial;
      std::string ext  = file.substr(file.find_last_of(".") + 1);
      std::string part = oModel.substr(0, oModel.find_last_of("/") + 1);
      
      std::string folder;
      if(ext == "mtr")
        folder = MODELPATH;
      else 
        folder = part;
        
      return sys::CFile(std::string(folder).append(file));
    }
  
    static ushort getOppositeIndex(const triangle_t& triangle, const edge_t& edge)
    {
      for(ushort i = 0; i < _COUNT(triangle.index); ++i)
      {
        ushort index = triangle.index[i];
        if(index != edge.a && index != edge.b)
          return index;
      }
      assert(0);
      return 0;
    }
    
    static void addNeighbor(neighbors_t& neighbors, ushort index)
    {
      // sys::info << "CMd5ObjectBuilder::addNeighbor(neighbors, " << index << ")" << sys::endl;
      if(neighbors.first == (ushort)(-1))
        neighbors.first = index;
      else if(neighbors.second == (ushort)(-1))
        neighbors.second = index;
      else
        assert(0);
    }
    
    static ushort getOther(const neighbors_t& neighbors, ushort current)
    {
      if(neighbors.first == current)
        return neighbors.second;
      else if(neighbors.second == current)
        return neighbors.first;
      assert(0);
      return 0;
    }
  };
}

#endif // __ogl__CMD5OBJECTBUILDER_HPP__














































