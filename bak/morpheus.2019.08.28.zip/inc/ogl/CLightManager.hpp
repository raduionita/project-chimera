#ifndef __clightmanager_hpp__
#define __clightmanager_hpp__

namespace ogl
{
  class CLightManager : public sys::CSingleton<CLightManager>
  {
    friend class sys::CSingleton<CLightManager>;
    
    protected:
    std::vector<CLight*> mLights;
    
    CLightManager()
    {
      sys::info << "app::CLightManager::CLightManager()" << sys::endl;
    }
    
    virtual ~CLightManager()
    {
      sys::info << "ogl::CLightManager::~CLightManager()" << sys::endl;
      for(auto pLight : mLights)
        _DELETE(pLight);
    }
    
    public:
    size_t addLight(CLight* pLight)
    {
      mLights.push_back(pLight);
      return mLights.size() - 1;
    }
  };
}

#endif // __clightmanager_hpp__
