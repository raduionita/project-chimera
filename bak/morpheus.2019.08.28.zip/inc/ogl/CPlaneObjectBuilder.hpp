#ifndef __cplaneobjectbuilder_hpp__
#define __cplaneobjectbuilder_hpp__

namespace ogl
{
  class CPlaneObjectBuilder : public CObjectBuilder
  {
    public:
    static constexpr GLbitfield REPEAT_UV = 0x0080;
    
    private:
    float      mWidth;
    float      mHeight;
    float      mTextureScale;
    math::vec3 mNormal; 
    ushort     mSubdivisions;
    
  
    public:
    CPlaneObjectBuilder() : CObjectBuilder(), mWidth(1.0f), mHeight(1.0), mTextureScale(1.0f), mNormal(math::Y), mSubdivisions(1)
    {
      sys::info << "ogl::CPlaneObjectBuilder::CPlaneObjectBuilder()" << sys::endl;
    }
    
    virtual ~CPlaneObjectBuilder()
    {
      sys::info << "ogl::CPlaneObjectBuilder::~CPlaneObjectBuilder()" << sys::endl;
    }
    
    public:
    CObject* build()
    {
      sys::info << "ogl::CPlaneObjectBuilder::build()" << sys::endl;
      
      sys::info << sys::tab << "WxH: " <<  mWidth << "x" << mHeight << sys::endl;
      sys::info << sys::tab << "mOptions: " << mOptions << sys::endl;
      
      bool bInverted  = hasOption(CObjectBuilder::INVERTED);
      bool bRepeatUVs = hasOption(CPlaneObjectBuilder::REPEAT_UV);
      bool bPositions = hasOption(CObjectBuilder::POSITIONS);
      bool bTexcoords = hasOption(CObjectBuilder::TEXCOORDS);
      bool bNormals   = hasOption(CObjectBuilder::NORMALS);
      bool bTangents  = hasOption(CObjectBuilder::TANGENTS);
      bool bBinormals = hasOption(CObjectBuilder::BINORMALS);
      
      float hWidth   = mWidth  / 2.0f;
      float hHeight  = mHeight / 2.0f;
      
      ushort nNumVertices = (mSubdivisions + 1) * (mSubdivisions + 1); // 4
      
      static math::vec3* positions = new math::vec3[nNumVertices];
      static math::vec2* texcoords = new math::vec2[nNumVertices];
      static math::vec3* normals   = new math::vec3[nNumVertices];
      static math::vec3* tangents  = nullptr;
      static math::vec3* binormals = nullptr;
      
      if(bTangents)
      {
        tangents  = new math::vec3[nNumVertices];
        binormals = new math::vec3[nNumVertices];
      }
      
      // TODO: invert should affect winding - swap(indices[i+1], indices[i+2])
      if(bInverted)
        mNormal = mNormal * -1.0f;
      
      float fTexSubDiv = bRepeatUVs ? (float)(mSubdivisions) : 1.0f;
      
      fTexSubDiv *= mTextureScale;
      
      for(ushort i = 0; i < nNumVertices; i++)
      {
        ushort nX = i % (mSubdivisions + 1); // 0 1 0 1
        ushort nZ = i / (mSubdivisions + 1); // 0 0 1 1
        
        //sys::info << i << " " << j << " " << nX << " " << nZ << sys::endl;
        
        // TODO: this should be affected by normal orientation
        positions[i][0] = ((float)(nX) / (float)(mSubdivisions)) * mWidth - hWidth;    // position.x
        positions[i][1] = 0.0f;                                                        // position.y
        positions[i][2] = ((float)(nZ) / (float)(mSubdivisions)) * mHeight - hHeight;  // position.z
        
        texcoords[i][0] = (float)(nX) / fTexSubDiv;                                    // texcoord.s
        texcoords[i][1] = (float)(nZ) / fTexSubDiv;                                    // texcoord.t

        normals[i][0] = mNormal.x;                                                     // normal.x
        normals[i][1] = mNormal.y;                                                     // normal.y
        normals[i][2] = mNormal.z;                                                     // normal.z
        
        // zero fill tangents & binormals
        if(bTangents)
        {
          tangents[i][0]  = 0.0f;
          tangents[i][1]  = 0.0f;
          tangents[i][2]  = 0.0f;
          
          binormals[i][0] = 0.0f;
          binormals[i][1] = 0.0f;
          binormals[i][2] = 0.0f;
        }
      
        //sys::info << positions[i] << sys::endl;
      }
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      ushort  nNumIndices = 6 * mSubdivisions * mSubdivisions;
      ushort* indices = new ushort[nNumIndices];
      
      // compute indices
      for(ushort i = 0, j = 0; i < nNumIndices; i+=6)
      {
        indices[i + 0] = j + mSubdivisions + 1 + (bInverted  ? 0 : 1);
        indices[i + 1] = j + mSubdivisions + 1 + (!bInverted ? 0 : 1);
        indices[i + 2] = j;
        indices[i + 3] = j + 1 + (!bInverted ? 0 : mSubdivisions + 1);
        indices[i + 4] = j + 1 + (bInverted  ? 0 : mSubdivisions + 1);
        indices[i + 5] = j;
        
        j = (j + 2) % (mSubdivisions + 1) ? j + 1 : j + 2;
        
        // for(ushort k = 0; k < 6; k++)
        //   sys::info << indices[i + k] << " ";
        // sys::info << sys::endl;
      }
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      // compute tangents
      if(bTangents)
      {
        for(ushort i = 0; i < nNumIndices; i+=3) // for each triangle
        {
          const ushort& i0 = indices[i+0];
          const ushort& i1 = indices[i+1];
          const ushort& i2 = indices[i+2];
          
          const math::vec3& p0 = positions[i0];
          const math::vec3& p1 = positions[i1];
          const math::vec3& p2 = positions[i2];
          
          const math::vec2& t0 = texcoords[i0];
          const math::vec2& t1 = texcoords[i1];
          const math::vec2& t2 = texcoords[i2];
          
          math::vec3 dp1 = p1 - p0;  // edge 1 = 1 -> 0 = (local x)
          math::vec3 dp2 = p2 - p0;  // edge 2 = 2 -> 0 = (local y)
          
          math::vec2 dt1 = t1 - t0;
          math::vec2 dt2 = t2 - t0;
          
          float r = 1.0f / (dt1.x * dt2.y - dt1.y * dt2.x);
          
          math::vec3 ta = (dp1 * dt2.y - dp2 * dt1.y) * r;    // tangent
          math::vec3 bi = (dp2 * dt1.x - dp1 * dt2.x) * r;    // binormal
          
          tangents[i0] = ta;
          tangents[i1] = ta;
          tangents[i2] = ta;
          
          binormals[i0] = bi;
          binormals[i1] = bi;
          binormals[i2] = bi;
        }
        
        for(size_t i = 0; i < nNumVertices; ++i)
        {
          const math::vec3& n = normals[i];
          const math::vec3& t = tangents[i];
          const math::vec3& b = binormals[i];
          
          tangents[i] = math::normalize(t - n * math::dot(n, t));                 // orthogonalize(Gram-Schmidt)
          tangents[i] = (math::dot(math::cross(n, t), b) < 0.0f) ? t * -1.0f : t; // handedness
        }
      }
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      // sys::info << sys::tab << "mNormal: " << mNormal << sys::endl;
      // sys::info << sys::tab << "sizeof(positions): " << positionsSize << sys::endl;
      
      CObject* pObject = new CObject;
      pObject->mNumVertices = nNumVertices;
      pObject->mNumIndices  = nNumIndices;
      
      pObject->setDrawStrategy(mDrawStrategy == nullptr ? new CDrawStrategy : mDrawStrategy);
      
      CMaterial* pMaterial = new CMaterial;
      ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
      pTextureBuilder->setFile("notfound.dds");
      CTexture* pTexture = pTextureBuilder->build();
      pTexture->setFiltering(ogl::CTexture::EFiltering::TRILINEAR);
      //pTexture->setWrapping(GL_CLAMP_TO_EDGE);
      delete pTextureBuilder;
      
      CShape* pShape = new CShape;
      pMaterial->setTexture(CTexture::EScope::DIFFUSE, pTexture);
      pShape->setVertexBufferRange(ogl::CBufferRange(0, pObject->mNumVertices, GL_FLOAT));
      pShape->setIndexBufferRange(ogl::CBufferRange(0, pObject->mNumIndices, GL_UNSIGNED_SHORT));
      pShape->setMaterial(pMaterial);
      pObject->addShape(pShape);
      
      pObject->mBuffers.resize(bTangents ? 5 : 4);
      
      // indices
      {
        glGenBuffers(1, &(pObject->mBuffers[INDEX_BUFFER_INDEX]));
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pObject->mBuffers[INDEX_BUFFER_INDEX]);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, pObject->mNumIndices * sizeof(ushort), &indices[0], GL_STATIC_DRAW);

        glGenVertexArrays(1, &(pObject->mVAO));
        glBindVertexArray(pObject->mVAO);
      }
      
      // positions
      if(bPositions)
      {
        glGenBuffers(1, &(pObject->mBuffers[POSITION_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[POSITION_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), &positions[0], GL_STATIC_DRAW);
        
        glVertexAttribPointer(POSITION_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (GLvoid*)((0) * sizeof(GLfloat)));
        glEnableVertexAttribArray(POSITION_ATTRIBUTE); // positions
      }
      
      // texcoords
      if(bTexcoords)
      {
        glGenBuffers(1, &(pObject->mBuffers[TEXCOORD_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[TEXCOORD_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec2), texcoords, GL_STATIC_DRAW);
        
        glVertexAttribPointer(TEXCOORD_ATTRIBUTE, 2, GL_FLOAT, GL_FALSE, sizeof(math::vec2), (GLvoid*)((0) * sizeof(GLfloat))); // (GLvoid*)((0 + 3)  * sizeof(GLfloat)));
        glEnableVertexAttribArray(TEXCOORD_ATTRIBUTE); // texcoords
      }
      
      // normals
      if(bNormals)
      {
        glGenBuffers(1, &(pObject->mBuffers[NORMAL_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[NORMAL_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), normals, GL_STATIC_DRAW);
        
        glVertexAttribPointer(NORMAL_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (GLvoid*)((0) * sizeof(GLfloat))); // (GLvoid*)((0 + 3 + 2) * sizeof(GLfloat)));
        glEnableVertexAttribArray(NORMAL_ATTRIBUTE); // normals
      }
      
      // tangents
      if(bTangents)
      {
        glGenBuffers(1, &(pObject->mBuffers[TANGENT_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[TANGENT_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), tangents, GL_STATIC_DRAW);
      
        glVertexAttribPointer(TANGENT_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (GLvoid*)((0) * sizeof(GLfloat))); // (GLvoid*)((0 + 3 + 2 + 3) * sizeof(GLfloat)));
        glEnableVertexAttribArray(TANGENT_ATTRIBUTE); // tangents
      }
      
      // binormals
      if(bTangents && bBinormals)
      {
        glGenBuffers(1, &(pObject->mBuffers[BINORMAL_BUFFER_INDEX]));
        glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[BINORMAL_BUFFER_INDEX]);
        glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), binormals, GL_STATIC_DRAW);
      
        glVertexAttribPointer(BINORMAL_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (GLvoid*)((0) * sizeof(GLfloat))); // (GLvoid*)((0 + 3 + 2 + 3) * sizeof(GLfloat)));
        glEnableVertexAttribArray(BINORMAL_ATTRIBUTE); // binormals
      }
      
      glBindBuffer(GL_ARRAY_BUFFER, 0);
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
      glBindVertexArray(0);
      
      // clean up
      { 
        delete [] indices;
        delete [] positions;
        delete [] texcoords;
        delete [] normals;
        if(bTangents)
        {
          delete [] tangents;
          delete [] binormals;
        }
      }
      
      glExitIfError();
      
      return pObject;
    }
    
    public:
    void setWidth(float width)
    {
      mWidth = width;
    }
    
    void setHeight(float height)
    {
      mHeight = height;
    }
    
    void setTextureScale(float scale)
    {
      mTextureScale = scale;
    }
    
    void setNormal(const math::vec3& normal)
    {
      mNormal = math::normalize(normal);
    }
    
    void setSubdivisions(ushort subdivisions)
    {
      mSubdivisions = subdivisions;
    }
    
    void addOption(uint option)
    {
      mOptions |= option;
    }
    
    void setOptions(uint options)
    {
      mOptions = options;
    }
  };
}

#endif // __cplaneobjectbuilder_hpp__
