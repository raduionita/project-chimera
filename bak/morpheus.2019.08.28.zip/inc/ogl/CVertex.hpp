#ifndef __cvertex_hpp__
#define __cvertex_hpp__

namespace ogl
{
  class CVertex
  {
    public:
    math::vec3 mPosition;
    math::vec2 mTexcoord;
    math::vec3 mNormal;
    math::vec3 mTangent;
    
    math::ivec4 mBoneIds;
    math::vec4  mBoneWeights;
    
    public:
    CVertex()
    {
    
    }
    
    CVertex(const math::vec3& position) 
    : mPosition(position)
    {
    
    }
    
    CVertex(const math::vec3& position, const math::vec2& texcoord) 
    : mPosition(position), mTexcoord(texcoord)
    {
    
    }
    
    CVertex(const math::vec3& position, const math::vec2& texcoord, const math::vec3& normal) 
    : mPosition(position), mTexcoord(texcoord), mNormal(normal)
    {
    
    }
    
    CVertex(const math::vec3& position, const math::vec2& texcoord, const math::vec3& normal, const math::vec3& tangent) 
    : mPosition(position), mTexcoord(texcoord), mNormal(normal), mTangent(tangent)
    {
    
    }
  
    math::vec3 getPosition() const { return mPosition; }
    math::vec2 getTexcoord() const { return mTexcoord; }
    math::vec3 getNormal()   const { return mNormal; }
    math::vec3 getTangent()  const { return mTangent; }
  };
}

#endif // __cvertex_hpp__
