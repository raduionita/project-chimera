#ifndef __cddstexturebuilder_hpp__
#define __cddstexturebuilder_hpp__

// surface description flags
#define DDS_CAPS        0x00000001
#define DDS_HEIGHT      0x00000002
#define DDS_WIDTH       0x00000004
#define DDS_PITCH       0x00000008
#define DDS_PIXELFORMAT 0x00001000
#define DDS_MIPMAPCOUNT 0x00020000
#define DDS_LINEARSIZE  0x00080000
#define DDS_DEPTH       0x00800000

// pixel format flags
#define DDS_ALPHAPIXELS 0x00000001
#define DDS_FOURCC      0x00000004
#define DDS_RGB         0x00000040
#define DDS_RGBA        0x00000041

// caps1 flags
#define DDS_COMPLEX     0x00000008
#define DDS_TEXTURE     0x00001000
#define DDS_MIPMAP      0x00400000

// caps2 flags
#define DDS_CUBEMAP           0x00000200
#define DDS_CUBEMAP_POSITIVEX 0x00000400
#define DDS_CUBEMAP_NEGATIVEX 0x00000800
#define DDS_CUBEMAP_POSITIVEY 0x00001000
#define DDS_CUBEMAP_NEGATIVEY 0x00002000
#define DDS_CUBEMAP_POSITIVEZ 0x00004000
#define DDS_CUBEMAP_NEGATIVEZ 0x00008000
#define DDS_CUBEMAP_ALL_FACES 0x0000FC00
#define DDS_VOLUME            0x00200000

#define DDS_FOURCC_DTX1 0x31545844 // = DTX1(in ASCII)
#define DDS_FOURCC_DTX3 0x33545844 // = DTX3(in ASCII)
#define DDS_FOURCC_DTX5 0x35545844 // = DTX5(in ASCII)

#define GL_BGR_EXT                                        0x80E0
#define GL_COMPRESSED_RGB_S3TC_DXT1_EXT                   0x83F0
#define GL_COMPRESSED_RGBA_S3TC_DXT1_EXT                  0x83F1
#define GL_COMPRESSED_RGBA_S3TC_DXT3_EXT                  0x83F2
#define GL_COMPRESSED_RGBA_S3TC_DXT5_EXT                  0x83F3

namespace ogl
{
  class CDdsTextureBuilder : public CTextureBuilder
  {
    private:
    typedef struct {
      ulong size;
      ulong flags;
      ulong fourcc;
      ulong bpp;
      ulong rbitmask;
      ulong gbitmask;
      ulong bbitmask;
      ulong abitmask;
    } pixelformat_t;
    typedef struct {
      ulong          size;
      ulong          flags;
      ulong          height;
      ulong          width;
      ulong          linearsize;
      ulong          depth;          // only if DDS_HEADER_FLAGS_VOLUME is in header_t::flags
      ulong          mipmapcount;
      ulong          reserved1[11];
      pixelformat_t pixelformat; 
      ulong          caps1;
      ulong          caps2;
      ulong          reserved2[3];
    } header_t;
    
    protected:
    std::string mFile;
    
    public:
    CDdsTextureBuilder() : CTextureBuilder()
    {
      sys::info << "ogl::CDdsTextureBuilder::CDdsTextureBuilder()" << sys::endl;
    }
    
    virtual ~CDdsTextureBuilder()
    {
      sys::info << "ogl::CDdsTextureBuilder::~CDdsTextureBuilder()" << sys::endl;
    }
    
    public:
    void setFile(const std::string& file)
    {
      mFile.clear();
      mFile.append(TEXTUREPATH).append(file);
    }
    
    CTexture* build()
    {
      sys::info << "ogl::CDdsTextureBuilder::build() " << sys::endl;
      
      CTexture* pTexture = nullptr;
      FILE* fp = NULL;
      
      if(mFile.empty())
      {
        sys::warn << "No file loaded. Reading empty texture." << sys::endl;
        return CTextureBuilder::build();
      }
      else
      {
        fp = fopen(mFile.c_str(), "rb");
      }
      
      if(fp == NULL)
      {
        sys::warn << "Can not open file: " << mFile << sys::endl;
        return CTextureBuilder::build();
      }
        
      // fseek(fp, 0, SEEK_END);
      // size_t filesize = ftell(fp);
      // rewind(fp);
      // sys::info << "file size: " << filesize << sys::endl;
      
      char filetype[3];
      fread(filetype, 1, 4, fp);
      if(strncmp(filetype, "DDS ", 4) != 0)
      {
        sys::warn << "File not a DDS texture." << sys::endl;
        fclose(fp);
        return CTextureBuilder::build();
      }
      
      sys::info << sys::tab << "texpath: " << mFile << sys::endl;
      
      // read header
      header_t header;
      fread(&header, sizeof(header_t), 1, fp);
      
      //@TODO: endian_swap();
      
      // read texture type: flat(1D 2D), cubemap, volumetric
      CTexture::EType type = CTexture::EType::FLAT;
      if(header.caps2 & DDS_CUBEMAP)
        type = CTexture::EType::CUBEMAP;
      if((header.caps2 & DDS_VOLUME) && (header.depth > 0))
        type = CTexture::EType::VOLUME;
      
      // set format & components
      uint   components = header.pixelformat.fourcc == DDS_FOURCC || header.pixelformat.bpp == 24 ? 3 : 4;
      GLenum format     = 0;
      GLenum target     = get_target(type);
      bool compressed = false;
      if(header.pixelformat.flags & DDS_FOURCC)
      {
        switch(header.pixelformat.fourcc)
        {
          case DDS_FOURCC_DTX1: format = GL_COMPRESSED_RGBA_S3TC_DXT1_EXT; break;
          case DDS_FOURCC_DTX3: format = GL_COMPRESSED_RGBA_S3TC_DXT3_EXT; break;
          case DDS_FOURCC_DTX5: format = GL_COMPRESSED_RGBA_S3TC_DXT5_EXT; break;
          default: 
            fclose(fp);
            sys::warn << "Compression type not recognized." << sys::endl;
            return CTextureBuilder::build(); 
        }
        compressed = true;
      }
      else if(header.pixelformat.flags == DDS_RGBA && header.pixelformat.bpp == 32)
      {
        format = GL_RGBA;
      }
      else if(header.pixelformat.flags == DDS_RGB && header.pixelformat.bpp == 32)
      {
        format = GL_RGBA;
      }
      else if(header.pixelformat.flags == DDS_RGB && header.pixelformat.bpp == 24)
      {
        format = GL_RGB;
      }
      else if(header.pixelformat.bpp == 8)
      {
        //@TODO: components = 1;
        //@TODO: format = GL_LUMINANCE;
        fclose(fp);
        sys::warn << "Luminance textures not supported." << sys::endl;
        return CTextureBuilder::build();
      }
      else
      {
        fclose(fp);
        sys::warn << "Format type not recognized." << sys::endl;
        return CTextureBuilder::build();
      }
      
      pTexture = new CTexture;
      
      // sys::info << sys::tab << "Fourcc: " << fourcc(header.pixelformat.fourcc) << sys::endl;
      pTexture->setWidth(header.width);
      pTexture->setHeight(clamp2one(header.height));
      pTexture->setDepth(clamp2one(header.depth));
      pTexture->setFormat(format);
      pTexture->setTarget(target);
      
      //glEnable(target); // for older ATIs
      pTexture->bind();      glPixelStorei(GL_UNPACK_ALIGNMENT, 1);  // pixel storage mode (1 = byte aligned)
      ushort layers  = type == CTexture::EType::CUBEMAP ? 6 : 1;
      header.mipmapcount = header.mipmapcount == 0 ? 1 : header.mipmapcount;
      
      sys::info << sys::tab << "w: " << header.width << " h: " << header.height << " d:" << header.depth << sys::endl;
      sys::info << sys::tab << "layers: " << layers << sys::endl;
      sys::info << sys::tab << "format: " << format << sys::endl;
      sys::info << sys::tab << "target: " << target << sys::endl;
      sys::info << sys::tab << "linearsize: " << header.linearsize << sys::endl;
      sys::info << sys::tab << "mipmaps: " << header.mipmapcount << sys::endl;
      sys::info << sys::tab << "compressed: " << compressed << sys::endl;
      sys::info << sys::tab << "type: " << (int)(type) << sys::endl;
      
      GLenum targets[6] = {
        GL_TEXTURE_CUBE_MAP_POSITIVE_X,
        GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
        GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
        GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
        GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
        GL_TEXTURE_CUBE_MAP_NEGATIVE_Z
      };
      
      uint width  = 0;
      uint height = 0;
      uint depth  = 0;
      for(ushort i = 0; i < layers; i++)
      {
        if(layers > 1)
          target = targets[i];
        sys::info << sys::tab << "layer: " << i << " target: " << target << sys::endl;
        
        //@TODO: flip texture
        
        width  = header.width;
        height = header.height;
        depth  = header.depth ? header.depth : 1;
        
        sys::info << sys::tab << "cursor position: " << ftell(fp) << sys::endl;
        
        // load texture levels - base level + mipmaps
        for(ushort j = 0; j < header.mipmapcount && (width || height); j++)
        {
          // read texture
          uint   bufsize = calc_mapsize(width, height, depth, components, format, compressed);
          ubyte* buffer  = new ubyte[bufsize];
          /* size_t read= */ fread(buffer, 1, bufsize, fp);

          // sys::info << sys::tab << "mipmap: " << j << " bufsize: " << bufsize << " read: " << read << sys::endl;
          
          if(compressed)
            if(type == CTexture::EType::VOLUME)
              glCompressedTexImage3D(target, j, format, width, height, depth, 0, bufsize, buffer);
            else
              glCompressedTexImage2D(target, j, format, width, height, 0, bufsize, buffer);
          else
            if(type == CTexture::EType::VOLUME)
              glTexImage3D(target, j, format, width, height, depth, 0, format, GL_UNSIGNED_BYTE, buffer);
            else
              glTexImage2D(target, j, format, width, height, 0, format, GL_UNSIGNED_BYTE, buffer);
          width  = clamp2one(width  >> 1);
          height = clamp2one(height >> 1);
          depth  = clamp2one(depth  >> 1);
          delete [] buffer;
        }
      }
      if(header.mipmapcount <= 1)
        glGenerateMipmap(GL_TEXTURE_2D);
      fclose(fp);
      
      // pTexture->setFiltering(CTexture::EFiltering::TRILINEAR);
      
      return pTexture;
    }
    
    private:
    static std::string fourcc(uint enc) // uint32_t
    {
      char c[5] = { '\0' };
      c[0] = enc >> 0  & 0xFF;
      c[1] = enc >> 8  & 0xFF;
      c[2] = enc >> 16 & 0xFF;
      c[3] = enc >> 24 & 0xFF;
      return c;                         // returns: "DTX5"
    }
    
    static void endian_swap()
    {
      
    }
    
    static uint calc_mapsize(uint width, uint height, uint depth, uint components, GLenum format, bool compressed = true)
    {
      return compressed ? ((width + 3) >> 2) * ((height + 3) >> 2) * depth * (format == GL_COMPRESSED_RGBA_S3TC_DXT1_EXT ? 8 : 16) 
                        : width * height * depth * components;
    }
  
    static GLenum get_target(CTexture::EType type)
    {
      switch(type)
      {
        case CTexture::EType::CUBEMAP: return GL_TEXTURE_CUBE_MAP;
        case CTexture::EType::VOLUME : return GL_TEXTURE_3D;
        default:
        case CTexture::EType::FLAT   : return GL_TEXTURE_2D;
      }
    }
    
    static uint clamp2one(uint value) 
    {
      return value < 1 ? 1 : value;
    }
  };  
}

#endif // __cddstexturebuilder_hpp__
