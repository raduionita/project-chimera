#ifndef __ogl_CTGATEXTUREBUILDER_HPP__
#define __ogl_CTGATEXTUREBUILDER_HPP__

// header_t::dataTypeCode
#define TGA_NO_IMAGE_DATA 0
#define TGA_UNCOMPRESSED_COLOR_MAPPED_IMAGE 1
#define TGA_UNCOMPRESSED_RGB_IMAGE 2
#define TGA_UNCOMPRESSED_MONOCHROME_IMAGE 3 // black and white
#define TGA_RUNLENGTH_ENCODED_COLOR_MAPPED_IMAGE 9
#define TGA_RUNLENGTH_ENCODED_RGB_IMAGE 10
#define TGA_COMPRESSED_MONOCHROME_IMAGE 11  // black and white
#define TGA_COMPRESSED_COLOR_MAPPED_HUFFMAN_DELTA_RUNLENGTH_ENCODING 32
#define TGA_COMPRESSED_COLOR_MAPPED_HUFFMAN_DELTA_RUNLENGTH_ENCODING_4PASS_QUADTREE_PROCESS 33

namespace ogl
{
  class CTgaTextureBuilder : public CTextureBuilder
  {
    protected:
    typedef struct {
      ubyte  idLength;        // length of the string located after the header
      ubyte  colorMapType;
      ubyte  dataTypeCode;    // data types
      ubyte  colorMapSpec[5];
      //ushort colorMapOrigin;
      //ushort colorMapLength;
      //ubyte  colorMapDepth;
      ushort xOrigin;
      ushort yOrigin;
      ushort width;      // width in px
      ushort height;     // height in px
      ubyte  bpp;        // bit rate
      ubyte  imageDesc;  
    } header_t;
  
    public:
    CTgaTextureBuilder() : CTextureBuilder()
    {
      sys::info << "ogl::CTgaTextureBuilder::CTgaTextureBuilder()" << sys::endl;
    }
    
    virtual ~CTgaTextureBuilder()
    {
      sys::info << "ogl::CTgaTextureBuilder::~CTgaTextureBuilder()" << sys::endl;
    }
  
    protected:
    std::string mFile;
    
    public:
    void setFile(const std::string& file)
    {
      mFile.clear();
      mFile.append(TEXTUREPATH).append(file);
    }
    
    CTexture* build()
    {
      sys::info << "ogl::CTgaTextureBuilder::build() " << sys::endl;
      
      FILE* fp = NULL;
      
      if(mFile.empty())
      {
        sys::warn << sys::tab << "No file loaded. Reading empty texture." << sys::endl;
        return CTextureBuilder::build();
      }
      else
      {
        fp = fopen(mFile.c_str(), "rb");
      }
      
      if(fp == NULL)
      {
        sys::warn << "Can not open file: " << mFile << sys::endl;
        return CTextureBuilder::build();
      }
      
      sys::info << sys::tab << "texpath: " << mFile << sys::endl;
      
      byte* data = nullptr;
      header_t header;
      
      /* size_t read = */fread((byte*)(&header), 1, sizeof(header), fp);
      
      // sys::info << "> " << ((int)header.dataTypeCode) << sys::endl;
      
      size_t datasize = header.width * header.height * header.bpp; // calculate image size
      
      data = new byte[datasize]; // (byte*) malloc(datasize);
      
      /* size_t read = */fread((byte*)(data), 1, datasize, fp);
      fclose(fp);
      
      byte temp;
      
      GLenum format   = GL_NONE;
      uint components = 0;
      uint alignment  = 0;
      if(header.bpp == 24) // BGR
      {
        format     = GL_RGB;
        components = 3;
        alignment  = 1;
        
        for(size_t i = 0; i < datasize; i+=3) // swap to RGB
        {
          temp      = data[i];
          data[i]   = data[i+2];
          data[i+2] = temp;
        }
      }
      else if(header.bpp == 32) // BGRA
      {
        format = GL_RGBA;
        components = 4;
        alignment  = 2;
        
        for(size_t i = 0; i < datasize; i+=4) // swap to RGBA
        {
          temp      = data[i];
          data[i]   = data[i+2];
          data[i+2] = temp;
        }
      }
      
      bool flipH = ((header.imageDesc & 0x10) == 0x10); // flipped horizontally
      bool flipV = ((header.imageDesc & 0x20) == 0x20); // flipped vertically
      
      //sys::info << "> imageDesc: " << header.imageDesc << sys::endl;
      //sys::info << "> flipped: " << (flipH ? "H" : "") << sys::endl;
      //sys::info << "> flipped: " << (flipV ? "V" : "") << sys::endl;
      
      if(flipH)
      {
        for(size_t h = 0; h < header.height; ++h)
        {
          for(size_t w = 0; w < header.width / 2; ++w)
          {
            swap(data + (h * header.width + w) * components, data + (h * header.width + header.width - w - 1) * components, components);
          }
        }
      }
      if(1 || flipV)
      {
        for(size_t w = 0; w < header.width; ++w)
        {
          for(size_t h = 0; h < header.height / 2; ++h)
          {
            swap(data + (h * header.width + w) * components, data + ((header.height - h - 1) * header.width + w) * components, components);
          }
        }
      }
      
      CTexture::EType type = CTexture::EType::FLAT;
      GLenum target     = GL_TEXTURE_2D;
      bool compressed   = false;
      ushort layers     = 1;
      ushort mipmaps    = 1;
      
      CTexture* pTexture = new CTexture;
      
      pTexture->setWidth(header.width);
      pTexture->setHeight(header.height);
      pTexture->setDepth(1);
      pTexture->setFormat(format);
      pTexture->setTarget(target);
      
      pTexture->bind();
//      glPixelStorei(GL_UNPACK_ROW_LENGTH, header.width);
      glPixelStorei(GL_UNPACK_ALIGNMENT, alignment);
      
      sys::info << sys::tab << "tex: " << (GLuint)(*pTexture) << sys::endl;
      sys::info << sys::tab << "w: " << header.width << " h: " << header.height << " d:" << 1 << sys::endl;
      sys::info << sys::tab << "bpp: " << ((int)(header.bpp)) << sys::endl; // std::dec
      sys::info << sys::tab << "layers: " << layers << sys::endl;
      sys::info << sys::tab << "format: " << format << sys::endl; // std::hex
      sys::info << sys::tab << "target: " << target << sys::endl; // std::hex 
      sys::info << sys::tab << "mipmaps: " << mipmaps << sys::endl;
      sys::info << sys::tab << "compressed: " << compressed << sys::endl;
      sys::info << sys::tab << "type: " << (int)(type) << sys::endl;
      
      if(compressed)
        glCompressedTexImage2D(target, 0, format, header.width, header.height, 0, datasize, data);
      else
        glTexImage2D(target, 0, format, header.width, header.height, 0, format, GL_UNSIGNED_BYTE, data);
        //glTexImage2D(target, 0, GL_RGBA, header.width, header.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
      
      glGenerateMipmap(target);
      
      delete [] data;
      
      // trilinear filtering
      glTexParameteri(target, GL_TEXTURE_WRAP_S, GL_REPEAT); 
      glTexParameteri(target, GL_TEXTURE_WRAP_T, GL_REPEAT); 
      glTexParameteri(target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);               // if >= max: use Linear 
      glTexParameteri(target, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); // if < max : blend mipmaps linear
      
      pTexture->unbind();
      
      glExitIfError();
      
      return pTexture;
    }
    
    private:
    static void swap(byte* src, byte* dst, size_t size)
    {
      byte* temp = new byte[size];
      
      memcpy(temp, src, size);
      memcpy(src, dst, size);
      memcpy(dst, temp, size);
      
      delete [] temp;
    }
  };
}

#endif // __ogl_CTGATEXTUREBUILDER_HPP__
