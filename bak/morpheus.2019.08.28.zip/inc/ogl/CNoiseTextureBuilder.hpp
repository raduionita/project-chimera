#ifndef __CNoiseTextureBuilder_hpp__
#define __CNoiseTextureBuilder_hpp__

namespace ogl
{
  class CNoiseTextureBuilder : public CTextureBuilder
  {
    protected:
    GLenum                           mTarget;
    GLint                            mFormat;
    uint                             mWidth;
    uint                             mHeight;
    uint                             mDepth;
    std::function<void(math::vec3&)> mCallback;
    
    public:
    CNoiseTextureBuilder() : CTextureBuilder(), mTarget(GL_NONE), mFormat(GL_RGB), mWidth(1), mHeight(1), mDepth(1)
    {
      sys::info << "ogl::CNoiseTextureBuilder::CNoiseTextureBuilder()" << sys::endl;
    }
    
    public:
    CTexture* build()
    {
      sys::info << "ogl::CNoiseTextureBuilder::build()" << sys::endl;
      
      CTexture* pTexture = new CTexture;
      
      mTarget = mTarget != GL_NONE ? mTarget : (mDepth > 1 ? GL_TEXTURE_3D : (mHeight > 1 ? GL_TEXTURE_2D : GL_TEXTURE_1D));
      
      pTexture->setTarget(mTarget);
      
      GLint  eInternalFormat = GL_RGB;
      GLenum eExternalFormat = GL_RGB;
      
      switch(mFormat)
      {
        case GL_RGB:
        {
          eInternalFormat = GL_RGB;
          eExternalFormat = GL_RGB;
        }
        break;
        case GL_RGB16F:
        {
          eInternalFormat = GL_RGB16F;
          eExternalFormat = GL_RGB;
        }
        break;
        default: // TODO: this needs better code
        {
          eInternalFormat = GL_RGB; 
          eExternalFormat = GL_RGB;
        }
        break;
      };
      
      switch(mTarget)
      {
        case GL_TEXTURE_1D:
        {
          sys::info << sys::tab << "GL_TEXTURE_1D" << sys::endl;
          sys::info << sys::tab << "W: " << mWidth << sys::endl;
          
          math::vec3* data = new math::vec3[mWidth];
          for(uint i = 0; i < mWidth; i++)
          {
            data[i].x = math::rand();
            data[i].y = math::rand();
            data[i].z = math::rand();
            
            if(mCallback) // if is callable
              mCallback(data[i]);
          }
          
          pTexture->bind();
          glTexImage1D(mTarget, 0, eInternalFormat, mWidth, 0, eExternalFormat, GL_FLOAT, data);
          pTexture->setFiltering(CTexture::EFiltering::TRILINEAR);
          pTexture->setWrapping(CTexture::EWrapping::REPEAT);
          
          delete [] data;
        }
        break;
        default:
        case GL_TEXTURE_2D:
        {
          sys::info << sys::tab << "GL_TEXTURE_2D" << sys::endl;
          sys::info << sys::tab << "WxH: " << mWidth << "x" << mHeight << sys::endl;
          
          
          math::vec3* data = new math::vec3[mWidth * mHeight];
          
          for(size_t i = 0, l = mWidth * mHeight; i < l; ++i)
          {
            math::vec3 color;
            color.r = ((float)rand() / RAND_MAX); // * 2.0f - 1.0f; // [0, 32767] / 32767 = 2 * [0, 1] = [0, 2] - 1 = [-1, 1]
            color.g = ((float)rand() / RAND_MAX); // * 2.0f - 1.0f;
            color.b = ((float)rand() / RAND_MAX);
            
            if(mCallback) // if is callable
              mCallback(color);
            
            data[i] = color;
          }
          
          pTexture->bind();
          glTexImage2D(mTarget, 0, eInternalFormat, mWidth, mHeight, 0, eExternalFormat, GL_FLOAT, data);
          pTexture->setFiltering(CTexture::EFiltering::NEAREST);
          pTexture->setWrapping(CTexture::EWrapping::REPEAT);
          
          delete [] data;
        }
        break;
        case GL_TEXTURE_3D:
        {
        
        }
        break;
      }
      
      sys::info << sys::tab << "texture: " << ((GLuint)(*pTexture)) << sys::endl;
      
      glExitIfError();
      
      return pTexture;
    }
    
    void setTarget(GLenum target) 
    {
      mTarget = target;
    }
    
    void setFormat(GLenum format)
    {
      mFormat = format;
    }
    
    void setWidth(uint width)
    {
      mWidth = width;
    }
    
    void setHeight(uint height)
    {
      mHeight = height;
    }
    
    void setDepth(uint depth)
    {
      mDepth = depth;
    }
  
    void setCallback(const std::function<void(math::vec3&)>& callback)
    {
      mCallback = callback;
    }
  };
}

#endif // __CNoiseTextureBuilder_hpp__
