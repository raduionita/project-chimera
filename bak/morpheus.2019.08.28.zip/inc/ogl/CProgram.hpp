#ifndef __cprogram_hpp__
#define __cprogram_hpp__

#include <map>         // std::map
#include <string>      // std::string
#include <iostream>    // sys::info
#include <functional>  // std::function

#include "CUniform.hpp"

namespace ogl
{
  class CProgramBuilder;
  class CProgramManager;
  
  class CRenderer;
  class CDrawCommand;

  class CProgram
  {
    friend class CProgramManager;
  
    public:
    GLuint                                         mProgram;
    bool                                           mLinked;
    bool                                           mActive;
    bool                                           mTessellated;
    std::map<std::string, CUniform*>               mUniforms;
    std::function<void(CRenderer*, CDrawCommand*)> mCallback;
    
    public:
    CProgram() : mProgram(GL_ZERO), mLinked(false), mActive(false), mTessellated(false)
    {
      sys::info << "ogl::CProgram::CProgram()" << sys::endl;
    }
    
    CProgram(GLuint program) : mProgram(program), mLinked(true), mActive(false), mTessellated(false)
    {
      sys::info << "ogl::CProgram::CProgram(program)" << sys::endl;
    }
    
    CProgram(GLuint program, GLboolean linked) : mProgram(program), mLinked(linked), mActive(false), mTessellated(false)
    {
      sys::info << "ogl::CProgram::CProgram(program, linked)" << sys::endl;
    }
    
    CProgram(const CProgram& that)
    {
      sys::info << "ogl::CProgram::CProgram(CProgram&)" << sys::endl;
      for(auto it = mUniforms.begin(); it != mUniforms.end(); ++it)
        if(it->second != nullptr)
          delete it->second;
      mUniforms.clear();
      glDeleteProgram(mProgram);
      
      mProgram     = that.mProgram;
      mLinked      = that.mLinked;
      mActive      = that.mActive;
      mTessellated = that.mTessellated;
      mUniforms    = that.mUniforms;
      mCallback    = that.mCallback;
    }
    
    virtual ~CProgram()
    {
      sys::info << "ogl::CProgram::~CProgram()" << sys::endl;
      for(auto it = mUniforms.begin(); it != mUniforms.end(); ++it)
        if(it->second != nullptr)
          delete it->second;
      mUniforms.clear();
      glDeleteProgram(mProgram);
    }
    
    CProgram& operator = (const CProgram& that)
    {
      if(this != &that) 
      {
        sys::info << "ogl::CProgram::operator=(CProgram&)" << sys::endl;
        for(auto it = mUniforms.begin(); it != mUniforms.end(); ++it)
          if(it->second != nullptr)
            delete it->second;
        mUniforms.clear();
        glDeleteProgram(mProgram);
        
        mProgram     = that.mProgram;
        mLinked      = that.mLinked;
        mActive      = that.mActive;
        mTessellated = that.mTessellated;
        mUniforms    = that.mUniforms;
        mCallback    = that.mCallback;
      }
      return *this;
    }
    
    operator GLuint ()
    {
      return mProgram;
    }
    
    void operator () (CRenderer* pRenderer, CDrawCommand* pDrawCommand)
    {
      enable();
      mCallback(pRenderer, pDrawCommand);
    }
    
    public:
    void use()
    {
      enable();
    }
    
    void unuse()
    {
      disable();
    }
    
    void enable()
    {
      if(1 /*mActive == false*/)
      {
        sys::info << "ogl::CProgram::enable()" << sys::endl;
      
        glValidateProgram(mProgram);
//        GLint status = GL_FALSE;
//        glGetProgramiv(mProgram, GL_VALIDATE_STATUS, &status);
//        {
//          GLint loglen;
//          glGetProgramiv(mProgram, GL_INFO_LOG_LENGTH, &loglen);
//          GLchar* error = new GLchar[loglen + 1];
//          glGetProgramInfoLog(mProgram, loglen, NULL, error);
//          error[loglen] = '\0';
//          sys::info << sys::tab << "status: " << status << ", message: " << error << sys::endl;
//          delete error;
//        }
        
        
        if(mLinked == true)
          glUseProgram(mProgram);
        //CProgramManager::getInstance()->enable(this);
        else
          sys::info << "> ERROR: Cannot use an unlinked program!" << sys::endl;
          
        mActive = true;
      }
    }
    
    void disable()
    {
      glUseProgram(0);
      mActive = false;
    }
    
    bool isLinked() const
    {
      return mLinked;
    }
    
    bool isTessellated() const
    {
      return mTessellated;
    }
    
    std::map<std::string, CUniform*> getUniforms()
    {
      return mUniforms;
    }
    
    void addUniform(const std::string& sName, CUniform* pUniform)
    {
      mUniforms.insert(std::make_pair(sName, pUniform));
    }
    
    void addUniform(CUniform* pUniform)
    {
      throw EXCEPTION << "NOT IMPLEMENTED!";
    }
    
    CUniform* getUniform(const std::string& name)
    {
      std::map<std::string, CUniform*>::iterator it = mUniforms.find(name);
      if(it == mUniforms.end())
      {
        sys::warn << "ogl::CUniform::getUniform(" << name << ") > ERROR: Uniform not found!" << sys::endl;
        return nullptr;
      }
      return it->second;
    }
    
    std::function<void(CRenderer*, CDrawCommand*)> getCallback()
    {
      return mCallback;
    }
    
    void setCallback(const std::function<void(CRenderer*, CDrawCommand*)>& callback)
    {
      mCallback = callback;
    }
    
    void setTessellated(bool tessellated)
    {
      mTessellated = tessellated;
    }
    
    template <typename T>
    void set(const T& obj)
    {
      // CScreen
      // CObject // CDrawable
      // CCamera
      // CLight
      // CAnimated
      
      throw EXCEPTION << "CProgram::set(const T&) - Not implemented!";
      // oStruct->setUniforms(this);
      
      // obj->getUniform();
      
      // for each uniforms in object
        // if program has an uniform
          // set that uniform
    }
    
    void set(const std::string& name, size_t count, int* data)                    // glUniform1iv
    {
      CUniform* uniform = getUniform(name);
      // TODO: replace with throw EXCEPTION - you can't set an uniform that doesn't exist
      if(uniform != nullptr)
      {
        GLint location = uniform->mLocation;
        glUniform1iv(location, count, data);
      }
    }
    
    void set(const std::string& name, float value)                                // glUniform1i
    {
      CUniform* uniform = getUniform(name);
      if(uniform != nullptr)
      {
        GLint location = uniform->mLocation;
        //sys::info << sys::tab << "set " << name << " = "<< value <<" uniform at location " << location << sys::endl;
        glUniform1f(location, value);
      }
    }
    
    void set(const std::string& name, int value)                                  // glUniform1i
    {
      CUniform* uniform = getUniform(name);
      if(uniform != nullptr)
      {
        GLint location = uniform->mLocation;
        //sys::info << sys::tab << "set " << name << " = "<< value <<" uniform at location " << location << sys::endl;
        glUniform1i(location, value);
      }
    }
    
    void set(const std::string& name, uint value)                                 // glUniform1i
    {
      CUniform* uniform = getUniform(name);
      if(uniform != nullptr)
      {
        GLint location = uniform->mLocation;
        //sys::info << sys::tab << "set " << name << " = "<< value <<" uniform at location " << location << sys::endl;
        glUniform1ui(location, value);
      }
    }
    
    void set(const std::string& name, const math::mat4& value)                    // glUniformMatrix4fv
    {
      CUniform* uniform = getUniform(name);
      if(uniform != nullptr)
      {
        GLint location = uniform->mLocation;
        glUniformMatrix4fv(location, 1, false, (const float*)(value));
      }
    }
    
    void set(const std::string& name, const math::vec3& value)                    // glUniform3fv
    {
      CUniform* uniform = getUniform(name);
      if(uniform != nullptr)
      {
        GLint location = uniform->mLocation;
        glUniform3fv(location, 1, (const GLfloat*)(value));
      }
    }
    
    void set(const std::string& name, size_t nSize, math::vec3* values)
    {
      CUniform* uniform = getUniform(name);
      if(uniform != nullptr)
      {
        GLint location = uniform->mLocation;
        glUniform3fv(location, nSize, (const GLfloat*)(&values[0]));
      }
    }
    
    void set(const std::string& name, const std::vector<math::vec3>& values)
    {
      size_t nSize = values.size();
      if(nSize != 0)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform3fv(location, nSize, (const GLfloat*)(&values[0]));
        }
      }
    }
    
    void setUniform(const std::string& name, bool value)                         // glUniform1ui
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform1ui(location, value);
        }
      }
    }
    
    void setUniform(const std::string& name, uint value)                         // glUniform1ui
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform1ui(location, value);
        }
      }
    }
    
    void setUniform(const std::string& name, int value)                          // glUniform1i
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform1i(location, value);
        }
      }
    }
    
    void setUniform(const std::string& name, float value)                        // glUniform1f
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform1f(location, value);
        }
      }
    }
    
    void setUniform(const std::string& name, float x, float y, float z)          // glUniform3f
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform3f(location, x, y, z);
        }
      }
    }
    
    void setUniform(const std::string& name, const math::vec3& value)            // glUniform3fv
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform3fv(location, 1, (const float*)(value));
        }
      }
    }
    
    void setUniform(const std::string& name, const math::vec2& value)            // glUniform3fv
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform2fv(location, 1, (const float*)(value));
        }
      }
    }
    
    void setUniform(const std::string& name, const math::ivec3& value)            // glUniform3iv
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform3iv(location, 1, (const int*)(value));
        }
      }
    }
    
    void setUniform(const std::string& name, const math::ivec4& value)           // glUniform4iv
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform4iv(location, 1, (const int*)(value));
        }
      }
    }
    
    void setUniform(const std::string& name, const math::vec4& value)            // glUniform4fv
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniform4fv(location, 1, (const float*)(value));
        }
      }
    }
    
    void setUniform(const std::string& name, const math::mat3& value)            // glUniformMatrix3fv
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniformMatrix3fv(location, 1, false, (const float*)(value));
        }
      }
    }
    
    void setUniform(const std::string& name, const math::mat4& value)            // glUniformMatrix4fv
    {
      if(mLinked)
      {
        CUniform* uniform = getUniform(name);
        if(uniform != nullptr)
        {
          GLint location = uniform->mLocation;
          glUniformMatrix4fv(location, 1, false, (const float*)(value));
        }
      }
    }
  };
}

#endif /* __cprogram_hpp__ */
