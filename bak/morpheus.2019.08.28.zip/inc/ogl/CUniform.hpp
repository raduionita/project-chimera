#ifndef __cuniform_hpp__
#define __cuniform_hpp__

#include <string>

namespace ogl
{
  class CProgram;
  
  class CUniform
  {
    friend class CProgram;
    
    private:
    std::string mName;
    GLenum      mType;
    CProgram*   mProgram;
    GLint       mLocation;
    GLboolean   mTransposed;
    GLushort    mNumComponents;
    
    public:
    CUniform() : mType(GL_NONE), mProgram(nullptr), mLocation(-1), mTransposed(GL_FALSE), mNumComponents(1)
    {
      sys::info << "ogl::CUniform::CUniform()" << sys::endl;
    }
    
    CUniform(const CUniform& that)
    {
      mName          = that.mName;
      mType          = that.mType;
      mProgram       = that.mProgram;
      mLocation      = that.mLocation;
      mTransposed    = that.mTransposed;
      mNumComponents = that.mNumComponents;
    }
    
    CUniform(GLenum type, GLushort numComponents = 1) : mType(type), mProgram(nullptr), mLocation(-1), mTransposed(GL_FALSE), mNumComponents(numComponents)
    {
      sys::info << "ogl::CUniform::CUniform(type, numComponents)" << sys::endl;
    }
    
    CUniform(const std::string& name, GLenum type, GLushort numComponents = 1) : mName(name), mType(type), mProgram(nullptr), mLocation(-1), mNumComponents(numComponents)
    {
      sys::info << "ogl::CUniform::CUniform(\""<< name <<"\", " << getTypeName(type) << ", "<< numComponents <<")" << sys::endl;
    }
    
    virtual ~CUniform()
    {
      sys::info << "ogl::CUniform::~CUniform()" << sys::endl;
    }
    
    CUniform& operator = (const CUniform& that)
    {
      if(this != &that)
      {
        mName          = that.mName;
        mType          = that.mType;
        mProgram       = that.mProgram;
        mLocation      = that.mLocation;
        mTransposed    = that.mTransposed;
        mNumComponents = that.mNumComponents;
      }
      return *this;
    }
    
    CUniform& operator = (const GLvoid* pValue)
    {
      sys::info << "ogl::CUniform::operator=(const GLvoid*)" << sys::endl;
      switch(mType)
      {
        case GL_BOOL:       glUniform1i(mLocation, *((GLint*)pValue));                 break;
        case GL_BOOL_VEC2:  glUniform2iv(mLocation, mNumComponents, ((GLint*)pValue)); break;
        case GL_BOOL_VEC3:
        case GL_BOOL_VEC4:  
        
        case GL_INT:        glUniform1i(mLocation, *((const GLint*)pValue));                  break;
        case GL_INT_VEC2: 
        case GL_INT_VEC3:
        case GL_INT_VEC4:
        
        case GL_UNSIGNED_INT:      glUniform1ui(mLocation, *((GLuint*)pValue));                 break;
        case GL_UNSIGNED_INT_VEC2: glUniform2uiv(mLocation, mNumComponents, ((GLuint*)pValue)); break;
        case GL_UNSIGNED_INT_VEC3:
        case GL_UNSIGNED_INT_VEC4:
        
        case GL_FLOAT:             glUniform1f(mLocation, *((GLfloat*)pValue));                 break;
        case GL_FLOAT_VEC2:        glUniform2fv(mLocation, mNumComponents, ((GLfloat*)pValue)); break;
        case GL_FLOAT_VEC3:
        case GL_FLOAT_VEC4:
        case GL_FLOAT_MAT2:        glUniformMatrix2fv(mLocation, mNumComponents, mTransposed, ((GLfloat*)pValue));   break;
        case GL_FLOAT_MAT2x3:      glUniformMatrix2x3fv(mLocation, mNumComponents, mTransposed, ((GLfloat*)pValue)); break;
        case GL_FLOAT_MAT2x4:
        case GL_FLOAT_MAT3:
        case GL_FLOAT_MAT3x2:
        case GL_FLOAT_MAT3x4:
        case GL_FLOAT_MAT4x2:
        case GL_FLOAT_MAT4x3:  
        
        case GL_DOUBLE:            glUniformMatrix2dv(mLocation, mNumComponents, mTransposed, ((GLdouble*)pValue)); break;
        case GL_DOUBLE_VEC2:
        case GL_DOUBLE_VEC3:
        case GL_DOUBLE_VEC4:
        case GL_DOUBLE_MAT2:
        case GL_DOUBLE_MAT2x3:
        case GL_DOUBLE_MAT2x4:
        case GL_DOUBLE_MAT3:
        case GL_DOUBLE_MAT3x2:
        case GL_DOUBLE_MAT3x4:
        case GL_DOUBLE_MAT4x2:
        case GL_DOUBLE_MAT4x3:
        
        case GL_SAMPLER_1D:                     glUniform1i(mLocation, *((GLint*)pValue)); break;
        case GL_SAMPLER_1D_SHADOW:
        case GL_SAMPLER_1D_ARRAY:
        case GL_SAMPLER_1D_ARRAY_SHADOW:
        case GL_SAMPLER_2D:
        case GL_SAMPLER_2D_SHADOW:
        case GL_SAMPLER_2D_ARRAY:
        case GL_SAMPLER_2D_ARRAY_SHADOW:
        case GL_SAMPLER_2D_MULTISAMPLE:
        case GL_SAMPLER_2D_MULTISAMPLE_ARRAY:
        case GL_SAMPLER_2D_RECT:
        case GL_SAMPLER_2D_RECT_SHADOW:
        case GL_SAMPLER_3D:
        case GL_SAMPLER_CUBE:
        case GL_SAMPLER_CUBE_SHADOW:
        case GL_SAMPLER_CUBE_MAP_ARRAY:
        case GL_SAMPLER_CUBE_MAP_ARRAY_SHADOW:
        case GL_SAMPLER_BUFFER:
        
        case GL_INT_SAMPLER_1D:
        case GL_INT_SAMPLER_1D_ARRAY:
        case GL_INT_SAMPLER_2D:
        case GL_INT_SAMPLER_2D_ARRAY:
        case GL_INT_SAMPLER_2D_MULTISAMPLE:
        case GL_INT_SAMPLER_2D_MULTISAMPLE_ARRAY:
        case GL_INT_SAMPLER_2D_RECT:
        case GL_INT_SAMPLER_3D:
        case GL_INT_SAMPLER_CUBE:
        case GL_INT_SAMPLER_CUBE_MAP_ARRAY:
        case GL_INT_SAMPLER_BUFFER:
        
        case GL_UNSIGNED_INT_SAMPLER_1D:
        case GL_UNSIGNED_INT_SAMPLER_1D_ARRAY:
        case GL_UNSIGNED_INT_SAMPLER_2D:
        case GL_UNSIGNED_INT_SAMPLER_2D_ARRAY:
        case GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE:
        case GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY:
        case GL_UNSIGNED_INT_SAMPLER_2D_RECT:
        case GL_UNSIGNED_INT_SAMPLER_3D:
        case GL_UNSIGNED_INT_SAMPLER_CUBE:
        case GL_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY:
        case GL_UNSIGNED_INT_SAMPLER_BUFFER:
        
        case GL_IMAGE_1D:                      // FLOAT
        case GL_IMAGE_1D_ARRAY:
        case GL_IMAGE_2D:
        case GL_IMAGE_2D_ARRAY:
        case GL_IMAGE_2D_RECT:
        case GL_IMAGE_2D_MULTISAMPLE:
        case GL_IMAGE_2D_MULTISAMPLE_ARRAY:
        case GL_IMAGE_3D:
        case GL_IMAGE_CUBE:
        case GL_IMAGE_CUBE_MAP_ARRAY:  
        
        case GL_INT_IMAGE_1D:
        case GL_INT_IMAGE_1D_ARRAY:
        case GL_INT_IMAGE_2D:
        case GL_INT_IMAGE_2D_ARRAY:
        case GL_INT_IMAGE_2D_RECT:
        case GL_INT_IMAGE_2D_MULTISAMPLE:
        case GL_INT_IMAGE_2D_MULTISAMPLE_ARRAY:
        case GL_INT_IMAGE_3D:
        case GL_INT_IMAGE_CUBE:
        case GL_INT_IMAGE_CUBE_MAP_ARRAY:
        
        case GL_UNSIGNED_INT_IMAGE_1D:
        case GL_UNSIGNED_INT_IMAGE_1D_ARRAY:
        case GL_UNSIGNED_INT_IMAGE_2D:
        case GL_UNSIGNED_INT_IMAGE_2D_ARRAY:
        case GL_UNSIGNED_INT_IMAGE_2D_RECT:
        case GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE:
        case GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY:
        case GL_UNSIGNED_INT_IMAGE_3D:
        case GL_UNSIGNED_INT_IMAGE_CUBE:
        case GL_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY:
        
        default:
        case GL_NONE:
          sys::warn << "ogl::CUniform::operator=(const GLvoid*) > Error: Uniform has no type!" << sys::endl;
        break;
      }
      
      return *this;
    }
    
    public:
    void setName(const std::string& name)
    {
      mName = name;
    }
    
    void setProgram(CProgram* oProgram)
    {
      mProgram = oProgram;
    }
    
    void setLocation(GLint location)
    {
      //std::cerr << "ogl::CUniform::setLocation(" << location << ")" << std::end;
      //  sys::info << "> ERROR: Uniform not found or bad name!" << sys::endl;
      //if(location == -1)
      //else  
      mLocation = location;
    }
    
    void setType(GLenum nType)
    {
      mType = nType;
    }
    
    void setTransposed(GLboolean bTransposed)
    {
      mTransposed = bTransposed;
    }
    
    void setNumComponents(GLushort nNumComponents)
    {
      mNumComponents = nNumComponents;
    }
    
    std::string getName() const
    {
      return mName;
    }
    
    CProgram* getProgram() const
    {
      return mProgram;
    }
    
    GLint getLocation() const
    {
      return mLocation;
    }
  
    GLenum getType() const
    {
      return mType;
    }
    
    GLboolean getTransposed() const
    {
      return mTransposed;
    }
  
    GLushort getNumComponents() const 
    {
      return mNumComponents;
    }
  };
  
  class CUniformBuilder : public sys::CBuilder<CUniform>
  {
    protected:
    CProgram* mProgram;
    GLushort  mNumComponents;
    
  };
  
  /*
  GL_BOOL;
  GL_BOOL_VEC2;
  GL_BOOL_VEC3;
  GL_BOOL_VEC4;
  
  GL_INT;
  GL_INT_VEC2;
  GL_INT_VEC3;
  GL_INT_VEC4;
  
  GL_UNSIGNED_INT;
  GL_UNSIGNED_INT_VEC2;
  GL_UNSIGNED_INT_VEC3;
  GL_UNSIGNED_INT_VEC4;
  
  GL_FLOAT;
  GL_FLOAT_VEC2;
  GL_FLOAT_VEC3;
  GL_FLOAT_VEC4;
  GL_FLOAT_MAT2;
  GL_FLOAT_MAT2x3;
  GL_FLOAT_MAT2x4;
  GL_FLOAT_MAT3;
  GL_FLOAT_MAT3x2;
  GL_FLOAT_MAT3x4;
  GL_FLOAT_MAT4x2;
  GL_FLOAT_MAT4x3;  
  
  GL_DOUBLE;
  GL_DOUBLE_VEC2;
  GL_DOUBLE_VEC3;
  GL_DOUBLE_VEC4;
  GL_DOUBLE_MAT2;
  GL_DOUBLE_MAT2x3;
  GL_DOUBLE_MAT2x4;
  GL_DOUBLE_MAT3;
  GL_DOUBLE_MAT3x2;
  GL_DOUBLE_MAT3x4;
  GL_DOUBLE_MAT4x2;
  GL_DOUBLE_MAT4x3;
  
  GL_SAMPLER_1D;                        // FLOAT
  GL_SAMPLER_1D_SHADOW;
  GL_SAMPLER_1D_ARRAY;
  GL_SAMPLER_1D_ARRAY_SHADOW;
  GL_SAMPLER_2D;
  GL_SAMPLER_2D_SHADOW;
  GL_SAMPLER_2D_ARRAY;
  GL_SAMPLER_2D_ARRAY_SHADOW;
  GL_SAMPLER_2D_MULTISAMPLE;
  GL_SAMPLER_2D_MULTISAMPLE_ARRAY;
  GL_SAMPLER_2D_RECT;
  GL_SAMPLER_2D_RECT_SHADOW;
  GL_SAMPLER_3D;
  GL_SAMPLER_CUBE;
  GL_SAMPLER_CUBE_SHADOW;
  GL_SAMPLER_CUBE_MAP_ARRAY;
  GL_SAMPLER_CUBE_MAP_ARRAY_SHADOW;
  GL_SAMPLER_BUFFER;
  
  GL_INT_SAMPLER_1D;
  GL_INT_SAMPLER_1D_ARRAY;
  GL_INT_SAMPLER_2D;
  GL_INT_SAMPLER_2D_ARRAY;
  GL_INT_SAMPLER_2D_MULTISAMPLE;
  GL_INT_SAMPLER_2D_MULTISAMPLE_ARRAY;
  GL_INT_SAMPLER_2D_RECT;
  GL_INT_SAMPLER_3D;
  GL_INT_SAMPLER_CUBE;
  GL_INT_SAMPLER_CUBE_MAP_ARRAY;
  GL_INT_SAMPLER_BUFFER;
  
  GL_UNSIGNED_INT_SAMPLER_1D;
  GL_UNSIGNED_INT_SAMPLER_1D_ARRAY;
  GL_UNSIGNED_INT_SAMPLER_2D;
  GL_UNSIGNED_INT_SAMPLER_2D_ARRAY;
  GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE;
  GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY;
  GL_UNSIGNED_INT_SAMPLER_2D_RECT;
  GL_UNSIGNED_INT_SAMPLER_3D;
  GL_UNSIGNED_INT_SAMPLER_CUBE;
  GL_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY;
  GL_UNSIGNED_INT_SAMPLER_BUFFER;
  
  GL_IMAGE_1D;                      // FLOAT
  GL_IMAGE_1D_ARRAY;
  GL_IMAGE_2D;
  GL_IMAGE_2D_ARRAY;
  GL_IMAGE_2D_RECT;
  GL_IMAGE_2D_MULTISAMPLE;
  GL_IMAGE_2D_MULTISAMPLE_ARRAY;
  GL_IMAGE_3D;
  GL_IMAGE_CUBE;
  GL_IMAGE_CUBE_MAP_ARRAY;  
  
  GL_INT_IMAGE_1D;
  GL_INT_IMAGE_1D_ARRAY;
  GL_INT_IMAGE_2D;
  GL_INT_IMAGE_2D_ARRAY;
  GL_INT_IMAGE_2D_RECT;
  GL_INT_IMAGE_2D_MULTISAMPLE;
  GL_INT_IMAGE_2D_MULTISAMPLE_ARRAY;
  GL_INT_IMAGE_3D;
  GL_INT_IMAGE_CUBE;
  GL_INT_IMAGE_CUBE_MAP_ARRAY;
  
  GL_UNSIGNED_INT_IMAGE_1D;
  GL_UNSIGNED_INT_IMAGE_1D_ARRAY;
  GL_UNSIGNED_INT_IMAGE_2D;
  GL_UNSIGNED_INT_IMAGE_2D_ARRAY;
  GL_UNSIGNED_INT_IMAGE_2D_RECT;
  GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE;
  GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY;
  GL_UNSIGNED_INT_IMAGE_3D;
  GL_UNSIGNED_INT_IMAGE_CUBE;
  GL_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY;
  
  GL_NONE;
  GL_UNDEFINED = GL_NONE;
  */
}

#endif // __cuniform_hpp__
