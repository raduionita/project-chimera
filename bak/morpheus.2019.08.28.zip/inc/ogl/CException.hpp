#ifndef __cexception_hpp__
#define __cexception_hpp__

#include <exception>
#include <string>
#include <iostream>

namespace ogl
{
  class CException : public sys::CException
  {
    public:
    CException() : sys::CException()
    {
    
    }
    
    CException(const std::string& message) : sys::CException(message)
    {
      
    }
    
    CException(const std::string& message, const std::string& file, size_t line) : sys::CException(message, file, line)
    {
      
    }
    
    CException(const std::string& file, size_t line) : sys::CException(file, line)
    {
      
    }
    
  };
}

#endif // __cexception_hpp__
