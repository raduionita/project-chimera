#ifndef __OGL_CBMPTEXTUREBUILDER_HPP__
#define __OGL_CBMPTEXTUREBUILDER_HPP__

namespace ogl
{
  class CBmpTextureBuilder : CTextureBuilder
  {
    public:
    CBmpTextureBuilder() : CTextureBuilder()
    {
      sys::info << "ogl::CBmpTextureBuilder::CBmpTextureBuilder()" << sys::endl;
    }
    
    virtual ~CBmpTextureBuilder()
    {
      sys::info << "ogl::CBmpTextureBuilder::~CBmpTextureBuilder()" << sys::endl;
    }
  
    protected:
    std::string mFile;
    
    public:
    void setFile(const std::string& file)
    {
      mFile.clear();
      mFile.append(TEXTUREPATH).append(file);
    }
    
    CTexture* build()
    {
      sys::info << "ogl::CBmpTextureBuilder::build() " << sys::endl;
      
//  GLubyte  header[54];             // .bmp begins with 54 byte header
//  GLuint   pos;                    // position of data in the file
//  GLuint   width, height;
//  GLuint   size;                   // width * height * 3
//  GLubyte* data;                   // data
//  
//  FILE* file = fopen(filepath, "rb");
//  if(file == NULL) { fprintf(stderr, "File reading error."); return 0; }
//  
//  // header = 54 bytes
//  if(fread(header, 1, 54, file) != 54) { fprintf(stderr, "Not BMP format."); fclose(file); return 0; }
//  
//  // header begins with BM
//  if(header[0] != 'B' || header[1] != 'M') { fprintf(stderr, "Not BMP format."); fclose(file); return 0; }
//  
//  pos    = *(int*)&(header[0x0A]);
//  size   = *(int*)&(header[0x22]);
//  width  = *(int*)&(header[0x12]);
//  height = *(int*)&(header[0x16]);
//  
//  if(size == 0) size = width * height * 3;  // r + g + b = 3 bytes
//  if(pos  == 0) pos  = 54;                  // data comes after the header
//  
//  data = new GLubyte[size];
//  fread(data, 1, size, file);
//  
//  fclose(file);                             // done
//  
//  GLuint tex;                               // create OpenGL texture
//  glGenTextures(1, &tex);
//  glBindTexture(GL_TEXTURE_2D, tex);        // make texture active
//  
//  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data); // load data
//  
//  delete [] data;                           // done with data
//  
//  // trilinear filtering
//  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); 
//  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); 
//  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);               // if >= max: use Linear 
//  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); // if < max : blend mipmaps linear
//  glGenerateMipmap(GL_TEXTURE_2D);
//  
//  glBindTexture(GL_TEXTURE_2D, 0);
    
      return nullptr;
    }  
  };
}

#endif // __OGL_CBMPTEXTUREBUILDER_HPP__
