#ifndef __ogl_CANIMATIONBUILDER_HPP__
#define __ogl_CANIMATIONBUILDER_HPP__

namespace ogl
{
  class CAnimationBuilder
  {
    public:
    static constexpr GLbitfield NONE       = 0x0000;
    static constexpr GLbitfield NORMALIZED = 0x0020;
    
    protected:
    GLbitfield mOptions;
    
    public:
    CAnimationBuilder() : mOptions(NONE)
    {
    
    }
    
    virtual ~CAnimationBuilder()
    {
      
    }
    
    public:
    virtual void setOptions(GLbitfield options)
    {
      mOptions = options;
    }
    
    virtual void addOption(GLbitfield option)
    {
      mOptions |= option;
    }
    
    virtual bool hasOption(GLbitfield options)
    {
      return mOptions & options;
    }
    
    
    public:
    virtual CAnimation* build() = 0;
  };
}

#endif // __ogl_CANIMATIONBUILDER_HPP__
