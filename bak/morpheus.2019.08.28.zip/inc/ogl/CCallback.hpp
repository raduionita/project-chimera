#ifndef __ogl_ccallback_hpp__
#define __ogl_ccallback_hpp__

namespace ogl
{
  template <typename T>
  class CCallback
  {
    protected:
    T mCallback;
    
    public:
    CCallback()
    {
    
    }
    
    CCallback(T callback)
    {
      mCallback = callback;
    }
    
    CCallback(const CCallback& that)
    {
      mCallback = that.mCallback;
    }
    
    virtual ~CCallback()
    {
      
    }
    
    CCallback& operator = (const CCallback& that)
    {
      if(this != &that)
      {
        mCallback = that.mCallback;
      }
      return *this;
    }
    
    void operator () ()
    {
      sys::info << "ogl::CCallback::operator()" << sys::endl;
    }
  };
}

#endif // __ogl_ccallback_hpp__
