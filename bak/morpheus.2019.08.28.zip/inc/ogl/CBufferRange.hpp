#ifndef __cbufferrange_hpp__
#define __cbufferrange_hpp__

namespace ogl
{
  class CBufferRange
  {
    protected:
    GLuint mPosition;
    GLuint mLength;
    GLenum mType;
    
    public:
    CBufferRange() : mPosition(0), mLength(0), mType(GL_NONE)
    {
    
    }
    
    CBufferRange(GLuint position, GLuint length, GLenum type) : mPosition(position), mLength(length), mType(type)
    {
    
    }
    
    CBufferRange(const CBufferRange& that)
    {
      mPosition = that.mPosition;
      mLength   = that.mLength;
      mType     = that.mType;
    }
    
    virtual ~CBufferRange()
    {
    
    }
    
    CBufferRange& operator = (const CBufferRange& that)
    {
      if(this != &that)
      {
        mPosition = that.mPosition;
        mLength   = that.mLength;
        mType     = that.mType;
      }
      return *this;
    }
    
    public:
    GLuint getPosition() const
    {
      return mPosition;
    }
    
    GLuint getLength() const
    {
      return mLength;
    }
    
    GLuint getType() const
    {
      return mType;
    }
  
    void setPosition(GLuint nPosition)
    {
      mPosition = nPosition;
    }
    
    void setLength(GLuint nLength)
    {
      mLength = nLength;
    }
    
    void setType(GLuint type)
    {
      mType = type;
    }
  };
}

#endif // __cbufferrange_hpp__
