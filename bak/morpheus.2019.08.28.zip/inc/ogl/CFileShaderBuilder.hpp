#ifndef __cfileshaderbuilder_hpp__
#define __cfileshaderbuilder_hpp__

#include <cstdio>
#include <string>
#include <exception>

#include "CShader.hpp"
#include "CShaderBuilder.hpp"
#include "CSourceShaderBuilder.hpp"

namespace ogl
{
  class CFileShaderBuilder : public CShaderBuilder
  {
    protected:
    std::string mFile;
    
    public:
    CFileShaderBuilder() : CShaderBuilder()
    {
      sys::info << "ogl::CFileShaderBuilder::CFileShaderBuilder()" << sys::endl;
    }
    
    virtual ~CFileShaderBuilder()
    {
      sys::info << "ogl::CFileShaderBuilder::~CFileShaderBuilder()" << sys::endl;
    }
    
    public:
    CShader* build()
    {
      sys::info << "ogl::CFileShaderBuilder::build() > " << mFile << sys::endl;
      
      if(mType == GL_NONE)
        throw EXCEPTION << "Type not defined!";
      //  CErrorManager::triggerError(EErrorType::FATAL, "ogl::CFileShaderBuilder::build() > Type not defined!");
      if(mFile.empty())
        throw EXCEPTION << "Source file not defined!";
      //  CErrorManager::triggerError(EErrorType::FATAL, "ogl::CFileShaderBuilder::build() > Source file not defined!");

      FILE* fp = fopen(mFile.c_str(), "rb");
      
      if(fp == NULL)
      {
        // triggerError()
        throw EXCEPTION << "Cannot open file: " << mFile.c_str() << ".";
        // return pShader;
      }
      
      fseek(fp, 0, SEEK_END);
      size_t length = ftell(fp);
      rewind(fp);
      
      char* data = new char[length + 1];
      
      if(data == nullptr)
      {
        // triggerError()
        fclose(fp);
        delete data;
        throw EXCEPTION << "Memory allocation error.";
        // return pShader;
      }
      
      size_t result = fread(data, 1, length, fp);
      
      if(result != length)
      {
        // triggerError()
        fclose(fp);
        delete data;
        throw EXCEPTION << "Reading error for file.";
        // return pShader;
      }
    
      data[length] = '\0';
      fclose(fp);
      
      CSourceShaderBuilder* pBuilder = new CSourceShaderBuilder;
      pBuilder->setSource(data);
      pBuilder->setType(mType);
      CShader* pShader = pBuilder->build();
      
      delete data;
      delete pBuilder;
      
      mType = GL_NONE;
      mFile.clear();
      
      return pShader;
    }
    
    void setFile(const std::string& file)
    {
      mFile.clear();
      mFile.append(SHADERPATH);
      mFile.append(file);
    }
  };
}

#endif // __cfileshaderbuilder_hpp__
