#ifndef __cassimpobjectbuilder_hpp__
#define __cassimpobjectbuilder_hpp__

#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

#include <vector>
#include <map>
#include <cassert>

#define NUM_BONES_PER_VERTEX 4

namespace ogl
{
  class CAssimpObjectBuilder : public CObjectBuilder
  {
    protected:
    typedef struct {
      float x;
      float y;
    } vec2_t;
    typedef struct {
      float x;
      float y;
      float z;
    } vec3_t;
    typedef struct {
      vec3_t position;
      vec2_t texcoord;
      vec3_t normal;
    } vertex_t;
    typedef struct {
      uint ids[NUM_BONES_PER_VERTEX];
      uint weights[NUM_BONES_PER_VERTEX];
    } bone_t; // vertex_bone_data_t

    protected:
    std::string mFile;
  
    public:
    CObject* build()
    {
      sys::info << "ogl::CAssimpObjectBuilder::build()" << sys::endl;
      
      // clear textures?
      
      CObject* pObject = new CObject;
      
      Assimp::Importer importer;
      const aiScene* paiScene = importer.ReadFile(mFile.c_str(), aiProcess_Triangulate | aiProcess_GenNormals | aiProcess_GenSmoothNormals | aiProcess_FlipUVs | aiProcess_CalcTangentSpace);
      
      if(!paiScene) 
      {
        sys::info << "> ERROR: Error parsing. " << importer.GetErrorString() << sys::endl;
        throw CException(importer.GetErrorString());
      }
      
      // bones
      // mGlobalInverseTransform = paiScene->mRootNode->mTransformation.Inverse();
      
      sys::info << sys::tab << "filepath: " << mFile << sys::endl;
      
      //pObject->mShapes.resize(paiScene->mNumMeshes);
      
      //mTextures.resize(paiScene->mNumMaterials);
      
      std::vector<ushort>      indices;
      std::vector<math::vec3>  positions;
      std::vector<math::vec2>  texcoords;
      std::vector<math::vec3>  normals;
      std::vector<math::vec3>  tangents;
      std::vector<math::ivec4> boneids;
      std::vector<math::vec4>  boneweights;

      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      sys::info << sys::tab << "mNumMeshes:    " << paiScene->mNumMeshes << sys::endl;
      sys::info << sys::tab << "mNumMaterials: " << paiScene->mNumMaterials << sys::endl;
      sys::info << sys::tab << "mNumTextures:  " << paiScene->mNumTextures << sys::endl;
      
//      pObject->mNumBones = 0;
      
      CDdsTextureBuilder* pTextureBuilder = new CDdsTextureBuilder;
      uint nNumTextureTypes = (uint)(CTexture::EScope::GENERIC);
      std::string texpath;
      std::string subpath = mFile.substr(0, mFile.find_last_of('/') + 1).substr(strlen(MODELPATH));
      const aiVector3D zero3d(0.0f, 0.0f, 0.0f);
      GLuint nVertexStart  = 0;
      GLuint nIndicesStart = 0;
      GLuint nVertexEnd    = 0;
      GLuint nIndicesEnd   = 0;
      float  fMax          = 0.0f;
      for(size_t i = 0, l = paiScene->mNumMeshes; i < l; ++i)
      {
        const aiMesh* paiMesh = paiScene->mMeshes[i];
        CShape* pShape    = new CShape;
        pShape->mMaterial = new CMaterial;
        
        sys::info << sys::tab << "mMaterialIndex: " << paiMesh->mMaterialIndex << sys::endl;
        
        const aiMaterial* paiMaterial = paiScene->mMaterials[paiMesh->mMaterialIndex];
        
        for(uint j = 0; j < nNumTextureTypes; j++)
        {
          CTexture::EScope eTextureType = (CTexture::EScope)(j);
        
          // 0x0 = aiTextureType_NONE
          // 0x1 = aiTextureType_DIFFUSE
          // 0x5 = aiTextureType_HEIGHT
          if(paiMaterial->GetTextureCount((aiTextureType)(eTextureType)) > 0) // load diffuse map
          {
            aiString file;
            if(paiMaterial->GetTexture((aiTextureType)(eTextureType), 0, &file, NULL, NULL, NULL, NULL, NULL) == AI_SUCCESS)
            {
              texpath.clear();
              texpath.append(subpath);
              texpath.append(file.data);
              texpath = texpath.substr(0, texpath.find_last_of('.')).append(".dds");
              pTextureBuilder->setFile(texpath);
              
              pShape->mMaterial->setTexture((ogl::CTexture::EScope)(eTextureType), pTextureBuilder->build());
            }
          }
        }
        
        for(size_t j = 0; j < paiMesh->mNumVertices; ++j)
        {
          const aiVector3D* pPosition = &(paiMesh->mVertices[j]);
          const aiVector3D* pNormal   = &(paiMesh->mNormals[j]);
          const aiVector3D* pTexcoord = paiMesh->HasTextureCoords(0) ? &(paiMesh->mTextureCoords[0][j]) : &zero3d;
          const aiVector3D* pTangent  = paiMesh->HasTextureCoords(0) ? &paiMesh->mTangents[j] : &zero3d;
          
          CVertex v;
          
          positions.push_back(math::vec3(pPosition->x, pPosition->y, pPosition->z));
          texcoords.push_back(math::vec2(pTexcoord->x, pTexcoord->y));
          normals.push_back(math::vec3(pNormal->x, pNormal->y, pNormal->z));
          tangents.push_back(math::vec3(pTangent->x, pTangent->y, pTangent->z));
          
          fMax = fMax >= std::abs(positions.back().x) ? fMax : std::abs(positions.back().x);
          fMax = fMax >= std::abs(positions.back().y) ? fMax : std::abs(positions.back().y);
          fMax = fMax >= std::abs(positions.back().z) ? fMax : std::abs(positions.back().z);
          
          //sys::info << "[" << j << "] " << v.mPosition.x << " " << v.mPosition.y << " " << v.mPosition.z << sys::endl;
        }
        nVertexEnd  = positions.size();
        
//        // load bones
//        for(size_t j = 0; j < paiMesh->mNumBones; ++j)
//        {
//          size_t      boneIndex = 0;
//          std::string boneName(paiMesh->mBones[i]->mName.data);
//          
//          if(pObject->mBoneMap.find(boneName) == pObject->mBoneMap.end()) // if new bone
//          {
//            // allocate index for new bone
//            boneIndex = pObject->mNumBones;
//            pObject->mNumBones++;
//            CObject::bone_t bone;
//            bone.mOffsetMatrix = toMatrix(paiMesh->mBones[i]->mOffsetMatrix);
//            pObject->mBones[boneIndex] = bone;
//            pObject->mBoneMap[boneName] = boneIndex;
//          }
//          else
//          {
//            boneIndex = pObject->mBoneMap[boneName];
//          }
//          
//          for(size_t k = 0; k < paiMesh->mBones[i]->mNumWeights; ++k)
//          {
//            size_t vertexId = nVertexStart + paiMesh->mBones[j]->mWeights[k].mVertexId;
//            float weight = paiMesh->mBones[j]->mWeights[k].mWeight;
//            addBoneData(vertices[vertexId], boneIndex, weight);
//          }
//          
//          // add bone data to vertexID -> boneIndex, weight
//        } // end load bones
        
        //sys::info << "paiMesh->mNumFaces: " << paiMesh->mNumFaces << sys::endl;
        
        for(size_t j = 0; j < paiMesh->mNumFaces; ++j)
        {
          const aiFace& face = paiMesh->mFaces[j];
          assert(face.mNumIndices == 3);
          indices.push_back(face.mIndices[0]);
          indices.push_back(face.mIndices[1]);
          indices.push_back(face.mIndices[2]);
          
          // sys::info << "[" << j << "] " << face.mIndices[0] << " " << face.mIndices[1] << " " << face.mIndices[2] << sys::endl;
        }
        nIndicesEnd = indices.size();
        
        pShape->setVertexBufferRange(CBufferRange(nVertexStart, nVertexEnd - nVertexStart,   GL_FLOAT));
        pShape->setIndexBufferRange(CBufferRange(nIndicesStart, nIndicesEnd - nIndicesStart, GL_UNSIGNED_SHORT));
        
        nVertexStart  = nVertexEnd;
        nIndicesStart = nIndicesEnd;
        
        pObject->addShape(pShape);
      }
      delete pTextureBuilder;
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
//      // load nodes
//      buildNodes(pObject->mRootNode, paiScene->mRootNode);
//      
//      // load/create animations
//      for(size_t i = 0; i < paiScene->mNumAnimations; ++i)
//      {
//        CObject::animation_t anim;
//        anim.duration = paiScene->mAnimations[i]->mDuration;
//        for(size_t j = 0; j < paiScene->mAnimations[i]->mNumChannels; ++j)
//        {
//          CObject::channel_t channnel;
//          channnel.name = std::string(paiScene->mAnimations[i]->mChannels[j]->mNodeName.data);
//          for(size_t k = 0; k < paiScene->mAnimations[i]->mChannels[j]->mNumPositionKeys; ++k)
//          {
//            CObject::vkey_t key;
//            key.time = paiScene->mAnimations[i]->mChannels[j]->mPositionKeys[k].mTime;
//            key.value.x = paiScene->mAnimations[i]->mChannels[j]->mPositionKeys[k].mValue.x;
//            key.value.y = paiScene->mAnimations[i]->mChannels[j]->mPositionKeys[k].mValue.y;
//            key.value.z = paiScene->mAnimations[i]->mChannels[j]->mPositionKeys[k].mValue.z;
//            channnel.positions.push_back(key);
//          }
//          for(size_t k = 0; k < paiScene->mAnimations[i]->mChannels[j]->mNumRotationKeys; ++k)
//          {
//            CObject::qkey_t key;
//            key.time = paiScene->mAnimations[i]->mChannels[j]->mRotationKeys[k].mTime;
//            key.value.w = paiScene->mAnimations[i]->mChannels[j]->mRotationKeys[k].mValue.w;
//            key.value.x = paiScene->mAnimations[i]->mChannels[j]->mRotationKeys[k].mValue.x;
//            key.value.y = paiScene->mAnimations[i]->mChannels[j]->mRotationKeys[k].mValue.y;
//            key.value.z = paiScene->mAnimations[i]->mChannels[j]->mRotationKeys[k].mValue.z;
//            channnel.rotations.push_back(key);
//          }
//          channnel.name = std::string(paiScene->mAnimations[i]->mChannels[j]->mNodeName.data);
//          for(size_t k = 0; k < paiScene->mAnimations[i]->mChannels[j]->mNumPositionKeys; ++k)
//          {
//            CObject::vkey_t key;
//            key.time = paiScene->mAnimations[i]->mChannels[j]->mScalingKeys[k].mTime;
//            key.value.x = paiScene->mAnimations[i]->mChannels[j]->mScalingKeys[k].mValue.x;
//            key.value.y = paiScene->mAnimations[i]->mChannels[j]->mScalingKeys[k].mValue.y;
//            key.value.z = paiScene->mAnimations[i]->mChannels[j]->mScalingKeys[k].mValue.z;
//            channnel.scalings.push_back(key);
//          }
//          anim.channels.push_back(channnel);
//        }
//      }
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      if(hasOption(CObjectBuilder::NORMALIZED) && fMax > 0.0f)
      {
        sys::info << sys::tab << "Normalizing... fMax: " << fMax << sys::endl;
        for(size_t i = 0, l = positions.size(); i < l; i++)
        {
          positions[i].x /= fMax;
          positions[i].y /= fMax;
          positions[i].z /= fMax;
        }
      }
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      pObject->setDrawStrategy(mDrawStrategy == nullptr ? new CDrawStrategy : mDrawStrategy);
      
      // set opengl stuff ////////////////////////////////////////////////////////////////////////////////////////////
      
      pObject->mNumVertices = nVertexEnd;
      pObject->mNumIndices  = nIndicesEnd;
      
      sys::info << sys::tab << "mNumIndices:  " << pObject->mNumIndices << sys::endl;
      sys::info << sys::tab << "mNumVertices: " << pObject->mNumVertices << sys::endl;
      
      //pObject->mBuffers[INDEX_BUFFER_INDEX] = CBuffer(GL_ELEMENT_ARRAY_BUFFER, pObject->mNumIndices * sizeof(ushort), GL_STATIC_DRAW);
      
      glGenBuffers(1, &(pObject->mBuffers[INDEX_BUFFER_INDEX]));
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pObject->mBuffers[INDEX_BUFFER_INDEX]);
      glBufferData(GL_ELEMENT_ARRAY_BUFFER, pObject->mNumIndices * sizeof(ushort), &indices[0], GL_STATIC_DRAW);
      
      glGenVertexArrays(1, &(pObject->mVAO));
      glBindVertexArray(pObject->mVAO);
      
      glGenBuffers(1, &(pObject->mBuffers[POSITION_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[POSITION_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), &positions[0], GL_STATIC_DRAW);
      
      glVertexAttribPointer(POSITION_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (GLvoid*)((0) * sizeof(GLfloat)));             // 0
      glEnableVertexAttribArray(POSITION_ATTRIBUTE); // positions
      
      glGenBuffers(1, &(pObject->mBuffers[TEXCOORD_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[TEXCOORD_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec2), &texcoords[0], GL_STATIC_DRAW);
      
      glVertexAttribPointer(TEXCOORD_ATTRIBUTE, 2, GL_FLOAT, GL_FALSE, sizeof(math::vec2), (GLvoid*)((0) * sizeof(GLfloat)));         // 1
      glEnableVertexAttribArray(TEXCOORD_ATTRIBUTE); // texcoords

      glGenBuffers(1, &(pObject->mBuffers[NORMAL_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[NORMAL_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), &normals[0], GL_STATIC_DRAW);
      
      glVertexAttribPointer(NORMAL_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (GLvoid*)((0) * sizeof(GLfloat)));       // 2
      glEnableVertexAttribArray(NORMAL_ATTRIBUTE);   // normals
      
      glGenBuffers(1, &(pObject->mBuffers[TANGENT_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[TANGENT_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), &tangents[0], GL_STATIC_DRAW);
      
      glVertexAttribPointer(TANGENT_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (GLvoid*)((0) * sizeof(GLfloat)));  // 3
      glEnableVertexAttribArray(TANGENT_ATTRIBUTE);  // tangents
      
      glGenBuffers(1, &(pObject->mBuffers[BONE_ID_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[BONE_ID_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::ivec4), &boneids[0], GL_STATIC_DRAW);
      
      glVertexAttribIPointer(BONE_ID_ATTRIBUTE, 4, GL_INT, sizeof(math::ivec4), (GLvoid*)((0) * sizeof(GLfloat)));
      glEnableVertexAttribArray(BONE_ID_ATTRIBUTE);  // bone ids
      
      glGenBuffers(1, &(pObject->mBuffers[BONE_WEIGHT_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[BONE_WEIGHT_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, pObject->mNumVertices * sizeof(math::vec3), &boneweights[0], GL_STATIC_DRAW);
      
      glVertexAttribPointer(BONE_WEIGHT_ATTRIBUTE, 4, GL_FLOAT, GL_FALSE, sizeof(math::vec4), (GLvoid*)((0) * sizeof(GLfloat)));
      glEnableVertexAttribArray(BONE_WEIGHT_ATTRIBUTE);  // bone weights
      
      glBindBuffer(GL_ARRAY_BUFFER, 0);
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
      glBindVertexArray(0);
      
      glExitIfError();
      
      return pObject;
    }

    void setFile(const std::string& file)
    {
      mFile.clear(); 
      mFile.append(MODELPATH).append(file);
    }
  
    protected:
    void addBoneData(CVertex& vertex, uint id, float weight) // find free slopt in bone_t structure
    {
      for(uint i = 0; i < MAX_BONES_PER_VERTEX; ++i)
      {
        if(vertex.mBoneWeights[i] == 0.0)
        {
          vertex.mBoneIds[i]     = id;
          vertex.mBoneWeights[i] = weight;
          return;
        }
      }
      
      assert(0); // should never get here - more bones that there is space for
    }
    
//    void buildNodes(CObject::node_t* dst, aiNode* src)
//    {
//      
//    }
  
    math::mat4 toMatrix(const aiMatrix4x4& m)
    {
      return math::mat4(
        math::vec4(m.a1, m.a2, m.a3, m.a4),
        math::vec4(m.b1, m.b2, m.b3, m.b4),
        math::vec4(m.c1, m.c2, m.c3, m.c4),
        math::vec4(m.d1, m.d2, m.d3, m.d4)
      );
    }
  };
}

#endif // __cassimpobjectbuilder_hpp__





























