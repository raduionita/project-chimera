#ifndef __ogl_CTRANSFORMHISTORY_HPP__
#define __ogl_CTRANSFORMHISTORY_HPP__

#include <map>

namespace ogl
{
  class CObject;

  class CTransform
  {
    public:
    math::vec3 mScale;
    math::quat mOrientation;
    math::vec3 mPosition;
    
    public:
    CTransform()
    {
    
    }
    
    CTransform(const math::vec3& scale, const math::quat& orientation, const math::vec3& position)
    : mScale(scale), mOrientation(orientation), mPosition(position)
    {
    
    }
    
    virtual ~CTransform()
    {
    
    }
    
    CTransform(const CTransform& that)
    {
      mScale       = that.mScale;
      mOrientation = that.mOrientation;
      mPosition    = that.mPosition;
    }
    
    CTransform& operator = (const CTransform& that)
    {
      if(this != &that)
      {
        mScale       = that.mScale;
        mOrientation = that.mOrientation;
        mPosition    = that.mPosition;
      }
      return *this;
    }
  
    public:
    math::mat4 getModelMatrix() const
    {
      return math::translate(mPosition) * math::toMatrix(mOrientation) * math::scale(mScale);
    }
  };
  
  class CTransformable
  {
    public:
    CTransform mTransform;
  };

  class CTransformHistory : public sys::CSingleton<CTransformHistory>
  {
    friend class sys::CSingleton<CTransformHistory>;
  
    protected:
    std::map<CObject*, CTransform> mTransforms; // TODO: replace CObject with CTransformable
    
    public:
    CTransform get(CObject* pObject) const
    {
      assert(pObject != nullptr);
      auto it = mTransforms.find(pObject);
      if(it == mTransforms.end())
        return CTransform();
      return it->second;
    }
    
    void set(CObject* pObject, const CTransform& oTransform)
    {
      mTransforms[pObject] = oTransform;
    }
  };
}

#endif // __ogl_CTRANSFORMHISTORY_HPP__
