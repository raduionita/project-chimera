#ifndef __ogl_cshadingtechique_hpp__
#define __ogl_cshadingtechique_hpp__

class CShadingTechnique
{
  //TODO this should replace probram callbacks
};

#endif // __ogl_cshadingtechique_hpp__
