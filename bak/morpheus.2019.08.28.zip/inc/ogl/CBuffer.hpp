#ifndef __cbuffer_hpp__
#define __cbuffer_hpp__

// array buffer
// element buffer
// texture buffer
// uniform buffer

namespace ogl
{
  class CBuffer
  {
    protected:
    GLuint mBuffer;
    
    public:
    CBuffer()
    {
      
    }
    
    public:
    operator GLuint() const
    {
      return mBuffer;
    }
    
    operator GLuint() 
    {
      return mBuffer;
    }
  };
}

#endif // __cbuffer_hpp__
