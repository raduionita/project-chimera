#ifndef __cspotlight_hpp__
#define __cspotlight_hpp__

namespace ogl
{
  class CSpotLight : public CPointLight
  {
    public:
    math::vec3 mDirection;
    float      mCutoff;
    
    public:
    CSpotLight() : CPointLight(), mDirection(math::Z), mCutoff(0.9f)
    {
      mType = CLight::SPOT;
    
      float vertices[] = {
        -0.25f, 0.0f,   0.0f, 
         0.25f, 0.0f,   0.0f, 
          0.0f,-0.25f,  0.0f, 
          0.0f, 0.25f,  0.0f, 
          0.0f,  0.0f,-0.25f, 
          0.0f,  0.0f, 0.25f };
         
      glGenBuffers(1, &mVBO);
      glBindBuffer(GL_ARRAY_BUFFER, mVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
      
      glGenVertexArrays(1, &mVAO);
      glBindVertexArray(mVAO);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)((0) * sizeof(GLfloat)));
      glEnableVertexAttribArray(0);
    }
    
    public:
    void setDirection(const math::vec3& direction)
    {
      mDirection = direction;
    }
    
    math::vec3 getDirection() const
    {
      return mDirection;
    }
  };
}

#endif // __cspotlight_hpp__
