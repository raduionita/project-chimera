#ifndef __cshader_hpp__
#define __cshader_hpp__

namespace ogl
{
  class CShader
  {
    public:
    enum EType
    {
      NONE            = GL_NONE,
      VERTEX          = GL_VERTEX_SHADER,
      GEOMETRY        = GL_GEOMETRY_SHADER,
      TESS_CONTROL    = GL_TESS_CONTROL_SHADER,
      TESS_EVALUATION = GL_TESS_EVALUATION_SHADER,
      FRAGMENT        = GL_FRAGMENT_SHADER
    };
  
    protected:
    GLenum mType;
    GLuint mShader;
    
    public:
    CShader() : mType(GL_NONE), mShader(GL_ZERO)
    {
      
    }
    
    CShader(GLuint shader) : mType(GL_NONE), mShader(shader)
    {
    
    }
    
    CShader(GLenum type, GLuint shader) : mType(type), mShader(shader)
    {
    
    }
    
    CShader(const CShader& that)
    {
      mType   = that.mType;
      mShader = that.mShader;
    }
    
    virtual ~CShader()
    {
      glDeleteShader(mShader);
    }
    
    CShader& operator = (const CShader& that)
    {
      if(this != &that)
      {
        mType   = that.mType;
        mShader = that.mShader;
      }
      return *this;
    }
    
    operator GLuint ()
    {
      return mShader;
    }
    
    public:
    void setShader(GLuint shader)
    {
      mShader = shader;
    }
    
    void setType(GLuint type)
    {
      mType = type;
    }
    
    GLuint getType() const
    {
      return mType;
    }
  };
}

#endif // __cshader_hpp__
