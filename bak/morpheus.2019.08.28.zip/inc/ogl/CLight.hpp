#ifndef __clight_hpp__
#define __clight_hpp__

namespace ogl
{
  class CLight : public CDrawable
  {
    public:
    static constexpr ushort POINT  = 1;
    static constexpr ushort DIRECT = 2;
    static constexpr ushort SPOT   = 3;
    
    public:
    ushort      mType;
    math::vec3  mColor;
    float       mAmbientIntensity;
    float       mDiffuseIntensity;
    
    GLuint mVAO;
    GLuint mVBO;
    
    public:
    CLight() : mType(0), mColor(1.0f), mAmbientIntensity(0.0f), mDiffuseIntensity(0.0f)
    {

    }
    
    CLight(ushort type) : mType(type), mColor(1.0f), mAmbientIntensity(0.0f), mDiffuseIntensity(0.0f)
    {

    }
    
    virtual ~CLight()
    {
      glDeleteBuffers(1, &mVBO);
      glDeleteVertexArrays(1, &mVAO);
    }
    
    public:
    virtual math::mat4 getM()
    {
      return math::translate(0.0f, 1.0f, 0.0f);
    }
    
    virtual ushort getType() const
    {
      return mType;
    }
    
    virtual void setType(ushort type)
    {
      mType = type;
    }
    
    //virtual CShadow getShadow()
    //{
    //  return CShadowManager::getInstance()->getShadow(this);
    //}
    
    virtual void draw()
    {
      glBindVertexArray(mVAO);
      glBindBuffer(GL_ARRAY_BUFFER, mVBO);
      
      glEnable(GL_POLYGON_OFFSET_LINE);
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
      glLineWidth(2.0f);
      
      bool bDepthTest = glIsEnabled(GL_DEPTH_TEST);
      bool bStencilTest = glIsEnabled(GL_STENCIL_TEST);
      if(bDepthTest)
        glDisable(GL_DEPTH_TEST);
      if(bStencilTest)  
        glDisable(GL_STENCIL_TEST);
        
      glDrawArrays(GL_LINES, 0, 6);
      
      if(bDepthTest)
        glEnable(GL_DEPTH_TEST);
      if(bStencilTest)  
        glEnable(GL_STENCIL_TEST);

      glBindVertexArray(0);
      
      glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
      glDisable(GL_POLYGON_OFFSET_LINE);
    }
    
    virtual CDrawCommand* getDrawCommand() = 0;
    
    friend sys::CLogger& operator << (sys::CLogger& out, const CLight& oLight);
  };
  
  sys::CLogger& operator << (sys::CLogger& out, const CLight& oLight)
  {
    out << "ogl::CLight: " << sys::endl;
    out << sys::tab << "mColor           : " << oLight.mColor << sys::endl;
    out << sys::tab << "mAmbientIntensity: " << oLight.mAmbientIntensity << sys::endl;
    out << sys::tab << "mDiffuseIntensity: " << oLight.mDiffuseIntensity;
    return out;
  }
}

#endif // __clight_hpp__
