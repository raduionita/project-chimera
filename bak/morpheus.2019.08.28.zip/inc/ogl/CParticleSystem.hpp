#ifndef __cparticlesystem_hpp__
#define __cparticlesystem_hpp__

namespace ogl
{
  class CParticleSystem
  {
    protected:
    uint mNumParticles;
    
    CProgram*  mUpdateProgram;
    CProgram*  mRenderProgram;
    
    math::vec3 mPosition;
    math::mat4 mViewMatrix;
    math::mat4 mProjectionMatrix;
    math::vec3 mCameraPosition;
    
    GLuint mVBOs[2];
    GLuint mTBOs[2];
    GLuint mVAOs[2];
    
    GLuint mActiveVBO;
    GLuint mActiveTBO;
    
    CTexture*  mRandomTexture;
    CTexture*  mDiffuseTexture;
    
    int mTime;
    
    bool mInit;
    bool mFirst;
    
    public:
    CParticleSystem() : mInit(false)
    {
      sys::info << "ogl::CParticleSystem::CParticleSystem()" << sys::endl;
    }
    
    virtual ~CParticleSystem()
    {
      sys::info << "ogl::CParticleSystem::~CParticleSystem()" << sys::endl;
      
      _DELETE(mRandomTexture);
      _DELETE(mDiffuseTexture);
      
      _DELETE(mUpdateProgram);
      _DELETE(mRenderProgram);
      
      glDeleteTransformFeedbacks(2, mTBOs);
      glDeleteBuffers(2, mVBOs);
    }
    
    public:
    bool init()
    {
      sys::info << "ogl::CParticleSystem::init()" << sys::endl;
      
      mFirst     = true;
      mInit      = true;
      mActiveVBO = 0;
      mActiveTBO = 1;
      mTime      = 0;
      mPosition  = math::vec3(0.0f, 0.0f, 0.0f);
      
      _ZEROMEM(mVBOs);
      _ZEROMEM(mTBOs);
      _ZEROMEM(mVAOs);
      
      CParticle particles[mNumParticles];
      _ZEROMEM(particles);
      
      particles[0].mType     = CParticle::LAUNCHER;
      particles[0].mPosition = mPosition;
      particles[0].mVelocity = math::vec3(0.0f, 0.0001f, 0.0f);
      particles[0].mLifetime = 0.0f;
      
      glGenTransformFeedbacks(2, mTBOs);
      glGenBuffers(2, mVBOs);
      
      for(short i = 0; i < 2; i++)
      {
        glBindTransformFeedback(GL_TRANSFORM_FEEDBACK, mTBOs[i]);
        glBindBuffer(GL_ARRAY_BUFFER, mVBOs[i]);
        glBufferData(GL_ARRAY_BUFFER, sizeof(particles), particles, GL_DYNAMIC_DRAW);
        glBindBufferBase(GL_TRANSFORM_FEEDBACK_BUFFER, 0, mVBOs[i]);
      }
      
      mUpdateProgram->enable();
      mUpdateProgram->setUniform("u_fLauncherLifetime",    100.0f);
      mUpdateProgram->setUniform("u_fPrimaryLifetime",    1000.0f);
      mUpdateProgram->setUniform("u_fSecondaryLifetime",  2500.0f);
      mUpdateProgram->setUniform("u_fTertiaryLifetime",   1500.0f);
      
      mRenderProgram->enable();
      mRenderProgram->setUniform("u_fBillboardSize", 0.1f);
      
      glGenVertexArrays(2, mVAOs);
      glBindVertexArray(mVAOs[0]);
      glVertexAttribPointer(0, 1, GL_FLOAT, GL_FALSE, sizeof(CParticle), (const GLvoid*)((0) * sizeof(GLfloat)));             // type
      glEnableVertexAttribArray(0);
      glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(CParticle), (const GLvoid*)((0 + 1) * sizeof(GLfloat)));         // position
      glEnableVertexAttribArray(1);
      glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(CParticle), (const GLvoid*)((0 + 1 + 3) * sizeof(GLfloat)));     // velocity
      glEnableVertexAttribArray(2);      glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, sizeof(CParticle), (const GLvoid*)((0 + 1 + 3 + 3) * sizeof(GLfloat))); // lifetime
      glEnableVertexAttribArray(3);
      
      glBindVertexArray(mVAOs[1]);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(CParticle), (const GLvoid*)((0 + 1) * sizeof(GLfloat)));         // position
      glEnableVertexAttribArray(0);
      
      return glCheckError();
    }
    
    void draw(int dt)
    {
      if(!mInit) return;
      
      sys::info << "ogl::CParticleSystem::draw(" << dt << ")" << sys::endl;
      
      mTime += dt;
      
      update(dt);
      render();
      
      // switch
      mActiveVBO = mActiveTBO;
      mActiveTBO = (mActiveTBO + 1) & 0x1;
    }
    
    protected:
    void update(int dt)
    {
      mUpdateProgram->enable();
      mUpdateProgram->setUniform("u_fTime",      (float)mTime);
      mUpdateProgram->setUniform("u_fDeltaTime", (float)dt);
      mRandomTexture->bind(OGL_TEXTURE_GENERIC);
      
      glEnable(GL_RASTERIZER_DISCARD);
      
      glBindBuffer(GL_ARRAY_BUFFER, mVBOs[mActiveVBO]);
      glBindTransformFeedback(GL_TRANSFORM_FEEDBACK, mTBOs[mActiveTBO]);
      
      glBindVertexArray(mVAOs[0]);
      
      glBeginTransformFeedback(GL_POINTS); ///////////////////////////////////////////////////////////////////////////
      if(mFirst)
      {
        glDrawArrays(GL_POINTS, 0, 1);
        mFirst = false;
      }
      else
      {
        glDrawTransformFeedback(GL_POINTS, mTBOs[mActiveVBO]);
      }
      glEndTransformFeedback(); //////////////////////////////////////////////////////////////////////////////////////
      
      // glExitIfError();
      
      glBindVertexArray(0);
      
      glDisable(GL_RASTERIZER_DISCARD);
    } 
    
    void render()
    {
      mRenderProgram->enable();
      mRenderProgram->setUniform("u_vCameraPosition", mCameraPosition);
      mRenderProgram->setUniform("u_mVP", mProjectionMatrix * mViewMatrix);
      mDiffuseTexture->bind(OGL_TEXTURE_DIFFUSE);
      
      glBindBuffer(GL_ARRAY_BUFFER, mVBOs[mActiveTBO]);
      
      glBindVertexArray(mVAOs[1]);
      
      glDrawTransformFeedback(GL_POINTS, mTBOs[mActiveTBO]);
      
      // glExitIfError();
      
      glBindVertexArray(0);
    }
    
    public:
    void setNumParticles(uint numParticles)
    {
      mNumParticles = numParticles;
    }
    
    void setPosition(const math::vec3& position)
    {
      mPosition = position;
    }
    
    void setUpdateProgram(CProgram* program)
    {
      mUpdateProgram = program;
    }
    
    void setRenderProgram(CProgram* program)
    {
      mRenderProgram = program;
    }
    
    void setViewMatrix(const math::mat4& m)
    {
      mViewMatrix = m;
    }
    
    void setProjectionMatrix(const math::mat4& m)
    {
      mProjectionMatrix = m;
    }
    
    void setCameraPosition(const math::vec3& v) 
    {
      mCameraPosition = v;
    } 
    
    void setRandomTexture(CTexture* texture)
    {
      mRandomTexture = texture;
    }
    
    void setDiffuseTexture(CTexture* texture)
    {
      mDiffuseTexture = texture;
    }
  };
}

#endif // __cparticlesystem_hpp__
