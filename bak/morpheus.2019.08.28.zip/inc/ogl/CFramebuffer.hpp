#ifndef __cframebuffer_hpp__
#define __cframebuffer_hpp__

namespace ogl
{
  class CFramebufferBuilder;

  //@TODO: write renderbuffer
  class CRenderbuffer
  {
  
  };

  class CFramebuffer
  {
    friend class CFramebufferBuilder;
  
    public:
    enum ETargets
    {
      DRAW = GL_DRAW_FRAMEBUFFER,
      READ = GL_READ_FRAMEBUFFER,
      BOTH = GL_FRAMEBUFFER,
    };
    
    enum EBuffers
    {
      COLOR = GL_COLOR_BUFFER_BIT,
      DEPTH = GL_DEPTH_BUFFER_BIT,
    };

    protected:
    GLuint                      mFBO;
    GLenum                      mTarget;
    GLsizei                     mWidth;
    GLsizei                     mHeight;
    std::map<GLenum, CTexture*> mClones;
    std::map<GLenum, CTexture*> mTextures;
    std::vector<GLenum>         mDrawbuffers;
    
    public:
    CFramebuffer() 
    : mFBO(0), mTarget(GL_FRAMEBUFFER), mWidth(0), mHeight(0)
    {
      
      glBindFramebuffer(mTarget, mFBO);
    }
    
    CFramebuffer(GLsizei width, GLsizei height) 
    : mFBO(0), mTarget(GL_FRAMEBUFFER), mWidth(width), mHeight(height)
    {
      // default framebuffer
      glBindFramebuffer(mTarget, mFBO);
    }
    
    CFramebuffer(GLenum fbo, GLenum target)
    : mFBO(fbo), mTarget(target), mWidth(0), mHeight(0)
    {
      glBindFramebuffer(mTarget, mFBO);
    }
    
    explicit CFramebuffer(GLenum target) 
    : mFBO(-1), mTarget(target), mWidth(0), mHeight(0)
    {
      glGenFramebuffers(1, &mFBO);
      glBindFramebuffer(mTarget, mFBO);
    }
    
    CFramebuffer(GLenum target, GLsizei width, GLsizei height) 
    : mFBO(-1), mTarget(target), mWidth(width), mHeight(height)
    {
      glGenFramebuffers(1, &mFBO);
      glBindFramebuffer(mTarget, mFBO);
    }
    
    CFramebuffer(const CFramebuffer& that)
    {
      if(mFBO != 0)
        glDeleteFramebuffers(1, &mFBO);
        
      mFBO     = that.mFBO;
      mTarget  = that.mTarget;
      mWidth   = that.mWidth;
      mHeight  = that.mHeight;
    }
    
    virtual ~CFramebuffer()
    {
      if(mFBO != 0)
        glDeleteFramebuffers(1, &mFBO);
        
      //@TODO: requires smart pointer
      for(auto it = mTextures.begin(); it != mTextures.end(); ++it)
        _DELETE(it->second);
      for(auto it = mClones.begin(); it != mClones.end(); ++it)
        _DELETE(it->second);
        
      mClones.clear();
      mTextures.clear();
    }
    
    CFramebuffer& operator = (const CFramebuffer& that)
    {
      if(this != &that)
      {
        if(mFBO != 0)
          glDeleteFramebuffers(1, &mFBO);
          
        mFBO     = that.mFBO;
        mTarget  = that.mTarget;
        mWidth   = that.mWidth;
        mHeight  = that.mHeight;
      }
      return *this;
    }
    
    operator GLuint ()
    {
      return mFBO;
    }
    
    public:
    virtual void bind(GLenum target = GL_FRAMEBUFFER, GLenum attachement = GL_NONE)
    {
      glBindFramebuffer(target, mFBO);
      
      if(target == GL_DRAW_FRAMEBUFFER || target == GL_FRAMEBUFFER)
      {
        //if(mDrawbuffers.size() > 0)
        //  glDrawBuffers(mDrawbuffers.size(), &mDrawbuffers[0]);
        glViewport(0, 0, mWidth, mHeight);
      }
      else if(attachement != GL_NONE)
      {
        glReadBuffer(attachement);
      }
      
      glExitIfError();
    }
    
    virtual void unbind()
    {
      glBindFramebuffer(mTarget, 0);
    }
    
    virtual void clear(GLbitfield buffer)
    {
      glClear(buffer);
    }
    
    virtual void addTexture(GLenum attachement, CTexture* pTexture)
    {
      mTextures[attachement] = pTexture;
      
      if(attachement != GL_DEPTH_ATTACHMENT && attachement != GL_DEPTH_STENCIL_ATTACHMENT)
        mDrawbuffers.push_back(attachement);
      
      //glFramebufferTexture2D(mTarget, attachement, pTexture->getTarget(), *pTexture, 0);
    }
    
    /**
     * @depricated
     * @return CTexture*
     */
    CTexture* getTexture(GLenum attachment)
    {
      std::map<GLenum, CTexture*>::const_iterator it = mTextures.find(attachment);
      if(it == mTextures.end())
        return nullptr;
      else
        return it->second;
    }
    
    CTexture* read(GLenum attachment)
    {
      std::map<GLenum, CTexture*>::const_iterator it = mTextures.find(attachment);
      if(it == mTextures.end())
        return nullptr;
      else
        return it->second;
    }
    
    CTexture* copy(GLenum attachment)
    {
      CTexture* pSrc = read(attachment);
      CTexture* pCpy = nullptr;
      
      auto it = mClones.find(attachment);
      if(it != mClones.end())
      {
        pCpy = it->second;
      }
      else
      {
        pCpy = new CTexture(*pSrc);
        
        mClones[attachment] = pCpy;
        
        // TODO: this should be inside texture...or something
        pCpy->setFiltering(CTexture::EFiltering::NEAREST);
        pCpy->setWrapping(CTexture::EWrapping::CLAMP_TO_EDGE);
      }
      
      // copy
      glCopyImageSubData(*pSrc, pSrc->getTarget(), 0, 0, 0, 0,
                         *pCpy, pCpy->getTarget(), 0, 0, 0, 0,
                         pCpy->getWidth(), pCpy->getHeight(), pCpy->getDepth());
      
      glExitIfError();
      
      return pCpy;
    }
    
    void write(GLenum a_bunch_of_attachements = GL_NONE)
    {
      
    }
    
    GLuint getFBO()
    {
      return mFBO;
    }
    
    GLint getWidth() const
    {
      return mWidth;
    }
    
    GLint getHeight() const
    {
      return mHeight;
    }
  
    GLenum getTarget() const
    {
      return mTarget;
    }
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CFramebufferBuilder : public sys::CSingleton<CFramebufferBuilder>
  {
    friend class sys::CSingleton<CFramebufferBuilder>;
  
    protected:
    std::map<GLenum, CTexture*> mTextures;
    GLsizei                     mWidth;
    GLsizei                     mHeight;
    GLsizei                     mTarget;
  
    public:
    CFramebufferBuilder() : mWidth(0), mHeight(0), mTarget(GL_FRAMEBUFFER)
    {
    
    }
    
    virtual ~CFramebufferBuilder()
    {
    
    }
    
    virtual CFramebuffer* build()
    {
      sys::info << "ogl::CFramebufferBuilder::build()" << sys::endl;
      
      CFramebuffer* pFramebuffer = new CFramebuffer(mTarget, mWidth, mHeight);
      
      //glViewport(0, 0, mWidth, mHeight);
      
      for(auto it = mTextures.begin(); it != mTextures.end(); ++it)
      {
        if(it->first != GL_NONE)
          glFramebufferTexture(mTarget, it->first, *(it->second), 0);
        pFramebuffer->addTexture(it->first, it->second);
      }
      
      if(pFramebuffer->mDrawbuffers.size() > 0)
        glDrawBuffers(pFramebuffer->mDrawbuffers.size(), &(pFramebuffer->mDrawbuffers)[0]);
      
      GLenum status = glCheckFramebufferStatus(mTarget);
      
      switch(status)
      {
        case GL_FRAMEBUFFER_COMPLETE:
          sys::info << sys::tab << "GL_FRAMEBUFFER_COMPLETE" << sys::endl;
        break;
        case GL_FRAMEBUFFER_UNDEFINED: // 0x8219 = 33305
          throw EXCEPTION << "Undefined!";
        break;
        case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT: // 0x8CD6 = 36054
          throw EXCEPTION << "Incomplete Attachement!";
        break;        case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT: // 0x8CD7 = 36055
          throw EXCEPTION << "Incomplete Missing Attachement!";
        break;
        case GL_FRAMEBUFFER_UNSUPPORTED:  // 0x8CDD = 36061 
          throw EXCEPTION << "Unsupported!";
        break;
        case GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS:
          throw EXCEPTION << "Incomplete Layer Targets!";
        break;
        default:
        // GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER
        // GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER
        // GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE
          throw EXCEPTION << "Other!";
        break;
      }
      
      glExitIfError();
      
      mTextures.clear();
      
      glBindFramebuffer(mTarget, 0);
      
      return pFramebuffer;
    }
    
    virtual void setWidth(GLsizei width)
    {
      mWidth = width;
    }
    
    virtual void setHeight(GLsizei height)
    {
      mHeight = height;
    }
    
    virtual void setTarget(GLenum target)
    {
      mTarget = target;
    }
    
    virtual void addTexture(GLenum attachement, CTexture* pTexture)
    {
      mTextures[attachement] = pTexture;
    }
  };
}

#endif // __cframebuffer_hpp__
