#ifndef __ogl_cgeometryframebuffer_hpp__
#define __ogl_cgeometryframebuffer_hpp__

namespace ogl
{
  class CGeometryFramebuffer : public CFramebuffer
  {
    public:
    CGeometryFramebuffer(GLsizeui nWidth, GLsizeui nHeight) : CFramebuffer(nWidth, nHeight)
    {
      
    }
  };
}

#endif // __ogl_cgeometryframebuffer_hpp__
