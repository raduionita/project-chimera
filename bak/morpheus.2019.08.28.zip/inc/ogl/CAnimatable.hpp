#ifndef __OGL_CANIMATABLE_HPP__
#define __OGL_CANIMATABLE_HPP__

namespace ogl
{
  class CAnimatable
  {
    public:
    typedef struct {
      int        parent;
      char       name[64];
      math::vec3 position;
      math::quat rotation;
      math::vec3 scaling;
    } joint_t;
    typedef struct {
      math::mat4* inverseTransforms;
      joint_t* joints;
      size_t   numJoints;
    } skeleton_t;
    
    public:
    skeleton_t* mSkeleton;
    
    public:
    CAnimatable()
    {
      sys::info << "ogl::CAnimatable::CAnimatable()" << sys::endl;
      
      mSkeleton = new skeleton_t;
      mSkeleton->joints = nullptr;
      mSkeleton->numJoints = 0;
    }
    
    virtual ~CAnimatable()
    {
      sys::info << "ogl::CAnimatable::~CAnimatable()" << sys::endl;
      
      if(mSkeleton->numJoints > 1) 
      {
        delete [] mSkeleton->joints;
        delete [] mSkeleton->inverseTransforms;
      }
      else 
        delete mSkeleton->joints;
      delete mSkeleton;
    }
    
    public:
    std::vector<math::mat4> getTransforms() const
    {
      std::vector<math::mat4> transforms;
      if(mSkeleton->numJoints)
      {
        for(size_t ji = 0; ji < mSkeleton->numJoints; ++ji)
        {
          CAnimatable::joint_t* joint = &mSkeleton->joints[ji];
          assert(joint);
          math::mat4 transform = math::translate(joint->position) * math::toMatrix(joint->rotation);
          transforms.push_back(transform);
        }
      }
      else
      {
        transforms.push_back(math::mat4());
      }
      return transforms;
    }
    
    math::mat4 getBoneMatrix(size_t ji) const
    {
      assert(ji < mSkeleton->numJoints);
      
      CAnimatable::joint_t* joint = &mSkeleton->joints[ji];
      assert(joint);
      return (math::translate(joint->position) * math::toMatrix(joint->rotation)) * mSkeleton->inverseTransforms[ji];
    }
  };
}

#endif // __OGL_CANIMATABLE_HPP__
