#ifndef __ogl_cprojector_hpp__
#define __ogl_cprojector_hpp__

namespace ogl
{
  class CProjector
  {
    public:
    math::vec3 mPosition;
    math::vec3 mTarget;
    math::vec3 mUp;
    
    float mFov;
    float mRatio;
    float mNear;
    float mFar;
    
    public:
    math::mat4 getViewMatrix() const
    {
      return math::lookat(mPosition, mTarget, mUp);
    }
    
    math::mat4 getProjectionMatrix() const
    {
      return math::perspective(mFov, mRatio, mNear, mFar);
    }
  };
}

#endif // __ogl_cprojector_hpp__
