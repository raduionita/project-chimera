#ifndef __ogl_csphereobjectbuilder_hpp__
#define __ogl_csphereobjectbuilder_hpp__

namespace ogl
{
  class CSphereObjectBuilder : public CObjectBuilder
  {
    private:
    float      mRadius;
    ushort     mSubdivisions;
  
    public:
    CSphereObjectBuilder() : CObjectBuilder(), mRadius(1.0f), mSubdivisions(1)
    {
      sys::info << "ogl::CSphereObjectBuilder::CSphereObjectBuilder()" << sys::endl;
    }
    
    virtual ~CSphereObjectBuilder()
    {
      sys::info << "ogl::CSphereObjectBuilder::~CSphereObjectBuilder()" << sys::endl;
    }
    
    public:
    CObject* build()
    {
      sys::info << "ogl::CSphereObjectBuilder::build()" << sys::endl;
      
      // TODO: use diamiond/icosphere/uv-sphere algorithm
      
      // size_t nNumVertices = 8 * std::pow(3, mSubdivisions); // 8 faces * 3 ^ subdivisions
      // OR
      // size_t mNumVertices = 6 // 
      
      return nullptr;
    }
  };
}

#endif // __ogl_csphereobjectbuilder_hpp__
