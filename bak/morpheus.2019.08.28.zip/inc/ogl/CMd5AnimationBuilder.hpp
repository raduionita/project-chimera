#ifndef __ogl_CMD5ANIMATIONBUILDER_HPP__
#define __ogl_CMD5ANIMATIONBUILDER_HPP__

namespace ogl
{
  class CMd5AnimationBuilder : public CAnimationBuilder
  {
    protected:
    typedef struct {
      char   name[64];
      int parent;
      math::vec3 position;
      math::quat rotation;
    } joint_t;
    typedef struct {
      joint_t* joints;
    } frame_t;
    typedef struct {
      math::vec3 min;
      math::vec3 max;
    } bbox_t;
    typedef struct {
      bbox_t*  bboxes;
      frame_t* frames;
      size_t   numFrames;
      size_t   numJoints;
      size_t   frameRate;
    } animation_t;
    typedef struct {
      char   name[64];
      int    parent;
      int    flags;
      size_t start;
    } jointinfo_t;
    typedef struct {
      math::vec3 position;
      math::quat rotation;
    } basejoint_t;
    
    protected:
    sys::CFile mFile;

    public:
    CMd5AnimationBuilder() : CAnimationBuilder()
    {
      sys::info << "ogl::CMd5AnimationBuilder::CMd5AnimationBuilder()" << sys::endl;
    }
    
    virtual ~CMd5AnimationBuilder()
    {
      sys::info << "ogl::CMd5AnimationBuilder::~CMd5AnimationBuilder()" << sys::endl;
    }
    
    public:
    void setFile(const std::string& sFile)
    {
      mFile = std::move(sys::CFile(sFile));
    }
    
    void setFile(sys::CFile&& oFile)
    {
      mFile = std::move(oFile);
    }
    
    CAnimation* build()
    {
      sys::info << "ogl::CMd5AnimationBuilder::build()" << sys::endl;
      
      animation_t* animation = new animation_t;
      buildAnimation(mFile, animation);
      
      /* ********************************************************************************************************** */
      
      CAnimation* pAnimation = new CAnimation(animation->numJoints, animation->numFrames);
      pAnimation->mFrameRate = animation->frameRate;
      pAnimation->mDuration  = ((float)(pAnimation->mNumFrames) / (float)(animation->frameRate));
      
      for(size_t fi = 0; fi < animation->numFrames; ++fi) // build bone matrices
      {
        for(size_t ji = 0; ji < animation->numJoints; ++ji)
        {
          joint_t* joint = &animation->frames[fi].joints[ji];
          pAnimation->mFrames[fi].joints[ji].parent   = joint->parent;
          pAnimation->mFrames[fi].joints[ji].position = joint->position;
          pAnimation->mFrames[fi].joints[ji].rotation = joint->rotation;
          //pAnimation->mFrames[fi].joints[ji].transform = math::translate(joint->position) * math::toMatrix(joint->rotation);
          // sys::info << "> (" << joint->position << ") (" << joint->rotation << ")\n";
        }
      }
      
      if(hasOption(NORMALIZED)) // normalize animation
      {
        
      }
      
      /* ********************************************************************************************************** */
      
      freeAnimation(animation);
      
      return pAnimation;
    }
  
    protected:
    static void freeAnimation(animation_t* animation)
    {
      for(size_t i = 0; i < animation->numFrames; ++i)
      {
        delete [] animation->frames[i].joints;
      }
      
      delete [] animation->bboxes;
      delete [] animation->frames;
      delete animation;
    }
    
    static void buildAnimation(const sys::CFile& oFile, animation_t* animation)
    {
      if(oFile.isEmpty())
        throw EXCEPTION << "ERROR: Builder requires a .md5anim file.";
      
      FILE* fp = NULL;
      fp = fopen(std::string(MODELPATH).append(oFile.getFilePath()).c_str(), "rb");
      if(fp == NULL)
        throw EXCEPTION << "Can not open file " << oFile.getFileName();
      
      char line[512];
      int  version = 0;
      size_t numComponents = 0;
      jointinfo_t* jointinfo = nullptr;
      basejoint_t* baseframe = nullptr;
      float* animdata = nullptr;
      
      float temp[6];
      size_t fi = 0, ji = 0, ci = 0;
      
      while(!feof(fp))
      {
        fgets(line, sizeof(line), fp);
        
        if(line[0] =='\0' || line[0] =='#' || (line[0] =='/' && line[1] == '/') || line[0] == '\n')
          continue; 
        assert(line);
        
        if(sscanf(line, " MDVersion %d", &version) == 1 && version != 10)
        {
          fclose(fp);
          throw EXCEPTION << "Bad model version." << oFile.getFileName();
        }
        else if(strncmp(line, "commandline", 11) == 0)
        { 
          // ignore
        }
        else if(sscanf(line, " numFrames %d", &animation->numFrames) == 1 && animation->numFrames > 0)
        {
          animation->frames = new frame_t[animation->numFrames];
          animation->bboxes = new bbox_t[animation->numFrames];   // a bbox for every frame
        }
        else if(sscanf(line, " numJoints %d", &animation->numJoints) == 1 && animation->numJoints > 0)
        {
          for(fi = 0; fi < animation->numFrames; ++fi)
            animation->frames[fi].joints = new joint_t[animation->numJoints]; // allocate mem for joints in each frame
          
          jointinfo = new jointinfo_t[animation->numJoints]; // allocate mem for building skeleton frames
          baseframe = new basejoint_t[animation->numJoints];
        }
        else if(sscanf(line, " frameRate %d", &animation->frameRate) == 1)
        {
          // animation's frame rate
        }
        else if(sscanf(line, " numAnimatedComponents %d", &numComponents) == 1 && numComponents > 0)
        {
          animdata = new float[numComponents];
        }
        else if(strncmp(line, "hierarchy {", 11) == 0)
        {
          for(ji = 0; ji < animation->numJoints; ++ji)
          {
            fgets(line, sizeof(line), fp); // read next line
            
            sscanf(line, " %s %d %d %d", jointinfo[ji].name, &jointinfo[ji].parent, &jointinfo[ji].flags, &jointinfo[ji].start);
          }
        }
        else if(strncmp(line, "bounds {", 8) == 0)
        {
          for(fi = 0; fi < animation->numFrames; ++fi)
          {
            fgets(line, sizeof(line), fp); // read next line
            
            if(sscanf(line, " ( %f %f %f ) ( %f %f %f )", &temp[0], &temp[1], &temp[2], &temp[3], &temp[4], &temp[5]) == 6)
            {
              animation->bboxes[fi].min = math::vec3(temp[0], temp[1], temp[2]);
              animation->bboxes[fi].max = math::vec3(temp[3], temp[4], temp[5]);
            }
          }
        }
        else if(strncmp(line, "baseframe {", 10) == 0)
        {
          for(ji = 0; ji < animation->numJoints; ++ji)
          {
            fgets(line, sizeof(line), fp); // read next line
            
            if(sscanf(line, " ( %f %f %f ) ( %f %f %f )", &temp[0], &temp[1], &temp[2], &temp[3], &temp[4], &temp[5]) == 6)
            {
              baseframe[ji].position = math::vec3(temp[0], temp[1], temp[2]);
              baseframe[ji].rotation = math::quat(math::vec3(temp[3], temp[4], temp[5]));
            }
          }
        }
        else if(sscanf(line, "frame %d {", &fi) == 1)
        {
          //sys::info << fi << sys::endl;
          
          for(ci = 0; ci < numComponents; ++ci) // fread frame data
            fscanf(fp, "%f", &animdata[ci]);
          
          buildSkeleton(jointinfo, baseframe, animdata, animation->frames[fi].joints, animation->numJoints);
        }
      }
      fclose(fp);
      
      sys::info << sys::endl;
      
      delete [] jointinfo; // free memory
      delete [] baseframe;
      delete [] animdata;
    }
    
    static void buildSkeleton(jointinfo_t* jointinfo, basejoint_t* baseframe, float* animdata, joint_t* joints, size_t numJoints)
    {
      float temp[6];
      size_t j = 0;
      
      for(size_t i = 0; i < numJoints; ++i)
      {
        const basejoint_t* basejoint = &baseframe[i];
        
        //memcpy(&temp[0], &basejoint->position, 3 * sizeof(float));
        //memcpy(&temp[3], &basejoint->rotation, 3 * sizeof(float));
        temp[0] = basejoint->position[0];
        temp[1] = basejoint->position[1];
        temp[2] = basejoint->position[2];
        temp[3] = basejoint->rotation[0];
        temp[4] = basejoint->rotation[1];
        temp[5] = basejoint->rotation[2];
        
        j = 0;
        
        if(jointinfo[i].flags & 1) // Tx
          temp[0] = animdata[jointinfo[i].start + j++];
        if(jointinfo[i].flags & 2) // Ty
          temp[1] = animdata[jointinfo[i].start + j++];
        if(jointinfo[i].flags & 4) // Tz
          temp[2] = animdata[jointinfo[i].start + j++];
        if(jointinfo[i].flags & 8) // Qx
          temp[3] = animdata[jointinfo[i].start + j++];
        if(jointinfo[i].flags & 16) // Qy
          temp[4] = animdata[jointinfo[i].start + j++];
        if(jointinfo[i].flags & 32) // Qz
          temp[5] = animdata[jointinfo[i].start + j++];
          
        joint_t* thisJoint = &joints[i];
        
        thisJoint->position = math::vec3(temp[0], temp[1], temp[2]);
        thisJoint->rotation = math::quat(math::vec3(temp[3], temp[4], temp[5]));
        
        thisJoint->parent = jointinfo[i].parent;
        strcpy(thisJoint->name, jointinfo[i].name);
        
        if(thisJoint->parent >= 0)                    // IF not root nodes
        {
          joint_t* parentJoint = &joints[thisJoint->parent];
          
          math::vec3 rotated = math::rotate(parentJoint->rotation, thisJoint->position);
          
          thisJoint->position = parentJoint->position + rotated;
          thisJoint->rotation = parentJoint->rotation * thisJoint->rotation;
          thisJoint->rotation = math::normalize(thisJoint->rotation);
        }
      }
    }
  };
}

#endif // __ogl_CMD5ANIMATIONBUILDER_HPP__


































