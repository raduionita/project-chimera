#ifndef __ogl_coctree_hpp__
#define __ogl_coctree_hpp__

namespace ogl
{
  class CNode
  {
    public:
    CNode*                mParent;
    CBBox                 mBBox;
    std::array<CNode*, 8> mChildren;
    std::vector<CEntity*> mEntities;
    
    
    public:
    void insert(CEntity* pEntity)
    {
      CBBox oBBox = oEntity->getBBox();
      
      for(size_t i = 0; i < 8; ++i) // for each children
      {
        CNode*& pChild = mChildren[i];
        
        
      }
    }
  };
  
  class COctree
  {
    protected:
    CNode* mRoot; // = new CNode(nullptr)
    
    public:
    void insert(CEntity* pEntity)
    {
      mRoot->insert(pEntity);
    }
  };
  
  
  COctree oStorage;
  oStorage.insert(pEntity);
}

#endif // __ogl_coctree_hpp__

/** INIT:
  CScene* pScene = new CScene;
  
  foreach <object> in <objects>
    CEntity* pEntity = new CEntity(<object>)
    
    pScene->insert(pEntity)
    
*/

/** UPDATE:
  fore

*/

/** RENDER:
  CQuery* pQuery = new CQuery;
  pQuery->select(CEntity::DRAWABLE) // EVENT, CAMERA, FORCE...
        ->from(pScene)
        ->where(CQuery::AABB, CQuery::IN, pFrustum);
  CResult* pResult = pQuery->exectute();
  while(pEntity = pResult->next())
    pRenderer->draw(pEntity);
*/
