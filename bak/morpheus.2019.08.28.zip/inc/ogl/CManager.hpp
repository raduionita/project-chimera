#ifndef __ogl_CMANAGER_HPP__
#define __ogl_CMANAGER_HPP__

namespace ogl
{
  class CManager : public sys::CSingleton<CManager> // CRegistrable
  {
    friend class sys::CSingleton<CManager>;
  };
}

#endif // __ogl_CMANAGER_HPP__
