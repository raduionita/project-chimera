#ifndef __ogl_CSHADERBUILDER_HPP__
#define __ogl_CSHADERBUILDER_HPP__

namespace ogl
{
  class CShaderBuilder
  {
    protected:
    GLenum mType;
    
    public:
    CShaderBuilder() : mType(GL_NONE)
    {
      sys::info << "ogl::CShaderBuilder::CShaderBuilder()" << sys::endl;
    }
    
    virtual ~CShaderBuilder()
    {
      sys::info << "ogl::CShaderBuilder::~CShaderBuilder()" << sys::endl;
    }
    
    public:
    virtual CShader* build() = 0;
    
    virtual void setType(GLenum type)
    {
      mType = type;
    }
  };
}

#endif // __ogl_CSHADERBUILDER_HPP__
