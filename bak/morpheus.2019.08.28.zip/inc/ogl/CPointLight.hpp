#ifndef __cpointlight_hpp__
#define __cpointlight_hpp__

namespace ogl
{
  class CPointLight : public CLight
  {
    public:
    // from CLight
    // ushort      mType;
    // math::vec3  mColor;
    // float       mAmbientIntensity;
    // float       mDiffuseIntensity;
    // GLuint mVAO;
    // GLuint mVBO;
    
    math::vec3 mPosition;
    float      mK0; // kc
    float      mK1; // kl
    float      mK2; // ke
    
    public:
    CPointLight() : CLight(CLight::POINT), mPosition(0.0f), mK0(0.0f), mK1(0.0f), mK2(0.0f)
    {
      const float vertices[] = {
        -0.25f, 0.00f, 0.00f, 
         0.25f, 0.00f, 0.00f, 
         0.00f,-0.25f, 0.00f, 
         0.00f, 0.25f, 0.00f, 
         0.00f, 0.00f,-0.25f, 
         0.00f, 0.00f, 0.25f };
         
      glGenBuffers(1, &mVBO);
      glBindBuffer(GL_ARRAY_BUFFER, mVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
      
      glGenVertexArrays(1, &mVAO);
      glBindVertexArray(mVAO);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)((0) * sizeof(GLfloat)));
      glEnableVertexAttribArray(0);
      
      glBindVertexArray(0);
      glBindBuffer(GL_ARRAY_BUFFER, 0);
    }
    
    public:
    virtual void setPosition(const math::vec3& position)
    {
      mPosition = position;
    }
    
    virtual math::vec3 getPosition() const
    {
      return mPosition;
    }
    
    virtual math::mat4 getM()
    {
      return math::translate(mPosition);
    }
    
    float getRadius() const
    {
      float maxchannel = math::max(math::max(mColor.x, mColor.y), mColor.y);
      
      float ret = (-mK1 + math::fastSqrt(mK1 * mK1 - 4 * mK2 * (mK2 - 256 * maxchannel * mDiffuseIntensity))) / 2 * mK2;
      
      return ret;
    }
    
    // from CDrawable
    public:
    CDrawCommand* getDrawCommand()
    {
      CDrawCommand* pCommand = new CDrawCommand;
      
      pCommand->mDrawable       = this;
      pCommand->mVAO            = mVAO;
      // pCommand->mBuffers     = mBuffers;
      pCommand->mTarget         = GL_ARRAY_BUFFER;
      // pCommand->mMode        = mMode;
      // pCommand->mBufferRange = mShapes[i]->mIndexBufferRange;
      // pCommand->mMaterial    = mShapes[i]->mMaterial;
      // pCommand->mBufferRange = CBufferRange(0, mNumIndices, GL_UNSIGNED_SHORT); // it->first->mIndexBufferRange;
      pCommand->mModelMatrix    = math::translate(mPosition);
      // pCommand->mMaterial    = it->first->mMaterial;
      // pCommand->mNext        = nullptr;
      
      return pCommand;
    }
  };
}

#endif // __cpointlight_hpp__
