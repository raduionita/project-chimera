#ifndef __ogl_crenderer_hpp__
#define __ogl_crenderer_hpp__

#include <vector>
#include <algorithm>
#include <utility>
#include <map>
#include <functional>
#include <cassert>

namespace ogl
{
  class CPixel
  {
    public:
    GLenum mFormat;
    GLenum mType;
    GLint  mX;
    GLint  mY;
    
    public:
    CPixel()
    : mFormat(GL_NONE), mType(GL_NONE), mX(-1), mY(-1)
    {
    }
    
    CPixel(GLenum format, GLenum type, GLint x, GLint y)
    : mFormat(format), mType(type), mX(x), mY(y)
    {
      
    }
  };
  
  class CPickPixel : public CPixel
  {
    public:
    union {
      struct { 
        int mObjectID;
        int mDrawID;
        int mPrimitiveID;
      };
      math::ivec3 mData;
    };
    
    GLint mX;
    GLint mY;
    
    public:
    CPickPixel(CFramebuffer* pFramebuffer, GLenum attachement, GLint x, GLint y) 
    : CPixel(), mObjectID(0), mDrawID(0), mPrimitiveID(0)
    {
      sys::info << "ogl::CPickPixel::CPickPixel(pFramebuffer, attachement, x, y)" << sys::endl;
    
      mX = x;
      mY = y;
    
      pFramebuffer->bind();
      glReadBuffer(attachement);
      
      CTexture* pTexture = pFramebuffer->getTexture(attachement);
      if(pTexture)
      {
        mFormat = pTexture->getFormat();
        mType   = pTexture->getType();
        
        glReadPixels(mX, pFramebuffer->getHeight() - mY - 1, 1, 1, mFormat, mType, &mData);
        
        //sys::info << sys::tab << "mX: " << mX << " mY: " << mY << sys::endl;
        //sys::info << sys::tab << "mObjectID: " << mObjectID << " mDrawID: " << mDrawID << " mPrimitiveID: " << mPrimitiveID << sys::endl;
        
        glReadBuffer(GL_NONE);
      }
    }
    
    GLint getX() const
    {
      return mX;
    }
    
    GLint getY() const
    {
      return mY;
    }
  
    math::ivec3 getData() const
    {
      return mData;
    }
  };

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
  
  class CRenderPass 
  {
    friend class CRenderer;
    
    protected:
    CRenderer* pRendered;
    
    public:
    CRenderPass() : pRendered(nullptr)
    {
    
    }
    
    CRenderPass(CRenderer* pRendered) : pRendered(pRendered)
    {
    
    }
    
    virtual ~CRenderPass()
    {
    
    }
    
    public:
    virtual void render() = 0;
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
  
  class CRenderer
  {
    friend class CRenderPass;
  
    public:
    static constexpr GLbitfield NONE = 0x0000;
  
    protected:
    std::vector<CDrawable*>   mDrawables;
    std::vector<GLbitfield>   mOptions;
    
    CProgram*                 mProgram;
    CCamera*                  mCamera;
    
    GLint                     mDrawableIndex;
    
    public:
    CRenderer() : /* mProgram(nullptr), */ mCamera(nullptr) /* , mDrawableIndex(0) */
    {
      
    }
    
    virtual ~CRenderer()
    {
      sys::info << "ogl::CRenderer::~CRenderer()" << sys::endl;
//      for(size_t i = 0; i < mRenderPasses.size(); ++i)
//        delete mRenderPasses[i];
    }
    
    public:
    virtual void setProgram(CProgram* program)
    {
      mProgram = program;
    }
    
    virtual CProgram* getProgram() const
    {
      return mProgram;
    }
    
    virtual void setCamera(CCamera* camera)
    {
      mCamera = camera;
    }
    
    virtual CCamera* getCamera() const
    {
      return mCamera;
    }
    
    virtual GLbitfield getOptions() const
    {
      return mOptions[mDrawableIndex];
    }
    
    virtual void setOptions(GLbitfield options)
    {
      mOptions[mDrawableIndex] = options;
    }
    
    virtual void addDrawable(CDrawable* drawable, GLbitfield options = EDrawOptions::GENERIC)
    {
      mDrawables.push_back(drawable);
      mOptions.push_back(options);
    }
    
    std::vector<CDrawable*>& getDrawables()
    {
      return mDrawables;
    }
  
    virtual void render() = 0;
  };
  
  class CDrawRenderer : public CRenderer
  {
    protected:
    std::vector<CLight*> mLights;
    GLenum               mWinding;
    GLenum               mCullFace;
    
    GLuint               mFBO;
    
    GLsizei mWidth;
    GLsizei mHeight;
    
    CPickPixel*          mPickPixel;
    CTexture*            mShadowTexture;
    
    GLint mDrawIndex;
    GLint mObjectIndex;
    
    public:
    CDrawRenderer() 
    : CRenderer(), mWinding(GL_CW), mCullFace(GL_BACK), mWidth(0), mHeight(0), mPickPixel(nullptr), mShadowTexture(nullptr)
    {
      mDrawIndex   = 0;
      mObjectIndex = 0;
      
      mFBO = 0;
    }
    
    CDrawRenderer(GLsizei width, GLsizei height) 
    : CRenderer(), mWinding(GL_CW), mCullFace(GL_BACK), mWidth(width), mHeight(height), mPickPixel(nullptr), mShadowTexture(nullptr)
    {
      mDrawIndex   = 0;
      mObjectIndex = 0;
      
      mFBO = 0;
    }
    
    virtual ~CDrawRenderer()
    {
      //_DELETE(mPickPixel);
      _DELETE(mShadowTexture);
    }
    
    public:
    void render()
    {
      sys::info << "ogl::CDrawRenderer::render()" << sys::endl;
      
      mDrawableIndex = 0;
      mDrawIndex     = 1;
      mObjectIndex   = 1;
      
      glBindFramebuffer(GL_FRAMEBUFFER, mFBO);
      
      glViewport(0, 0, mWidth, mHeight);

      glEnable(GL_DEPTH_TEST);
      glDepthFunc(GL_LEQUAL);
      
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      glEnable(GL_CULL_FACE);
      glCullFace(mCullFace);
      glFrontFace(mWinding);
      
      mProgram->enable();
      
      for(CDrawable* pDrawable : mDrawables)
      {
        // sys::info << sys::tab << "drawables..." << sys::endl;
        
        CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
        CDrawCommand*  pFirstCommand = pDrawCommand;
        GLbitfield     options       = getOptions();
        CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
        
        if(pDrawCommand != nullptr)
        {
          if(options & ogl::EDrawOptions::WIREFRAME)
          {
            glEnable(GL_POLYGON_OFFSET_LINE);
            glPolygonOffset(-1.0f, -1.0f);
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            glLineWidth(1.0f);
          }
          else
          {
            glEnable(GL_POLYGON_OFFSET_FILL);
            glPolygonOffset(1.0f, 1.0f);
          }
        
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
          
          mProgram->getCallback()(this, pDrawCommand);
          
          while(pDrawCommand != nullptr)
          {
            pDrawCommand->mMode = mProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
            
            // materials on
            if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // activate textures
            {
              pDrawCommand->mMaterial->bind();
            }
            
            pDrawStrategy->draw(pDrawCommand); // draw array/elements/instanced
            
            // materials off
            if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // activate textures
            {
              pDrawCommand->mMaterial->unbind();
            }
            
            pDrawCommand = pDrawCommand->mNext;
            
            mDrawIndex++;
            
            //break;
          }
          
          //glBindBuffer(pDrawCommand->mTarget, 0); // will cause seg fault cause by now pDrawCommand will be null
          glBindVertexArray(0);
          
          if(options & ogl::EDrawOptions::WIREFRAME)
          {
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            glDisable(GL_POLYGON_OFFSET_LINE);
          }
          else
          {
            glDisable(GL_POLYGON_OFFSET_FILL);
          }
          
          // buffers off
          
          _DELETE(pFirstCommand);
          
          mObjectIndex++;
          mDrawableIndex++;
        }
      }
      
      glExitIfError();
      
      mProgram->disable();
      
      mLights.clear();
      mDrawables.clear();
      mOptions.clear();
    }
    
    void render(CDrawable* pDrawable, GLbitfield options = EDrawOptions::GENERIC)
    {
      sys::info << "ogl::CDrawRenderer::render(CDrawable*)" << sys::endl;
      
      mDrawableIndex = 0;
      mOptions.push_back(options);
      
      if(options & ogl::EDrawOptions::NODEPTHTEST) 
      {
        glDisable(GL_DEPTH_TEST);
      } 
      else
      {
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
      }
      
      glEnable(GL_CULL_FACE);
      glCullFace(mCullFace);
      glFrontFace(mWinding);
      
      mProgram->enable();
      
      {
        CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
        CDrawCommand*  pFirstCommand = pDrawCommand;
        GLbitfield     options       = getOptions();
        CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
        
        if(pDrawCommand != nullptr)
        {
          if(options & ogl::EDrawOptions::WIREFRAME)
          {
            glEnable(GL_POLYGON_OFFSET_LINE);
            glPolygonOffset(-1.0f, -1.0f);
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            glLineWidth(1.0f);
          }
          else
          {
            glEnable(GL_POLYGON_OFFSET_FILL);
            glPolygonOffset(1.0f, 1.0f);
          }
          
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
          
          mProgram->getCallback()(this, pDrawCommand);
          
          while(pDrawCommand != nullptr)
          {
            pDrawCommand->mMode = mProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
            
            // materials on
            if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // activate textures
            {
              pDrawCommand->mMaterial->bind();
            }
            
            pDrawStrategy->draw(pDrawCommand); // draw array/elements/instanced
            
            // materials off
            if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // activate textures
            {
              pDrawCommand->mMaterial->unbind();
            }
            
            pDrawCommand = pDrawCommand->mNext;
            
            //break;
          }
          
          //glBindBuffer(pDrawCommand->mTarget, 0); // will cause seg fault cause by now pDrawCommand will be null
          glBindVertexArray(0);
          
          if(options & ogl::EDrawOptions::WIREFRAME)
          {
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            glDisable(GL_POLYGON_OFFSET_LINE);
          }
          else
          {
            glDisable(GL_POLYGON_OFFSET_FILL);
          }
          
          // buffers off
          
          _DELETE(pFirstCommand);
        }
      }
      
      glExitIfError();
      
      mProgram->disable();
      
      mLights.clear();
      mDrawables.clear();
      mOptions.clear();
    }
    
    void clear() const
    {
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glBindFramebuffer(GL_FRAMEBUFFER, mFBO);
      glViewport(0, 0, mWidth, mHeight);
    }
    
    CLight* getLight(size_t i) 
    {
      return mLights[i];
    }
    
    std::vector<CLight*>& getLights()
    {
      return mLights;
    }
  
    void addLight(CLight* pLight)
    {
      mLights.push_back(pLight);
    }
  
    void setWinding(GLenum winding)
    {
      mWinding = winding;
    }
    
    void setCullFace(GLenum face)
    {
      mCullFace = face;
    }
  
    void setPickPixel(CPickPixel* pPickPixel)
    {
      mPickPixel = pPickPixel;
    }
    
    CPickPixel* getPickPixel() const
    {
      return mPickPixel;
    }
    
    void setShadowTexture(CTexture* pTexture)
    {
      _DELETE(mShadowTexture);
      mShadowTexture = pTexture;
    }
    
    void setClearDepth(float d)
    {
      glClearDepthf(d);
    }
    
    void setClearColor(float r, float g, float b, float a)
    {
      glClearColor(a, a, a, a);
    }
    
    void setClearColor(const math::vec4& v)
    {
      setClearColor(v.r, v.g, v.b, v.a);
    }
  
    GLint getObjectIndex() const
    {
      return mObjectIndex;
    }
    
    GLint getDrawIndex() const
    {
      return mDrawIndex;
    }
  };
  
  class CPickRenderer : public CRenderer
  {
    protected:
    int           mWidth;
    int           mHeight;
    CFramebuffer* mFramebuffer;
    CTexture*     mPickTexture;
    CTexture*     mDepthTexture;
    CPickPixel*   mPickPixel;
    
    GLint mDrawIndex;
    GLint mObjectIndex;
    
    GLint mX;
    GLint mY;
    
//    GLuint mFBO;
//    GLuint mPickTex;
//    GLuint mDepthTex;
    
    public:
    CPickRenderer(int width, int height) : CRenderer(), mWidth(width), mHeight(height)
    {
      sys::info << "ogl::CPickRenderer::CPickRenderer(width, height)" << sys::endl;
    
      mDrawIndex   = 0;
      mObjectIndex = 0;
      
      mX = -1;
      mY = -1;
     
      CFramebufferBuilder* pFramebufferBuilder = CFramebufferBuilder::getInstance();
      pFramebufferBuilder->setWidth(width);
      pFramebufferBuilder->setHeight(height);
      pFramebufferBuilder->setTarget(GL_FRAMEBUFFER); 
      
      
      mPickTexture = new CTexture(GL_TEXTURE_2D, GL_RGB32UI, mWidth, mHeight, GL_RGB_INTEGER, GL_UNSIGNED_INT);
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT0, mPickTexture);
      
      mDepthTexture = new CTexture(GL_TEXTURE_2D, GL_DEPTH_COMPONENT32, mWidth, mHeight, GL_DEPTH_COMPONENT, GL_FLOAT);
      pFramebufferBuilder->addTexture(GL_DEPTH_ATTACHMENT, mDepthTexture);
      
      mFramebuffer = pFramebufferBuilder->build();
      
      delete pFramebufferBuilder;
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
//      glGenTextures(1, &mPickTex);
//      glBindTexture(GL_TEXTURE_2D, mPickTex);
//      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB32UI, mWidth, mHeight, 0, GL_RGB_INTEGER, GL_UNSIGNED_INT, NULL);
//      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//      
//      glGenTextures(1, &mDepthTex);
//      glBindTexture(GL_TEXTURE_2D, mDepthTex);
//      glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32, mWidth, mHeight, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
//      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//      
//      glGenFramebuffers(1, &mFBO);
//      glBindFramebuffer(GL_FRAMEBUFFER, mFBO);
//      glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, mPickTex,  0);
//      glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,  GL_TEXTURE_2D, mDepthTex, 0);
//      
//      GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
//      if(status != GL_FRAMEBUFFER_COMPLETE)
//      {
//        std::cerr << "> ERROR: Bad Framebuffer: " << status << sys::endl;
//      }
//      
//      glBindTexture(GL_TEXTURE_2D, 0);
//      glBindFramebuffer(GL_FRAMEBUFFER, 0);
      
      glExitIfError();
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      mPickPixel = nullptr;
    }
    
    virtual ~CPickRenderer()
    {
      _DELETE(mPickTexture);
      _DELETE(mDepthTexture);
      _DELETE(mFramebuffer);
      _DELETE(mPickPixel);
    }
    
    public:
    void render()
    {
      mDrawIndex   = 1;
      mObjectIndex = 1;
      
      mFramebuffer->bind();
      
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glFrontFace(GL_CW);
      glCullFace(GL_BACK);
      
      mProgram->enable();
      
      for(CDrawable* pDrawable : mDrawables)
      {
        // sys::info << sys::tab << "drawables..." << sys::endl;
        
        CDrawCommand* pDrawCommand  = pDrawable->getDrawCommand();
        CDrawCommand* pFirstCommand = pDrawCommand;
        //GLbitfield    options       = getOptions();
        
        if(pDrawCommand != nullptr)
        {
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
        
          mProgram->getCallback()(this, pDrawCommand);
          
          while(pDrawCommand != nullptr)
          {
            if(pDrawCommand->mTarget == GL_ELEMENT_ARRAY_BUFFER)
            {
              glDrawElements(pDrawCommand->mMode,
                             pDrawCommand->mBufferRange.getLength(), 
                             pDrawCommand->mBufferRange.getType(), 
                             (GLvoid*)(pDrawCommand->mBufferRange.getPosition() * getSizeOf(pDrawCommand->mBufferRange.getType())));
            }
            else if(pDrawCommand->mTarget == GL_ARRAY_BUFFER)
            {
              glDrawArrays(pDrawCommand->mMode,
                           pDrawCommand->mBufferRange.getPosition(),
                           pDrawCommand->mBufferRange.getLength());
            }
            else
            {
              // ERROR: Wrong buffer
            }
            
            pDrawCommand = pDrawCommand->mNext;
            
            mDrawIndex++;
          }
          
          // buffers off
          
          _DELETE(pFirstCommand);
          
          mObjectIndex++;
          mDrawableIndex++;
        }
        
      }
      
      if((!mPickPixel && mX != INVALID_UINT && mY != INVALID_UINT) || (mPickPixel && mX != mPickPixel->getX() && mY != mPickPixel->getY()))
      {
        _DELETE(mPickPixel);
        mPickPixel = new CPickPixel(mFramebuffer, GL_COLOR_ATTACHMENT0, mX, mY);
        
        // CFramebufferSelectorBuilder* pBuilder = CBuilderManager::getBuilder<CFramebufferSelectorBuilder>();
        // CFramebufferSelectorBuilder* pBuilder = new CFramebufferSelectorBuilder;
        // pBuilder->setFramebuffer(mFramebuffer);
        // pBuilder->setAttachement(GL_COLOR_ATTACHMENT0);
        // pBuilder->setX(mX);
        // pBuilder->setY(mY);
        // mSelector = pBuilder->build();
      }
      
      mProgram->disable();
      mFramebuffer->unbind();
      mDrawables.clear();
    }
    
    CPickPixel* getPickPixel() const
    { 
      return mPickPixel;
    }
    
    GLint getDrawIndex() const
    {
      return mDrawIndex;
    }
    
    GLint getObjectIndex() const
    {
      return mObjectIndex;
    }
    
    void setXY(GLint x, GLint y)
    {
      mX = x;
      mY = y;
    }
    
    CFramebuffer* getFramebuffer() const
    {
      return mFramebuffer;
    }
  };

  class CShadowRenderer : public CRenderer
  {
    protected:
    GLsizei mWidth;
    GLsizei mHeight;
    
    public:
    CShadowRenderer(GLsizei width, GLsizei height) : CRenderer()
    {
      
    }
    
    public:
    void render() 
    {
      
    }
  };

  class CGeometryRenderer : public CRenderer
  {
    public:
    enum : GLenum
    {
      POSITION_UNIT = GL_TEXTURE0,
      TEXCOORD_UNIT = GL_TEXTURE1,
      NORMAL_UNIT   = GL_TEXTURE2,
      TANGENT_UNIT  = GL_TEXTURE3,
      DIFFUSE_UNIT  = GL_TEXTURE4,
      FINAL_UNIT    = GL_TEXTURE5
    };
    
    public:
    CFramebuffer* mFramebuffer;
    
    int           mWidth;
    int           mHeight;
    
    GLenum               mWinding;
    GLenum               mCullFace;
    
    public:
    CGeometryRenderer(int width, int height) : CRenderer(), mFramebuffer(nullptr), mWidth(width), mHeight(height)
    {
      sys::info << "ogl::CGeometryRenderer::CGeometryRenderer(width, height)" << sys::endl;
      
      CFramebufferBuilder* pFramebufferBuilder = CFramebufferBuilder::getInstance();
      pFramebufferBuilder->setWidth(width);
      pFramebufferBuilder->setHeight(height);
      pFramebufferBuilder->setTarget(GL_DRAW_FRAMEBUFFER);
      
//      mFramebuffer = new CFramebuffer(GL_DRAW_FRAMEBUFFER, mWidth, mHeight);
      
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT0, new CTexture(GL_TEXTURE_2D, GL_RGB32F, mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::BILINEAR));
//      glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, *mPositionTexture, 0);
      
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT1, new CTexture(GL_TEXTURE_2D, GL_RGB32F, mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::BILINEAR));
//      glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, *mTexcoordTexture, 0);
      
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT2, new CTexture(GL_TEXTURE_2D, GL_RGB32F, mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::BILINEAR));
//      glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT2, GL_TEXTURE_2D, *mNormalTexture, 0);
      
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT3, new CTexture(GL_TEXTURE_2D, GL_RGB32F, mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::BILINEAR));
//      glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT3, GL_TEXTURE_2D, *mTangentTexture, 0);
      
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT4, new CTexture(GL_TEXTURE_2D, GL_RGB32F, mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::BILINEAR));
//      glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT4, GL_TEXTURE_2D, *mDiffuseTexture, 0);
      
      pFramebufferBuilder->addTexture(GL_DEPTH_STENCIL_ATTACHMENT, new CTexture(GL_TEXTURE_2D, GL_DEPTH32F_STENCIL8, mWidth, mHeight, GL_DEPTH_STENCIL, GL_FLOAT_32_UNSIGNED_INT_24_8_REV));
//      glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, *mDepthTexture, 0);
      
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT5, new CTexture(GL_TEXTURE_2D, GL_RGBA, mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::BILINEAR));
//      glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT5, GL_TEXTURE_2D, *mFinalTexture, 0);
      
//      GLenum drawBuffers[] { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1, GL_COLOR_ATTACHMENT2,
//                             GL_COLOR_ATTACHMENT3, GL_COLOR_ATTACHMENT4 };
//      glDrawBuffers(5, drawBuffers);
//      
//      GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
      
//      if(status != GL_FRAMEBUFFER_COMPLETE)
//      {
//        sys::info << "> ERROR: Framebuffer failed! " << status << sys::endl;
//        glExitIfError();
//      }
      
//      glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
      
      mFramebuffer = pFramebufferBuilder->build();
      
      mFramebuffer->unbind();
      
      glExitIfError();
    }
    
    virtual ~CGeometryRenderer()
    {
      sys::info << "ogl::CGeometryRenderer::~CGeometryRenderer()" << sys::endl;
      
      _DELETE(mFramebuffer);
    }
    
    public:
    void render()
    {
      mFramebuffer->bind(GL_DRAW_FRAMEBUFFER);
      glDrawBuffer(GL_COLOR_ATTACHMENT5);
      glClear(GL_COLOR_BUFFER_BIT);
      
      GLenum drawBuffers[] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1, GL_COLOR_ATTACHMENT2, GL_COLOR_ATTACHMENT3, GL_COLOR_ATTACHMENT4 };
      glDrawBuffers(5, drawBuffers);
      
      glEnable(GL_CULL_FACE);
      glCullFace(mCullFace);
      glFrontFace(mWinding);
      
      glDepthMask(GL_TRUE);   // prevent everything but this pass to write to depth buffer | this must be before glClear
      
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      glEnable(GL_DEPTH_TEST); // only geometry pass does depth test
      
      // glDisable(GL_BLEND);     // not needed in the geometru pass
      
      mProgram->enable();
      
      for(CDrawable* pDrawable : mDrawables)
      {
        // sys::info << sys::tab << "drawables..." << sys::endl;
        
        CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
        CDrawCommand*  pFirstCommand = pDrawCommand;
        CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
        GLbitfield     options       = getOptions();
        
        if(pDrawCommand != nullptr)
        {
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
        
          mProgram->getCallback()(this, pDrawCommand);
          
          while(pDrawCommand != nullptr)
          {
            if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // activate textures
            {
              pDrawCommand->mMaterial->bind();
            }
            
            pDrawStrategy->draw(pDrawCommand); // draw array/elements/instanced
            
            // materials off
            if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // activate textures
            {
              pDrawCommand->mMaterial->unbind();
            }
            
            pDrawCommand = pDrawCommand->mNext;
          }
          
          // buffers off
          
          _DELETE(pFirstCommand);
        }
      }
      
      mProgram->disable();
      
      glDepthMask(GL_FALSE);    // here depth is populated & stencil pass depends on it, but doesn't write it
      glDisable(GL_DEPTH_TEST);
      
      glExitIfError();
      
      mDrawables.clear();
      mOptions.clear();
    }
    
    CFramebuffer* getFramebuffer() const
    {
      return mFramebuffer;
    }
  
    void setClearDepth(float d)
    {
      glClearDepthf(d);
    }
    
    void setClearColor(float r, float g, float b, float a)
    {
      glClearColor(a, a, a, a);
    }
    
    void setClearColor(const math::vec4& v)
    {
      setClearColor(v.r, v.g, v.b, v.a);
    }
  
    void setWinding(GLenum winding)
    {
      mWinding = winding;
    }
    
    void setCullFace(GLenum face)
    {
      mCullFace = face;
    }
  
    CTexture* getPositionTexture()
    {
      return mFramebuffer->getTexture(GL_COLOR_ATTACHMENT0);
    }
    
    CTexture* getTexcoordTexture()
    {
      return mFramebuffer->getTexture(GL_COLOR_ATTACHMENT1);
    }
    
    CTexture* getNormalTexture()
    {
      return mFramebuffer->getTexture(GL_COLOR_ATTACHMENT2);
    }
    
    CTexture* getTangentTexture()
    {
      return mFramebuffer->getTexture(GL_COLOR_ATTACHMENT3);
    }
    
    CTexture* getDepthTexture()
    {
      return mFramebuffer->getTexture(GL_DEPTH_STENCIL_ATTACHMENT);
    }
    
    CTexture* getDiffuseTexture()
    {
      return mFramebuffer->getTexture(GL_COLOR_ATTACHMENT4);
    }
    
    CTexture* getFinalTexture()
    {
      return mFramebuffer->getTexture(GL_COLOR_ATTACHMENT5);
    }
  };

  class CPointLightRenderer : public CRenderer
  {
    public:
    std::vector<CLight*> mLights;
    CPointLight*         mPointLight;
    
    GLenum               mWinding;
    GLenum               mCullFace;
    
    int           mWidth;
    int           mHeight;
    
    GLuint        mFBO;
    
    CGeometryRenderer* mGeometryRenderer;
    
    CProgram* mLightProgram;
    CProgram* mStencilProgram;
    
    public:
    CPointLightRenderer(int width, int height) : CRenderer(), mWidth(width), mHeight(height), mGeometryRenderer(nullptr)
    {
      sys::info << "ogl::CPointLightRenderer::CPointLightRenderer(width, height)" << sys::endl;
      
      mFBO = 0;
      mLightProgram = nullptr;
      mStencilProgram = nullptr;
      
      glExitIfError();
    }
    
    virtual ~CPointLightRenderer()
    {
      sys::info << "ogl::CPointLightRenderer::~CPointLightRenderer()" << sys::endl;
    }
    
    public:
    void render()
    {
      assert(mGeometryRenderer != nullptr);
      
      //mGeometryRenderer->getFramebuffer()->bind(GL_READ_FRAMEBUFFER);

      //glViewport(0, 0, mWidth, mHeight);
    
      //glEnable(GL_DEPTH_TEST);
      //glDepthFunc(GL_LEQUAL);
      //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      //glEnable(GL_CULL_FACE);
      //glCullFace(mCullFace);
      
      //glEnable(GL_POLYGON_OFFSET_FILL);
      //glPolygonOffset(1.0f, 1.0f);

      CDrawable*     pDrawable     = mDrawables[0]; // must have one drawable
      CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
      CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
      
      glBindVertexArray(pDrawCommand->mVAO);
      glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
      
      glEnable(GL_STENCIL_TEST);
      
      for(CLight* pLight : mLights)
      {
        mPointLight           = dynamic_cast<ogl::CPointLight*>(pLight);
        ogl::CObject* pObject = dynamic_cast<ogl::CObject*>(pDrawable);
      
        // stencil pass
        mStencilProgram->enable();
        
        glDrawBuffer(GL_NONE); // mGeometryRenderer bind for stencil pass
        
        glEnable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glClear(GL_STENCIL_BUFFER_BIT);
        glStencilFunc(GL_ALWAYS, 0, 0x00);   // always succeed
        glStencilOpSeparate(GL_BACK,  GL_KEEP, GL_INCR_WRAP, GL_KEEP); // incress stencil value for back faces
        glStencilOpSeparate(GL_FRONT, GL_KEEP, GL_DECR_WRAP, GL_KEEP); // decress stencil value for front faces
        
        mStencilProgram->getCallback()(this, pObject->getDrawCommand());
        
        pDrawStrategy->draw(pDrawCommand); // maby this should be replaced with drawing a circle
        
        // light pass
        mLightProgram->enable();
        
        glDrawBuffer(GL_COLOR_ATTACHMENT5); // final
        mGeometryRenderer->getPositionTexture()->bind(CGeometryRenderer::POSITION_UNIT); // CTechnique::POSITION_UNIT
        //mGeometryRenderer->getPositionTexture()->bind(CGeometryRenderer::TEXCOORD_UNIT);
        mGeometryRenderer->getNormalTexture()->bind(CGeometryRenderer::NORMAL_UNIT);
        //mGeometryRenderer->getNormalTexture()->bind(CGeometryRenderer::TANGENT_UNIT);
        mGeometryRenderer->getDiffuseTexture()->bind(CGeometryRenderer::DIFFUSE_UNIT);
        
        glStencilFunc(GL_NOTEQUAL, 0, 0xFF); // -1 + 1 = 0 // draw if not equal to 0
        glDisable(GL_DEPTH_TEST);            // objects behind & in front will have stencil 0, inside will be 1
        glEnable(GL_BLEND);                  // enable blending - geometry pass didn't need it
        glBlendEquation(GL_FUNC_ADD);
        glBlendFunc(GL_ONE, GL_ONE);      // 1 * src + 1 * dst
        glEnable(GL_CULL_FACE);
        glCullFace(GL_FRONT);
        
        mLightProgram->getCallback()(this, pObject->getDrawCommand());
        
        pDrawStrategy->draw(pDrawCommand); // draw array/elements/instanced
        
        glDisable(GL_BLEND);
        
        mLightProgram->disable();
      }
      
      glDisable(GL_STENCIL_TEST);
      
      _DELETE(pDrawCommand);
      
      glExitIfError(); // should be replaced throw Exception if error
      
      mLights.clear();
      mDrawables.clear();
      mOptions.clear();
    }
    
    void setLightProgram(CProgram* program)
    {
      mLightProgram = program;
    }
    
    void setStencilProgram(CProgram* program)
    {
      mStencilProgram = program;
    }
    
    CProgram* getLightProgram()
    {
      return mLightProgram;
    }
    
    CProgram* getStencilProgram()
    {
      return mStencilProgram;
    }
    
    void setGeometryRenderer(CGeometryRenderer* pGeometryRenderer)
    {
      mGeometryRenderer = pGeometryRenderer;
    }
    
    CPointLight* getPointLight()
    {
      return mPointLight;
    }
    
    CLight* getLight(size_t i) 
    {
      return mLights[i];
    }
    
    std::vector<CLight*>& getLights()
    {
      return mLights;
    }
  
    void addLight(CLight* pLight)
    {
      mLights.push_back(pLight);
    }
    
    void setWinding(GLenum winding)
    {
      mWinding = winding;
    }
    
    void setCullFace(GLenum face)
    {
      mCullFace = face;
    }
  
    void setClearDepth(float d)
    {
      glClearDepthf(d);
    }
    
    void setClearColor(float r, float g, float b, float a)
    {
      glClearColor(a, a, a, a);
    }
    
    void setClearColor(const math::vec4& v)
    {
      setClearColor(v.r, v.g, v.b, v.a);
    }
  };
  
  class CDirectLightRenderer : public CRenderer
  {
    public:
    std::vector<CLight*> mLights;
    CDirectLight*        mDirectLight;
    
    int mWidth;
    int mHeight;
    
    GLuint mFBO;
    
    CGeometryRenderer* mGeometryRenderer;
    
    public:
    CDirectLightRenderer(int width, int height) : CRenderer(), mWidth(width), mHeight(height), mGeometryRenderer(nullptr)
    {
      sys::info << "ogl::CDirectLightRenderer::CDirectLightRenderer(width, height)" << sys::endl;
      
      mFBO = 0;
      
      glExitIfError();
    }
    
    virtual ~CDirectLightRenderer()
    {
      sys::info << "ogl::CDirectLightRenderer::~CDirectLightRenderer()" << sys::endl;
    }
    
    public:
    void render()
    {
      assert(mGeometryRenderer != nullptr);
    
      glDisable(GL_DEPTH_TEST);
      glEnable(GL_BLEND);                 // enable blending - geometry pass didn't need it
      glBlendEquation(GL_FUNC_ADD);       
      glBlendFunc(GL_ONE, GL_ONE);        // 1 * src + 1 * dst
      
      glDisable(GL_CULL_FACE);
      
      glDrawBuffer(GL_COLOR_ATTACHMENT5); // final
      mGeometryRenderer->getPositionTexture()->bind(CGeometryRenderer::POSITION_UNIT); // CTechnique::POSITION_UNIT
      //mGeometryRenderer->getPositionTexture()->bind(CGeometryRenderer::TEXCOORD_UNIT);
      mGeometryRenderer->getNormalTexture()->bind(CGeometryRenderer::NORMAL_UNIT);
      //mGeometryRenderer->getNormalTexture()->bind(CGeometryRenderer::TANGENT_UNIT);
      mGeometryRenderer->getDiffuseTexture()->bind(CGeometryRenderer::DIFFUSE_UNIT);
      
      mProgram->enable();

      CDrawable*     pDrawable     = mDrawables[0]; // must have one drawable
      CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
      CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
      
      glBindVertexArray(pDrawCommand->mVAO);
      glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
      
      for(CLight* pLight : mLights)
      {
        mDirectLight          = dynamic_cast<ogl::CDirectLight*>(pLight);
        ogl::CObject* pObject = dynamic_cast<ogl::CObject*>(pDrawable);
        
        mProgram->getCallback()(this, pObject->getDrawCommand());
        
        pDrawStrategy->draw(pDrawCommand); // draw array/elements/instanced
      }
      
      glDisable(GL_BLEND);
      
      _DELETE(pDrawCommand);
      
      mProgram->disable();
      
      glExitIfError(); // should be replaced throw Exception if error
      
      mLights.clear();
      mDrawables.clear();
      mOptions.clear();
    }
    
    void setGeometryRenderer(CGeometryRenderer* pGeometryRenderer)
    {
      mGeometryRenderer = pGeometryRenderer;
    }
    
    CDirectLight* getDirectLight()
    {
      return mDirectLight;
    }
    
    CLight* getLight(size_t i) 
    {
      return mLights[i];
    }
  
    void addLight(CLight* pLight)
    {
      mLights.push_back(pLight);
    }
  };

  class CForwardRenreder : public CRenderer
  {
    protected:
    std::vector<CLight*> mLights;
    
    GLuint  mFBO;
    
    GLsizei mWidth;
    GLsizei mHeight;
    
    CLight* mLight;
    
    public:
    CForwardRenreder() 
    : CRenderer(), mFBO(0), mWidth(0), mHeight(0), mLight(nullptr)
    {
      mFBO = 0;
    }
    
    CForwardRenreder(GLsizei width, GLsizei height) 
    : CRenderer(), mFBO(0), mWidth(width), mHeight(height)
    {
      mFBO = 0;
    }
    
    virtual ~CForwardRenreder()
    {
      
    }
    
    public:
    void render()
    {
      sys::info << "ogl::CForwardRenreder::render()" << sys::endl;
      
      //glEnable(GL_CULL_FACE);
      //glCullFace(GL_BACK);
      //glFrontFace(GL_CCW);
      
      // glBindFramebuffer(GL_FRAMEBUFFER, mFBO);
      
      glEnable(GL_DEPTH_TEST);
      glDepthRange(0.0f, 1.0f);
      glDepthFunc(GL_LEQUAL);
      glDepthMask(GL_TRUE); // before clearing enable depth writing
      glClearDepthf(1.0f);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT); // clear color + depth + stencil buffers
      
//      CProgramManager*       pProgramManager = CProgramManager::getInstance();
      CProgramDescriptor* pProgramDescriptor = new CProgramDescriptor;
      CProgram*                    pProgram  = nullptr;
      
      { // render scene into depth
        sys::info << sys::tab << "depth pass" << sys::endl;
        
        glDrawBuffer(GL_NONE);      // disable write to color buffer for depth write
        
        mDrawableIndex = 0;
        
        for(CDrawable* pDrawable : mDrawables) // for all drawables
        {
          CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
          CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
          
          // find the right program
//          pProgramDescriptor->setRenderingScope(ERenderingScope::NONE);        // null shader
//          pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType()); // eg: EDrawStrategyType::INSTANCED
//          pProgramDescriptor->setShadingMode(EShadingMode::NONE);
//          pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//          pProgram = pProgramManager->getProgram(*pProgramDescriptor);
          
          
          // sys::info << (*pProgramDescriptor) << sys::endl;
          setProgram(pProgram);
          
          // TODO: replace by draw command builder
          // CDrawCommandBuilder* pDrawCommandBuilder = new CDrawCommandBuilder;
          // pDrawCommandBuilder->setDrawable(pDrawable);
          // pDrawCommandBuilder->setProgram(pProgram);
          // pDrawCommandBuilder->setOptions(EDrawOptions::USE_MATERIALS);
          // CDrawCommand* pDrawCommand = pDrawCommandBuilder->build();
          pDrawCommand->mMode = mProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
          
          // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
          
          // TODO: combine these to into one, using a check for runnting general stuff vs. object specific stuff
          // TODO: use ProgramManager to enable programs, maybe prevent enabling/running same program twice
          pProgram->enable();
          mProgram->getCallback()(this, pDrawCommand);
          
          // don't enable materials 
          
          // draw
          pDrawStrategy->draw(pDrawCommand); // draw single/instanced
          // pDrawCommand = pDrawCommand->next(); // this sets mMode for pDrawCommand using parent mode
          
          _DELETE(pDrawCommand);
          
          ++mDrawableIndex;
        }
      }
      
      /*
      
      { // render depth buffer as fullscreen quad 
        sys::info << sys::tab << "draw depth buffer" << sys::endl;
        //glDisable(GL_CULL_FACE);
        glDrawBuffer(GL_BACK);
        glDisable(GL_DEPTH_TEST);
        
        GLfloat* pixels = new GLfloat[mWidth * mHeight];
        memset(pixels, 0, mWidth * mHeight * sizeof(GLfloat));
        // glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glReadPixels(0, 0, mWidth, mHeight, GL_DEPTH_COMPONENT, GL_FLOAT, pixels);
        
        for(int i = 0; i < mWidth * mHeight; ++i)
          pixels[i] = (2.0f * mCamera->getNear()) / (mCamera->getFar() + mCamera->getNear() - pixels[i] * (mCamera->getFar() - mCamera->getNear()));
        
        static GLuint tex = 0;
        if( tex > 0 )
          glDeleteTextures( 1, &tex );
        glGenTextures(1, &tex);
        glBindTexture( GL_TEXTURE_2D, tex);
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
        glTexImage2D( GL_TEXTURE_2D, 0, GL_R8, mWidth, mHeight, 0, GL_RED, GL_FLOAT, pixels);
        
        pProgramDescriptor->setRenderingScope(ERenderingScope::QUAD);
        pProgramDescriptor->setDrawStrategyType(EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ELightingPass::NONE);
        pProgram = pProgramManager->getProgram(*pProgramDescriptor);
        setProgram(pProgram);
        
        pProgram->enable();
        pProgram->getCallback()(this, nullptr);
        
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        
        delete [] pixels;
      }
      
      */
      
      glEnable(GL_STENCIL_TEST);
      
      { // render shadow volume into stencil
        sys::info << sys::tab << "shadow volume pass" << sys::endl;
        
        // glDrawBuffer(GL_BACK);
        
        glDepthMask(GL_FALSE);                // disable writing to depth - write to color already disabled
        glEnable(GL_DEPTH_CLAMP);             // clamp at the max depth value - for the projected-to-infinite vertices
        glDisable(GL_CULL_FACE);              // no face culling - we need front & back of the shadow volume
        
        glStencilFunc(GL_ALWAYS, 0x0, 0xFF);  // always pass stencil test - only depth matters here
        
        // using the alread computed depth buffer - draw volume shadow - draw back & front faces
        // if the resulting back-facing fragment has a depth lower than the depth buffer =>  stencil++
        // if the resulting front-facing fragment has a depth lower than the depth buffer => stencil--
        glStencilOpSeparate(GL_BACK,  GL_KEEP, GL_INCR_WRAP, GL_KEEP); // back-facing frag depth fail increese stencil
        glStencilOpSeparate(GL_FRONT, GL_KEEP, GL_DECR_WRAP, GL_KEEP); // front-facing frag depth fail decresse stencil
        
        // for each light...
        for(CLight* pLight : mLights) // each light generates a a shadow volume for each object
        {
          mDrawableIndex = 0; 
          
          // use light to project stencil shadow using mesh silhouette
          mLight = pLight;
          
          // sys::info << (*mLight) << sys::endl;
        
          for(CDrawable* pDrawable : mDrawables)
          {
            GLbitfield options = getOptions();
            if(options & ~EDrawOptions::NOSHADOWCAST)  // for each shadow casting object
            {
              CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
              CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();

              // find the right program
//              pProgramDescriptor->setRenderingScope(ERenderingScope::SHADOW_VOLUME);
//              pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType());
//              pProgramDescriptor->setShadingMode(EShadingMode::NONE);
//              pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//              pProgram = pProgramManager->getProgram(*pProgramDescriptor);
              setProgram(pProgram);
              
              // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
              glBindVertexArray(pDrawCommand->mVAO);
              glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // MUST
              
              // TODO: combine these to into one, using a check for runnting general stuff vs. object specific stuff
              pProgram->enable(); // shadow program
              mProgram->getCallback()(this, pDrawCommand);
              
              // don't enable materials 
              
              pDrawStrategy->draw(pDrawCommand); // draw single/instanced
              
              _DELETE(pDrawCommand);
            }
            ++mDrawableIndex;
          }
        }
        
        glDisable(GL_DEPTH_CLAMP); // restore
        glEnable(GL_CULL_FACE);
      }
      
      { // render shadowed scene (diffuse light)
        sys::info << sys::tab << "diffuse(shadowed) pass" << sys::endl;
        
        glDrawBuffer(GL_BACK); // enable writing into the color buffer
        glDepthMask(GL_FALSE);
        glStencilFunc(GL_EQUAL, 0x0, 0xFF);     // draw only fragments with stencil value = 0 // +1-1 = 0
        glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP); // prevent update to the stencil buffer by keeping prev. values
        
        // for(CLight* pLight : mLights)
        //   pLight->mAmbientIntensity = 0.0f; // no ambient color this pass
        
        mDrawableIndex = 0;
        
        for(CDrawable* pDrawable : mDrawables)
        {
          GLbitfield options = getOptions();
          
          CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
          CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
          
          // find the right program
//          pProgramDescriptor->setRenderingScope(ERenderingScope::FORWARD);
//          pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType()); // should be EDrawStrategyType::SINGLE
//          pProgramDescriptor->setShadingMode(ogl::EShadingMode::BLINN_PHONG);
//          pProgramDescriptor->setLightingPass(ELightingPass::DIFFUSE);
//          // sys::info << (*pProgramDescriptor) << sys::endl;
//          pProgram = pProgramManager->getProgram(*pProgramDescriptor);
//          setProgram(pProgram);
          
          // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // MUST
          
          // TODO: combine these to into one, using a check for runnting general stuff vs. object specific stuff
          pProgram->enable(); // lighting(diffuse) program
          mProgram->getCallback()(this, pDrawCommand);
          
          if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // activate textures
          {
            pDrawCommand->mMaterial->bind();
          }
          
          pDrawStrategy->draw(pDrawCommand); // draw single/instanced
          
          if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // deactivate textures
          {
            pDrawCommand->mMaterial->unbind();
          }
          
          // pDrawCommand = pDrawCommand->next();
          
          _DELETE(pDrawCommand);
          
          ++mDrawableIndex;
        }
      }
      
      glDisable(GL_STENCIL_TEST); // cancels glStencilFunc() filter for fragments with stencil value 0
      
      { // render ambient light
        sys::info << sys::tab << "ambient pass" << sys::endl;
        
        // glDrawBuffer(GL_BACK); color writing is already enabled from the diffuse pass
        
        glEnable(GL_BLEND);
        glBlendEquation(GL_FUNC_ADD);
        glBlendFunc(GL_ONE, GL_ONE);
        
        // for(CLight* pLight : mLights)
        //   pLight->mDiffuseIntensity = 0.0f; // no ambient color this pass
        
        mDrawableIndex = 0;
        
        for(CDrawable* pDrawable : mDrawables)
        {
          GLbitfield options = getOptions();
          
          CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
          CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
          
          // find the right program
//          pProgramDescriptor->setRenderingScope(ERenderingScope::FORWARD);
//          pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType());
//          pProgramDescriptor->setShadingMode(ogl::EShadingMode::BLINN_PHONG);
//          pProgramDescriptor->setLightingPass(ELightingPass::AMBIENT);
//          // sys::info << (*pProgramDescriptor) << sys::endl;
//          pProgram = pProgramManager->getProgram(*pProgramDescriptor);
//          setProgram(pProgram);
          
          // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // MUST
          
          // TODO: combine these to into one, using a check for runnting general stuff vs. object specific stuff
          pProgram->enable(); // lighting(diffuse) program
          mProgram->getCallback()(this, pDrawCommand);
          
          if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // activate textures
          {
            pDrawCommand->mMaterial->bind();
          }
        
          pDrawStrategy->draw(pDrawCommand); // draw single/instanced
          
          if(options & ~EDrawOptions::NOMATERIAL && pDrawCommand->mMaterial) // deactivate textures
          {
            pDrawCommand->mMaterial->unbind();
          }
        
          // pDrawCommand = pDrawCommand->next();
            
          _DELETE(pDrawCommand);
          
          ++mDrawableIndex;
        }
        
        glDisable(GL_BLEND);
      }
      
      /*
      
      { // draw silhouette for testing
        sys::info << sys::tab << "silhouette pass" << sys::endl;
      
        glDrawBuffer(GL_BACK);
        glStencilFunc(GL_ALWAYS, 0x0, 0xFF);
        glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
        
        for(CLight* pLight : mLights) // each light generates a a shadow volume for each object
        {
          mDrawableIndex = 0; 
          
          // use light to project stencil shadow using mesh silhouette
          mLight = pLight;
          
          // sys::info << (*mLight) << sys::endl;
        
          for(CDrawable* pDrawable : mDrawables)
          {
            GLbitfield options = getOptions();
            if(options & ~EDrawOptions::NOSHADOWCAST)  // for each shadow casting object
            {
              CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
              CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();

              // find the right program
              pProgramDescriptor->setRenderingScope(ERenderingScope::SILHOUETTE);
              pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType());
              pProgramDescriptor->setShadingMode(EShadingMode::FLAT);
              pProgramDescriptor->setLightingPass(ELightingPass::NONE);
              // sys::info << (*pProgramDescriptor) << sys::endl;
              pProgram = pProgramManager->getProgram(*pProgramDescriptor);
              setProgram(pProgram);
              
              // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
              glBindVertexArray(pDrawCommand->mVAO);
              glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // MUST
              
              // TODO: combine these to into one, using a check for runnting general stuff vs. object specific stuff
              pProgram->enable(); // shadow program
              mProgram->getCallback()(this, pDrawCommand);
              
              // don't enable materials 
              
              pDrawStrategy->draw(pDrawCommand); // draw single/instanced
              
              _DELETE(pDrawCommand);
            }
            ++mDrawableIndex;
          }
        }
      }
      
      */
      
      { // draw lights icons
        sys::info << sys::tab << "draw light icons" << sys::endl;
        
        for(CLight* pLight : mLights)
        {
          CPointLight* pPointLight = dynamic_cast<CPointLight*>(pLight);
        
//          pProgramDescriptor->setRenderingScope(ERenderingScope::FORWARD);        // null shader
//          pProgramDescriptor->setDrawStrategyType(EDrawStrategyType::SINGLE); // eg: EDrawStrategyType::INSTANCED
//          pProgramDescriptor->setShadingMode(EShadingMode::FLAT);
//          pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//          pProgram = pProgramManager->getProgram(*pProgramDescriptor);
//          setProgram(pProgram);
          
          pProgram->enable();
          mProgram->getCallback()(this, pPointLight->getDrawCommand());
          
          pLight->draw();
        }
      }
      
      // throw EXCEPTION << "STOP!";
      
      _DELETE(pProgramDescriptor);
      
      glExitIfError();
      
      mLights.clear();
      mDrawables.clear();
      mOptions.clear();
    }
    
    void clear() const
    {
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
      glBindFramebuffer(GL_FRAMEBUFFER, mFBO);
      glViewport(0, 0, mWidth, mHeight);
    }
    
    CLight* getLight() const
    {
      return mLight;
    }
    
    CLight* getLight(size_t i) 
    {
      return mLights[i];
    }
    
    std::vector<CLight*>& getLights()
    {
      return mLights;
    }
  
    void addLight(CLight* pLight)
    {
      mLights.push_back(pLight);
    }
  };
  
  class CMotionBlurRenderer : public CRenderer
  {
    std::vector<CLight*> mLights;
    
    CFramebuffer*  mFBO;
    
    GLsizei mWidth;
    GLsizei mHeight;
    
    CLight* mLight;
    
    public:
    CMotionBlurRenderer() 
    : CRenderer(), mFBO(nullptr), mWidth(0), mHeight(0)
    {
      mFBO = 0;
    }
    
    CMotionBlurRenderer(GLsizei width, GLsizei height) 
    : CRenderer(), mFBO(nullptr), mWidth(width), mHeight(height)
    {
      CFramebufferBuilder* pFramebufferBuilder = CFramebufferBuilder::getInstance();
      
      pFramebufferBuilder->setWidth(width);
      pFramebufferBuilder->setHeight(height);
      pFramebufferBuilder->setTarget(GL_DRAW_FRAMEBUFFER);
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT0, new CTexture(GL_TEXTURE_2D, GL_RGB32F, mWidth, mHeight, GL_RGB, GL_FLOAT, CTexture::EFiltering::NEAREST));
      pFramebufferBuilder->addTexture(GL_COLOR_ATTACHMENT1, new CTexture(GL_TEXTURE_2D, GL_RG32F,  mWidth, mHeight, GL_RG,  GL_FLOAT, CTexture::EFiltering::NEAREST));
      pFramebufferBuilder->addTexture(GL_DEPTH_ATTACHMENT,  new CTexture(GL_TEXTURE_2D, GL_DEPTH_COMPONENT, mWidth, mHeight, GL_DEPTH_COMPONENT, GL_FLOAT, CTexture::EFiltering::BILINEAR));
      
      mFBO = pFramebufferBuilder->build();
      
      glExitIfError();
    }
  
    virtual ~CMotionBlurRenderer()
    {
      delete mFBO;
    }
  
    public:
    void render()
    {
      sys::info << "ogl::CMotionBlurRenderer::render()" << sys::endl;
      
//      CProgramManager*       pProgramManager = CProgramManager::getInstance();
      CProgramDescriptor* pProgramDescriptor = new CProgramDescriptor;
      CProgram*                    pProgram  = nullptr;
      
      // glViewport(0, 0, mWidth, mHeight);
      
      glEnable(GL_DEPTH_TEST);
      // glDepthFunc(GL_LEQUAL);
      // glDepthMask(GL_FALSE);
      
      glEnable(GL_CULL_FACE);
      glCullFace(GL_BACK);
      glFrontFace(GL_CCW);
      
      { // render pass
        sys::info << " > INFO: render pass" << sys::endl;
        mFBO->bind();
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        mDrawableIndex = 0;
        
        for(CDrawable* pDrawable : mDrawables)
        {
          GLbitfield options = getOptions();
          
          CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
          CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
        
//          pProgramDescriptor->setRenderingScope(ERenderingScope::FORWARD);
//          pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType());
//          pProgramDescriptor->setShadingMode(EShadingMode::FLAT);
//          pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//          pProgramDescriptor->setRenderingOptions((uint)(ERenderingOptions::MOTION_BLUR));
//          pProgram = pProgramManager->getProgram(*pProgramDescriptor);
//          setProgram(pProgram); // MUST
          
          pDrawCommand->mMode = mProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
          
          // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
          
          pProgram->enable();
          pProgram->getCallback()(this, pDrawCommand);
          
          // TODO: draw command builder?
          // CDrawCommandBuilder* pDrawCommandBuilder = new CDrawCommandBuilder;
          // pDrawCommandBuilder->setProgram(pProgram); // and change pDrawCommand->mMode to GL_PATCHES if necessary
          // pDrawCommandBuilder->setDrawable(pDrawable);
          // pDrawCommandBuilder->setRendererd(this);
          // CDrawCommand* pDrawCommand = pDrawCommandBuilder->build()
          
          CDrawCommand* pFirstCommand = pDrawCommand;
          while (pDrawCommand != nullptr) 
          {
            if((options & ~EDrawOptions::NOMATERIAL) && (pDrawCommand->mMaterial != nullptr)) // activate textures
            {
              pDrawCommand->mMaterial->bind();
            }
            
            pDrawStrategy->draw(pDrawCommand); // draw single/instanced
            
            if((options & ~EDrawOptions::NOMATERIAL) && (pDrawCommand->mMaterial != nullptr)) // deactivate textures
            {
              pDrawCommand->mMaterial->unbind();
            }
          
            pDrawCommand = pDrawCommand->next();
          }
          _DELETE(pFirstCommand);
          
          // glBindVertexArray(0);

          ++mDrawableIndex;
        }
        
        glExitIfError();
      }
      
      { // motion blur pass
        sys::info << " > INFO: motion blur pass" << sys::endl;
        
        // glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0); // mMainFbo.bind(GL_DRAW_FRAMEBUFFER);
        // mFBO->unbind();
        
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0); // bind for write
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        mFBO->bind(GL_READ_FRAMEBUFFER);           // bind for read
        mFBO->getTexture(GL_COLOR_ATTACHMENT0)->bind(GL_TEXTURE0);
        mFBO->getTexture(GL_COLOR_ATTACHMENT1)->bind(GL_TEXTURE1);
        
//        pProgramDescriptor->setRenderingScope(ERenderingScope::MOTION_BLUR);
//        pProgramDescriptor->setDrawStrategyType(EDrawStrategyType::NONE);
//        pProgramDescriptor->setShadingMode(EShadingMode::NONE);
//        pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//        pProgramDescriptor->setRenderingOptions((uint)(ERenderingOptions::NONE));
//        pProgram = pProgramManager->getProgram(*pProgramDescriptor);
//        setProgram(pProgram); // MUST
        
        pProgram->enable();
        pProgram->getCallback()(this, nullptr);
        
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        
        mFBO->getTexture(GL_COLOR_ATTACHMENT0)->unbind(GL_TEXTURE0);
        mFBO->getTexture(GL_COLOR_ATTACHMENT1)->unbind(GL_TEXTURE1);
        
        glExitIfError();
      }
      
      _DELETE(pProgramDescriptor);
      
      glExitIfError();
      
      mLights.clear();
      mDrawables.clear();
      mOptions.clear();
    }
    
    CLight* getLight(size_t i) 
    {
      return mLights[i];
    }
    
    std::vector<CLight*>& getLights()
    {
      return mLights;
    }
  
    void addLight(CLight* pLight)
    {
      mLights.push_back(pLight);
    }
  };
  
  class CPCFShadowMapRenderer : public CRenderer
  {
    protected:
    std::vector<CLight*> mLights;
    
    GLsizei mWidth;
    GLsizei mHeight;
    
    GLuint mVBO;
    GLuint mVAO;
    
    CFramebuffer* mFbo;
    
    std::map<CLight*, CShadow*> mShadows;
    
    public:
    CPCFShadowMapRenderer(GLsizei width, GLsizei height) 
    : CRenderer(), mWidth(width), mHeight(height), mFbo(nullptr)
    {
      mFbo = new CFramebuffer(mWidth, mHeight); // TODO: this binds to 0, need a better implementation
      
      ///////////////////////////////////////////////////////////////////////
      
      /*
      glGenTextures(1, &mShadowMap);            // create texture for depth buffer
      glBindTexture(GL_TEXTURE_2D, mShadowMap);
      glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32, width, height, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
      //glTexStorage2D(GL_TEXTURE_2D, 1, GL_DEPTH_COMPONENT32, width, height);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);        // turn on tex comparison
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
      
      // GL_DEPTH_COMPONENT = 1xfloat
      // GL_RGBA = 4xfloat
      
      glGenFramebuffers(1, &mShadowFbo); // create fbo
      glBindFramebuffer(GL_FRAMEBUFFER, mShadowFbo);
      glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, mShadowMap, 0);
      //glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, mShadowMap, 0);
      
      sys::info << sys::tab << "mShadowFbo: " <<  mShadowFbo << sys::endl;
      sys::info << sys::tab << "mShadowMap: " <<  mShadowMap << sys::endl;
      
      glDrawBuffer(GL_NONE); // disable write to color buffer
      glReadBuffer(GL_NONE);
      
      GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
      if(status != GL_FRAMEBUFFER_COMPLETE)
        std::cerr << "> ERROR: fbo error, status: " << status << sys::endl;
        
      glBindFramebuffer(GL_FRAMEBUFFER, 0);
      
      */
      
      /////////////////////////////////////////////////////////////////////
      
      const float vertices[24] = {
        -1.0, -1.0, 0.0, 1.0, 0.0, 0.0,
         1.0, -1.0, 0.0, 1.0, 1.0, 0.0,
        -1.0,  1.0, 0.0, 1.0, 0.0, 1.0,
         1.0,  1.0, 0.0, 1.0, 1.0, 1.0 };
      
      glGenBuffers(1, &mVBO);
      glBindBuffer(GL_ARRAY_BUFFER, mVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
      
      glGenVertexArrays(1, &mVAO);
      glBindVertexArray(mVAO);
      glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)((0) * sizeof(GLfloat)));
      glEnableVertexAttribArray(0);
      glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)((4) * sizeof(GLfloat)));
      glEnableVertexAttribArray(1);
      
      glBindVertexArray(0);
      glBindBuffer(GL_ARRAY_BUFFER, 0);
      
      // TODO: Builder factory/manager that instantiates IBuilder relative to the thread
      //       If a thread asks for a builder, return one from the it's repository - the builder stays singletone on that thread
      //       The singleton doesn't cross threads, if another thread asks for a builder, create a new one on that thread
      
      // TODO: create a CFramebufferManager that helps you bind which one should be active
      // CFramebufferManager::getInstance()->getFramebuffer(NGIN)->bind(CFramebuffer::READ);
      
      glExitIfError();
    }
    
    virtual ~CPCFShadowMapRenderer()
    {
      delete mFbo;
      for(auto it = mShadows.begin(); it != mShadows.end(); ++it)
        delete it->second;
    }
    
    public:
    void render()
    {
      sys::info << "ogl::CPCFShadowMapRenderer::render()" << sys::endl;
      
//      CProgramManager*       pProgramManager = CProgramManager::getInstance();
//      CProgramDescriptor* pProgramDescriptor = new CProgramDescriptor;
      
      glEnable(GL_CULL_FACE);
      glFrontFace(GL_CCW);
      
      { // shadow map pass
        sys::info << sys::tab << "shadow map pass" << sys::endl;
        
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
        glDepthMask(GL_TRUE);
        
        glExitIfError();
        
        static const struct {
          GLenum     eTarget;
          math::vec3 vDirection;
          math::vec3 vUp;
        } oPointLightConfigs[6] = {
          // face, direction, up
          { GL_TEXTURE_CUBE_MAP_POSITIVE_X, math::vec3( 1.0f, 0.0, 0.0f), math::vec3(0.0f, 1.0f, 0.0f) },
          { GL_TEXTURE_CUBE_MAP_NEGATIVE_X, math::vec3(-1.0f, 0.0, 0.0f), math::vec3(0.0f, 1.0f, 0.0f) },
          { GL_TEXTURE_CUBE_MAP_POSITIVE_Y, math::vec3( 0.0f,-1.0, 0.0f), math::vec3(0.0f, 0.0f, 1.0f) },
          { GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, math::vec3( 0.0f, 1.0, 0.0f), math::vec3(0.0f, 0.0f,-1.0f) },
          { GL_TEXTURE_CUBE_MAP_POSITIVE_Z, math::vec3( 0.0f, 0.0, 1.0f), math::vec3(0.0f, 1.0f, 0.0f) },
          { GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, math::vec3( 0.0f, 0.0,-1.0f), math::vec3(0.0f, 1.0f, 0.0f) }
        };
        
        for(CLight* pLight : mLights)
        {
          sys::info << sys::tab << "for type " << pLight->getType() << " light" << sys::endl;
          
          // for each light bind a shadow framebuffer
          CShadow* pShadow = getShadow(pLight);
          
          ushort nLayers = pLight->getType() == CLight::POINT ? 6 : 1;
          
          for(ushort i = 0; i < nLayers; ++i) // 6 for point, 1 for spot & direct
          {
            if(nLayers == 1)
              pShadow->bind();                                  // bind shadow fbo for writing
            else
              pShadow->bind(oPointLightConfigs[i].eTarget);
              
            sys::info << sys::tab << "layer " << i << sys::endl;
            
            glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);       // mask-of color rendering
            glDrawBuffer(GL_NONE);                                     // disable write to color buffer
            glReadBuffer(GL_NONE);                                     // disable read  from color buffer
            glCullFace(GL_FRONT);                                      // render only backfaces - aboid self-shadowing
            pShadow->clear(CFramebuffer::DEPTH | CFramebuffer::COLOR); // clear shadow fbo depth buffer
            
            glExitIfError();
            
            mDrawableIndex = 0; // MUST
            for(CDrawable* pDrawable : mDrawables)
            {
              GLbitfield options = getOptions();
              if(options & ~EDrawOptions::NOSHADOWCAST) // no drawing objects that don't cast shadows
              {
                sys::info << sys::tab << "drawing object " << mDrawableIndex << sys::endl;
                
                // TODO:
                // CShadowMapRenderPass*& pRenderPass = mRenderPasses[ERenderPass::SHADOW_MAP];
                // pRenderPass->setLight(pLight);
                // pRenderPass->setRenderer(this);
                // pRenderPass->render();
                
                CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
                CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
              
//                pProgramDescriptor->setRenderingScope(ERenderingScope::NONE);
//                pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType());
//                pProgramDescriptor->setShadingMode(EShadingMode::FLAT);
//                pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//                pProgramDescriptor->setRenderingOptions(ERenderingOptions::NONE);
//                mProgram = pProgramManager->getProgram(*pProgramDescriptor); // TODO: might be no need for member program
              
                pDrawCommand->mMode = mProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
              
                { // program setup
                  mProgram->enable();
                  
                  math::mat4 mM = pDrawCommand->mModelMatrix;
                  math::mat4 mV;
                  math::mat4 mP;
                  
                  switch(pLight->getType())
                  {
                    case ogl::CLight::DIRECT:
                    {
                      ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
                      mV = math::lookat(-pDirectLight->mDirection, math::O , math::Y);
                      mP = math::ortho(-5.0f, +5.0f, -5.0f, +5.0f, -25.0f, +25.0f);
                    }
                    break;
                    case ogl::CLight::SPOT:
                    {
                      ogl::CSpotLight* pSpotLight = dynamic_cast<ogl::CSpotLight*>(pLight);
                      mV = math::lookat(pSpotLight->mPosition, pSpotLight->mDirection, math::Y);
                      mP = mCamera->getProjectionMatrix();
                    }
                    break;
                    case ogl::CLight::POINT:
                    {
                      ogl::CPointLight* pPointLight = dynamic_cast<ogl::CPointLight*>(pLight);
                      mV = math::lookat(pPointLight->mPosition, pPointLight->mPosition + oPointLightConfigs[i].vDirection, oPointLightConfigs[i].vUp);
                      mP = math::perspective(90.0f, 1.0f, mCamera->getNear(), mCamera->getFar()); // MUST BE 90.0f
                    }
                    break;
                  }
                  
                  mProgram->setUniform("u_mMVP", mP * mV * mM);
                }
                
                { // draw
                  // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
                  // moved inside inside first getDrawCommand()
                  glBindVertexArray(pDrawCommand->mVAO);
                  glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
                  
                  CDrawCommand* pFirstCommand = pDrawCommand;
                  while(pDrawCommand != nullptr)
                  {
                    pDrawStrategy->draw(pDrawCommand); 
                    pDrawCommand = pDrawCommand->next();
                  }
                  _DELETE(pFirstCommand);
                }
              }
              
              ++mDrawableIndex; // MUST
            }
          }
        }
        
        glExitIfError();
      }
      
      // TODO: try passing the resulted texture through gaussian blur(maybe 2 pass)
      
      /*
      
      { // render depth buffer as fullscreen quad 
        sys::info << sys::tab << "draw depth buffer(fullscreen quad)" << sys::endl;

        mFbo->bind(CFramebuffer::DRAW);                         // bind default framebuffer
        glDrawBuffer(GL_BACK);                                         // re-enable drawing on the color buffer
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);               // mask-on color buffer        glCullFace(GL_BACK);                                           // re-enable backface rendering
        mFbo->clear(CFramebuffer::COLOR | CFramebuffer::DEPTH); // clear default framebuffer
        
        CShadow* pShadow = getShadow(mLights[2]);
        
        //pShadow->bind(CFramebuffer::READ);                         // is this really needed?
        pShadow->read();
        pShadow->getTexture(GL_DEPTH_ATTACHMENT)->bind(GL_TEXTURE0); // bind shadow texture
        
        pProgramDescriptor->setRenderingScope(ERenderingScope::QUAD);
        pProgramDescriptor->setDrawStrategyType(EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions(ERenderingOptions::NONE);
        mProgram = pProgramManager->getProgram(*pProgramDescriptor);
        
        mProgram->enable();
        mProgram->getCallback()(nullptr, nullptr);
        
        glBindBuffer(GL_ARRAY_BUFFER, mVBO);
        glBindVertexArray(mVAO);
        
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        
        glExitIfError();
        
        CModelManager::getInstance()->getModel("CUBE");
      }
      
      */
      
      { // color pass + additive blending
        sys::info << sys::tab << "lighting pass + additive blending" << sys::endl;
        
        glFrontFace(GL_CCW);
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        
        mFbo->bind(GL_FRAMEBUFFER);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE); // before glClear(...)
        glDrawBuffer(GL_BACK);
        glReadBuffer(GL_BACK);
        mFbo->clear(CFramebuffer::COLOR | CFramebuffer::DEPTH);
        
        // enable additive blending
        glEnable(GL_BLEND);
        glBlendEquation(GL_FUNC_ADD);
        glBlendFunc(GL_ONE, GL_ONE);
        
        glEnable(GL_CULL_FACE);
        glFrontFace(GL_CCW);
        glCullFace(GL_BACK);
        
        glExitIfError();
        
//        pProgramDescriptor->setRenderingScope(ERenderingScope::FORWARD);
//        pProgramDescriptor->setDrawStrategyType(EDrawStrategyType::SINGLE);
//        pProgramDescriptor->setShadingMode(EShadingMode::BLINN_PHONG);
//        pProgramDescriptor->setLightingPass(ELightingPass::BOTH);
//        pProgramDescriptor->setRenderingOptions(ERenderingOptions::STATIC | ERenderingOptions::SHADOW);
//        mProgram = pProgramManager->getProgram(*pProgramDescriptor); // MUST
//        mProgram->enable();
        
        math::mat4 mV = mCamera->getViewMatrix();
        math::mat4 mP = mCamera->getProjectionMatrix();
        mProgram->setUniform("u_mV", mV); // math::lookat(math::vec3(0.0f, 3.0f, -3.0f), math::O, math::Y));
        mProgram->setUniform("u_mP", mP);
        mProgram->setUniform("u_oCamera.vPosition",  mCamera->getPosition());
        mProgram->setUniform("u_fSpecularPower",     256.00f);
        mProgram->setUniform("u_fSpecularIntensity",   0.75f);
        
        // for each shadow... bind shadow... render scene...
        for(CLight* pLight : mLights)
        {
          CShadow* pShadow = getShadow(pLight);
        
          //pShadow->read();
        
          switch(pLight->getType())
          {
            case CLight::DIRECT:
            {
              sys::info << sys::tab << "set direct shadow map 0" << sys::endl;
              pShadow->getTexture(GL_DEPTH_ATTACHMENT)->bind(OGL_TEXTURE_DIRECTSHADOW); // bind shadow texture
              // mProgram->set("u_sDirectShadowMap", 4); 
              // the 4 is from GL_TEXTURE4(OGL_TEXTURE_DIRECTSHADOW) - REMEMBER THIS YOU STUPID FUCK...OR ELSE
              // mProgram->set("u_sDirectShadowMaps[0]", *(pShadow->getTexture(GL_DEPTH_ATTACHMENT))); // THIS IS BAD - DO NOT DO THIS AGAIN
              
              ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
              math::mat4 mV = math::lookat(-pDirectLight->mDirection, math::O , math::Y);
              math::mat4 mP = math::ortho(-5.0f, +5.0f, -5.0f, +5.0f, -25.0f, +25.0f);
            
              mProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
              mProgram->setUniform("u_oDirectLight.vDirection",        pDirectLight->mDirection);
              mProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
              mProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
              mProgram->setUniform("u_oDirectLight.mVP",               mP * mV);
              
              mProgram->setUniform("u_oSpotLight.bEnabled",          false);
              mProgram->setUniform("u_oDirectLight.bEnabled",        true);
              mProgram->setUniform("u_oPointLight.bEnabled",         false);
            }
            break;
            case CLight::SPOT:
            {
              sys::info << sys::tab << "set spot shadow map 0" << sys::endl;
              pShadow->getTexture(GL_DEPTH_ATTACHMENT)->bind(OGL_TEXTURE_SPOTSHADOW); // bind shadow texture
              
              ogl::CSpotLight* pSpotLight = dynamic_cast<ogl::CSpotLight*>(pLight);
              math::mat4 mV = math::lookat(pSpotLight->getPosition(), pSpotLight->getDirection(), math::Y);
              
              mProgram->setUniform("u_oSpotLight.vColor",            pSpotLight->mColor);
              mProgram->setUniform("u_oSpotLight.vPosition",         pSpotLight->mPosition);
              mProgram->setUniform("u_oSpotLight.vDirection",        pSpotLight->mDirection);
              mProgram->setUniform("u_oSpotLight.fCutoff",           pSpotLight->mCutoff);
              mProgram->setUniform("u_oSpotLight.fAmbientIntensity", pSpotLight->mAmbientIntensity);
              mProgram->setUniform("u_oSpotLight.fDiffuseIntensity", pSpotLight->mDiffuseIntensity);
              mProgram->setUniform("u_oSpotLight.fK0",               pSpotLight->mK0);
              mProgram->setUniform("u_oSpotLight.fK1",               pSpotLight->mK1);
              mProgram->setUniform("u_oSpotLight.fK2",               pSpotLight->mK2);
              mProgram->setUniform("u_oSpotLight.mVP",               mP * mV);
              
              mProgram->setUniform("u_oSpotLight.bEnabled",          true);
              mProgram->setUniform("u_oDirectLight.bEnabled",        false);
              mProgram->setUniform("u_oPointLight.bEnabled",         false);
            }
            break;
            case CLight::POINT:
            {
              sys::info << sys::tab << "set point shadow map 0" << sys::endl;
              pShadow->getTexture(GL_DEPTH_ATTACHMENT)->bind(OGL_TEXTURE_POINTSHADOW);
              
              ogl::CPointLight* pPointLight = dynamic_cast<ogl::CPointLight*>(pLight);
              mProgram->setUniform("u_oPointLight.vColor",            pPointLight->mColor);
              mProgram->setUniform("u_oPointLight.vPosition",         pPointLight->mPosition);
              mProgram->setUniform("u_oPointLight.fAmbientIntensity", pPointLight->mAmbientIntensity);
              mProgram->setUniform("u_oPointLight.fDiffuseIntensity", pPointLight->mDiffuseIntensity);
              mProgram->setUniform("u_oPointLight.fK0",               pPointLight->mK0);
              mProgram->setUniform("u_oPointLight.fK1",               pPointLight->mK1);
              mProgram->setUniform("u_oPointLight.fK2",               pPointLight->mK2);
              
              mProgram->setUniform("u_oSpotLight.bEnabled",          false);
              mProgram->setUniform("u_oDirectLight.bEnabled",        false);
              mProgram->setUniform("u_oPointLight.bEnabled",         true);
            }
            break;
          }
          
          { // draw
            mDrawableIndex = 0;
            for(CDrawable* pDrawable : mDrawables)
            {
              sys::info << sys::tab << "drawing object " << mDrawableIndex << sys::endl;
            
              //GLbitfield options = getOptions();
              CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
              CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
             
              pDrawCommand->mMode     = mProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
              
              // set model matrix
              math::mat4 mM = pDrawCommand->mModelMatrix; 
              mProgram->setUniform("u_mM", mM);
              
              // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
              glBindVertexArray(pDrawCommand->mVAO);
              glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
            
              glExitIfError();
            
              CDrawCommand* pFirstCommand = pDrawCommand;
              while(pDrawCommand != nullptr)
              {
                //if((options & ~EDrawOptions::NOMATERIAL) && (pDrawCommand->mMaterial != nullptr)) // activate textures
                
                glExitIfError();
                
                pDrawCommand->mMaterial->getTexture(CTexture::EScope::DIFFUSE)->bind(OGL_TEXTURE_DIFFUSE);
                pDrawCommand->mMaterial->getTexture(CTexture::EScope::NORMALS)->bind(OGL_TEXTURE_NORMALS);
                pDrawCommand->mMaterial->getTexture(CTexture::EScope::ENVIRONMENT)->bind(OGL_TEXTURE_ENVIRONMENT);
                
                glExitIfError();
                
                pDrawStrategy->draw(pDrawCommand);
                
                pDrawCommand = pDrawCommand->next();
              }
              
              glExitIfError();
              
              glBindVertexArray(0);
              glBindBuffer(pFirstCommand->mTarget, 0);
              
              _DELETE(pFirstCommand);
            
              ++mDrawableIndex;
            }
          }
        }
        
        glDisable(GL_BLEND);
      }
      
      /*
      
      { // color pass
        sys::info << sys::tab << "lighting pass" << sys::endl;
        glCullFace(GL_BACK);
      
        mFbo->bind(GL_FRAMEBUFFER);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE); // before glClear(...)
        glDrawBuffer(GL_BACK);
        mFbo->clear(CFramebuffer::COLOR | CFramebuffer::DEPTH);
        
        glExitIfError();
        
        // render all drawables
        mDrawableIndex = 0;
        for(CDrawable* pDrawable : mDrawables)
        {
          sys::info << sys::tab << "drawing object " << mDrawableIndex << sys::endl;
        
          //GLbitfield options = getOptions();
          CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
          CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
         
          pProgramDescriptor->setRenderingScope(ERenderingScope::FORWARD);
          pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType());
          pProgramDescriptor->setShadingMode(EShadingMode::BLINN_PHONG);
          pProgramDescriptor->setLightingPass(ELightingPass::BOTH);
          pProgramDescriptor->setRenderingOptions(ERenderingOptions::STATIC | ERenderingOptions::SHADOW);
          mProgram = pProgramManager->getProgram(*pProgramDescriptor); // MUST
          
          pDrawCommand->mProgram  = mProgram;
          pDrawCommand->mMode     = mProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
          pDrawCommand->mRenderer = this;
          
          mProgram->enable();
          mProgram->getCallback()(nullptr, pDrawCommand);
          
          // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
          
          sys::info << sys::tab << "" << mShadows.size() << " shadow maps found" << sys::endl;
          for(auto it = mShadows.begin(); it != mShadows.end(); ++it)
          {
            CLight*  pLight  = it->first;
            CShadow* pShadow = it->second;
            pShadow->bind(CFramebuffer::READ);
            switch(pLight->getType())
            {
              case CLight::DIRECT:
              {
                sys::info << sys::tab << "set direct shadow map 0" << sys::endl;
                pShadow->getTexture(GL_DEPTH_ATTACHMENT)->bind(OGL_TEXTURE_DIRECTSHADOW); // bind shadow texture
                mProgram->set("u_sDirectShadowMaps[0]", 4);
                // the 4 is from GL_TEXTURE4(OGL_TEXTURE_DIRECTSHADOW) - REMEMBER THIS YOU STUPID FUCK...OR ELSE
                // mProgram->set("u_sDirectShadowMaps[0]", *(pShadow->getTexture(GL_DEPTH_ATTACHMENT))); // THIS IS BAD - DO NOT DO THIS AGAIN
              }
              break;
              case CLight::SPOT:
              {
                sys::info << sys::tab << "set spot shadow map 0" << sys::endl;
                pShadow->getTexture(GL_DEPTH_ATTACHMENT)->bind(OGL_TEXTURE_SPOTSHADOW); // bind shadow texture
                mProgram->set("u_sSpotShadowMaps[0]", 5);
              }
              break;
              case CLight::POINT:
              {
                
              }
              break;
            }
          }
          
          glExitIfError();
          
          CDrawCommand* pFirstCommand = pDrawCommand;
          while(pDrawCommand != nullptr)
          {
            //if((options & ~EDrawOptions::NOMATERIAL) && (pDrawCommand->mMaterial != nullptr)) // activate textures
            
            glExitIfError();
            
            pDrawCommand->mMaterial->getTexture(CTexture::EScope::DIFFUSE)->bind(OGL_TEXTURE_DIFFUSE);
            pDrawCommand->mMaterial->getTexture(CTexture::EScope::NORMALS)->bind(OGL_TEXTURE_NORMALS);
            
            glExitIfError();
            
            pDrawStrategy->draw(pDrawCommand);
            
            pDrawCommand = pDrawCommand->next();
          }
          
          glExitIfError();
          
          glBindVertexArray(0);
          glBindBuffer(pFirstCommand->mTarget, 0);
          
          _DELETE(pFirstCommand);
        
          ++mDrawableIndex;
        }
        
        glExitIfError();
      }
      
      */
      
      /*
      
      { // wireframe pass
        sys::info << sys::tab << "draw wireframe" << sys::endl;
        
        glEnable(GL_POLYGON_OFFSET_LINE);
        glPolygonOffset(-1.0f, -1.0f);
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        glLineWidth(0.5f);
        
        mDrawableIndex = 0;
        for(CDrawable* pDrawable : mDrawables)
        {
          GLbitfield options = getOptions();
          CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
          CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
          
          pProgramDescriptor->setRenderingScope(ERenderingScope::WIREFRAME);
          pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType());
          pProgramDescriptor->setShadingMode(EShadingMode::NONE);
          pProgramDescriptor->setLightingPass(ELightingPass::NONE);
          pProgramDescriptor->setRenderingOptions(ERenderingOptions::NONE);
          mProgram = pProgramManager->getProgram(*pProgramDescriptor); // MUST
          
          pDrawCommand->mProgram  = mProgram;
          pDrawCommand->mRenderer = this;
          
          mProgram->enable();
          mProgram->getCallback()(nullptr, pDrawCommand);
          
          // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
          
          CDrawCommand* pFirstCommand = pDrawCommand;
          while(pDrawCommand != nullptr)
          {
            if((options & ~EDrawOptions::NOMATERIAL) && (pDrawCommand->mMaterial != nullptr)) // activate textures
              pDrawCommand->mMaterial->bind();
            
            pDrawStrategy->draw(pDrawCommand);
            
            if((options & ~EDrawOptions::NOMATERIAL) && (pDrawCommand->mMaterial != nullptr)) // activate textures
              pDrawCommand->mMaterial->unbind();
            
            pDrawCommand = pDrawCommand->next();
          }
          
          glBindVertexArray(0);
          glBindBuffer(pFirstCommand->mTarget, 0);
          
          _DELETE(pFirstCommand);
          
          mDrawableIndex++;
        }
        
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glDisable(GL_POLYGON_OFFSET_LINE);
        
        glExitIfError();
      }
      
      */
      
      { // normals pass
        sys::info << sys::tab << "draw normals" << sys::endl;
        
        glLineWidth(0.5f);
        
//        pProgramDescriptor->setRenderingScope(ERenderingScope::NORMALS);
//        pProgramDescriptor->setDrawStrategyType(EDrawStrategyType::SINGLE);
//        pProgramDescriptor->setShadingMode(EShadingMode::NONE);
//        pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//        pProgramDescriptor->setRenderingOptions(ERenderingOptions::NONE);
//        mProgram = pProgramManager->getProgram(*pProgramDescriptor); // MUST
//        mProgram->enable();
        
        math::mat4 mV = mCamera->getViewMatrix();
        math::mat4 mP = mCamera->getProjectionMatrix();
        mProgram->setUniform("u_mVP", mP * mV);
        
        mDrawableIndex = 0;
        for(CDrawable* pDrawable : mDrawables)
        {
          GLbitfield options = getOptions();
          CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
          CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();

          pDrawCommand->mMode = GL_POINTS;

          math::mat4 mM = pDrawCommand->mModelMatrix;
          mProgram->setUniform("u_mM",  mM);
          
          // TODO: move this inside CDrawStrategy and have a bit(isVboBound?)
          glBindVertexArray(pDrawCommand->mVAO);
          glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
          
          CDrawCommand* pFirstCommand = pDrawCommand;
          while(pDrawCommand != nullptr)
          {
            if((options & ~EDrawOptions::NOMATERIAL) && (pDrawCommand->mMaterial != nullptr)) // activate textures
              pDrawCommand->mMaterial->bind();
            
            pDrawStrategy->draw(pDrawCommand);
            
            if((options & ~EDrawOptions::NOMATERIAL) && (pDrawCommand->mMaterial != nullptr)) // activate textures
              pDrawCommand->mMaterial->unbind();
            
            pDrawCommand = pDrawCommand->next();
          }
          
          glBindVertexArray(0);
          glBindBuffer(pFirstCommand->mTarget, 0);
        
          _DELETE(pFirstCommand);
          
          mDrawableIndex++;
        }
        
        glExitIfError();
      }
      
      { // draw lights icons
        sys::info << sys::tab << "draw light icons" << sys::endl;
        
        for(CLight* pLight : mLights)
        {
          if(pLight->getType() == CLight::DIRECT)
            continue;
        
//          pProgramDescriptor->setRenderingScope(ERenderingScope::FORWARD);        // null shader
//          pProgramDescriptor->setDrawStrategyType(EDrawStrategyType::SINGLE); // eg: EDrawStrategyType::INSTANCED
//          pProgramDescriptor->setShadingMode(EShadingMode::FLAT);
//          pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//          pProgramDescriptor->setRenderingOptions(ERenderingOptions::NONE);
//          mProgram = pProgramManager->getProgram(*pProgramDescriptor);
          
          CDrawCommand* pDrawCommand = pLight->getDrawCommand();
          pDrawCommand->mRenderer = this;
          pDrawCommand->mProgram = mProgram;
          
          mProgram->enable();
          mProgram->getCallback()(nullptr, pDrawCommand);
          
          pLight->draw();
          
          glBindVertexArray(0);
          glBindBuffer(pDrawCommand->mTarget, 0);
          
          _DELETE(pDrawCommand);
        }
      }
      
//      _DELETE(pProgramDescriptor);
      
      glExitIfError();
      
      mLights.clear();
      mDrawables.clear();
      mOptions.clear();
    }
    
    CLight* getLight(size_t i) 
    {
      return mLights[i];
    }
    
    std::vector<CLight*>& getLights()
    {
      return mLights;
    }
  
    void addLight(CLight* pLight)
    {
      // TODO: change this method to addLight(CLight*, CLightDescriptor)
      // TODO: create shadow, if light supports shadows
      mLights.push_back(pLight);
    }
    
    CShadow* getShadow(CLight* pLight)
    {
      sys::info << "ogl::CPCFShadowMapRenderer::getShadow(CLight*) " << sys::endl;
    
      auto it = mShadows.find(pLight);
      if(it != mShadows.end())
        return it->second;
      
      sys::info << ">INFO: light type: " << pLight->getType() << sys::endl;
      
      CShadow* pShadow = new CShadow(pLight->getType(), 512, 512);
      mShadows[pLight] = pShadow;
      return pShadow;
    }
  };

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CRendererBuilder
  {
    enum ERendererType
    {
      FORWARD,
      DEFERRED
    };
  
    protected:
    ERendererType mType;
    
    public:
    CRenderer* build()
    {
      return nullptr;
    }
    
    void setType(ERendererType eType)
    {
      mType = eType;
    }
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CForwardRenderPass : public CRenderPass
  {
    public:
    void render()
    {
      
    }
  };
  
  class CMotionBlurRenderPass : public CRenderPass
  {
    public:
    void render()
    {
      
    }
  };

  class CShadowMapRenderPass : public CRenderPass
  {
    public:
    CLight*    mLight;
    CRenderer* mRenderer;
    
    public:
    CShadowMapRenderPass() : mLight(nullptr), mRenderer(nullptr)
    {
      
    }
    
    public:
    void render()
    {
//      CProgramManager*       pProgramManager = CProgramManager::getInstance();
//      CProgramDescriptor* pProgramDescriptor = new CProgramDescriptor;
      CProgram*                     pProgram = nullptr;
      
      for(CDrawable* pDrawable : mRenderer->getDrawables())
      {
        CDrawCommand*  pDrawCommand  = pDrawable->getDrawCommand();
        CDrawStrategy* pDrawStrategy = pDrawable->getDrawStrategy();
      
//        pProgramDescriptor->setRenderingScope(ERenderingScope::FORWARD);
//        pProgramDescriptor->setDrawStrategyType(pDrawStrategy->getType());
//        pProgramDescriptor->setShadingMode(EShadingMode::FLAT);
//        pProgramDescriptor->setLightingPass(ELightingPass::NONE);
//        pProgramDescriptor->setRenderingOptions(ERenderingOptions::NONE);
//        pProgram = pProgramManager->getProgram(*pProgramDescriptor); // MUST
      
        pDrawCommand->mProgram    = pProgram;
        pDrawCommand->mMode       = pProgram->isTessellated() ? GL_PATCHES : pDrawCommand->mMode;
        pDrawCommand->mRenderer   = mRenderer;
        pDrawCommand->mRenderPass = this;
    
        // moved inside inside first getDrawCommand()
        // glBindVertexArray(pDrawCommand->mVAO);
        // glBindBuffer(pDrawCommand->mTarget, pDrawCommand->mBuffers[INDEX_BUFFER_INDEX]); // must
        
        CDrawCommand* pFirstCommand = pDrawCommand;
        while(pDrawCommand != nullptr)
        {
          pDrawStrategy->draw(pDrawCommand);
          
          pDrawCommand = pDrawCommand->next();
        }
        _DELETE(pFirstCommand);
      }
      
//      _DELETE(pProgramDescriptor);
      
      mLight = nullptr;
      mRenderer = nullptr;
//      pProgramManager = nullptr;
//      pProgramDescriptor = nullptr;
      pProgram = nullptr;
    }
    
    public:
    void setLight(CLight* pLight)
    {
      mLight = pLight;
    }
    
    void setRenderer(CRenderer* pRenderer)
    {
      mRenderer = pRendered;
    }
  };
}

#endif // __ogl_crenderer_hpp__
