#ifndef __cboxobjectbuilder_hpp__
#define __cboxobjectbuilder_hpp__

namespace ogl
{
  class CBoxObjectBuilder : public CObjectBuilder
  {
    private:
    float  mWidth;
    float  mHeight;
    float  mDepth;
    float  mTextureScale;
    ushort mSubdivisions;
    
    public:
    CBoxObjectBuilder() : CObjectBuilder(), mWidth(1.0f), mHeight(1.0f), mDepth(1.0f), mTextureScale(1.0f), mSubdivisions(1)
    {
    
    }

    public:
    CObject* build()
    {
      sys::info << "ogl::CBoxObjectBuilder::build()" << sys::endl;
    
      float dmax    = hasOption(CObjectBuilder::NORMALIZED) ? math::max(mWidth, math::max(mHeight, mDepth)) : 1.0f;
    
      float hwidth  = (mWidth  / 2.0f) / dmax;
      float hheight = (mHeight / 2.0f) / dmax;
      float hdepth  = (mDepth  / 2.0f) / dmax;
      
      const size_t nNumVertices = 24;
      const size_t nNumIndices  = 36;
      
      // bool bFlatface = hasOption(CObjectBuilder::FLATFACE);
      
      math::vec3* positions = new math::vec3[nNumVertices];
      positions[ 0] = math::vec3(-hwidth,-hheight, hdepth);
      positions[ 1] = math::vec3(-hwidth,-hheight, hdepth);
      positions[ 2] = math::vec3(-hwidth,-hheight, hdepth);
      positions[ 3] = math::vec3( hwidth,-hheight, hdepth);
      positions[ 4] = math::vec3( hwidth,-hheight, hdepth);
      positions[ 5] = math::vec3( hwidth,-hheight, hdepth);
      positions[ 6] = math::vec3( hwidth, hheight, hdepth);
      positions[ 7] = math::vec3( hwidth, hheight, hdepth);
      positions[ 8] = math::vec3( hwidth, hheight, hdepth);
      positions[ 9] = math::vec3(-hwidth, hheight, hdepth);
      positions[10] = math::vec3(-hwidth, hheight, hdepth);
      positions[11] = math::vec3(-hwidth, hheight, hdepth);
      positions[12] = math::vec3(-hwidth,-hheight,-hdepth);
      positions[13] = math::vec3(-hwidth,-hheight,-hdepth);
      positions[14] = math::vec3(-hwidth,-hheight,-hdepth);
      positions[15] = math::vec3( hwidth,-hheight,-hdepth);
      positions[16] = math::vec3( hwidth,-hheight,-hdepth);
      positions[17] = math::vec3( hwidth,-hheight,-hdepth);
      positions[18] = math::vec3( hwidth, hheight,-hdepth);
      positions[19] = math::vec3( hwidth, hheight,-hdepth);
      positions[20] = math::vec3( hwidth, hheight,-hdepth);
      positions[21] = math::vec3(-hwidth, hheight,-hdepth);
      positions[22] = math::vec3(-hwidth, hheight,-hdepth);
      positions[23] = math::vec3(-hwidth, hheight,-hdepth);
      
      math::vec2* texcoords = new math::vec2[nNumVertices];
      texcoords[ 0] = math::vec2(1.0f, 1.0f);
      texcoords[ 1] = math::vec2(0.0f, 1.0f);
      texcoords[ 2] = math::vec2(0.0f, 1.0f);
      texcoords[ 3] = math::vec2(0.0f, 1.0f);
      texcoords[ 4] = math::vec2(1.0f, 1.0f);
      texcoords[ 5] = math::vec2(1.0f, 1.0f);
      texcoords[ 6] = math::vec2(0.0f, 0.0f);
      texcoords[ 7] = math::vec2(1.0f, 0.0f);
      texcoords[ 8] = math::vec2(1.0f, 0.0f);
      texcoords[ 9] = math::vec2(1.0f, 0.0f);
      texcoords[10] = math::vec2(0.0f, 0.0f);
      texcoords[11] = math::vec2(0.0f, 0.0f);
      texcoords[12] = math::vec2(0.0f, 1.0f);
      texcoords[13] = math::vec2(1.0f, 1.0f);
      texcoords[14] = math::vec2(0.0f, 0.0f);
      texcoords[15] = math::vec2(1.0f, 1.0f);
      texcoords[16] = math::vec2(0.0f, 1.0f);
      texcoords[17] = math::vec2(1.0f, 0.0f);
      texcoords[18] = math::vec2(1.0f, 0.0f);
      texcoords[19] = math::vec2(0.0f, 0.0f);
      texcoords[20] = math::vec2(1.0f, 1.0f);
      texcoords[21] = math::vec2(0.0f, 0.0f);
      texcoords[22] = math::vec2(1.0f, 0.0f);
      texcoords[23] = math::vec2(0.0f, 1.0f);
      
      math::vec3* normals = new math::vec3[nNumVertices];
      normals[ 0] = math::vec3( 0.0f, 0.0f, 1.0f);
      normals[ 1] = math::vec3(-1.0f, 0.0f, 0.0f);
      normals[ 2] = math::vec3( 0.0f,-1.0f, 0.0f);
      normals[ 3] = math::vec3( 0.0f, 0.0f, 1.0f);
      normals[ 4] = math::vec3( 1.0f, 0.0f, 0.0f);
      normals[ 5] = math::vec3( 0.0f,-1.0f, 0.0f);
      normals[ 6] = math::vec3( 0.0f, 0.0f, 1.0f);
      normals[ 7] = math::vec3( 1.0f, 0.0f, 0.0f);
      normals[ 8] = math::vec3( 0.0f, 1.0f, 0.0f);
      normals[ 9] = math::vec3( 0.0f, 0.0f, 1.0f);
      normals[10] = math::vec3(-1.0f, 0.0f, 0.0f);
      normals[11] = math::vec3( 0.0f, 1.0f, 0.0f);
      normals[12] = math::vec3( 0.0f, 0.0f,-1.0f);
      normals[13] = math::vec3(-1.0f, 0.0f, 0.0f);
      normals[14] = math::vec3( 0.0f,-1.0f, 0.0f);
      normals[15] = math::vec3( 0.0f, 0.0f,-1.0f);
      normals[16] = math::vec3( 1.0f, 0.0f, 0.0f);
      normals[17] = math::vec3( 0.0f,-1.0f, 0.0f);
      normals[18] = math::vec3( 0.0f, 0.0f,-1.0f);
      normals[19] = math::vec3( 1.0f, 0.0f, 0.0f);
      normals[20] = math::vec3( 0.0f, 1.0f, 0.0f);
      normals[21] = math::vec3( 0.0f, 0.0f,-1.0f);
      normals[22] = math::vec3(-1.0f, 0.0f, 0.0f);
      normals[23] = math::vec3( 0.0f, 1.0f, 0.0f);

      static GLushort indices[] = {
         3,  0,  9, // triangle 0  // face 0 // +z
         3,  9,  6, // triangle 1  // face 0
        12, 15, 18, // triangle 2  // face 1 // -z
        12, 18, 21, // triangle 3  // face 1
         1, 13, 22, // triangle 4  // face 2 // -x
         1, 22, 10, // triangle 5  // face 2
        16,  4,  7, // triangle 6  // face 3 // +x
        16,  7, 19, // triangle 7  // face 4 
         2,  5, 17, // triangle 8  // face 5 // -y
         2, 17, 14, // triangle 9  // face 5 
        23, 20,  8, // triangle 10 // face 6 // +y
        23,  8, 11  // triangle 11 // face 7
      };
      
      math::vec3* tangents  = new math::vec3[nNumVertices];
      math::vec3* binormals = new math::vec3[nNumVertices];
      for(size_t i = 0; i < nNumIndices; i+=3) // for every triangle
      {
        ushort i0 = indices[i+0];
        ushort i1 = indices[i+1];
        ushort i2 = indices[i+2];

        math::vec3& p0 = positions[i0];
        math::vec3& p1 = positions[i1];
        math::vec3& p2 = positions[i2];
        
        math::vec2& t0 = texcoords[i0];
        math::vec2& t1 = texcoords[i1];
        math::vec2& t2 = texcoords[i2];
        
        math::vec3 dp1(p1 - p0); // e1
        math::vec3 dp2(p2 - p0); // e2
        
        math::vec3 normal = math::normalize(math::cross(dp2, dp1));
        normals[i0] += normal; // avarage the normals
        normals[i0]  = math::normalize(normals[i0]);
        normals[i1] += normal;
        normals[i1]  = math::normalize(normals[i1]);
        normals[i2] += normal;
        normals[i2]  = math::normalize(normals[i2]);
        
        math::vec2 dt1 = t1 - t0;
        math::vec2 dt2 = t2 - t0;
        
        float r = 1.0f / (dt1.x * dt2.y - dt1.y * dt2.x);
        math::vec3 ta = (dp1 * dt2.y - dp2 * dt1.y) * r;    // tangent
        math::vec3 bi = (dp2 * dt1.x - dp1 * dt2.x) * r;    // binormal
        
        tangents[i0] = ta;
        tangents[i1] = ta;
        tangents[i2] = ta;
        
        binormals[i0] = bi;
        binormals[i1] = bi;
        binormals[i2] = bi;
      }
      
      if(hasOption(CObjectBuilder::INVERTED)) 
      {
        for(size_t i = 0; i < nNumVertices; ++i)
        {
          normals[i]   *= -1.0f;
          tangents[i]  *= -1.0f;
          binormals[i] *= -1.0f;
        }
        
        for(ushort i = 0; i < nNumIndices; i+=3)
        {
          GLushort tmp = indices[i+1];
          indices[i+1] = indices[i+2];
          indices[i+2] = tmp;
        }
      }
      
      if(mTextureScale != 1.0f)
      {
        for(size_t i = 0; i < nNumVertices; ++i)
          texcoords[i] = texcoords[i] / mTextureScale;
      }
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      CObject* pObject = new CObject;
      pObject->mNumVertices = nNumVertices;
      pObject->mNumIndices  = nNumIndices;
      
      pObject->setDrawStrategy(mDrawStrategy == nullptr ? new CDrawStrategy : mDrawStrategy);
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      { // shapes
        CShape* pShape = new CShape;
        pShape->setVertexBufferRange(0, pObject->mNumVertices, GL_FLOAT);
        pShape->setIndexBufferRange(0, pObject->mNumIndices, GL_UNSIGNED_SHORT);
        
        CMaterial* pMaterial = new CMaterial;
        CDdsTextureBuilder* pTextureBuilder = new CDdsTextureBuilder;
        pTextureBuilder->setFile("notfound.dds");
        CTexture* pTexture = pTextureBuilder->build();
        pTexture->setFiltering(CTexture::EFiltering::TRILINEAR);
        delete pTextureBuilder;
        
        pMaterial->setTexture(CTexture::EScope::DIFFUSE, pTexture);
        pShape->setMaterial(pMaterial);
        
        pObject->addShape(pShape);
      }
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      pObject->mBuffers.resize(5);
      
      glGenVertexArrays(1, &(pObject->mVAO));
      glBindVertexArray(pObject->mVAO);
      
      // indices
      glGenBuffers(1, &(pObject->mBuffers[INDEX_BUFFER_INDEX]));
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pObject->mBuffers[INDEX_BUFFER_INDEX]);
      glBufferData(GL_ELEMENT_ARRAY_BUFFER, nNumIndices * sizeof(GLushort), indices, GL_STATIC_DRAW);
      
      // positions
      glGenBuffers(1, &(pObject->mBuffers[POSITION_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[POSITION_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, nNumVertices * sizeof(math::vec3), positions, GL_STATIC_DRAW);
      
      glVertexAttribPointer(POSITION_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3),  (const GLvoid*)(0));
      glEnableVertexAttribArray(POSITION_ATTRIBUTE); // positions
      
      // texcoords
      glGenBuffers(1, &(pObject->mBuffers[TEXCOORD_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[TEXCOORD_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, nNumVertices * sizeof(math::vec2), texcoords, GL_STATIC_DRAW);
      
      glVertexAttribPointer(TEXCOORD_ATTRIBUTE, 2, GL_FLOAT, GL_FALSE, sizeof(math::vec2), (const GLvoid*)(0)); //(GLvoid*)((0 + 3) * sizeof(GLfloat)));
      glEnableVertexAttribArray(TEXCOORD_ATTRIBUTE); // texcoords
      
      // normals
      glGenBuffers(1, &(pObject->mBuffers[NORMAL_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[NORMAL_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, nNumVertices * sizeof(math::vec3), normals, GL_STATIC_DRAW);
      
      glVertexAttribPointer(NORMAL_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (const GLvoid*)(0)); //(GLvoid*)((0 + 3 + 2) * sizeof(GLfloat)));
      glEnableVertexAttribArray(NORMAL_ATTRIBUTE); // normals
      
      // tangents
      glGenBuffers(1, &(pObject->mBuffers[TANGENT_BUFFER_INDEX]));
      glBindBuffer(GL_ARRAY_BUFFER, pObject->mBuffers[TANGENT_BUFFER_INDEX]);
      glBufferData(GL_ARRAY_BUFFER, nNumVertices * sizeof(math::vec3), tangents, GL_STATIC_DRAW);
      
      glVertexAttribPointer(TANGENT_ATTRIBUTE, 3, GL_FLOAT, GL_FALSE, sizeof(math::vec3), (const GLvoid*)(0)); //(GLvoid*)((0 + 3 + 2) * sizeof(GLfloat)));
      glEnableVertexAttribArray(TANGENT_ATTRIBUTE); // tangents
      
      // clean
      glBindBuffer(GL_ARRAY_BUFFER, 0);
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
      glBindVertexArray(0);
      
      delete [] positions;
      delete [] texcoords;
      delete [] normals;
      delete [] tangents;
      delete [] binormals;
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      return pObject;
    }
    
    void setWidth(float width)
    {
      mWidth = width;
    }
    
    void setHeight(float height)
    {
      mHeight = height;
    }
    
    void setDepth(float depth)
    {
      mDepth = depth;
    }
    
    void setTextureScale(float scale)
    {
      mTextureScale = scale;
    }
  
    void setSubdivisions()
    {
      throw EXCEPTION << "Not Implemented!";
    }
  };
}

#endif // __cboxobjectbuilder_hpp__
