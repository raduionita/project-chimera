#ifndef __cmodel_hpp__
#define __cmodel_hpp__

#include <vector>
#include <string>
#include <cassert>

namespace ogl
{
  /* TODO: change CObject to just hold a pointer to object with vbo/vao */

  class CObject : public CDrawable, public CAnimatable //, CTransformable // see CTransformHistory
  {
  /*
  CModel(std::vector<CModelData>& data) // CModelData -> std::vector<CShapeData>
  {
    sys::info << "ogl::CModel::CModel(vector<CModelData>) > size: " << data.size() << sys::endl;
    
    GLsizeiptr nVboSize = 0;
    GLsizeiptr nEboSize = 0;
    
    mShapes.resize(data.size());
    
    for(size_t i = 0; i < data.size(); ++i)
    {
      nVboSize += data[i].getVertices().size();
      nEboSize += data[i].getIndices().size();
    }
    
    mVertexBuffer = new CVertexBuffer(nVboSize, GL_STATIC_DRAW);
    mIndexBuffer  = new CIndexBuffer(nEboSize, GL_STATIC_DRAW);
    
    GLintptr uVboOffset = 0;
    GLintptr uEboOffset = 0;
    
    glGenVertexArrays(1, &mVertexArray);
    glBindVertexArray(mVertexArray);
    
    for(size_t i = 0; i < data.size(); ++i)
    {
      CModelData* oModelData = &data[i];
      
      mShapes[i] = new CShape(
        CBufferRange(uVboOffset, (GLsizeiptr) oModelData->mVertices.size()),
        CBufferRange(uEboOffset, (GLsizeiptr) oModelData->mIndices.size()),
        new CMaterial);
      
      mVertexBuffer->write(mShapes[i]->getVertexBufferRange(), oModelData->getVertices().data());
      mIndexBuffer->write(mShapes[i]->getVertexBufferRange(),  oModelData->getIndices().data());
      
      // attributes
      GLintptr   offset  = 0;
      GLsizeiptr stride = 0;
      stride += oModelData->hasPositions() ? 3 : 0;
      stride += oModelData->hasTexcoords() ? 2 : 0;
      stride += oModelData->hasNormals() ? 3 : 0;
      stride += oModelData->hasTangents() ? 3 : 0;
      if(oModelData->hasPositions()) 
      {
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride * sizeof(GLfloat), (GLvoid*)(offset * sizeof(GLfloat)));
        glEnableVertexAttribArray(0);
        offset += 3;
      }
      if(oModelData->hasTexcoords())
      {
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride * sizeof(GLfloat), (GLvoid*)(offset * sizeof(GLfloat)));
        glEnableVertexAttribArray(1);
        offset += 2;
      }
      if(oModelData->hasNormals())
      {
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride * sizeof(GLfloat), (GLvoid*)(offset * sizeof(GLfloat)));
        glEnableVertexAttribArray(2);
        offset += 3;
      }
      if(oModelData->hasTangents())
      {
        glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, stride * sizeof(GLfloat), (GLvoid*)(offset * sizeof(GLfloat)));
        glEnableVertexAttribArray(3);
        offset += 3;
      }
      
      uVboOffset += oModelData->mVertices.size();
      uEboOffset += oModelData->mIndices.size();
    }
  }
    
  CModel(const CModel& that)
  {
    delete mVertexBuffer;
    delete mIndexBuffer;
    for(size_t i = 0; i < mShapes.size(); ++i) 
    {
      delete mShapes[i];
      mShapes[i] = that.mShapes[i];
    }
    mVertexBuffer = that.mVertexBuffer;
    mIndexBuffer  = that.mIndexBuffer;
    mShapes       = that.mShapes;
  }
  */

    public:
    enum EDrawOptions : GLbitfield
    {
      INVISIBLE  = 0x0000,
      REGULAR    = 0x0001,
      WIREFRAME  = 0x0002,
      NOMATERIAL = 0x0004
    };
    
    enum EShapeScope : ushort
    {
      NONE = 0x00,
      DRAW = 0x01
    };
    
    public:
    /** CSkeleton*     mSkeleton;     */ /** @see CAnimatable */
    /** CDrawStrategy* mDrawStrategy; */ /** @see CDrawable   */
    
    GLuint               mVAO;
    std::vector<GLuint>  mBuffers;
    
    GLushort             mNumVertices;
    GLushort             mNumIndices;
    GLenum               mMode;
    
    protected:
    std::vector<CShape*> mShapes;
    // ogl::CBBox                 mBBox;
    // std::vector<ogl::CPolygon> mPolygons;
    
    math::mat4 mModelMatrix;
    
    public:
    math::vec3 mPosition;
    math::quat mOrientation;
    math::vec3 mScale;
    
    public:
    CObject() 
    : CDrawable(), CAnimatable(), mVAO(0), mNumVertices(0), mNumIndices(0), mMode(GL_TRIANGLES), mScale(1.0f)
    {
      sys::info << "ogl::CObject::CObject()" << sys::endl;
    }
    
    CObject(const CObject& that)
    {
      sys::info << "ogl::CObject::CObject(CObject&)" << sys::endl;
      
      mVAO          = that.mVAO;
      mBuffers      = that.mBuffers;
      mNumVertices  = that.mNumVertices;
      mNumIndices   = that.mNumIndices;
      mShapes       = that.mShapes;
      mMode         = that.mMode;
      _DELETE(mDrawStrategy);
      mDrawStrategy = that.mDrawStrategy;
    }
    
    CObject& operator = (const CObject& that)
    {
      sys::info << "ogl::CObject::operator=(CObject&)" << sys::endl;
      
      if(this != &that)
      {
        mVAO         = that.mVAO;
        mBuffers     = that.mBuffers;
        mNumVertices = that.mNumVertices;
        mNumIndices  = that.mNumIndices;
        mShapes      = that.mShapes;
        mMode        = that.mMode;
        _DELETE(mDrawStrategy);
        mDrawStrategy = that.mDrawStrategy;
      }
      
      return *this;
    }
    
    virtual ~CObject()
    {
      sys::info << "ogl::CObject::~CObject()" << sys::endl;
      
      for(CShape* pShape : mShapes)
        _DELETE(pShape);
      
      glDeleteVertexArrays(1, &mVAO);
      for(size_t i = 0; i < mBuffers.size(); ++i)
        glDeleteBuffers(1, &mBuffers[i]);
      
      //delete mDrawStrategy; // gets deleted in ~CDrawable()
    }
    
    CShape* operator [] (size_t position)
    {
      sys::info << "ogl::CObject::operator[](" << position << ")" << sys::endl;
      assert(position >= 0);
      assert(position < mShapes.size());
      return mShapes[position];
    }
    
    public:
    CDrawCommand* getDrawCommand()
    {
      sys::info << "ogl::CObject::getDrawCommand()" << sys::endl;
    
//      glBindVertexArray(mVAO);
//      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mBuffers[INDEX_BUFFER_INDEX]); // must
      return getDrawCommand(0);
    }
    
    protected:
    CDrawCommand* getDrawCommand(size_t i)
    {
      CDrawCommand* pCommand = nullptr;
      
      if(i < mShapes.size())
      {
        CShape* const& pShape = mShapes[i];
      
        pCommand               = new CDrawCommand;
        pCommand->mDrawable    = this;
        pCommand->mVAO         = mVAO;
        pCommand->mBuffers     = mBuffers;
        pCommand->mTarget      = GL_ELEMENT_ARRAY_BUFFER;
        pCommand->mMode        = mMode;
        pCommand->mBufferRange = pShape->mIndexBufferRange;
        pCommand->mModelMatrix = getModelMatrix();
        pCommand->mMaterial    = pShape->mMaterial;
        pCommand->mNext        = getDrawCommand(i+1);
      }
      
      return pCommand;
    }

    public:
    void setM(const math::mat4& mM)
    {
      mModelMatrix = mM;
    }
    
    math::mat4 getM() const
    {
      return mModelMatrix;
    }
    
    math::mat4 getModelMatrix() const
    {
      return math::translate(mPosition) * math::toMatrix(mOrientation) * math::scale(mScale);
    }
    
    CShape* getShape(size_t i) const 
    {
      sys::info << "ogl::CObject::operator[](" << i << ")" << sys::endl;
      assert(i >= 0);
      assert(i < mShapes.size());
      return mShapes[i];
    }
    
    void addShape(CShape* pShape)
    {
      mShapes.push_back(pShape);
      //mShapes[pShape] = OGL_SHAPE_SCOPE_DEFAULT; // change this to internel EType/EScope/CDescriptor
    }
    
    GLuint getVAO() const
    {
      return mVAO;
    }
    
    void setVAO(GLuint vao)
    {
      mVAO = vao;
    }
    
    std::vector<GLuint> getBuffers() const
    {
      return mBuffers;
    }
    
    GLuint getBuffer(GLuint buffer)
    {
      assert(buffer < mBuffers.size());
      return mBuffers[buffer];
    }
    
    void setMode(GLenum eMode)
    {
      mMode = eMode;
    }
    
    GLenum getMode() const
    {
      return mMode;
    }
    
    void scale(float scalar)
    {
      mScale *= scalar;
    }
    
    void rotate(const math::quat& rotation)
    {
      mOrientation *= rotation;
    }
    
    void translate(const math::vec3& translation)
    {
      mPosition += translation;
    }
    
    math::quat getOrientation() const
    {
      return mOrientation;
    }
    
    void setOrientation(const math::quat& orientation)
    {
      mOrientation = orientation;
    }
    
    math::vec3 getScale() const
    {
      return mScale;
    }
    
    void setScale(const math::vec3& scale)
    {
      mScale = scale;
    }
    
    math::vec3 getPosition() const
    {
      return mPosition;
    }
    
    void setPosition(const math::vec3& position)
    {
      mPosition = position;
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  };
}

#endif // __cmodel_hpp__
