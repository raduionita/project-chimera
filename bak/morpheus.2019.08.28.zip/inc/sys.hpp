#ifndef __sys_hpp__
#define __sys_hpp__

#include "sys/CFile.hpp"
#include "sys/CSingleton.hpp"
#include "sys/CException.hpp"
#include "sys/CLogger.hpp"

#include "sys/CPointer.hpp"
#include "sys/CLinkedList.hpp"
#include "sys/CMemoryPool.hpp"
#include "sys/CBuilder.hpp"
#include "sys/CDescriptor.hpp"

namespace sys
{
  template <typename T>
  using ptr = CPointer<T>;
}

namespace sys
{
  std::string trim(const std::string& str)
  {
    std::string out;
    out.reserve(str.size());
    for(size_t i = 0, j = 0; i < str.size(); ++i)
    {
      const char& ch = str[i];
      if(ch != '\t' && ch != ' ' && ch != '\n')
        out[j++] = ch;
    }
    out.shrink_to_fit();
    return out;
  }
}

#endif /* __sys_hpp__ */
