#ifndef CSPHERE_HPP_INCLUDED
#define CSPHERE_HPP_INCLUDED

namespace math
{
  class CSphere
  {
    public:
    math::vec3 mPosition;
    float      mRadius;
  
    public:
    CSphere() : mPosition(0.0f), mRadius(1.0f)
    {
    
    }
    
    CSphere(const math::vec3 position) : mPosition(position), mRadius(1.0f)
    {
    
    }
    
    CSphere(float radius) : mPosition(0.0f), mRadius(radius)
    {
    
    }
    
    CSphere(const math::vec3 position, float radius) : mPosition(position), mRadius(radius)
    {
    
    }
  };
}

#endif // CSPHERE_HPP_INCLUDED
