#ifndef CPLANE_HPP_INCLUDED
#define CPLANE_HPP_INCLUDED

namespace math
{
  class CPlane
  {
    public:
    math::vec3 mNormal;   // plane direction
    float      mDistance; // distance from origin
    
    // L = <N, d>
    
    public:
    CPlane(const math::vec3& n, float d) 
    : mNormal(math::normalize(n)), mDistance(d)
    {
    
    }
    
    CPlane(const math::vec3& p, const math::vec3& n)
    : mNormal(math::normalize(n)), mDistance(-math::dot(mNormal, p))
    {
    
    }
    
    CPlane(const math::vec3& p0, const math::vec3& p1, const math::vec3& p2)
    : mNormal(math::normalize(math::cross(p1-p0, p2-p0))), mDistance(-math::dot(mNormal, p0))
    {
    
    }
    
    virtual ~CPlane()
    {
      
    }
    
    public:
    math::vec3 getNormal() const
    {
      return mNormal;
    }
    
    float getDistance() const
    {
      return mDistance;
    }
    
    /**
     * Return closest distance from origin to plane
     * @return math::vec3
     */
    math::vec3 getPosition() const
    {
      return -mNormal * mDistance;
    }
  };
}

#endif // CPLANE_HPP_INCLUDED
