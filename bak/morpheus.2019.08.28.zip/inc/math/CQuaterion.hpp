#ifndef CQUATERION_HPP_
#define CQUATERION_HPP_

namespace math
{
  template <typename T>
  class CQuaterion
  {
    private:
    union
    {
      T data[4];
      struct { T w; T x; T y; T z; };
    };
    public:
    CQuaterion() : w(T(1)), x(0), y(0), z(0)
    { 
      
    }
    CQuaterion(const T s) : w(s), x(0), y(0), z(0)
    { 
    
    }
    CQuaterion(const T deg, const CVector<T, 3>& v)
    {
      T rad = math::radians(deg);
      T halfrad = rad / T(2);
      T s = std::sin(halfrad);
      T c = std::cos(halfrad);
      
      CVector<T, 3> vn = math::normalize(v);
      
      w = c;
      x = vn.x * s;
      y = vn.y * s;
      z = vn.z * s;
    }
    CQuaterion(const T w, const T x, const T y, const T z) : w(w), x(x), y(y), z(z)
    {
      
    }
    
    /**
     * Construct unit quaterion from a 3D vector
     *
     * @param CVector<T, 3> v
     */
    CQuaterion(const CVector<T, 3>& v) : x(v.x), y(v.y), z(v.z) // this is a unit quat - compute w
    {
      // w*w + x*x + y*y + z*z = 1
      T t = T(1) - (v.x*v.x) - (v.y*v.y) - (v.z*v.z);
      w = t < T(0) ? T(0) : -(T)sqrt(t);
    }
    
    CQuaterion(const T pitch, const T yaw, const T roll) // quaterion from euler angles
    {
      T half = T(1) / T(2);
      T p = radians(pitch * half);
      T y = radians(yaw   * half);
      T r = radians(roll  * half);
      
      T sinp = (T)sin(p);
      T siny = (T)sin(y);
      T sinr = (T)sin(r);
      T cosp = (T)cos(p);
      T cosy = (T)cos(y);
      T cosr = (T)cos(r);
      
      w = cosr * cosp * cosy + sinr * sinp * siny;
      x = sinr * cosp * cosy - cosr * sinp * siny;
      y = cosr * sinp * cosy + sinr * cosp * siny;
      z = cosr * cosp * siny - sinr * sinp * cosy;
      
      normalize();
    }
    
    CQuaterion(const CQuaterion& that)
    { 
      w = that.w;
      x = that.x;
      y = that.y;
      z = that.z;
    }
    
    CQuaterion& operator = (const CQuaterion& that)
    {
      if(this != &that)
      {
        w = that.w;
        x = that.x;
        y = that.y;
        z = that.z;
      }
      return *this;
    }
    
    T&       operator [] (const ushort i)
    {
      return data[i];
    }
    const T& operator [] (ushort i) const
    {
      return data[i];
    }

    CQuaterion  operator +  (const CQuaterion& rhs) const
    {
      return CQuaterion(w + rhs.w, x + rhs.x, y + rhs.y, z + rhs.z);
    }
    CQuaterion& operator += (const CQuaterion& rhs)
    {
      w += rhs.w;
      x += rhs.x;
      y += rhs.y;
      z += rhs.z;
      return *this;
    }

    CQuaterion  operator -  (const CQuaterion& rhs) const
    {
      return CQuaterion(w - rhs.w, x - rhs.x, y - rhs.y, z - rhs.z);
    }
    CQuaterion& operator -= (const CQuaterion& rhs)
    {
      w -= rhs.w;
      x -= rhs.x;
      y -= rhs.y;
      z -= rhs.z;
      return *this;
    }  
    CQuaterion  operator -  () const
    {
      return CQuaterion(-w, -x, -y, -z);
    }
    
    CQuaterion  operator *  (const T s) const
    {
      return CQuaterion(w * s, x * s, y * s, z * s);
    }
    CQuaterion& operator *= (const T s) 
    {
      w *= s;
      x *= s;
      y *= s;
      z *= s;
      return *this;
    }    
    CQuaterion& operator *= (const CQuaterion& rhs) 
    {
      *this = *this * rhs;
      return *this;
    }
    
    CQuaterion  operator *  (const CQuaterion& q) const
    {
      return CQuaterion<T>(
        w * q.w - x * q.x - y * q.y - z * q.z,
        w * q.x + x * q.w + y * q.z - z * q.y,
        w * q.y - x * q.z + y * q.w + z * q.x,
        w * q.z + x * q.y - y * q.x + z * q.w);
    }
    CQuaterion  operator *  (const CVector<T, 4>& v) const
    {
      return CQuaterion<T>(
        w * v.w - x * v.x - y * v.y - z * v.z,   // w
        w * v.x + x * v.w + y * v.z - z * v.y,   // x
        w * v.y - x * v.z + y * v.w + z * v.x,   // y
        w * v.z + x * v.y - y * v.x + z * v.w);  // z
    }
    
    CVector<T, 3> operator * (const CVector<T, 3>& v) const
    {
      CVector<T, 3> vn = math::normalize(v);
      
      CQuaterion<T> V(T(0), vn.x, vn.y, vn.z);
      CQuaterion<T> C = math::inverse(*this);
      CQuaterion<T> R = *this * (V * C);
      
      return CVector<T, 3>(R.x, R.y, R.z);
    }
    
    CQuaterion  operator /  (const T s) const
    {
      return CQuaterion(w / s, x / s, y / s, z / s);
    }
    
    CQuaterion& operator /= (const T s) 
    {
      w /= s;
      x /= s;
      y /= s;
      z /= s;
      return *this;
    }
    
    operator       CVector<T, 4> () 
    {
      return CVector<T, 4>(x, y, z, w);
    }
    operator const CVector<T, 4> () const
    {
      //return *(const CVector<T, 4>*)& data[0];
      return CVector<T, 4>(x, y, z, w);
    }
    
    explicit operator       T* ()
    {
      return (T*)(&data[0]);
    }
    explicit operator const T* () const
    {
      return (const T*)(&data[0]);
    }
    
    bool operator == (const CQuaterion& rhs) const
    {
      return (w == rhs.w) && (x == rhs.x) && (y == rhs.y) && (z == rhs.z);
    }
    bool operator != (const CQuaterion& rhs) const
    {
      return (w != rhs.w) || (x != rhs.x) || (y != rhs.y) || (z != rhs.z);
    }

    CMatrix<T, 4, 4> asMatrix() const
    {
      CMatrix<T, 4, 4> m;
      
      const T xx = x * x;
      const T yy = y * y;
      const T zz = z * z;
      // const T ww = w * w;
      const T xy = x * y;
      const T xz = x * z;
      const T xw = x * w;
      const T yz = y * z;
      const T yw = y * w;
      const T zw = z * w;
      
      m[0][0] = T(1) - T(2) * (yy + zz);
      m[0][1] =        T(2) * (xy + zw); // -
      m[0][2] =        T(2) * (xz - yw); // +
      m[0][3] =        T(0);

      m[1][0] =        T(2) * (xy - zw); // +
      m[1][1] = T(1) - T(2) * (xx + zz); 
      m[1][2] =        T(2) * (yz + xw); // -
      m[1][3] =        T(0);

      m[2][0] =        T(2) * (xz + yw); // -
      m[2][1] =        T(2) * (yz - xw); // +
      m[2][2] = T(1) - T(2) * (xx + yy);
      m[2][3] =        T(0);

      m[3][0] =        T(0);
      m[3][1] =        T(0);
      m[3][2] =        T(0);
      m[3][3] =        T(1);
      
      return m;
    }
    
    float getAxisAngle() const
    {
      float scale = std::sqrt(x * x + y * y + z * z);
      const CVector<T, 3>& axis(x / scale, y / scale, z / scale);
      float angle = std::acos(w) * T(2);
      return angle;
    }
    
    T length() const
    {
      return sqrt(w*w + x*x + y*y + z*z);
    }
    
    void normalize()
    {
      T ll = w*w + x*x + y*y + z*z;
      
      if(fabs(ll) > EPSILON<T>() && fabs(ll - T(1)) > EPSILON<T>())
      {
        T l = sqrt(ll);
        w /= l;
        x /= l;
        y /= l;
        z /= l;
      }
    }
    
    void conjugate()
    {
      x = -x;
      y = -y;
      z = -z;
    }
    
    void inverse()
    {
      conjugate();
      normalize();
    }
    
    template <typename T1>
    friend std::ostream& operator << (std::ostream&, CQuaterion<T1>&);
  };
  
  /** external operators */ /* ********************************************************************************** */
  
  template <typename T>
  CQuaterion<T> operator * (const T& s, const CQuaterion<T>& q)
  {
    return q * s;
  }
  
  template <typename T>
  CQuaterion<T> operator / (const T& s, const CQuaterion<T>& q)
  {
    return CQuaterion<T>(s / q.w, s / q.x, s / q.y, s / q.z);
  }
  
  template <typename T>
  std::ostream& operator << (std::ostream& out, CQuaterion<T>& q)
  {
    out << "["<< q.w << ", (" << q.x << ", " << q.y << ", " << q.z << ")]";
    return out;
  }
}

#endif /* CQUATERION_HPP_ */
