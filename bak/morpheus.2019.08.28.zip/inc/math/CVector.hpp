#ifndef CVECTOR_HPP_
#define CVECTOR_HPP_

#include <iostream>

namespace math
{
  template <typename T>
  class CVector<T, 2> 
  {
    template<typename F, const ushort n>
    friend class CVector;
    
    private:
      typedef CVector<T, 2>  vec_t;
      static const ushort size = 2;
      union
      {
        T data[2];
        struct { T x; T y; };
        struct { T s; T t; };
        struct { T r; T g; };
      };
    public:
      CVector() : x(T(0)), y(T(0)) { }
      CVector(const CVector& that) 
      {
        data[0] = that.data[0];
        data[1] = that.data[1];
      }
      CVector(const T s) 
      {
        data[0] = s;
        data[1] = s;
      }
      CVector(const T x, const T y)
      {
        data[0] = x;
        data[1] = y;
      }
      CVector(const CVector<T, 3>& xyz)
      {
        data[0] = xyz.data[0];
        data[1] = xyz.data[1];
      }
      
      CVector& operator = (const CVector& rhs)
      {
        for(ushort i = 0; i < size; i++)
          data[i] = rhs.data[i];
        return *this;
      }
      CVector& operator = (const T rhs)
      {
        for(ushort i = 0; i < size; i++)
          data[i] = rhs.data[i];
        return *this;
      }
      
      T&       operator [] (const ushort i)
      {
        return data[i];
      }
      const T& operator [] (const ushort i) const
      {
        return data[i];
      }
  
      CVector operator  + (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] + rhs.data[i];
        return result;  
      }
      CVector& operator += (const CVector& rhs)
      {
        return (*this = *this + rhs);
      }
  
      CVector  operator -  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++) 
          result.data[i] = data[i] - rhs.data[i];
        return result;  
      }
      CVector& operator -= (const CVector& rhs)
      {
        return (*this = *this - rhs);
      }
      CVector  operator -  () const
      {
        CVector result;
        for(ushort i = 0; i < size; i++) 
          result.data[i] = -data[i];
        return result;  
      }
  
      CVector  operator * (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] * rhs.data[i];
        return result;  
      }
      CVector& operator *= (const CVector& rhs) 
      {
        return (*this = *this * rhs);
      }
      CVector  operator *  (const T rhs) const 
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] * rhs;
        return result;  
      }
      CVector& operator *= (const T rhs) 
      {
        return (*this = *this * rhs);
      }
      CVector  operator /  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] / rhs.data[i];
        return result;  
      }
      CVector& operator /= (const CVector& rhs) 
      {
        return (*this = *this / rhs);   // assing(*this / rhs);
      }
      CVector  operator /  (const T rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] / rhs;
        return result;  
      }
      CVector& operator /= (const T rhs) 
      {
        return (*this = *this / rhs);   // assing(*this / rhs);
      }
      
      bool operator < (const CVector& rhs) const
      {
        if(x < rhs.x)
        {
          return true;
        }
        else if(x == rhs.x)
        {
          return y < rhs.y; 
        }
        return false;
      }
      
      explicit operator        T* ()
      { 
        return (T*)(&data[0]); 
      }    
      explicit operator const T* () const 
      { 
        return (const T*)(&data[0]); 
      }    
      
      T length()
      {
        return (T)sqrt(x*x + y*y);
      }
      void normalize()
      {
        T l = length();
        if(l != T(1))
        {
          x /= l;
          y /= l;
        }
      }
  
      template <typename T1, const ushort n1>
      friend std::ostream& operator << (std::ostream&, const CVector<T1, n1>&);
  };
  
  template <typename T>
  class CVector<T, 3>
  {
    template<typename F, const ushort n>
    friend class CVector;
    
    private:
      typedef CVector<T, 3>  vec_t;
      static const ushort size = 3;
      union
      {
        T data[3];
        struct { T x; T y; T z; };
        struct { T s; T t; T p; };
        struct { T r; T g; T b; };
      };
    public:
      CVector() : x(T(0)), y(T(0)), z(T(0)) { }
      CVector(const CVector& that) 
      {
        for(ushort i = 0; i < size; i++)
          data[i] = that.data[i];
      }
      CVector(const T s) 
      { 
        for(ushort i = 0; i < size; i++)
          data[i] = s;
      }
      CVector(const T x, const T y, const T z) 
      { 
        data[0] = x;
        data[1] = y;
        data[2] = z;
      }
      CVector(const CVector<T, 2>& xy, const T z) 
      {
        data[0] = xy.data[0];
        data[1] = xy.data[1];
        data[2] = z;
      }
      CVector(const T x, const CVector<T, 2>& yz)
      {
        data[0] = x;
        data[1] = yz.data[1];
        data[2] = yz.data[2];
      }
      CVector(const CVector<T, 4>& xyzw)
      {
        data[0] = xyzw.data[0];
        data[1] = xyzw.data[1];
        data[2] = xyzw.data[2];
      }
      
      CVector& operator = (const CVector& rhs)
      {
        for(ushort i = 0; i < size; i++)
          data[i] = rhs.data[i];
        return *this;
      }
      CVector& operator = (const T rhs)
      {
        for(ushort i = 0; i < size; i++)
          data[i] = rhs;
        return *this;
      }
      
      T&       operator [] (ushort i)
      {
        return data[i];
      }
      const T& operator [] (ushort i) const
      {
        return data[i];
      }
  
      CVector  operator + (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] + rhs.data[i];
        return result;  
      }
      CVector& operator += (const CVector& rhs)
      {
        return (*this = *this + rhs);
      }
  
      CVector  operator -  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++) 
          result.data[i] = data[i] - rhs.data[i];
        return result;  
      }
      CVector& operator -= (const CVector& rhs)
      {
        return (*this = *this - rhs);
      }
      CVector  operator -  () const
      {
        CVector result;
        for(ushort i = 0; i < size; i++) 
          result.data[i] = -data[i];
        return result;  
      }
  
      CVector  operator *  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] * rhs.data[i];
        return result;  
      }
      CVector& operator *= (const CVector& rhs) 
      {
        return (*this = *this * rhs);
      }
      CVector  operator *  (const T rhs) const 
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] * rhs;
        return result;  
      }
      CVector& operator *= (const T rhs) 
      {
        return (*this = *this * rhs);
      }
      CVector  operator /  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] / rhs.data[i];
        return result;  
      }
      CVector& operator /= (const CVector& rhs) 
      {
        return (*this = *this / rhs);   // assing(*this / rhs);
      }
      CVector  operator /  (const T rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] / rhs;
        return result;  
      }
      CVector& operator /= (const T rhs) 
      {
        return (*this = *this / rhs);   // assing(*this / rhs);
      }
  
      bool operator < (const CVector& rhs) const
      {
        if(x < rhs.x)
        {
          return true;
        }
        else if(x == rhs.x)
        {
          if(y < rhs.y)
          {
            return true;
          }
          else if(y == rhs.y)
          {
            return z < rhs.z;
          }
        }
        return false;
      }
  
      explicit operator       T* () 
      { 
        return (T*)(&data[0]); 
      }
      explicit operator const T* () const 
      { 
        return (const T*)(&data[0]); 
      }    
  
      T length()
      {
        return (T)sqrt(x*x + y*y + z*z);
      }
      
      void normalize()
      {
        T l = length();
        if(l != T(1))
        {
          x /= l;
          y /= l;
          z /= l;
        }
      }
      
      void rotate(const CQuaterion<T>& Q) // rotate vector to quat orientation
      {
        *this = Q * (*this);
      }
      
      template <typename T1, const ushort n1>
      friend std::ostream& operator << (std::ostream&, const CVector<T1, n1>&);
  };
  
  template <typename T>
  class CVector<T, 4>
  {
    template<typename F, const ushort n>
    friend class CVector;
    
    private:
      typedef CVector<T, 4>  vec_t;
      static const ushort size = 4;  
      union
      {
        T data[4];
        struct { T x; T y; T z; T w; };
        struct { T s; T t; T p; T q; };
        struct { T r; T g; T b; T a; };
      };
    public:
      CVector() : x(T(0)), y(T(0)), z(T(0)), w(T(0)) { }
      CVector(const CVector& that) 
      {
        for(ushort i = 0; i < size; i++)
          data[i] = that.data[i];
      }
      CVector(const T s) 
      { 
        for(ushort i = 0; i < size; i++)
          data[i] = s;
      } 
      CVector(const T x, const T y, const T z, const T w) 
      { 
        data[0] = x;
        data[1] = y;
        data[2] = z;
        data[3] = w;
      }
      CVector(const CVector<T, 2>& xy, const T z, const T w) 
      {
        data[0] = xy.data[0];
        data[1] = xy.data[1];
        data[2] = z;
        data[3] = w;
      }
      CVector(const T x, const CVector<T, 2>& yz, const T w) 
      {
        data[0] = x;
        data[1] = yz.data[1];
        data[2] = yz.data[2];
        data[3] = w;
      }
      CVector(const T x, const T y, const CVector<T, 2>& zw) 
      {
        data[0] = x;
        data[1] = y;
        data[2] = zw.data[2];
        data[3] = zw.data[3];
      }
      CVector(const CVector<T, 3>& xyz, const T w) 
      {
        data[0] = xyz.data[0];
        data[1] = xyz.data[1];
        data[2] = xyz.data[2];
        data[3] = w;
      }
      CVector(const T x, const CVector<T, 3>& yzw) 
      {
        data[0] = x;
        data[1] = yzw.data[1];
        data[2] = yzw.data[2];
        data[3] = yzw.data[3];
      }
      
      CVector& operator =  (const CVector& rhs)
      {
        for(ushort i = 0; i < size; i++)
          data[i] = rhs.data[i];
        return *this;
      }
      CVector& operator =  (const T rhs)
      {
        for(ushort i = 0; i < size; i++)
          data[i] = rhs;
        return *this;
      }
      
      T&       operator [] (const ushort i)
      {
        return data[i];
      }
      const T& operator [] (const ushort i) const
      {
        return data[i];
      }
  
      CVector  operator +  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] + rhs.data[i];
        return result;  
      }
      CVector& operator += (const CVector& rhs)
      {
        return (*this = *this + rhs);
      }
      CVector  operator -  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++) 
          result.data[i] = data[i] - rhs.data[i];
        return result;  
      }
      CVector& operator -= (const CVector& rhs)
      {
        return (*this = *this - rhs);
      }
      CVector  operator -  () const
      {
        CVector result;
        for(ushort i = 0; i < size; i++) 
          result.data[i] = -data[i];
        return result;  
      }
  
      CVector  operator *  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] * rhs.data[i];
        return result;  
      }
      CVector& operator *= (const CVector& rhs) 
      {
        return (*this = *this * rhs);
      }
      CVector  operator *  (const T rhs) const 
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] * rhs;
        return result;  
      }
      CVector& operator *= (const T rhs) 
      {
        return (*this = *this * rhs);
      }
      CVector  operator /  (const CVector& rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] / rhs.data[i];
        return result;  
      }
      CVector& operator /= (const CVector& rhs) 
      {
        return (*this = *this / rhs);   // assing(*this / rhs);
      }
      CVector  operator /  (const T rhs) const
      {
        CVector result;
        for(ushort i = 0; i < size; i++)
          result.data[i] = data[i] / rhs;
        return result;  
      }
      CVector& operator /= (const T rhs) 
      {
        return (*this = *this / rhs);   // assing(*this / rhs);
      }
  
      bool operator < (const CVector& rhs) const
      {
        if(x < rhs.x)                       // TODO: use math::greater()
        {
          return true;
        }
        else if(x == rhs.x)                 // TODO: use math::equals()
        {
          if(y < rhs.y)
          {
            return true;
          }
          else if(y == rhs.y)
          {
            if(z < rhs.z)
            {
              return true;
            }
            else if(z == rhs.z)
            {
              return w < rhs.w;
            }
          }
        }
        return false;
      }
  
      explicit operator       T* () 
      { 
        return (T*)(&data[0]); 
      }    
      explicit operator const T* () const 
      { 
        return (const T*)(&data[0]); 
      }    
      
      T length()
      {
        return (T)sqrt(x*x + y*y + z*z + w*w);
      }
      void normalize()
      {
        T l = length();
        if(l != T(1))
        {
          x /= l;
          y /= l;
          z /= l;
          w /= l;
        }
      }
  
      template <typename T1, const ushort n1>
      friend std::ostream& operator<<(std::ostream&, const CVector<T1, n1>&);
  };
  
  /** external operators */ /* ********************************************************************************** */
  
  template <typename T, const ushort n>
  std::ostream& operator << (std::ostream& out, const CVector<T, n>& v)
  {
    out << "[ ";
    for(ushort i = 0; i < n; i++)
      out << v[i] << " ";
    out << "]";
    return out;
  }
  
  template <typename T, const ushort n>
  const CVector<T, n> operator * (const T s, const CVector<T, n>& v)
  {
    return v * s;
  }
  
  template <typename T, const ushort n>
  const CVector<T, n> operator / (const T s, const CVector<T, n>& v)
  {
    CVector<T, n> result(0);
    for(ushort i = 0; i < n; i++)
      result[i] = s / v[i];
    return result;
  }
  
  template <typename T, const ushort c, const ushort r>
  CVector<T, c> operator * (const CMatrix<T, c, r>& mat, const CVector<T, r>& vec)
  {
    CVector<T, c> result(T(0));
    for(ushort i = 0; i < r; i++)
      for(ushort j = 0; j < c; j++)
        result[j] += vec[i] * mat[j][i];
    return result;  
  }

  template <typename T, const ushort n> 
  bool operator == (const CVector<T,n >& left, const CVector<T, n>& right)
  {
    for(size_t i = 0; i < n; ++i)
      if(!math::equals(left[i], right[i])) // if not equal using epsilon comparison
        return false;
    return true;
  }
}

#endif /* CVECTOR_HPP_ */
