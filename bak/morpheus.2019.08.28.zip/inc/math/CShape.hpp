#ifndef __MATH_CSHAPE_HPP__
#define __MATH_CSHAPE_HPP__

#include <cassert>
#include <vector>

namespace math
{
  class CShape
  {
    public:
    std::vector<math::CPlane> mPlanes;
    
    public:
    CShape()
    {
    
    }
    
    CShape(size_t i)
    {
      //mPlanes.resize(i);
    }
    
    CShape(const std::vector<math::CPlane>& planes) : mPlanes(planes)
    {
    
    }
    
    virtual ~CShape()
    {
    
    }
    
    virtual void addPlane(const CPlane& plane)
    {
      mPlanes.push_back(plane);
    }
    
    virtual void setPlane(size_t i, const CPlane& plane)
    {
      assert(i < mPlanes.size());
      mPlanes[i] = plane;
    }
    
    virtual CPlane getPlane(size_t i) const
    {
      assert(i < mPlanes.size());
      return mPlanes[i];
    }
  };
}

#endif // __MATH_CSHAPE_HPP__
