#ifndef __MATH_CRAY_HPP__
#define __MATH_CRAY_HPP__

namespace math
{
  class CRay
  {
    public:
    math::vec3 mPosition;
    math::vec3 mDirection;
    
    public:
    CRay(const math::vec3& d) 
    : mPosition(0.0f), mDirection(math::normalize(d))
    {
    
    }
    
    CRay(const math::vec3& p, const math::vec3& d)
    : mPosition(p), mDirection(math::normalize(d))
    {
      
    }
    
    math::vec3 getPoint(float t) const
    {
      assert(t >= math::EPSILON<float>());
      return mPosition + t * mDirection;
    }
    
    virtual ~CRay()
    {
      
    }
  };
}

#endif // __MATH_CRAY_HPP__
