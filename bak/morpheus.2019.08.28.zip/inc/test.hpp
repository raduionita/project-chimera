#ifndef __TEST_HPP__
#define __TEST_HPP__

namespace test
{
  
  
  /**
   * Is the point on the - side, on, or + side of the plane?
   * @param  math::vec3   point
   * @param  math::CPlane plane
   * @return bool
   */
  unsigned int evalPointToPlane(const math::vec3& point, const math::CPlane& plane)
  {
    return 1;
  }
  
  
  bool doesRayIntersectPlane(const math::CRay& ray, const math::CPlane& plane)
  {
    float DdotN = math::dot(ray.mDirection, plane.mNormal);
    
    if(math::equals(DdotN, 0.0f)) // ray || to plane - angle between ray and plane normal = 90 deg
      return false;
      
    float t = math::dot(plane.mNormal, plane.mDistance * plane.mNormal - ray.mPosition) / DdotN; 
    
    // for possible collision t must be >= 0
    
    if(math::lesser(t, 0.0f)) // if t < 0
      return false;
    
    return false;
  }
  
  bool doesSphereIntersectSphere(const math::CSphere& s1, const math::CSphere& s2)
  {
    math::vec3  v = s1.mPosition - s2.mPosition;
    float   dist2 = v.x * v.x + v.y * v.y + v.z * v.z;
    float minDist = s1.mRadius + s2.mRadius;
    minDist *= minDist; 
    return dist2 <= minDist;
  }
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CObject
  {
    public:
    math::vec3 mPosition;
    math::vec3 mVelocity;
    float      mRadius;
  };
  
  class CIntersectionTest 
  { 
    protected:
    CObject* mObject1;
    CObject* mObject2;
  
    public:
    CIntersectionTest() : mObject1(nullptr) , mObject2(nullptr)
    {
    
    }
    
    bool operator () ()
    {
      assert(mObject1 != nullptr);
      assert(mObject2 != nullptr);
      return test();
    }
    
    protected:
    virtual bool test() = 0;
    
    public:
    bool run()
    {
      return (*this)();
    }
  };
  
  class CSphereIntersectionTest : public CIntersectionTest
  {
    protected:
    bool test()
    {
      return false;
    }
  };
  
//  COobject* pObject1 = nullptr;
//  COobject* pObject2 = nullptr;
//  CSphereIntersectionTest* pIntersectionTest = new CSphereIntersectionTest(pObject1, pObject2);
//  pIntersectionTest();
  
  
  /**
   * Bound sphere collision detection
   * @see http://www.gamedev.net/page/resources/_/technical/math-and-physics/simple-bounding-sphere-collision-detection-r1234
   */
  bool evalSpehereIntersectionTest(const CObject* pObject1, const CObject* pObject2)
  {
    math::vec3 dv = pObject2->mVelocity - pObject2->mVelocity; // relative velocity
    math::vec3 dp = pObject2->mPosition - pObject2->mPosition; // relative position
    
    float r = pObject1->mRadius + pObject2->mRadius; // min distance - when the 2 spheres are touching in 1 point
    
    // dp^2 -r^2
    float pp = dp.x*dp.x + dp.y*dp.y + dp.z*dp.z - r*r; // math::dot(dp, dp) - r*r
    if(pp < 0)  // check if the spheres are already intersecting
      return true;
  
    // dp*dv
    float pv = math::dot(dp, dv);
    if(pv >= 0) // check if speres are moving away from each other
      return false;
      
    // dv^2
    float vv = math::dot(dv, dv); // squared magnitude of relative velocity
    if((pv + vv) <= 0 && (vv + 2 * pv + pp) >= 0) // check if spehere can intersect within 1 frame
      return false;
    // TODO: test this - the orig formula: (vv - pv < 0)
    
    // delta/4
    // float D = pv * pv - pp * vv;
    // return D > 0;
    
    // optimization - prevent precision loss at great speeds - divide by vv
    // tmin = -dp*dv/dv*dv
    float tmin = -pv/vv; // time when distance between spheres is minimal
    // delat/(4*dv*dv) = -(dp*dp - r*r +dp*dv * tmin)
    return (pp + pv * tmin > 0); 
    // TODO: test if this should be (pp + pv * tmin < 0) caused of the inversed sign
  }
  
  
//  EClassifyResult CClassify::evalPolygonAndPlane(const CPolygon& polygon, const math::CPlane& plane);
//  
//  class CIntersectResult { };
//  class CIntersect { };
//  
//  CIntersectResult test::CCIntersect::testRayAndPlane(const math::CRay& ray, const math::CPlane& plane);
}

#endif // __TEST_HPP__
