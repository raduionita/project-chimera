#ifndef UTIL_HPP_
#define UTIL_HPP_

#include "util/CFile.hpp"
#include "util/CLog.hpp"
#include "util/CDescriptor.hpp"
#include "util/CSingleton.hpp"

/* 
  TODO: util to become core
*/
// namespace core
namespace util
{
  template<typename T>
  class CEnum
  {
    public:
    enum : T
    {
      NONE = 0
    };
    
    protected:
    CEnum()
    {
    
    }
    
    CEnum(const CEnum&)
    {
    
    }
    
    virtual ~CEnum()
    {
    
    }
    
    CEnum& operator = (const CEnum&)
    {
      return *this;
    }
  };
  
  class CDrawOptions : public CEnum<unsigned int>
  {
    public:
    enum EDrawOptions : unsigned int
    {
      NONE       = CEnum<unsigned int>::NONE,
      NOMATERIAL
    };
  };
}

#endif /* UTIL_HPP_ */
