#ifndef __main_hpp__
#define __main_hpp__

#define LOGGING 1

#define KEY_PRESS       1
#define KEY_RELEASE     0
#define KEY_ESC        27
#define KEY_BACKSPACE   8
#define KEY_ENTER      13
#define KEY_SHIFT      16
#define KEY_SPACEBAR   32
#define KEY_LEFT       37
#define KEY_UP         38
#define KEY_RIGHT      39
#define KEY_DOWN       40
#define KEY_Z         122
#define KEY_X         120
#define KEY_W         119
#define KEY_A          97
#define KEY_S         115
#define KEY_D         100
#define KEY_P         112
#define KEY_Q         113
#define KEY_E         101
#define KEY_NUM_7      55
#define KEY_NUM_8      56
#define KEY_NUM_9      57
#define KEY_NUM_UP     56
#define KEY_NUM_4      52
#define KEY_NUM_LEFT   52
#define KEY_NUM_2      50
#define KEY_NUM_DOWN   50
#define KEY_NUM_6      54
#define KEY_NUM_RIGHT  54

#define MOUSE_PRESS   0
#define MOUSE_RELEASE 1
#define MOUSE_LEFT    0
#define MOUSE_MIDDLE  1
#define MOUSE_RIGHT   2

#define _COUNT(array) sizeof(array) / sizeof(array[0])
#define _DELETE(p) { delete p; p = nullptr; }
#define _ZEROMEM(a) memset(a, 0, sizeof(a))

#define RESTART_INDEX (ushort)(-1)

#define _(type) (type)(-1) // TODO: replace with dynamic enums/tags

#endif // __main_hpp__
