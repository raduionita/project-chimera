#ifndef __util_cdescriptor_hpp__
#define __util_cdescriptor_hpp__

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>

namespace sys
{
  class CTag
  {
    public:
    typedef int value_t;
    
    protected:
    value_t                         mValue;
    static std::vector<std::string> mTable;
    
    public:
    CTag(const std::string& name)
    {
      mTable.push_back(name);
      mValue = mTable.size() - 1;
    }
    
    CTag(const CTag& that)
    {
      mValue = that.mValue;
    }
    
    CTag(CTag&& that)
    {
      mValue = std::move(that.mValue);
    }
    
    CTag& operator = (const CTag& that)
    {
      if(this != &that)
        mValue = that.mValue;
      return *this;
    }
    
    CTag& operator = (const CTag&& that)
    {
      if(this != &that)
        mValue = std::move(that.mValue);
      return *this;
    }
    
    bool operator == (const CTag& that)
    {
      return mValue == that.mValue;
    }
    
    explicit operator value_t ()
    {
      return mValue;
    }  
    
    explicit operator const value_t () const
    {
      return mValue;
    }
  
    operator const std::string () const
    {
      return mTable[mValue];
    }
  
    friend bool operator <  (const CTag& lhs, const CTag& rhs);
    
    friend bool operator == (const CTag& lhs, const CTag& rhs);
    
    friend bool operator != (const CTag& lhs, const CTag& rhs);
    
    public:
    const std::string& getTagName() const
    {
      return mTable[mValue];
    }
  };
  
  std::vector<std::string> CTag::mTable;
  
  class CDescriptor
  {
    protected:
    std::vector<CTag> mTags;
    
    public:
    CDescriptor()
    {
      
    }
    
    CDescriptor(const CDescriptor& that)
    {
      mTags = that.mTags;
    }
    
    CDescriptor(const CTag& tag)
    {
      mTags.push_back(tag);
    }
    
    CDescriptor& operator = (const CDescriptor& that)
    {
      if(this != &that)
      {
        mTags = that.mTags;
      }
      return *this;
    }
    
    CDescriptor& operator += (const CDescriptor& that)
    {
      if(this != &that)
      {
        for(CTag oTag : that.mTags)
          mTags.push_back(oTag);
      }
      return *this;
    }
    
    CDescriptor& operator += (const CTag& that)
    {
      mTags.push_back(that);
      return *this;
    }
    
    operator const std::string() const
    {
      std::ostringstream oss;
      oss << "ogl::CDescriptor: ";
      for(CTag tag : mTags)
        oss << tag.getTagName() << " ";
      return oss.str().c_str();
    }
    
    public:
    bool hasTag(const CTag& tag)
    {
      for(CTag& oTag : mTags)
        if(oTag == tag)
          return true;
      return false;
    }
    
    friend bool operator <  (const CDescriptor& lhs, const CDescriptor& rhs);
    
    friend bool operator == (const CDescriptor& lhs, const CDescriptor& rhs);
    
    friend bool operator != (const CDescriptor& lhs, const CDescriptor& rhs);
    
    friend CDescriptor operator + (const CTag& lhs, const CTag& rhs);
    
    friend CDescriptor operator + (const CDescriptor& lhs, const CTag& rhs);
    
    friend CDescriptor operator - (const CDescriptor& lhs, const CTag& rhs);
    
    friend std::ostream& operator << (std::ostream&, const CDescriptor&);
    
    friend sys::CLogger& operator << (sys::CLogger&, const CDescriptor&);
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
  
  CDescriptor operator + (const CTag& lhs, const CTag& rhs)
  {
    CDescriptor out(lhs);
    out.mTags.push_back(rhs);
    return out;
  }
  
  CDescriptor operator + (const CDescriptor& lhs, const CTag& rhs)
  {
    CDescriptor out(lhs);
    for(auto it = out.mTags.begin(); it != out.mTags.end(); ++it)
      if(*it == rhs)
        return out;
    out.mTags.push_back(rhs);
    return out;
  }
  
  CDescriptor operator - (const CDescriptor& lhs, const CTag& rhs)
  {
    CDescriptor out(lhs);
    for(auto it = out.mTags.begin(); it != out.mTags.end(); ++it)
      if(*it == rhs)
        out.mTags.erase(it);
    return out;
  }

  std::ostream& operator << (std::ostream& out, const CDescriptor& oDescriptor)
  {
    out << "ogl::CDescriptor: ";
    for(CTag tag : oDescriptor.mTags)
      out << tag.getTagName() << " ";
    return out;
  }
  
  sys::CLogger& operator << (sys::CLogger& logger, const CDescriptor& oDescriptor)
  {
    logger << "ogl::CDescriptor: ";
    for(CTag tag : oDescriptor.mTags)
      logger << tag.getTagName() << " ";
    return logger;
  }
  
  bool operator <  (const CTag& lhs, const CTag& rhs)
  {
    return lhs.mValue < rhs.mValue;
  }
  
  bool operator == (const CTag& lhs, const CTag& rhs)
  {
    return lhs.mValue == rhs.mValue;
  }
  
  bool operator != (const CTag& lhs, const CTag& rhs)
  {
    return lhs.mValue != rhs.mValue;
  }
  
  bool operator < (const CDescriptor& lhs, const CDescriptor& rhs)
  {
    return lhs.mTags < rhs.mTags;
  }
  
  bool operator == (const CDescriptor& lhs, const CDescriptor& rhs)
  {
    if(lhs.mTags.size() != rhs.mTags.size())
      return false;
    
    size_t l = lhs.mTags.size();
    size_t f = 0;
    for(size_t i = 0; i < l; ++i)
    {
      for(size_t j = 0; j < l; ++j)
      {
        if(lhs.mTags[i] == rhs.mTags[j])
        {
          ++f;
          break;
        }
      }
    }
    
    if(f == l)
      return true;
    
    return false;
  }  
  
  bool operator != (const CDescriptor& lhs, const CDescriptor& rhs)
  {
    return !(lhs == rhs);
  }

  namespace tags
  {
    static const sys::CTag NONE("NONE");
    static const sys::CTag DUMMY("DUMMY");
    static const sys::CTag CURRENT("CURRENT");
  }
}

#endif // __util_cdescriptor_hpp__


































