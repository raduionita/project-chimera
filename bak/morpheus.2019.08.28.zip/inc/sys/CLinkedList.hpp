#ifndef __sys_clinkedlist_hpp__
#define __sys_clinkedlist_hpp__

namespace sys
{
  template <typename T> 
  class CLinkedList;

  template <typename T>
  class CIterator
  {
    friend class CLinkedList<T>;
  
    protected:
    T             mObject;
    CIterator<T>* mNext;
    
    public:
    CIterator() : mNext(nullptr)
    {
      
    }
    
    CIterator(T& oObject) : mObject(oObject), mNext(nullptr)
    {
      
    }
    
    virtual ~CIterator()
    {
      delete mNext;
    }
    
    T& operator * ()
    {
      return mObject;
    }
  
    // CIterator<T>* operator ++ ()
    // {
    //   mNext = mNext->mNext;
    // }
  };

  template <typename T>
  class CLinkedList
  {
    public:
    typedef CIterator<T>* iterator_t;
    
    protected:
    CIterator<T>* mFirst;
    CIterator<T>* mCurr;
    
    public:
    CLinkedList() : mFirst(nullptr), mCurr(nullptr)
    {
      
    }
    
    protected:
    /**
     * @param uint          back = 0 Count back this may items
     * @param CIterator<T>* pMark    Last item, considering back counting
     */
    CIterator<T>* last(size_t back = 0)
    {
      CIterator<T>* pMark = mCurr;
      CIterator<T>* pLast = mCurr;
      
      size_t i = 0;
      
      while(pLast->mNext != nullptr)
      {
        pLast = pLast->mNext;
        
        if(i < back)
          ++i;                  // stay
        else // if(i == back)
          pMark = pMark->mNext; // advance
      }
      
      if(i < back)
        return nullptr;
      else
        return pMark;
    }
    
    public:
    CIterator<T>* pop()
    {
      CIterator<T>* pPrevLast = last(-1); // get previous to last
      
      CIterator<T>* pLast = pPrevLast->mNext;
      pPrevLast->mNext = nullptr;
      
      return pLast;
    }
    
    void push(T& oObject)
    {
      CIterator<T>* pLast = last();
      if(pLast == nullptr)
        mCurr = new CIterator<T>(oObject);
      else
        pLast = new CIterator<T>(oObject);
    }
    
    CIterator<T>* next()
    {
      if(mCurr != nullptr && mCurr->mNext != nullptr)
      {
        mCurr = mCurr->mNext;
        return mCurr;
      }
      
      return nullptr;
    }
    
    CIterator<T>* back()
    {
      return nullptr;
    }
    
    CIterator<T>* current()
    {
      return mCurr;
    }
    
    CIterator<T>* first()
    {
      return mFirst;
    }
    
    void reset()
    {
      mCurr = mFirst;
    }
  };
  
  void dummy()
  {
    CLinkedList<CException> ll;
    CLinkedList<CException>::iterator_t it;
    while((it = ll.next()) != nullptr)
    {
      
    }
  }
}

namespace fake
{
  class CObject { };

  template <typename T>
  class CLinkedList
  {
    protected:
    T*              mData;
    CLinkedList<T>* mNext;
    
    public:
    CLinkedList() : mData(nullptr), mNext(nullptr)
    {
      
    }
    
    CLinkedList(const T& data) : mNext(nullptr)
    {
      mData = &data;
    }
    
    virtual ~CLinkedList()
    {
      delete mNext;
    }
  
    public:
    void push(const T& data)
    {
      CLinkedList<T>* pLast = mNext;
      while(pLast != nullptr)
        pLast = pLast->mNext;
      pLast = new CLinkedList(&data);
    }
    
    CLinkedList<T>& next()
    {
      if(mNext != nullptr) 
        mData = mNext->mData;
      return *this;
    }
    
    CLinkedList<T>& peek()
    {
      return *mNext;
    }
    
    T& operator * ()
    {
      return *mData;
    }
    
    const T& operator * () const
    {
      return *mData;
    }
  };
  
  void dummy()
  {
    CLinkedList<CObject> lList;
  }
}

#endif // __sys_clinkedlist_hpp__
