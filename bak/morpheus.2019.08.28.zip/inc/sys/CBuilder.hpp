#ifndef __util_cbuilder_hpp__
#define __util_cbuilder_hpp__

namespace sys
{
  template <typename T>
  class CBuilder
  {
    public:
    virtual ~CBuilder()
    {
      
    }
    
    public:
    virtual T* build() = 0;
  };
  
  // class CSomethingBuilder : public CBuilder<CSomething>;
}

#endif // __util_cbuilder_hpp__
