#ifndef __sys_cpointer_hpp__
#define __sys_cpointer_hpp__

namespace sys
{
  template <typename T>
  class CPointer
  {
    protected:
    T*   mPointer;
    int* mCount;
    
    public:
    CPointer() 
    {
      mPointer = nullptr;
      mCount   = new int(0);
    }
    
    CPointer(T* pPointer)
    {
      mPointer = pPointer;
      mCount   = new int(1);
    }
    
    CPointer(const CPointer& that)
    {
      mPointer = that.mPointer;
      mCount   = that.mCount;
      ++(*mCount);
    }
    
    virtual ~CPointer()
    {
      if(--(*mCount) == 0) 
      {
        delete mPointer; mPointer = nullptr;
        delete mCount; mCount = nullptr;
      }
    }
    
    CPointer& operator = (const CPointer& that)
    {
      if(this != &that)
      {
        if(*(mCount) == 0)
        {
          delete mPointer; mPointer = nullptr;
          delete mCount; mCount = nullptr;
        }
        
        mPointer = that.mPointer;
        mCount   = that.mCount;
      }
      
      // sys::ptr<CObject> pObject0(new CObject);
      // sys::ptr<CObject> pObject1 = pObject0;
      
      return *this;
    }
    
    CPointer& operator = (T* pPointer)
    {
      if(*(mCount) == 0)
      {
        delete mPointer; mPointer = nullptr;
        delete mCount; mCount = nullptr;
      }
      
      mPointer = pPointer;
      mCount   = new int(1);
      
      // sys::ptr<CObject> pObject = new CObject;
      
      return *this;
    }
    
    T& operator * ()
    {
      return *mPointer;
    }
    
    T* operator -> ()
    {
      return mPointer;
    }
    
    bool operator == (std::nullptr_t)
    {
      return mPointer == nullptr;
    }
    
    bool operator == (const T* pPointer)
    {
      return mPointer == pPointer;
    }
    
    bool operator == (const CPointer& oPointer)
    {
      return mPointer == oPointer.mPointer;
    }
    
    bool operator == (bool state)
    {
      if(state) // mPointer == true
        return mPointer != nullptr;
      return mPointer == nullptr;
    }
    
    operator bool ()
    {
      return mPointer != nullptr;
    }
    
    bool operator ! ()
    {
      return mPointer == nullptr;
    }
  };
}

#endif // __sys_cpointer_hpp__
