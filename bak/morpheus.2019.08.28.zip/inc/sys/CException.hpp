#ifndef __util_cexception_hpp__
#define __util_cexception_hpp__

#include <exception>
#include <string>
#include <iostream>

namespace sys
{
  class CException : public std::exception
  {
    protected:
    std::string mMessage;
    std::string mFile;
    size_t      mLine;
    
    public:
    CException() : std::exception()
    {
    
    }
    
    CException(const std::string& message) 
    : mMessage(message)
    {
      
    }
    
    CException(const std::string& message, const std::string& file, size_t line) 
    : mMessage(message), mFile(file), mLine(line)
    {
      
    }
    
    CException(const std::string& file, size_t line) 
    : mFile(file), mLine(line)
    {
      
    }
    
    CException& operator << (const std::string& message)
    {
      mMessage.append(message);
      return *this;
    }
    
    public:
    virtual const char* what() const throw()
    {
      return mMessage.c_str();
    }
    
    CException& setMessage(const std::string& message)
    {
      mMessage = message;
      return *this;
    }
  
    CException& setFile(const std::string& file)
    {
      mFile = file;
      return *this;
    }
    
    CException& setLine(size_t line)
    {
      mLine = line;
      return *this;
    }
  };
}

#define EXCEPTION (sys::CException(__FILE__, __LINE__))

#endif // __util_cexception_hpp__
