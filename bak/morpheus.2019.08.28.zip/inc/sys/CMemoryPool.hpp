#ifndef __sys_cmemorypool_hpp__
#define __sys_cmemorypool_hpp__


#include <map>
#include <cassert>

namespace sys
{
  template <typename T>
  class CMemoryPool
  {
    protected:
    std::map<T*, size_t> mPool;
    
    public:
    CMemoryPool()
    {
      
    };
    
    virtual ~CMemoryPool()
    {
      sys::info << "CMemoryPool::~CMemoryPool()" << sys::endl;
      clear();
    };
    
    T* allocate(size_t size = 1)
    {
      assert(size);
      if(size == 1)
      {
        T* ptr = new T;
        mPool[ptr] = 1;
      
        return ptr;
      }
      else
      {
        T* ptr = new T[size];
        mPool[ptr] = size;
        return ptr;
      }
    }
    
    T* allocate(const T* value, size_t size = 1)
    {
      assert(size);
    
      if(size == 1)
      {
        T* ptr = new T(*value);
        mPool[ptr] = 1;
        
        return ptr;
      }
      else // > 1
      {
        T* ptr = new T[size];
        //for(size_t i = 0; i < size; i++)
        //  ptr[i] = value[i];
          
        memcpy(ptr, value, size);;
        
        mPool[ptr] = size;
        
        return ptr;
      }
    }
    
    void clear()
    {
      if(mPool.empty() == false)
      {
        sys::info << "CMemoryPool::clear() [" << mPool.size() << "] > ";
        for(auto it = mPool.begin(); it != mPool.end(); ++it)
        {
          sys::info << static_cast<const void*>(it->first) << " ";
          if(it->second == 1)
            delete it->first;
          else
            delete [] it->first;
        }
        sys::info << sys::endl;
        mPool.clear();
      }
    }
    
    size_t size()
    {
      return mPool.size();
    }
  };
}


#endif // __sys_cmemorypool_hpp__
