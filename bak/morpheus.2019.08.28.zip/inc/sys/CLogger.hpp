#ifndef CLOG_HPP_
#define CLOG_HPP_

#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>

#ifndef LOGGING
  #define LOGGING 1
#endif // LOGGING

namespace sys
{
  class CLogger;

  class CLoggerStrategy
  {
    friend class CLogger;
  
    public:
    CLoggerStrategy()
    {
      //CLogger& log = CLogger::getInstance();
      //log << *this;
    }
  
    virtual ~CLoggerStrategy()
    {
      
    }
  
    public:
    virtual void log(const std::string& message) = 0;
  };
  
  void flush(CLoggerStrategy& strategy, std::string& output)
  {
    strategy.log(output);
  }
  
  void endl(CLoggerStrategy& strategy, std::string& output)
  {
    output.append("\n");
    sys::flush(strategy, output);
  }

  class CLogger
  {
    public:
    typedef void(*manipulator_t)(CLoggerStrategy&, std::string&);
    typedef struct tm timeinfo_t;
    
    enum class EType : int
    {
      INFO  = 0x01,
      DEBUG = 0x02,
      WARN  = 0x04,
      FATAL = 0x10
    };
  
    protected:
    static CLogger*  sInstance;
    CLoggerStrategy* mStrategy;
    std::string      mOutput;
    EType            mType;
    time_t           mTime;
    
    public:
    CLogger() : mStrategy(nullptr), mType(EType::INFO)
    {
      
    }
    
    CLogger(CLoggerStrategy* pStrategy)
    {
      mStrategy = pStrategy;
    }
    
    virtual ~CLogger()
    {
      *this << sys::flush;
    }
    
    public:
    CLogger& operator << (const EType& type)
    {
      mType = type;
      return *this;
    }

    CLogger& operator << (const std::string& output)
    {
      mOutput.append(output);
      return *this;
    }
    
    CLogger& operator << (manipulator_t manipulator)
    {
      if(!mOutput.empty() && LOGGING)
      {
        switch(mType)
        {
          default:
          case EType::INFO:  mOutput = "INFO: "  + mOutput; break;
          case EType::DEBUG: mOutput = "DEBUG: " + mOutput; break;
          case EType::WARN:  mOutput = "WARN: "  + mOutput; break;
          case EType::FATAL: mOutput = "FATAL: " + mOutput; break;
        };
        
        static timeinfo_t* timeinfo;
        std::time(&mTime);
        timeinfo = std::localtime(&mTime);
        
        char timestr[23];
        std::strftime(timestr, 23, "[%Y-%m-%d %H:%M:%S] ", timeinfo);
        timestr[22] = '\0';
        
        mOutput = timestr + mOutput;
        
        manipulator(*mStrategy, mOutput);
      }
      mOutput.clear();
      return *this;
    }
  
    template <typename T>
    CLogger& operator << (const T& output)
    {
      std::stringstream ss;
      ss << output;
      mOutput.append(ss.str());
      return *this;
    }
    
    template <typename T>
    friend CLogger& operator << (const CLogger::EType&, const T&);
  
    public:
    CLogger& setStrategy(CLoggerStrategy* pStrategy)
    {
      mStrategy = pStrategy;
      return *this;
    }
  };

  class CFileLoggerStrategy : public CLoggerStrategy
  {
    friend class CLogger;
    
    protected:
    std::fstream mFStream;
    
    public:
    CFileLoggerStrategy(const CFile& file) : CLoggerStrategy()
    {
      mFStream.open(file.getFilePath().c_str(), std::ios::binary | std::ios::out | std::ios::trunc);
      if(!mFStream.is_open())
        throw EXCEPTION << "Failed to open/create log file: " << file.getFilePath();
    }
    
    ~CFileLoggerStrategy()
    {
      mFStream.close();
    }
    
    public:
    void log(const std::string& output)
    {
      mFStream.write(output.c_str(), output.size());
    }
  };
  
  class CCoutLoggerStrategy : public CLoggerStrategy
  {
    friend class CLogger;
    
    public:
    CCoutLoggerStrategy() : CLoggerStrategy()
    {
      
    }
    
    public:
    void log(const std::string& output)
    {
      std::cout << output;
    }
  };

  CCoutLoggerStrategy cout;
  CLogger             log(&cout);
  const std::string   tab("\t");
  
  CLogger::EType info  = CLogger::EType::INFO;
  CLogger::EType debug = CLogger::EType::DEBUG;
  CLogger::EType warn  = CLogger::EType::WARN;
  CLogger::EType error = CLogger::EType::FATAL;
  
  template <typename T>
  CLogger& operator << (const CLogger::EType& type, const T& output)
  {
    log << type;
    log << output;
    return log;
  }

  CLoggerStrategy& operator >> (CLoggerStrategy& oStrategy, CLogger& oLog)
  {
    oLog.setStrategy(&oStrategy);
    return oStrategy;
  }
}


#endif /* CLOG_HPP_ */
