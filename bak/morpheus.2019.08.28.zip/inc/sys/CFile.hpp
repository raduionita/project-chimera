#ifndef __util_cfile_hpp__
#define __util_cfile_hpp__

#include <string>
#include <utility>

namespace sys
{
  class CFile
  {
#define DS "/"
  
    protected:
    std::string mFolder;
    std::string mBase;
    std::string mExt;
    
    bool        mEmpty;
  
    public:
    CFile() : mEmpty(true)
    {
      
    }
    
    CFile(const std::string& oFilePath) : mEmpty(false)
    {
      mEmpty = oFilePath.empty();
      
      if(!mEmpty) 
      {
        size_t nDotPos = oFilePath.find_last_of(".");
        mExt  = oFilePath.substr(nDotPos + 1);
        size_t nFilePos = oFilePath.find_last_of(DS);
        mBase = oFilePath.substr(nFilePos + 1, nDotPos - nFilePos - 1);
        mFolder = oFilePath.substr(0, nFilePos + 1);
      }
    }
    
    virtual ~CFile()
    {
      
    }
    
    CFile(const CFile& that)
    {
      if(!that.mEmpty)
      {
        mEmpty  = false;
        mFolder = that.mFolder;
        mBase   = that.mBase;
        mExt    = that.mExt;
      }
    }
    
    CFile(CFile&& that)
    {
      if(!that.mEmpty)
      {
        mEmpty  = false;
        mFolder = std::move(that.mFolder);
        mBase   = std::move(that.mBase);
        mExt    = std::move(that.mExt);
      }
    }
    
    CFile& operator = (CFile& that)
    {
      if(this != &that && !that.mEmpty)
      {
        mEmpty  = false;
        mFolder = that.mFolder;
        mBase   = that.mBase;
        mExt    = that.mExt;
      }
      
      return *this;
    }
    
    CFile& operator = (CFile&& that)
    {
      if(this != &that && !that.mEmpty)
      {
        mEmpty  = false;
        mFolder = std::move(that.mFolder);
        mBase   = std::move(that.mBase);
        mExt    = std::move(that.mExt);
      }
      
      return *this;
    }
    
    inline bool operator == (bool value)
    {
      return mEmpty != value;
    }
    
    inline operator const char* () const
    {
      return getFilePath().c_str();
    }
    
    public:
    inline std::string getFilePath() const
    {
      return std::string(mFolder).append(mBase).append(".").append(mExt);
    }
    
    inline std::string getFileName() const
    {
      return std::string(mBase).append(".").append(mExt);
    }    
    
    inline std::string getBaseName() const
    {
      return mBase;
    }
    
    inline std::string getFileType() const
    {
      return mExt;
    }
    
    inline std::string getMimeType() const
    {
      return "";
    }
    
    //std::string read()
    //{
    //  // read file bit by bit :)
    //}
    
    inline bool isEmpty() const
    {
      return mEmpty;
    }
    
    friend std::ostream& operator << (std::ostream&, const CFile&);
    
    // getModified() const
    // getCreated() const 
    // getSize() const
  };
  
  std::ostream& operator << (std::ostream& out, const CFile& file)
  {
    out << file.getFilePath();
    return out;
  }
}

namespace sys
{
//  class CFileReader
//  {
//    CFile mFile;
//  
//    public:
//    CFileReader(const CFile& oFile, std::ios::openmode ) : mFile(mFile)
//    {
//      
//    }
//    
//    public:
//    std::string read(const CFile& oFile)
//    {
//      std::ifstream ifs(mFile, std::ios_base::binary | std::ios_base::in);
//    }
//  };
}

#endif // __util_cfile_hpp__
