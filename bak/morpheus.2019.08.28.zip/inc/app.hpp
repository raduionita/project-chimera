#ifndef __app_hpp__
#define __app_hpp__

#undef near   // FIX: remove Win16 compiler pointers
#undef far    // FIX: remove Win16 compiler pointers

#include <iostream>
#include <memory>
#include <array>
#include <cstring>
#include <utility>
#include <sstream>

#define FREEGLUT_STATIC     // requires: libfreeglut_static.a libgdi32.a libwinmm.a
#include <gl/gl_core_4_4.h> // requires: libglLoad.a | before freeglut.h
#include <gl/freeglut.h>    // requires: libopengl32.a libglut32.a

#include "math.hpp"
#include "test.hpp" // interserction testing

namespace app
{
  typedef unsigned int   uint;
  typedef unsigned short ushort;
  typedef unsigned char  ubyte;
  typedef char           byte;
  
  namespace tags
  {
    static const sys::CTag GENERIC("GENERIC");
  };
}

#include "app/CEventManager.hpp"

#include "ogl.hpp"

#include "app/CApp.hpp"
#include "app/CController.hpp"
//#include "app/CCamera.hpp"            //@TODO: depricated class -- to be removed
#include "app/controller/CCameraController.hpp"
#include "app/controller/CLightController.hpp"
#include "app/controller/CPickRendererController.hpp"

#include "app/CScene.hpp"
#include "app/CSceneBuilder.hpp"

//#include "app/app/CTest01App.hpp"
//#include "app/app/COGLDev01App.hpp"
//#include "app/app/COGLDev02App.hpp"
//#include "app/app/COGLDev03App.hpp"
//#include "app/app/COGLDev04ShadowMapApp.hpp"
//#include "app/app/COGLDev05SkyboxApp.hpp"
//#include "app/app/COGLDev06NormalMapApp.hpp"
//#include "app/app/COGLDev07BillboardingApp.hpp"
//#include "app/app/COGLDev08TransformFeedbackApp.hpp"
//#include "app/app/COGLDev09PickingApp.hpp"
//#include "app/app/COGLDev10TessellationApp.hpp"
//#include "app/app/COGLDev11InstancedApp.hpp"
//#include "app/app/COGLDev35DeferredApp.hpp"
//#include "app/app/COGLDev38SkinningApp.hpp"
//#include "app/app/COGLDev39ShadowVolumeApp.hpp"
//#include "app/app/COGLDev41MotionBlurApp.hpp"
//#include "app/app/COGLDev42PCFShadowMapApp.hpp"
#include "app/app/COGLDev45AmbientOcclusionApp.hpp"

#endif /* __app_hpp__ */
