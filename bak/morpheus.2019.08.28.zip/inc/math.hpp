#ifndef __math_hpp__
#define __math_hpp__

#ifdef near
#undef near   // FIX: remove Win16 compiler pointers
#endif
#ifdef far
#undef far    // FIX: remove Win16 compiler pointers
#endif

#include <cmath>    // sin(), cos(), tan()
#include <cassert>  // assert() static_assert<T>()
#include <cstdlib>  // rand(), srand()
#include <ctime>    // time()
#include <limits>   // numeric_limits<T>::epsilon()

namespace math
{
  typedef unsigned int   uint;
  typedef char           byte;
  typedef unsigned char  ubyte;
  typedef unsigned short ushort;
  
  /* ************************************************************************************************************** */
  
  const float E        = 2.71828182845904f;
  const float PI       = 3.14159265358979f;
  const float RAD      = PI / 180.0f;
  const float EPSILONF = 0.00001f;          // 10^-5
  const float EPSILOND = 0.000000001f;      // 10^-9
  
  template <typename T> inline const T      EPSILON() { return T(0); }                 // until variable templates
  template <>           inline const float  EPSILON<float>()  { return 0.00001f; }     // 10^-5
  template <>           inline const double EPSILON<double>() { return 0.000000001f; } // 10^-9
  // OR use std::numeric_limits<T>::epsilon()
  
  template <typename T> inline const T HALF() { static T half = T(1) / T(2); return half; }
  
  static uint  SEED = 0x13371337;
  
  /* ************************************************************************************************************** */
  
  template <typename T, ushort cols, ushort rows>
  class CMatrix;
  
  template <typename T, ushort size>
  class CVector;

  template <typename T>
  class CQuaterion;
  
  typedef CMatrix<float, 4, 4>  mat4;
  typedef CMatrix<float, 4, 3>  mat4x3;
  typedef CMatrix<float, 3, 3>  mat3;
  typedef CMatrix<float, 2, 2>  mat2;
  typedef CMatrix<double, 4, 4> dmat4;
  typedef CMatrix<double, 4, 3> dmat4x3;
  typedef CMatrix<double, 3, 3> dmat3;
  typedef CMatrix<double, 2, 2> dmat2;
  
  typedef CVector<float, 4>   vec4;
  typedef CVector<float, 3>   vec3;
  typedef CVector<float, 2>   vec2;  
  typedef CVector<double, 4> dvec4;
  typedef CVector<double, 3> dvec3;
  typedef CVector<double, 2> dvec2;
  typedef CVector<int, 4>    ivec4;
  typedef CVector<int, 3>    ivec3;
  typedef CVector<int, 2>    ivec2;
  typedef CVector<uint, 4>   uvec4;
  typedef CVector<uint, 3>   uvec3;
  typedef CVector<uint, 2>   uvec2;
  typedef CVector<bool, 4>   bvec4;
  typedef CVector<bool, 3>   bvec3;
  typedef CVector<bool, 2>   bvec2;
  
  typedef CQuaterion<float>   quat;
  typedef CQuaterion<double> dquat;
  typedef CQuaterion<int>    iquat;
  
  /* ************************************************************************************************************** */
  
  inline bool isPowerOf2(int nValue)
  {
    bool bLastBit = false;
    while(nValue != 0)
    {
      bLastBit = (bool)(nValue & 0x1);
      nValue >>= 1;
      if(bLastBit != false && nValue != 0)
        return false;
    }
    return true;
  }
  
  /**
   * Equals (a == b) compare using EPSILON tolerance
   * @param T a
   * @param T b
   * @return bool
   */
  template <typename T>
  inline bool equals(T a, T b) // eq
  {
    return std::abs(a - b) <= EPSILON<T>();
  }
  
  /**
   * Lesser (a < b) compare using EPSILON tolerance
   * @param T a
   * @param T b
   * @return bool
   */
  template <typename T>
  inline bool lesser(T a, T b) // lt <
  {
    return (b - a) > EPSILON<T>();
  }
  
  /**
   * Greater (a > b) compare using EPSILON tolerance
   * @param T a
   * @param T b
   * @return bool
   */
  template <typename T>
  inline bool greater(T a, T b) // gt >
  {
    return (a - b) > EPSILON<T>();
  }
  
  /**
   * Greater or equal (a <= b) compare using EPSILON tolerance
   * @param T a
   * @param T b
   * @return bool
   */
  template <typename T>
  inline bool gequal(T a, T b) // gte >=
  {
    return greater(a, b) || equals(a, b);
  }
  
  /**
   * Less or equal (a >= b) compare using EPSILON tolerance
   * @param T a
   * @param T b
   * @return bool
   */
  template <typename T>
  inline bool lequal(T a, T b) // lte <=
  {
    return lesser(a, b) || equals(a, b);
  }
  
  /**
   * Get T fractional part - fract(2.32) => 0.32
   * 
   * @param  T value
   * @return T
   */
  template <typename T>
  inline T fract(T value) // float fractional part
  {
    return value - std::floor(value);
  }
  
  /**
   * Return a vector made out of the fractional parts of the src vector
   *
   * @param  CVector<T, n> src
   * @return CVector<T, n>
   */
  template <typename T, const ushort n> // return vector made of the componets fractional part
  inline CVector<T, n> fract(const CVector<T, n> src)
  {
    CVector<T, n> res;
    for(ushort i = 0; i < n; i++)
      res[i] = fract(src[i]);
    return res;
  }
  
  /**
   * Round to a specific power
   * @example proundf(0.123456789f, -6) => 0.123457f
   * @param  float value
   * @param  int   power
   * @return float 
   */
  float proundf(float value, int power) // proundf(0.123456789f, -6) => 0.123457
  {
    int divider = pow(10, power < 0 ? -1 * power : power);
    if(power < 0)
      return ::roundf(value * divider) / divider; 
    else if(power > 0)
      return ::roundf(value / divider) * divider; 
    return value;
  }
  
  /**
   * Use std::min() instead
   */
  template <typename T> // int, float max
  inline T min(T a, T b)
  {
    return a < b ? a : b;
  }    
  
  /**
   * Use std::max() instead
   */
  template <typename T> // int, float max
  inline T max(T a, T b)
  {
    return a >= b ? a : b;
  }
  
  /**
   * Use std::abs() instead
   */
  template <typename T>
  inline T abs(T a)
  {
    return a < T(0) ? a * T(-1) : a;
  }

  /**
   * Return vector made of a the minimum components of v1, v2
   *
   * @param CVector<T, n> v1
   * @param CVector<T, n> v2
   * @return CVector<T, n>
   */
  template <typename T, const ushort n> // return vector made of the minimum component values
  inline CVector<T, n> min(const CVector<T, n>& v1, const CVector<T, n>& v2)
  {
    CVector<T, n> result;
    for(ushort i = 0; i < n; i++)
      result[i] = std::min(v1[i], v2[i]);
    return result;
  }
  
  /**
   * Return vector made of a the maximum components of v1, v2
   *
   * @param CVector<T, n> v1
   * @param CVector<T, n> v2
   * @return CVector<T, n>
   */
  template <typename T, const ushort n> // return vector made of the maximum component values
  inline CVector<T, n> max(const CVector<T, n>& v1, const CVector<T, n>& v2)
  {
    CVector<T, n> result;
    for(ushort i = 0; i < n; i++)
      result[i] = std::max(v1[i], v2[i]);
    return result;
  }
  
  inline float rand() // seed based rand
  {
    float res;
    uint  tmp;
    SEED *= 16807;
    tmp = SEED ^ (SEED >> 4) ^ (SEED << 15);
    
    *((uint*) &res) = (tmp >> 9) | 0x3F800000;
    
    return (res - 1.0f);
  }

  inline int rand(int left, int right) // int range random number generator
  {
    std::srand(time(nullptr));
    int res = std::rand() % (right - left) + left;
    std::srand(res * time(nullptr));
    return res;
  }
  
  template <typename T, const ushort n>
  inline CVector<T, n> rand(const CVector<T, n>& src)
  {
    CVector<T, n> result;
    for(int i = 0; i < n; i++)
      result[i] = static_cast<T>(rand());
    return result;
  }
  
  /**
   * Pseudo Random Number Generator
   *
   * @param  uint min
   * @param  uint max
   * @return uint
   */
  inline uint prng(const uint min, const uint max) // simple pseudo-random generator
  {
    static unsigned int nSeed = 5324;
    nSeed = (7455345 * nSeed + 2464531);
    unsigned int nRand = nSeed % 31423;
    nRand = (nRand % (max + 1 - min)) + min;
    return nRand;
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  /**
   * Fast square root
   *
   * @param  float value
   * @return float
   */
  inline float fastSqrt(float value) // fast sqrt
  {
    unsigned int i = *(unsigned int*) &value;
    i += 127 << 23;   // adjust bias
    i >>= 1;
    return *(float*) &i;
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  template <typename T> // degrees to radians
  inline T radians(T degrees) 
  {
    // return degrees * RAD;
    return degrees * static_cast<T>(RAD);
  }
  
  template <typename T> // radians to degrees
  inline T degrees(T radians) 
  {
    // return radians / RAD;
    return radians / static_cast<T>(RAD);
  }
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  template <typename T, typename S> // linear interpolation
  inline T mix(const T& A, const T& B, const S& t) 
  {
    return B + t * (B - A);
  }
  
  template <typename T, typename S> // quadratic bezier (3 component interpolation)
  inline T mix(const T& A, const T& B, const T& C, const S& t) 
  {
    T D = mix(A, B, t); // D = A + t(B - A)
    T E = mix(B, C, t); // E = B + t(C - B)
    T P = mix(D, E, t); // P = D + t(E - D)
    return P;
  }
  
  template <typename T, typename S> // cubic bezier (4 component interpolation)
  inline T mix(const T& A, const T& B, const T& C, const T& D, const S& t) 
  {
    T E = mix(A, B, t);
    T F = mix(B, C, t);
    T G = mix(C, D, t);
    T P = mix(E, F, G, t);
    return P;
  }

  template <typename T> // clamp value between a min(left) and a max(right)
  inline T clamp(T value, T left, T right)
  {
    return std::min(std::max(value, left), right);
  }
  
  template <typename T, const ushort n> // clamp vector between 2 vector limits
  inline CVector<T, n> clamp(const CVector<T, n>& v, const CVector<T, n>& left, const CVector<T, n>& right)
  {
    return min(max(v, left), right);
  }
  
  template <typename T> // if src excedes [lower, uppper] then is wrapped around
  inline T wrap(const T& src, const T& lower, const T& upper) 
  {
    T res(src);
    T dif(upper - lower);
    while(res > upper)
      res -= dif;
    while(res < lower)
      res += dif;
    return res;
  }
  
  template <typename T> // if v < e return 0 else return 1
  inline T step(T e, T v)
  {
    return v < e ? T(0) : T(1);
  }
  
  template <typename T, const ushort n> // for i elem of the return, 0.0 is returned if v[i] < e[i], 1.0 otherwise
  CVector<T, n> step(const CVector<T, n>& e, const CVector<T, n>& v)
  {
    CVector<T, n> result;
    for(ushort i = 0; i < n; i++)
      result[i] = v[i] < e[i] ? T(0) : T(1);
    return result;
  }
  
  template <typename T> // y = 3x^2 - 2x^3 | e0 < x < e1 | Hermite interpolation
  T smoothstep(T e0, T e1, T v) 
  {
    T x;
    // scale and clamp x to 0..1 range
    // (v - e0) / (e1 - e0) - scale: e0-----v---------e2
    x = clamp((v - e0) / (e1 - e0), T(0), T(1));
    // return vector position of the graph determined by the equation
    return x * x * (T(3) - x * T(2));
  }
  
  template <typename T, const ushort n> // y = 3x^2 - 2x^3
  CVector<T, n> smoothstep(const CVector<T, n>& e0, const CVector<T, n>& e1, const CVector<T, n>& v)
  {
    CVector<T, n> x;
    x = clamp((v - e0) / (e1 - e0), CVector<T, n>(T(0)), CVector<T, n>(T(1)));
    return x * x * (CVector<T, n>(T(3)) - x * CVector<T, n>(T(2)));
  }
  
  template <typename T> // y = 6x^5 - 15x^4 + 10x^3
  T smootherstep(T e0, T e1, T v)
  {
    T x;
    x = clamp((v - e0) / (e1 - e0), T(0), T(1));
    return x * x * x * (x * (x * T(6) - T(15)) + T(10));
  }
  
  template <typename T, const ushort n> // y = 6x^5 - 15x^4 + 10x^3
  CVector<T, n> smootherstep(const CVector<T, n>& e0, const CVector<T, n>& e1, const CVector<T, n>& v)
  {
    CVector<T, n> x;
    x = clamp((v - e0) / (e1 - e0), CVector<T, n>(T(0)), CVector<T, n>(T(1)));
    return x * x * x * (x * (x * CVector<T, n>(T(6)) - CVector<T, n>(T(15))) + CVector<T, n>(T(10)));
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  template <typename T, const ushort c, const ushort r> // return matrix transpose
  CMatrix<T, r, c> transpose(const CMatrix<T, c, r>& src)
  {
    CMatrix<T, r, c> result;
    for(ushort j = 0; j < c; j++)
      for(ushort i = 0; i < r; i++)
        result[i][j] = src[j][i];
    return result;
  }
  
  template <typename T, const ushort c, const ushort r> // return identity matrix from src matrix
  CMatrix<T, c, r> identity(const CMatrix<T, c, r>& src)
  {
    CMatrix<T, r, c> result;
    for(ushort j = 0; j < r; j++)
      result[j][j] = T(1);
    return result;
  }
  
  template <typename T, const ushort n> // return identity matrix using T type and n row&col number
  CMatrix<T, n, n> identity()
  {
    CMatrix<T, n, n> result;
    for(ushort j = 0; j < n; j++)
      result[j][j] = T(1);
    return result;
  }
  
  template <typename T, const ushort c, const ushort r> // shring matrix by elimination row & column
  CMatrix<T, c-1, r-1> shrink(const CMatrix<T, c, r>& src, const ushort y, const ushort x)
  {
    assert((x < r) && (y < c) && r > 2 && c > 2);
    CMatrix<T, c-1, r-1> result;
    for(ushort j1 = 0, j2 = 0; j1 < c; j1++)
    {
      if(y == j1) continue;
      for(ushort i1 = 0, i2 = 0; i1 < r; i1++)
      {
        if(x == i1) continue;
        result[j2][i2] = src[j1][i1];
        i2++;
      }
      j2++;
    }
    return result;
  }
  
  template <typename T> // return mat<T, 2 2> determinant
  T det(const CMatrix<T, 2, 2>& m1)                                             // @TODO: merge with full template version
  {
    return m1[0][0] * m1[1][1] - m1[1][0] * m1[0][1];
  }
  
  template <typename T, const ushort c, const ushort r> // return mat<T, c, r> determinant
  T det(const CMatrix<T, c, r>& m1)
  {
    static_assert(r > 1 && c > 1, "1x1 CMatrixrix not allowed!");
    T result(0);
    for(ushort j = 0; j < c; j++)
    {
      CMatrix<T, c-1, r-1> m2 = shrink(m1, j, 0);
      result += (j % 2 == 0 ? 1 : -1) * m1[j][0] * det(m2);
    }      
    return result;
  }

  template <typename T>
  CMatrix<T, 4, 4> inverse(const CMatrix<T, 4, 4>& src)
  {
    T c00 = src[2][2] * src[3][3] - src[3][2] * src[2][3];
    T c02 = src[1][2] * src[3][3] - src[3][2] * src[1][3];
    T c03 = src[1][2] * src[2][3] - src[2][2] * src[1][3];
    
    T c04 = src[2][1] * src[3][3] - src[3][1] * src[2][3];
    T c06 = src[1][1] * src[3][3] - src[3][1] * src[1][3];
    T c07 = src[1][1] * src[2][3] - src[2][1] * src[1][3];
    
    T c08 = src[2][1] * src[3][2] - src[3][1] * src[2][2];
    T c10 = src[1][1] * src[3][2] - src[3][1] * src[1][2];
    T c11 = src[1][1] * src[2][2] - src[2][1] * src[1][2];
    
    T c12 = src[2][0] * src[3][3] - src[3][0] * src[2][3];
    T c14 = src[1][0] * src[3][3] - src[3][0] * src[1][3];
    T c15 = src[1][0] * src[2][3] - src[2][0] * src[1][3];
    
    T c16 = src[2][0] * src[3][2] - src[3][0] * src[2][2];
    T c18 = src[1][0] * src[3][2] - src[3][0] * src[1][2];
    T c19 = src[1][0] * src[2][2] - src[2][0] * src[1][2];
    
    T c20 = src[2][0] * src[3][1] - src[3][0] * src[2][1];
    T c22 = src[1][0] * src[3][1] - src[3][0] * src[1][1];
    T c23 = src[1][0] * src[2][1] - src[2][0] * src[1][1];
    
    CVector<T, 4> f0(c00, c00, c02, c03);
    CVector<T, 4> f1(c04, c04, c06, c07);
    CVector<T, 4> f2(c08, c08, c10, c11);
    CVector<T, 4> f3(c12, c12, c14, c15);
    CVector<T, 4> f4(c16, c16, c18, c19);
    CVector<T, 4> f5(c20, c20, c22, c23);
    
    CVector<T, 4> v0(src[1][0], src[0][0], src[0][0], src[0][0]);
    CVector<T, 4> v1(src[1][1], src[0][1], src[0][1], src[0][1]);
    CVector<T, 4> v2(src[1][2], src[0][2], src[0][2], src[0][2]);
    CVector<T, 4> v3(src[1][3], src[0][3], src[0][3], src[0][3]);
    
    CVector<T, 4> i0(v1 * f0 - v2 * f1 + v3 * f2);
    CVector<T, 4> i1(v0 * f0 - v2 * f3 + v3 * f4);
    CVector<T, 4> i2(v0 * f1 - v1 * f3 + v3 * f5);
    CVector<T, 4> i3(v0 * f2 - v1 * f4 + v2 * f5);
    
    CVector<T, 4> sa(+1, -1, +1, -1); // sign A
    CVector<T, 4> sb(-1, +1, -1, +1); // sign B
    
    CMatrix<T, 4, 4> inv(i0 * sa, i1 * sb, i2 * sa, i3 * sb);
    
    CVector<T, 4> r0(inv[0][0], inv[1][0], inv[2][0], inv[3][0]);
    CVector<T, 4> d0(src[0] * r0);
    
    T det = (d0.x + d0.y) + (d0.z + d0.w);
    
    T detInv = T(1) / det;
    
    return inv / detInv;
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  template <typename T, const ushort n> 
  T length(const CVector<T, n>& v) // calculate length of a vector
  {
    T sum(0);
    for(ushort i = 0; i < n; i++)
      sum += v[i] * v[i];
    return (T)std::sqrt(sum);
  }
  
  template <typename T, const ushort n> 
  CVector<T, n> normalize(const CVector<T, n>& v) // return normalized vector
  {
    return v / length(v);
  }
  
  template <typename T, const ushort n> 
  T dot(const CVector<T, n>& v1, const CVector<T, n>& v2) // return dot product between 2 vectors
  {
    T res(0);
    for(ushort i = 0; i < n; i++)
      res += v1[i] * v2[i];
    return res;
  }  
  
  template <typename T> 
  T dot(const CQuaterion<T>& q1, const CQuaterion<T>& q2) // return dot product between 2 quaternions
  {
    T res(0);
    for(ushort i = 0; i < 4; ++i)
      res += q1[i] * q2[i];
    return res;
  }
  
  template <typename T> 
  CVector<T, 3> cross(const CVector<T, 3>& v1, const CVector<T, 3>& v2) // return vector resulted from cross product between 2 3D vectors
  {
    return CVector<T, 3>(
      v1.y * v2.z - v1.z * v2.y,
      v1.z * v2.x - v1.x * v2.z,
      v1.x * v2.y - v1.y * v2.x);
  }
  
  template <typename T, const ushort n> 
  T distance(const CVector<T, n>& v1, const CVector<T, n>& v2) // return distance between 2 vectors | length(v1 - v0)
  {
    return length(v2 - v1);
  }
  
  template <typename T, const ushort n> 
  T angle(const CVector<T, n>& v1, const CVector<T, n>& v2) // return angle between vectors | arccos(dot(v2, v1)) | needs normalized v1,v2
  {
    return (T)(::acos(dot(v1, v2)));
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  template <typename T> 
  CQuaterion<T> normalize(const CQuaterion<T>& q) // return normalized quaterion
  {
    return q / length(CVector<T, 4>(q));
  }
  
  template <typename T>
  CQuaterion<T> conjugate(const CQuaterion<T>& q) // return the quaterion conjugate
  {
    return CQuaterion<T>(q.w, -q.x, -q.y, -q.z);
  }
  
  template <typename T> 
  void quat2mat(const CQuaterion<T>& q, CMatrix<T, 4, 4>& m) // populate a matrix with quaterion values
  {
    m = q.asMatrix();
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> quat2mat(const CQuaterion<T>& q) // extract matrix4x4 from a quaterion
  {
    return q.asMatrix();
  }
  
  template <typename T>
  CQuaterion<T> cross(const CQuaterion<T>& q1, const CQuaterion<T>& q2)
  {
    return CQuaterion<T>(T(0), q1.y * q2.z - q1.z * q2.y, q1.z * q2.x - q1.x * q2.z, q1.x * q2.y - q1.y - q2.x);
  }

  template <typename T>
  CQuaterion<T> inverse(const CQuaterion<T>& q)
  {
    CQuaterion<T> r(q);
    r.inverse();
    return r;
  }
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  template <typename T, const ushort n> 
  CVector<T, n> reflect(const CVector<T, n>& I, const CVector<T, n>& N) // reflect vector relative to surface normal
  {
    // dot(N, I) - angle between vector & normal    //       /|2 * dot(I,N) * N 
    // 2 * dot(N, I) * N - resize normal            //    -I/ |
    return T(2) * dot(I, N) * N - I;                //     R\ |N/I
    // return I - T(2) * dot(N, I) * N;             //       \|/    
  }
  
  template <typename T, const ushort n> 
  CVector<T, n> refract(const CVector<T, n>& I, const CVector<T, n>& N, T eta) // eta = n1/n2 - ratio of the refraction indices
  {
    T cos1 = dot(N, I);                                // cos of angle between I & N in the 1st medium
    T cos2 = T(1) - eta * eta * (T(1) - cos1 * cos1);  // cos of angle between I(refracted) & N in 2nd medium
    if(cos2 < T(0))                                    // no sqrt from negative numbers
      return CVector<T, n>(T(0));
    cos2 = sqrt(cos2);
    return eta * I - (eta * cos1 + cos2) * N; // OR eta * I + (eta * cos1 - cos2) * N - for N pointing down
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> translate(const T& x, const T& y, const T& z) // create translation matrix from a direction vector
  {
    return CMatrix<T, 4, 4>(
      CVector<T, 4>(T(1), T(0), T(0), T(0)),
      CVector<T, 4>(T(0), T(1), T(0), T(0)),
      CVector<T, 4>(T(0), T(0), T(1), T(0)),
      CVector<T, 4>(   x,    y,    z, T(1))
    );
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> translate(const CVector<T, 3>& v) // create translation matrix from a direction vector
  {
    return CMatrix<T, 4, 4>(
      CVector<T, 4>(T(1), T(0), T(0), T(0)),
      CVector<T, 4>(T(0), T(1), T(0), T(0)),
      CVector<T, 4>(T(0), T(0), T(1), T(0)),
      CVector<T, 4>(v[0], v[1], v[2], T(1))
    );
  }

  template <typename T> // rotation matrix from axis and angle | R = cos*I + sin*[u]x + (1-cos)uXu | tensor product
  CMatrix<T, 4, 4> rotate(const T& a, const T& x, const T& y, const T& z) // scalars
  {
    const T xx = x * x;
    const T yy = y * y;
    const T zz = z * z;
    const T xy = x * y;
    const T xz = x * z;
    const T yz = y * z;
    
    const T rads = radians(a);   // float
    const T c = (T) ::cos(rads);     // float
    const T s = (T) ::sin(rads);     // float
    const T omc = T(1) - c;      // one minus cos
    
    return CMatrix<T, 4, 4>(
      CVector<T, 4>(T(xx * omc + c),     T(xy * omc + z * s), T(xz * omc - y * s), T(0)),
      CVector<T, 4>(T(xy * omc - z * s), T(yy * omc + c),     T(yz * omc + x * s), T(0)),
      CVector<T, 4>(T(xz * omc + y * s), T(yz * omc - x * s), T(zz * omc + c),     T(0)),
      CVector<T, 4>(T(0),                T(0),                T(0),                T(1))
    );
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> rotate(const T& a, const CVector<T, 3>& v) // rotation matrix - vector
  {
    return rotate(a, v[0], v[1], v[2]);
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> rotate(const T& ax, const T& ay, const T& az) // matrix rotation using angles
  {
    return rotate(ax, T(1), T(0), T(0)) * rotate(ay, T(0), T(1), T(0)) * rotate(az, T(0), T(0), T(1));
  }
  
  template <typename T, const ushort n> 
  CVector<T, n> rotateX(const T& a, const CVector<T, n>& vec)
  {
    CVector<T, n> res(vec);
    const T rads = radians(a);
    const T cosa = ::cos(rads);
    const T sina = ::cos(rads);
    
    res.y = vec.y * cosa - vec.z * sina;
    res.z = vec.y * sina + vec.z * cosa;
    
    return res;
  }
  
  template <typename T, const ushort n> 
  CVector<T, n> rotateY(const T& a, const CVector<T, n>& vec)
  {
    CVector<T, n> res(vec);
    const T rads = radians(a);
    const T cosa = ::cos(rads);
    const T sina = ::cos(rads);
    
    res.x = vec.x * cosa + vec.z * sina;
    res.z =-vec.x * sina + vec.z * cosa;
    
    return res;
  }
  
  template <typename T, const ushort n> 
  CVector<T, n> rotateZ(const T& a, const CVector<T, n>& vec)
  {
    CVector<T, n> res(vec);
    const T rads = radians(a);
    const T cosa = ::cos(rads);
    const T sina = ::cos(rads);
    
    res.x = vec.x * cosa - vec.y * sina;
    res.y = vec.x * sina + vec.y * cosa;
    
    return res;
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> scale(const T& x, const T& y, const T& z) // matrix-vector scaling - scalars
  {
    return CMatrix<T, 4, 4>(
      CVector<T, 4>(   x, T(0), T(0), T(0)),
      CVector<T, 4>(T(0),    y, T(0), T(0)),
      CVector<T, 4>(T(0), T(0),    z, T(0)),
      CVector<T, 4>(T(0), T(0), T(0), T(1))
    );
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> scale(const CVector<T, 3>& v) // // matrix-vector scaling - vector
  {
    return scale(v[0], v[1], v[2]);
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> scale(T s) // matrix-vector scaling - vector
  {
    return scale(s, s, s);
  }

  template <typename T, const ushort c, const ushort r> // matrix x matrix component multiplication
  CMatrix<T, c, r> matrixCompMult(const CMatrix<T, c, r>& m1, const CMatrix<T, c, r>& m2)
  {
    CMatrix<T, c, r> result;
    for(ushort j = 0; j < r; j++)
      for(ushort i = 0; i < c; i++) 
        result[i][j] = m1[i][j] * m2[i][j];
    return result;
  }
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  template <typename T> // recalculate the actual up vector, relative to the looking direction
  CMatrix<T, 4, 4> lookat(const CVector<T, 3>& position, const CVector<T, 3>& target, const CVector<T, 3>& up)
  {
    const CVector<T, 3> f(normalize(target - position)); // direction = target - position
    const CVector<T, 3> s(normalize(cross(f, up)));      // side = forward x up
    const CVector<T, 3> u(cross(s, f));                  // up - recomputed
    const CMatrix<T, 4, 4> M = CMatrix<T, 4, 4>(
      CVector<T, 4>(-s.x,  u.x, -f.x, T(0)),
      CVector<T, 4>(-s.y,  u.y, -f.y, T(0)),
      CVector<T, 4>(-s.z,  u.z, -f.z, T(0)),
      CVector<T, 4>(T(0), T(0), T(0), T(1))
      //CVector<T, 4>(-dot(s, position), -dot(u, position), dot(f, position), T(1))
    );
    return M * translate(-position);
  }
  
  template <typename T> // generate perspective matrix using viewport dimensions + near & far plane positions
  CMatrix<T, 4, 4> frustum(T left, T right, T bottom, T top, T near, T far)
  {
    if((right == left) || (top == bottom) || (near == far) || (near < T(0)) || (far < T(0)))
      return identity<T, 4>();
    return CMatrix<T, 4, 4>(
      CVector<T, 4>((T(2) * near) / (right - left), T(0) , (right + left) / (top - bottom), T(0)),
      CVector<T, 4>(T(0), (T(2) * near) / (top - bottom), (top + bottom) / (top - bottom), T(0)),
      CVector<T, 4>(T(0), T(0), -(far + near) / (far - near), -(T(2) * far * near) / (far - near)),
      CVector<T, 4>(T(0), T(0), -T(1), T(0))
    );
  }
  
  template <typename T> // return perspective matrix using field of view, aspect ratio, near & far planes
  CMatrix<T, 4, 4> perspective(T fovy, T ratio, T near, T far)
  {
    assert(far > near);
    
    T q = T(1) / tan(radians(fovy / T(2)));
    T A = q / ratio;
    T B = (near + far) / (near - far);
    T C = (T(2) * near *  far) / (near - far);
    return CMatrix<T, 4, 4>(
      CVector<T, 4>(   A, T(0), T(0), T(0)),
      CVector<T, 4>(T(0),    q, T(0), T(0)),
      CVector<T, 4>(T(0), T(0),    B, T(-1)),
      CVector<T, 4>(T(0), T(0),    C, T(0))
    );
    
//    T q = T(1) / tan(radians(fovy / T(2)));
//    T A = q / ratio;
//    T B = - (near + far) / (near - far);
//    T C = - (T(2) * near *  far) / (near - far);
//    return CMatrix<T, 4, 4>(
//      CVector<T, 4>(   A, T(0), T(0), T(0)),
//      CVector<T, 4>(T(0),    q, T(0), T(0)),
//      CVector<T, 4>(T(0), T(0),    B,-T(1)),
//      CVector<T, 4>(T(0), T(0),    C, T(0))
//    );

//    T scale  = tan(radians(fovy / T(2))) * near;
//    T right  = ratio * scale;
//    T left   = -right;
//    T top    = scale;
//    T bottom = - top;
//    return CMatrix<T, 4, 4>(
//      CVector<T, 4>((T(2) * near) / (right - left), T(0) , T(0),     T(0)),
//      CVector<T, 4>(T(0), (T(2) * near) / (top - bottom), T(0),      T(0)),
//      CVector<T, 4>(T(0), T(0), -(far + near) / (far - near),       -T(1)),
//      CVector<T, 4>(T(0), T(0), -(T(2) * far * near) / (far - near), T(0))
//    );
//    
//    return frustum(left, right, bottom, top, near, far); 
  }
  
  template <typename T> 
  CMatrix<T, 4, 4> ortho(T left, T right, T bottom, T top, T near, T far) // return orthographic projection matrix
  {
    CMatrix<T, 4, 4> result;
    result[0][0] = T(2) / (right - left);
    result[1][1] = T(2) / (top - bottom);
    result[2][2] = T(2) / (near - far);               // - 2 / (far - near)
    result[3][0] = (left + right) / (left - right);   // - (left + right) / (right - left)
    result[3][1] = (bottom + top) / (bottom - top);   // - (top + bottom) / (top - bottom)
    result[3][2] = (far + near) / (far - near);       // - (far + near) / (far - near)
    result[3][3] = T(1);
    return result;
//    return CMatrix<T, 4, 4>(
//      CVector<T, 4>(T(2) / (right - left), T(0), T(0), T(0)),
//      CVector<T, 4>(T(0), T(2) / (top - bottom), T(0), T(0)),
//      CVector<T, 4>(T(0), T(0), T(2)/ (near - far), T(0)),
//      CVector<T, 4>((left + right) / (left - right), (bottom + top) / (bottom - top), (far + near) / (far - near), T(1))
//    );
  }

  template <typename T>
  CVector<T, 3> unProject(const CVector<T, 3>& window, const CMatrix<T, 4, 4>& modelview, const CMatrix<T, 4, 4> projection, const CVector<T, 4> viewport)
  {
    CVector<T, 4> inverse = math::inverse(projection * modelview);
    
    CVector<T, 4> temp(window, T(1));
    temp.x = (temp.x - T(viewport[0])) / T(viewport[2]) ;
    temp.x = (temp.y - T(viewport[1])) / T(viewport[3]) ;
    temp = temp * T(2) - T(1);
    
    CVector<T, 4> object = inverse * temp;
    object /= object.w;
    
    return CVector<T, 3>(object.x, object.y, object.z);
  }
}

#include "math/CQuaterion.hpp"
#include "math/CVector.hpp"
#include "math/CMatrix.hpp"
#include "math/CPlane.hpp"
#include "math/CRay.hpp"
#include "math/CShape.hpp"
#include "math/CSphere.hpp"

namespace math
{
  const vec3 O = vec3(0.0f, 0.0f, 0.0f);
  const vec3 X = vec3(1.0f, 0.0f, 0.0f);
  const vec3 Y = vec3(0.0f, 1.0f, 0.0f);
  const vec3 Z = vec3(0.0f, 0.0f, 1.0f);
  
  template <typename T> 
  void rotate(CVector<T, 3>& v, const T& theta, const CVector<T, 3>& a) // rotate vector around axis by angle
  {
    //const T s = std::sin(radians(theta / T(2)));
    //const T c = std::cos(radians(theta / T(2)));
    
    quat V(T(0), v.x, v.y, v.z);
    //quat R(a.x * s, a.y * s, a.z * s, c);
    quat R(theta, a);
    quat C = conjugate(R);
    quat W = (R * V) * C;
    
    //sys::info << R << sys::endl;
    //sys::info << V << sys::endl;
    //sys::info << C << sys::endl;
    
    v.x = W.x;
    v.y = W.y;
    v.z = W.z;
  }
  
  template <typename T>
  CVector<T,3> rotate(const CQuaterion<T>& Q, const CVector<T, 3>& v)
  {
    CQuaterion<T> C = conjugate(Q);
    CQuaterion<T> V(T(0), v.x, v.y, v.z);
    CQuaterion<T> R = (Q * V) * C;
    return CVector<T, 3>(R.x, R.y, R.z);
  }
  
//  template <typename T>
//  CQuaterion<T> conjugate(const CQuaterion<T>& q)
//  {
//    CQuaterion<T> c(q);
//    c.conjugate();
//    return c;
//  }
  
  template <typename T>
  CQuaterion<T> slerp(const CQuaterion<T>& A, const CQuaterion<T>& B, T t) // spherical linear interpolation
  {
    CQuaterion<T> Q;
    
    const T epsilon = EPSILON<T>();
    T to[4];
    T omega, cosom, sinom, scale0, scale1;
    cosom = A.x * B.x + A.y * B.y + A.z * B.z + A.w * B.w; // 4D dot product
    // cosom = math::dot(A, B);
    
    assert(cosom < T(1.1)); // they should be unit quaterions <= 1.0f
    
    if(cosom < T(0))  // adjust signs if necessary
    {
      cosom = -cosom;
      to[0] = -B.x;
      to[1] = -B.y;
      to[2] = -B.z;
      to[3] = -B.w;
    }
    else
    {
      to[0] = B.x;
      to[1] = B.y;
      to[2] = B.z;
      to[3] = B.w;
    }
    
    if((T(1) - cosom) > epsilon)  // calculate coefficients
    {
      // standard case: slerp
      
      omega = std::acos(cosom);
      sinom = std::sin(omega);
      scale0 = std::sin((T(1) - t) * omega) / sinom;
      scale1 = std::sin(t * omega) / sinom;
    }
    else
    {
      // A & B are very close: linear interpolation
      scale0 = T(1) - t;
      scale1 = t;
    }
    
    Q.x = scale0 * A.x + scale1 * to[0];
    Q.y = scale0 * A.y + scale1 * to[1];
    Q.z = scale0 * A.z + scale1 * to[2];
    Q.w = scale0 * A.w + scale1 * to[3];
    
    return Q;
  }

  template <typename T>
  CMatrix<T, 4, 4> toMatrix(const CQuaterion<T>& q)
  {
      CMatrix<T, 4, 4> m;
      
      const T xx = q.x * q.x;
      const T yy = q.y * q.y;
      const T zz = q.z * q.z;
      // const T ww = q.w * q.w;
      const T xy = q.x * q.y;
      const T xz = q.x * q.z;
      const T xw = q.x * q.w;
      const T yz = q.y * q.z;
      const T yw = q.y * q.w;
      const T zw = q.z * q.w;
      
      m[0][0] = T(1) - T(2) * (yy + zz);
      m[0][1] =        T(2) * (xy + zw); // -
      m[0][2] =        T(2) * (xz - yw); // +
      m[0][3] =        T(0);

      m[1][0] =        T(2) * (xy - zw); // +
      m[1][1] = T(1) - T(2) * (xx + zz); 
      m[1][2] =        T(2) * (yz + xw); // -
      m[1][3] =        T(0);

      m[2][0] =        T(2) * (xz + yw); // -
      m[2][1] =        T(2) * (yz - xw); // +
      m[2][2] = T(1) - T(2) * (xx + yy);
      m[2][3] =        T(0);

      m[3][0] =        T(0);
      m[3][1] =        T(0);
      m[3][2] =        T(0);
      m[3][3] =        T(1);
      
      return m;
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace math
{
  typedef math::vec3 CPoint;
  typedef ushort     ETestResult ;
  
  enum : ushort
  {
    OUTSIDE,
    INTERSECTS,
    INSIDE
  };

  ETestResult testPointInSphere(const CPoint& point, const CSphere& sphere)
  {
    return false;
  }
}

#endif /* __math_hpp__ */
