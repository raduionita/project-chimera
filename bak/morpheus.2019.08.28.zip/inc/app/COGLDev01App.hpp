#ifndef __COGLDev01App_hpp__
#define __COGLDev01App_hpp__

#include <cmath>

namespace app
{
  class COGLDev01App : public CApp
  {
    private: 
    ogl::CProgram* pProgram;
    GLuint         vao;
    GLuint         vbo;
    GLuint         ebo;
    
    app::CCamera*  pCamera;
    
    public:
    COGLDev01App()
    {
      std::cout << "app::COGLDev01App::COGLDev01App()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "COGLDev01App");
    }
  
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev01App::onInit()" << std::endl;
      glClearColor(0.2f, 0.2f, 0.2f, 0.0f);
      //glClearDepth(1.0f);
      
      pCamera = new app::CCamera(50.0f, mConfig.mRatio, 0.1f, 100.0f);
      
      //ogl::CBinaryShaderBuilder pShaderBuilder = new ogl::CBinaryShaderBuilder(); 
      ogl::CFileShaderBuilder* pShaderBuilder = new ogl::CFileShaderBuilder(); 
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("simple_01.vs.glsl");
      ogl::CShader* pVShader = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("simple_01.fs.glsl");
      ogl::CShader* pFShader = pShaderBuilder->build();
      delete pShaderBuilder;
      
      // ogl::CShaderManager pShaderManager;
      //pShaderManager->addShader(id, pShader);
      
      // pShader = pShaderManager->getShader(id);
      
      //ogl::CBinaryProgramBuilder pProgramBuilder = new ogl::CBinaryProgramBuilder;
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      pProgramBuilder->addShader(pVShader);
      pProgramBuilder->addShader(pFShader);
      pProgramBuilder->addUniform("u_fTime",      new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
      pProgram = pProgramBuilder->build();
      delete pProgramBuilder;
      delete pVShader;
      delete pFShader;
      
      //for(auto it = pProgram->getUniforms().begin(); it != pProgram->getUniforms().end(); ++it)
        //std::cout << "> INFO: uniform: " << it->first << std::endl;
      
      // ogl::CProgramManager pProgramManager;
      // pProgramManager->addProgram(pProgram);
      
      // pProgram = pProgramManager->getProgram(id);
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      math::vec3 vertices[] = {
        math::vec3(-10.0f, -1.0f,-10.0f),
        math::vec3(-10.0f, -1.0f, 10.0f),
        math::vec3( 10.0f, -1.0f, 10.0f),
        math::vec3( 10.0f, -1.0f,-10.0f)
        //math::vec3(-1.0f,-1.0f, 0.5773f),
        //math::vec3( 0.0f,-1.0f,-1.15475f),
        //math::vec3( 1.0f,-1.0f, 0.5773f),
        //math::vec3( 0.0f, 1.0f, 0.0f)
      };
      glGenBuffers(1, &vbo);
      glBindBuffer(GL_ARRAY_BUFFER, vbo);
      glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
      
      glGenVertexArrays(1, &vao);
      glBindVertexArray(vao);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
      glEnableVertexAttribArray(0);
      
      GLushort indices[] = {
        0, 1, 2,
        0, 2, 3
        //0, 3, 1,
        //1, 3, 2,
        //2, 3, 0,
        //0, 1, 2
      };
      glGenBuffers(1, &ebo);
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
      glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    }  
    
    void onDraw(int nTime)
    {
      const float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev01App::onDraw(" << nTime << ") > " << fTime << std::endl;
      
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      // pProgram = CProgramManager::getInstance()->getProgram(id);
      // float fScale = (sinf(fTime * math::PI) + 1.0f) / 2.0f;
      
      static float fScale = 0.0f;
      fScale += 0.001f;
      math::mat4 u_mM;
      math::mat4 u_mV;
      math::mat4 u_mP;
      u_mM *= math::translate(0.0f, 0.0f, 5.0f);
      //u_mM *= math::rotate(fScale * 100.0f, math::Z);
      //u_mM *= math::scale(sinf(fScale));
      //u_mV  = math::lookat(math::vec3(0.0f, 0.0f, 0.0f), math::vec3(0.0f, 0.0f, 1.0f), math::Y);
      u_mV  = pCamera->getViewMatrix();
      u_mP  = pCamera->getProjectionMatrix();
      
      pProgram->use();
      pProgram->setUniform("u_fTime", fTime);
      pProgram->setUniform("u_mMV", u_mV * u_mM);
      pProgram->setUniform("u_mP",  u_mP);
      pProgram->setUniform("u_bWireframe",  false);
      
      // exit();
      
      glEnable(GL_DEPTH_TEST);
      //glEnable(GL_CULL_FACE);
      
      glBindVertexArray(vao);
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
      glEnableVertexAttribArray(0);
      //glDrawArrays(GL_TRIANGLES, 0, 3);
      
      glEnable(GL_POLYGON_OFFSET_FILL);
      glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
      glPolygonOffset(1.0f, 1.0f); 
      glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, 0);
      
      pProgram->setUniform("u_bWireframe",  true);
      
      glEnable(GL_POLYGON_OFFSET_LINE);
      glPolygonOffset(-1, -1);
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
      glLineWidth(1.0f);
      glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, 0);
      glDisable(GL_POLYGON_OFFSET_LINE);
      
      glDisableVertexAttribArray(0);
      
      pProgram->unuse();
    }
    
    void onStop()
    {
      std::cout << "app::COGLDev01App::onStop()" << std::endl;
      delete pProgram;
      delete pCamera;
      glDeleteBuffers(1, &vbo);
    }
    /*
    void onKey(int key, int action)
    {
      CApp::onKey(key, action);
      pCamera->onKey(key, action);
    }
    
    void onMouseButton(int button, int state, int x, int y)
    {
      CApp::onMouseButton(button, state, x, y);
      pCamera->onMouseButton(button, state, x, y);
    }
    
    void onMouseMove(int x, int y)
    {
      CApp::onMouseMove(x, y);
      pCamera->onMouseMove(x, y);
    }
    
    void onMouseDrag(int x, int y)
    {
      CApp::onMouseDrag(x, y);
      pCamera->onMouseDrag(x, y);
    }*/
  };
}

#endif // __COGLDev01App_hpp__
