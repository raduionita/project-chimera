#ifndef __app_cscenebuilder_hpp__
#define __app_cscenebuilder_hpp__

#include <pugixml/pugixml.hpp>

#include <fstream> // ifstream

namespace app
{
  class CSceneBuilder : public sys::CBuilder<CScene>
  {
    
  };
  
  class CXmlSceneBuilder : public CSceneBuilder
  {
    protected:
    sys::CFile mFile;
    
    public:
    CScene* build()
    {
      sys::info << "ogl::CXmlSceneBuilder::build()" << sys::endl;
    
      if(mFile.isEmpty()) 
        throw EXCEPTION << "File not found, while trying to build scene from XML file!";
      
      pugi::xml_document doc;
      pugi::xml_parse_result result = doc.load_file(mFile.getFilePath().c_str());
      if(!result)
        throw EXCEPTION << result.description();
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
      
      CScene* pScene = new CScene;
      {
        pugi::xml_node _scene = doc.child("scene");
        pugi::xml_node _objects = _scene.child("objects");
        buildObjects(pScene, _objects);
        pugi::xml_node _cameras = _scene.child("cameras");
        buildCameras(pScene, _cameras);
        pugi::xml_node _lights = _scene.child("lights");
        buildLights(pScene, _lights);
      }
      return pScene;
    }
    
    void setFile(const std::string& sFile)
    {
      mFile = std::move(sys::CFile(SCENEPATH + sFile));
    }
    
    void setFile(sys::CFile&& oFile)
    {
      mFile = std::move(oFile);
    }
  
    protected:
    void buildObjects(CScene*& pScene, const pugi::xml_node& _objects)
    {
      // TODO: based on the file type load manager
      // ogl::CBuilderManager* pManager = ogl::CBuilderManager::getInstance();
      
      ogl::CMd5ObjectBuilder*   pMd5Builder   = new ogl::CMd5ObjectBuilder;
      ogl::CPlaneObjectBuilder* pPlaneBuilder = new ogl::CPlaneObjectBuilder;
      ogl::CBoxObjectBuilder*   pBoxBuilder   = new ogl::CBoxObjectBuilder;
    
      for(pugi::xml_node _object = _objects.first_child(); _object; _object = _object.next_sibling())
      {
        pugi::xml_attribute _type = _object.attribute("type");
        if(!_type)
          throw EXCEPTION << "<object type=\"?\" > attribute is mandatory!";
        pugi::xml_attribute _id    = _object.attribute("id");
        if(!_id)
          throw EXCEPTION << "<object id=\"?\"> attribute is mandatory!";
        //pugi::xml_attribute _ref = _object.attribute("ref");
        
        ogl::CObject* pObject = nullptr;
        sys::CDescriptor oDescriptor(app::tags::OBJECT);
        
        if(strncmp(_type.value(), "md5mesh", 7) == 0) 
        {
          pugi::xml_attribute _src = _object.attribute("src");
          if(!_src)
            throw EXCEPTION << "<object src=\"?\"> attribute is mandatory!";
            
          pMd5Builder->setFile(_src.value());
          pMd5Builder->addOption(ogl::CObjectBuilder::NORMALIZED);
          pMd5Builder->addOption(ogl::CObjectBuilder::FLIPYZ); // this might not work with animation
          pObject = pMd5Builder->build();
          
          oDescriptor += ogl::tags::MESH + ogl::tags::MD5MESH;
        }
        else if(strncmp(_type.value(), "plane", 5) == 0) 
        {
          float width = 1.0f;
          pugi::xml_attribute _width = _object.attribute("width");
          if(_width)
            sscanf(_width.value(), "%f", &width);
          pPlaneBuilder->setWidth(width);
          
          float height = 1.0f;
          pugi::xml_attribute _height = _object.attribute("height");
          if(_height)
            sscanf(_height.value(), "%f", &height);
          pPlaneBuilder->setHeight(height);
          
          int subdivisions = 1;
          pugi::xml_attribute _subdivisions = _object.attribute("subdivisions");
          if(_subdivisions)
            sscanf(_subdivisions.value(), "%d", &subdivisions);
          pPlaneBuilder->setSubdivisions(subdivisions);
          
          pPlaneBuilder->setTextureScale(0.5f);
          pPlaneBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
          pPlaneBuilder->addOption(ogl::CObjectBuilder::TANGENTS);
          pObject = pPlaneBuilder->build();
          
          oDescriptor += ogl::tags::PLANE;
        }
        else if(strncmp(_type.value(), "box", 3) == 0) 
        {
          float width = 1.0f;
          pugi::xml_attribute _width = _object.attribute("width");
          if(_width)
            sscanf(_width.value(), "%f", &width);
          pBoxBuilder->setWidth(width);
          
          float height = 1.0f;
          pugi::xml_attribute _height = _object.attribute("height");
          if(_height)
            sscanf(_height.value(), "%f", &height);
          pBoxBuilder->setHeight(height);
          
          float depth = 1.0f;
          pugi::xml_attribute _depth = _object.attribute("depth");
          if(_depth)
            sscanf(_depth.value(), "%f", &depth);
          pBoxBuilder->setDepth(depth);
          
          pugi::xml_attribute _invert = _object.attribute("invert");
          if(_invert)
            pBoxBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        
          pObject = pBoxBuilder->build();
          
          oDescriptor += ogl::tags::BOX;
        }
        else
        {
          throw EXCEPTION << "<object type=\"" << _type.value() << "\"> Not implemented!";
        }
        
        glExitIfError();
        
        pugi::xml_node _shapes = _object.child("shapes");
        if(_shapes)
          buildShapes(pObject, _shapes);
        pugi::xml_attribute _position = _object.attribute("position");
        if(_position)
        {
          float position[3] = { 0.0f, 0.0f, 0.0f };
          if(sscanf(_position.value(), "%f %f %f", &position[0], &position[1], &position[2]) != 0)
            pObject->translate(math::vec3(position[0], position[1], position[2]));
        }
        pugi::xml_attribute _scale = _object.attribute("scale");
        if(_scale)
        {
          float scale = 1.0f;
          if(sscanf(_scale.value(), "%f", &scale) != 0)
            pObject->scale(scale);
        }
        
        // save to CTransformHistory
        
        pScene->addObject(new app::CSceneObject(pObject, oDescriptor));
      }
      
      _DELETE(pMd5Builder);
      _DELETE(pPlaneBuilder);
      _DELETE(pBoxBuilder);
    }
    
    void buildCameras(CScene*& pScene, const pugi::xml_node& _cameras)
    {
      for(pugi::xml_node _camera = _cameras.first_child(); _camera; _camera = _camera.next_sibling())
      {
        //TODO: more camera types and projectio nmodes
        //pugi::xml_attribute _type       = _camera.attribute("type");
        //pugi::xml_attribute _projection = _camera.attribute("projection");
        pugi::xml_attribute _position   = _camera.attribute("position");
        
        float position[3] = { 0.0f, 0.0f, 0.0f };
        if(_position)
          sscanf(_position.value(), "%f %f %f", &position[0], &position[1], &position[2]);
        
        ogl::CCamera*    pCamera = new ogl::CCamera(math::vec3(position[0], position[1], position[2]));
        sys::CDescriptor oDescriptor(app::tags::CAMERA);
        
        pugi::xml_attribute _current = _camera.attribute("current");
        if(_current)
          oDescriptor += app::tags::MAINCAMERA;

        pScene->addCamera(new app::CSceneCamera(pCamera, oDescriptor));
      }
    }
    
    void buildLights(CScene*& pScene, const pugi::xml_node& _lights)
    {
      for(pugi::xml_node _light = _lights.first_child(); _light; _light = _light.next_sibling())
      {
        pugi::xml_attribute _type   = _light.attribute("type");
        if(!_type)
          throw EXCEPTION << "<light type=\"?\"> attribute mandatory!";
        
        if(strncmp(_type.value(), "spot", 4) == 0)
        {
          float position[3]  = { 0.0f, 1.0f, 0.0f };
          pugi::xml_attribute _position   = _light.attribute("position");
          if(!_position)
            throw EXCEPTION << "<light type=\"spot\" position=\"?\"> attribute mandatory!";
          else
            sscanf(_position.value(), "%f %f %f", &position[0], &position[1], &position[2]);
          
          float direction[3] = { 0.0f };
          pugi::xml_attribute _direction  = _light.attribute("direction");
          if(_direction)
            sscanf(_direction.value(), "%f %f %f", &direction[0], &direction[1], &direction[2]);
          
          float color[3] = { 1.0f };
          pugi::xml_attribute _color   = _light.attribute("color");
          if(_color)
            sscanf(_color.value(), "%f %f %f", &color[0], &color[1], &color[2]);
          
          float cutoff = 0.0f;
          pugi::xml_attribute _cutoff = _light.attribute("cutoff");
          if(_cutoff)
            sscanf(_cutoff.value(), "%f", &cutoff);
            
          float diffuse = 0.0f;
          pugi::xml_attribute _diffuse = _light.attribute("diffuse");
          if(_diffuse)
            sscanf(_diffuse.value(), "%f", &diffuse);
          
          float ambient = 0.0f;
          pugi::xml_attribute _ambient = _light.attribute("ambient");
          if(_ambient)
            sscanf(_ambient.value(), "%f", &ambient);
          
          float attenuation[3] = { 0.0f };
          pugi::xml_attribute _attenuation = _light.attribute("attenuation");
          if(_attenuation)
            sscanf(_attenuation.value(), "%f %f %f", &attenuation[0], &attenuation[1], &attenuation[2]);
          
          ogl::CSpotLight* pLight = new ogl::CSpotLight;
          pLight->mColor            = math::vec3(color[0], color[1], color[2]);
          pLight->mPosition         = math::vec3(position[0], position[1], position[2]);
          pLight->mDirection        = math::vec3(direction[0], direction[1], direction[2]);
          pLight->mCutoff           = cutoff;
          pLight->mAmbientIntensity = ambient;
          pLight->mDiffuseIntensity = diffuse;
          pLight->mK0               = attenuation[0];
          pLight->mK1               = attenuation[1];
          pLight->mK2               = attenuation[2];
          
          pScene->addLight(new CSceneLight(pLight, app::tags::LIGHT + app::tags::SPOTLIGHT));
        }
        else if(strncmp(_type.value(), "point", 5) == 0)
        {
          float position[3]  = { 0.0f, 1.0f, 0.0f };
          pugi::xml_attribute _position   = _light.attribute("position");
          if(!_position)
            throw EXCEPTION << "<light type=\"spot\" position=\"?\"> attribute mandatory!";
          else
            sscanf(_position.value(), "%f %f %f", &position[0], &position[1], &position[2]);
            
          float color[3] = { 1.0f };
          pugi::xml_attribute _color   = _light.attribute("color");
          if(_color)
            sscanf(_color.value(), "%f %f %f", &color[0], &color[1], &color[2]);

          float diffuse = 0.0f;
          pugi::xml_attribute _diffuse = _light.attribute("diffuse");
          if(_diffuse)
            sscanf(_diffuse.value(), "%f", &diffuse);
          
          float ambient = 0.0f;
          pugi::xml_attribute _ambient = _light.attribute("ambient");
          if(_ambient)
            sscanf(_ambient.value(), "%f", &ambient);
          
          float attenuation[3] = { 0.0f };
          pugi::xml_attribute _attenuation = _light.attribute("attenuation");
          if(_attenuation)
            sscanf(_attenuation.value(), "%f %f %f", &attenuation[0], &attenuation[1], &attenuation[2]);
        
          ogl::CPointLight* pLight = new ogl::CPointLight;
          pLight->mColor            = math::vec3(color[0], color[1], color[2]);
          pLight->mPosition         = math::vec3(position[0], position[1], position[2]);
          pLight->mAmbientIntensity = ambient;
          pLight->mDiffuseIntensity = diffuse;
          pLight->mK0               = attenuation[0];
          pLight->mK1               = attenuation[1];
          pLight->mK2               = attenuation[2];
          
          pScene->addLight(new CSceneLight(pLight, app::tags::LIGHT + app::tags::POINTLIGHT));
        }
        else if(strncmp(_type.value(), "direct", 6) == 0)
        {
          float direction[3] = { 0.0f };
          pugi::xml_attribute _direction  = _light.attribute("direction");
          if(_direction)
            sscanf(_direction.value(), "%f %f %f", &direction[0], &direction[1], &direction[2]);
            
          float color[3] = { 1.0f };
          pugi::xml_attribute _color   = _light.attribute("color");
          if(_color)
            sscanf(_color.value(), "%f %f %f", &color[0], &color[1], &color[2]);

          float diffuse = 1.0f;
          pugi::xml_attribute _diffuse = _light.attribute("diffuse");
          if(_diffuse)
            sscanf(_diffuse.value(), "%f", &diffuse);
          
          float ambient = 0.0f;
          pugi::xml_attribute _ambient = _light.attribute("ambient");
          if(_ambient)
            sscanf(_ambient.value(), "%f", &ambient);
        
          ogl::CDirectLight* pLight = new ogl::CDirectLight;
          pLight->mColor            = math::vec3(color[0], color[1], color[2]);
          pLight->mDirection        = math::vec3(direction[0], direction[1], direction[2]);
          pLight->mAmbientIntensity = ambient;
          pLight->mDiffuseIntensity = diffuse;
          
          pScene->addLight(new CSceneLight(pLight, app::tags::LIGHT + app::tags::DIRECTLIGHT));
        }
        else
        {
          throw EXCEPTION << "<light type=\"" << _type.value() << "\"> not supported!";
        }
      }
    }
    
    void buildEvents(CScene*& pScene, const pugi::xml_node& _events)
    {
      throw EXCEPTION << "NOT IMPLEMENTED!";
    }
  
    void buildShapes(ogl::CObject*& pObject, const pugi::xml_node& _shapes)
    {
      size_t i = 0;
      for(pugi::xml_node _shape = _shapes.first_child(); _shape; _shape = _shape.next_sibling())
      {
        ogl::CShape* pShape = pObject->getShape(i);
        
        pugi::xml_node _textures = _shape.child("textures");
        if(_textures)
          buildTextures(pShape, _textures);
          
        ++i;
      }
    }
    
    void buildTextures(ogl::CShape* const& pShape, const pugi::xml_node& _textures)
    {
      ogl::CTgaTextureBuilder* pTgaTextureBuilder = new ogl::CTgaTextureBuilder;
    
      for(pugi::xml_node _texture = _textures.first_child(); _texture; _texture = _texture.next_sibling())
      {
        pugi::xml_attribute _scope = _texture.attribute("scope");
        pugi::xml_attribute _src   = _texture.attribute("src");
        if(!_scope || !_src)
          throw EXCEPTION << "<texture scope=\"?\" src=\"?\"> attributes are mandatory!";
        
        pTgaTextureBuilder->setFile(_src.value());
        
        if(strncmp(_scope.value(), "diffuse", 7) == 0)
        {
          pShape->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTgaTextureBuilder->build());
        }
        else if(strncmp(_scope.value(), "normals", 7) == 0)
        {
          pShape->getMaterial()->setTexture(ogl::CTexture::EScope::NORMALS, pTgaTextureBuilder->build());
        }
        else if(strncmp(_scope.value(), "height", 5) == 0)
        {
          pShape->getMaterial()->setTexture(ogl::CTexture::EScope::HEIGHT, pTgaTextureBuilder->build());
        }
        else
        {
          throw EXCEPTION << "<texture scope=\"" << _scope.value() << "\" > Not supported!";
        }
      }
      
      _DELETE(pTgaTextureBuilder);
    }
  };
}

#endif // __app_cscenebuilder_hpp__


















