#ifndef __app_cogldev45ambientocclusionapp_hpp__
#define __app_cogldev45ambientocclusionapp_hpp__

namespace app
{
  class COGLDev45AmbientOcclusionApp : public CApp
  {
    protected:
    ogl::CRenderer* pRenderer;
    ogl::CScene*    pScene;
    
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev45AmbientOcclusionApp::onInit() " << std::endl;
      
      // create scene here
      pScene = new app::COGLDev45Scene;
      
      
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev45AmbientOcclusionApp::onDraw(nTime) > " << fTime << std::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime)); // must
      
      /////////////////////////////////////////////////////
      
      CCamera* pCamera = pScene->getCamera(0);
      
      pRenderer->setCamera(pCamera);
      pRenderer->addLight(pSpotLight, util::ETag::NO_SHADOW + util::ETag::EMPTY);
      pRenderer->addLight(pSpotLight, util::ETag::NO_SHADOW);
      pRenderer->addLight(pDirectLight, util::ETag::NO_SHADOW);
      pRenderer->addLight(pPointLight);
      pRenderer->addDrawable(pObjectB, util::ETag::NO_SHADOW);
      pRenderer->addDrawable(pObject0);
      pRenderer->addDrawable(pObject1);
      pRenderer->render();
      
      glCheckError();
      
      CApp::exit();
    }
    
    void onStop()
    { 
      std::cout << "app::COGLDev45AmbientOcclusionApp::onStop()" << std::endl;
      
      _DELETE(pScene);
      
      ogl::CProgramManager::freeInstance();
      app::CEventManager::freeInstance();
      ogl::CTransformHistory::freeInstance();
    }
  };
}

#endif // __app_cogldev45ambientocclusionapp_hpp__
