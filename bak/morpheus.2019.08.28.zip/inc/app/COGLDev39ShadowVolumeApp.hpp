#ifndef __app_cogldev39shadowvolumeapp_hpp__
#define __app_cogldev39shadowvolumeapp_hpp__

namespace app
{
  class COGLDev39ShadowVolumeApp : public CApp
  {
    private:
    ogl::CPointLight* pPointLight;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CObject* pObjectP;
    ogl::CObject* pObject0;
    
    ogl::CForwardRenreder* pForwardRenderer;
    
    public:
    COGLDev39ShadowVolumeApp()
    {
      pPointLight       = nullptr;
      pCamera           = nullptr;
      pCameraController = nullptr;
      pObjectP          = nullptr;
      pObject0          = nullptr;
      pForwardRenderer  = nullptr;
    
      std::cout << "app::COGLDev39ShadowVolumeApp::COGLDev39ShadowVolumeApp()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      mConfig.mWidth      = 640;
      mConfig.mHeight     = 480;
      strcpy(mConfig.mTitle, "COGLDev39ShadowVolumeApp");
    }
    
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev39ShadowVolumeApp::onInit() " << std::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_renderers();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev39ShadowVolumeApp::onDraw(nTime) > " << nTime << std::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime)); // must

      /////////////////////////////////////////////////////
      
      pPointLight->mPosition = math::vec3(sin(fTime) * 1.5f, 1.5f, cos(fTime) * 1.5f);
      
      /////////////////////////////////////////////////////
      
      pForwardRenderer->clear();
      pForwardRenderer->setCamera(pCamera);
      pForwardRenderer->addLight(pPointLight);
      pForwardRenderer->addDrawable(pObjectP, ogl::EDrawOptions::NOSHADOWCAST);
      pForwardRenderer->addDrawable(pObject0);
      pForwardRenderer->render();
      
      glCheckError();
      
      // CApp::exit();
    }
    
    void onStop()
    { 
      std::cout << "app::COGLDev39ShadowVolumeApp::onStop()" << std::endl;
      
      _DELETE(pPointLight);
      
      _DELETE(pCamera);
      _DELETE(pCameraController);
      
      _DELETE(pForwardRenderer);
      
      _DELETE(pObjectP);
      _DELETE(pObject0);
    }
    
    private:
    void init_lights()
    {
      std::cout << "app::COGLDev39ShadowVolumeApp::init_lights()" << std::endl;
    
      pPointLight                    = new ogl::CPointLight;
      pPointLight->mColor            = math::vec3(1.0f, 0.25f, 0.25f);
      pPointLight->mPosition         = math::vec3(2.5f, 2.5f, 2.5f);
      pPointLight->mDiffuseIntensity = 0.8f;
      pPointLight->mAmbientIntensity = 0.2f;
      
      // ogl::CLightManager::getInstance()->addLight(pPointLight); // 0
    }
    
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(0.0f, -1.5f, -3.5f));
      pCameraController = new CCameraController(pCamera);
      
      //ogl::CCameraManager::getInstance()->addCamera(pCamera); // 0
      //app::CControllerManager::getInstance()->addController(pCamaraController); // 0
    }
    
    void init_programs()
    {
      ogl::CFileShaderBuilder*     pShaderBuilder = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      ogl::CProgramDescriptor* pProgramDescriptor = new ogl::CProgramDescriptor;
      ogl::CProgram*                     pProgram = nullptr;
      ogl::CProgramManager*       pProgramManager = ogl::CProgramManager::getInstance();
      
      ogl::CShader* pVShader = nullptr;
      ogl::CShader* pGShader = nullptr;
      ogl::CShader* pFShader = nullptr;
      
      { // null shader
        std::cout << "> INFO: null_01" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("null_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("null_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "> INFO: running null_01" << std::endl;
          
          ogl::CForwardRenreder* pForwardRenderer = dynamic_cast<ogl::CForwardRenreder*>(pRenderer);
          ogl::CProgram*      pProgram            = pForwardRenderer->getProgram();
          ogl::CCamera*       pCamera             = pForwardRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::NONE);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::NONE);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }      
      { // simple shader
        std::cout << "> INFO: simple_01" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("simple_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("simple_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "> INFO: running simple_01" << std::endl;
          
          ogl::CForwardRenreder* pForwardRenderer = dynamic_cast<ogl::CForwardRenreder*>(pRenderer);
          ogl::CProgram*      pProgram      = pForwardRenderer->getProgram();
          ogl::CCamera*       pCamera       = pForwardRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMV", mV * mM);
          pProgram->setUniform("u_mP",  mP);
          
          pProgram->setUniform("u_bWireframe", (bool)(pForwardRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::FORWARD);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // quad shader
        std::cout << "> INFO: quad_01" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("quad_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("quad_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "> INFO: running quad_01" << std::endl;
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::QUAD);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // shadow volume rendering
        std::cout << "> INFO: shadow_volume" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("shadow_volume.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_GEOMETRY_SHADER);
        pShaderBuilder->setFile("shadow_volume.gs.glsl");
        pGShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("shadow_volume.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pGShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mM",                    new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",                    new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",                    new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oPointLight.vPosition", new ogl::CUniform(GL_FLOAT_VEC3));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "> INFO: running shadow_volume" << std::endl;
          
          ogl::CForwardRenreder* pForwardRenderer = dynamic_cast<ogl::CForwardRenreder*>(pRenderer);
          ogl::CProgram*         pProgram         = pForwardRenderer->getProgram();
          ogl::CCamera*          pCamera          = pForwardRenderer->getCamera();
          ogl::CLight*           pLight           = pForwardRenderer->getLight();
          ogl::CPointLight*      pPointLight      = dynamic_cast<ogl::CPointLight*>(pLight);
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mM", mM);
          pProgram->setUniform("u_mV", mV);
          pProgram->setUniform("u_mP", mP);
          pProgram->setUniform("u_oPointLight.vPosition", pPointLight->getPosition());
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::SHADOW_VOLUME);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::NONE);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pGShader; delete pFShader; 
      }
      { // silhouette rendering
        std::cout << "> INFO: silhouette_01" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("silhouette_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_GEOMETRY_SHADER);
        pShaderBuilder->setFile("silhouette_01.gs.glsl");
        pGShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("silhouette_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pGShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mM",                    new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",                    new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",                    new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oPointLight.vPosition", new ogl::CUniform(GL_FLOAT_VEC3));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "> INFO: running silhouette_01" << std::endl;
          
          ogl::CForwardRenreder* pForwardRenderer = dynamic_cast<ogl::CForwardRenreder*>(pRenderer);
          ogl::CProgram*         pProgram         = pForwardRenderer->getProgram();
          ogl::CCamera*          pCamera          = pForwardRenderer->getCamera();
          ogl::CLight*           pLight           = pForwardRenderer->getLight();
          ogl::CPointLight*      pPointLight      = dynamic_cast<ogl::CPointLight*>(pLight);
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mM", mM);
          pProgram->setUniform("u_mV", mV);
          pProgram->setUniform("u_mP", mP);
          pProgram->setUniform("u_oPointLight.vPosition", pPointLight->getPosition());
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::SILHOUETTE);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pGShader; delete pFShader; 
      }
      { // forward rendering diffuse pass - no ambient light
        std::cout << "> INFO: forward_render_diffuse_pass" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("forward_render_ambient_pass.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("forward_render_diffuse_pass.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oPointLight.vColor", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oPointLight.vPosition", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oPointLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK0", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK1", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK2", new ogl::CUniform(GL_FLOAT));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "> INFO: running forward_render_diffuse_pass" << std::endl;
          
          ogl::CForwardRenreder* pForwardRenderer = dynamic_cast<ogl::CForwardRenreder*>(pRenderer);
          ogl::CProgram*         pProgram         = pForwardRenderer->getProgram();
          ogl::CCamera*          pCamera          = pForwardRenderer->getCamera();
          ogl::CLight*           pLight           = pForwardRenderer->getLight(0);
          ogl::CPointLight*      pPointLight      = dynamic_cast<ogl::CPointLight*>(pLight);
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
          pProgram->setUniform("u_oPointLight.vColor",            pPointLight->mColor);
          pProgram->setUniform("u_oPointLight.vPosition",         pPointLight->mPosition);
          pProgram->setUniform("u_oPointLight.fDiffuseIntensity", pPointLight->mDiffuseIntensity);
          pProgram->setUniform("u_oPointLight.fK0",               pPointLight->mK0);
          pProgram->setUniform("u_oPointLight.fK1",               pPointLight->mK1);
          pProgram->setUniform("u_oPointLight.fK2",               pPointLight->mK2);
        });

        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::FORWARD);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::BLINN_PHONG);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::DIFFUSE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader;
      }
      { // forward rendering ambient pass - no diffuse light
        std::cout << "> INFO: forward_render_ambient_pass" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("forward_render_ambient_pass.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("forward_render_ambient_pass.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oPointLight.vColor", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oPointLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "> INFO: running forward_render_ambient_pass" << std::endl;
          ogl::CForwardRenreder* pForwardRenderer = dynamic_cast<ogl::CForwardRenreder*>(pRenderer);
          ogl::CProgram*         pProgram         = pForwardRenderer->getProgram();
          ogl::CCamera*          pCamera          = pForwardRenderer->getCamera();
          ogl::CLight*           pLight           = pForwardRenderer->getLight(0);
          ogl::CPointLight*      pPointLight      = dynamic_cast<ogl::CPointLight*>(pLight);
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
          pProgram->setUniform("u_oPointLight.vColor",            pPointLight->mColor);
          pProgram->setUniform("u_oPointLight.fAmbientIntensity", pPointLight->mAmbientIntensity);
        });

        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::FORWARD);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::BLINN_PHONG);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::AMBIENT);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader;
      }
      
      _DELETE(pShaderBuilder);
      _DELETE(pProgramBuilder);
      _DELETE(pProgramDescriptor);
    }
    
    void init_objects()
    {
      std::cout << "app::COGLDev39ShadowVolumeApp::init_objects()" << std::endl;
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        pObjectBuilder->setTextureScale(0.5f);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        // pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
        pTextureBuilder->setFile("ground/rocks_d.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        pTextureBuilder->setFile("ground/rocks_h.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::HEIGHT,  pTextureBuilder->build()); // displacement
        
        glExitIfError();
        
        delete pObjectBuilder;
      }
      { // boblampclean
        ogl::CMd5ObjectBuilder* pObjectBuilder = new ogl::CMd5ObjectBuilder;
        pObjectBuilder->setFile("boblampclean/boblampclean.md5mesh");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObjectBuilder->addOption(ogl::CObjectBuilder::ADJACENCY);
        pObject0 = pObjectBuilder->build();

        pObject0->scale(2.0f);
        pObject0->rotate(math::quat(-90.0f, math::X) * math::quat(180.0f, math::Z));
        
        glExitIfError();
        
        delete pObjectBuilder;
      }
    }
  
    void init_renderers()
    {
      std::cout << "app::COGLDev39ShadowVolumeApp::init_renderers()" << std::endl;
      
      pForwardRenderer = new ogl::CForwardRenreder(mConfig.mWidth, mConfig.mHeight);
    }
  };
}

#endif // __app_cogldev39shadowvolumeapp_hpp__
