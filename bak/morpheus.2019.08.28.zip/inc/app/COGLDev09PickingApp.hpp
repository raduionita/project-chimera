#ifndef __cogldev09pickingapp_hpp__
#define __cogldev09pickingapp_hpp__

namespace app
{
  class COGLDev09PickingApp : public CApp
  {
    protected:
    ogl::CProgram* pProgramPicking;
    ogl::CProgram* pProgramBillboard;
    ogl::CProgram* pProgramSkybox;
    ogl::CProgram* pProgramShadow;
    ogl::CProgram* pProgramRender;
    ogl::CProgram* pProgramFlat;
    
    ogl::CObject*  pObjectB;
    ogl::CObject*  pObjectP;
    ogl::CObject*  pObject1;
    ogl::CObject*  pObjectS;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CDirectLight*     pDirectLight;
    ogl::CPointLight*      pPointLights[2];
    ogl::CSpotLight*       pSpotLights[2];
    app::CLightController* pLightController;
    
    ogl::CDrawRenderer*           pDrawRenderer;
    ogl::CShadowRenderer*         pShadowRenderer;
    ogl::CPickRenderer*           pPickRenderer;
    app::CPickRendererController* pPickRendererController;
    
    public:
    COGLDev09PickingApp()
    {
      std::cout << "app::COGLDev09PickingApp::COGLDev09PickingApp()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "COGLDev09PickingApp");
    }
    
    void onInit()
    {
      std::cout << "app::COGLDev09PickingApp::onInit() " << std::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_renderers();
      
      glExitIfError();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev09PickingApp::onDraw(nTime) > " << nTime << std::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime));
      
      // pShadowRenderPass->setLight(pDirectLight);
      // pShadowRenderPass->addDrawable(pObject1);
      // pRenderer->render(pShadowRenderPass);
      
      pPickRenderer->setCamera(pCamera);
      pPickRenderer->addDrawable(pObject1);
      pPickRenderer->addDrawable(pObjectP);
      pPickRenderer->render();
      
      
      pDrawRenderer->setCamera(pCamera);
      pDrawRenderer->addLight(pDirectLight);
      pDrawRenderer->addLight(pSpotLights[0]);
      // pDrawRenderer->addLight(pSpotLights[1]);
      // pDrawRenderer->addLight(pPointLights[0]);
      // pDrawRenderer->addLight(pPointLights[1]);
      // pDrawRenderer->addShadowTextuture(pShadowRenderPass->getTexture());
      pDrawRenderer->setPickPixel(pPickRenderer->getPickPixel());
      pDrawRenderer->addDrawable(pObject1/*, ogl::EDrawOptions::WIREFRAME*/);
      pDrawRenderer->addDrawable(pObjectP);
      pDrawRenderer->render();
      
      glExitIfError();
      
      CApp::exit();
    }
    
    void onStop()
    {
      std::cout << "app::COGLDev09PickingApp::onStop()" << std::endl;
      
      _DELETE(pProgramPicking);
      _DELETE(pProgramBillboard);
      _DELETE(pProgramSkybox);
      _DELETE(pProgramShadow);
      _DELETE(pProgramRender);
      _DELETE(pProgramFlat);
      
      _DELETE(pObjectB);
      _DELETE(pObjectP);
      _DELETE(pObject1);
      _DELETE(pObjectS);
      
      _DELETE(pCameraController);
      _DELETE(pCamera);
      
      _DELETE(pLightController);
      _DELETE(pDirectLight);
      _DELETE(pPointLights[0]);
      _DELETE(pPointLights[1]);
      _DELETE(pSpotLights[0]);
      _DELETE(pSpotLights[1]);
      
      _DELETE(pDrawRenderer);
      _DELETE(pPickRenderer);
      _DELETE(pShadowRenderer);
    }
    
    private:
    void init_programs()
    {
      ogl::CFileShaderBuilder*    pShaderBuilder = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      
      ogl::CShader* pVShader;
      ogl::CShader* pGShader;
      ogl::CShader* pFShader;
      
      { // billboard
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("billboard_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_GEOMETRY_SHADER);
        pShaderBuilder->setFile("billboard_01.gs.glsl");
        pGShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("billboard_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pGShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mVP",             new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_vCameraPosition", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramBillboard::mCallback()" << std::endl;
        });
        pProgramBillboard = pProgramBuilder->build();
        
        delete pVShader; delete pGShader; delete pFShader;
      }
      { // skybox
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("skybox_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("skybox_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramSkybox::mCallback()" << std::endl;
        });
        pProgramSkybox = pProgramBuilder->build();
        
        delete pVShader; delete pFShader; 
      }
      { // shadow
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("shadow_map_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("shadow_map_01_shadow.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramShadow::mCallback()" << std::endl;
        });
        pProgramShadow = pProgramBuilder->build();
        
        delete pVShader; delete pFShader; 
      }
      { // picking
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("picking_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("picking_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mMVP",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_vIdentifier", new ogl::CUniform(GL_INT_VEC3));
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramPicking::mCallback()" << std::endl;
          
          ogl::CPickRenderer* pPickRenderer = dynamic_cast<ogl::CPickRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pPickRenderer->getProgram();
          ogl::CCamera*       pCamera       = pPickRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
          pProgram->setUniform("u_vIdentifier", math::ivec3(pPickRenderer->getDrawIndex(), pPickRenderer->getObjectIndex(), 1));
        });
        pProgramPicking = pProgramBuilder->build();
        
        delete pVShader; delete pFShader; 
      }
      { // flat
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("flat_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("flat_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mMVP",  new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
        });
        pProgramFlat = pProgramBuilder->build();
        
        delete pVShader; delete pFShader; 
      }
      { // render + light + shadow + normal + pick
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("lighting_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("lighting_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mLightMVP",  new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
        pProgramBuilder->addUniform("u_nOptions",   new ogl::CUniform(GL_UNSIGNED_INT));
        
        pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fEyePosition",       new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_vPickPixel",       new ogl::CUniform(GL_INT_VEC3));
        pProgramBuilder->addUniform("u_vIdentifier",      new ogl::CUniform(GL_INT_VEC3));
        pProgramBuilder->addUniform("u_nPickMode",        new ogl::CUniform(GL_INT));
        
        for(size_t i = 0; i < 2; i++)
        {
          char name[128];
          memset(name, 0, sizeof(name));
          snprintf(name, sizeof(name), "u_oPointLights[%d].vColor", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oPointLights[%d].vPosition", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fAmbientIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fDiffuseIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK0", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK1", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK2", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        }
        
        for(size_t i = 0; i < 2; i++)
        {
          char name[128];
          memset(name, 0, sizeof(name));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vColor", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vPosition", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vDirection", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fCutoff", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fAmbientIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fDiffuseIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK0", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK1", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK2", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        }
      
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramRender::mCallback()" << std::endl;
          
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          ogl::CPickPixel*    pPickPixel    = pDrawRenderer->getPickPixel();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mM",  mM);
          pProgram->setUniform("u_mMV", mV * mM);
          pProgram->setUniform("u_mP",  mP);
          pProgram->setUniform("u_fSpecularIntensity",  0.0f);
          pProgram->setUniform("u_fSpecularPower",      0.0f);
          pProgram->setUniform("u_fEyePosition",        pCamera->getPosition());
          pProgram->setUniform("u_nOptions",            (USE_DIFFUSE_MAP | USE_SHADOW_MAP)); // @TODO: doesn't work !?
          pProgram->setUniform("u_bWireframe",          (bool)(pDrawRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
          
          if(pPickPixel)
          {
            pProgram->setUniform("u_vPickPixel",  pPickPixel->getData());
            pProgram->setUniform("u_vIdentifier", math::ivec3(pDrawRenderer->getObjectIndex(), pDrawRenderer->getDrawIndex(), 0));
            pProgram->setUniform("u_nPickMode",   ogl::EPickMode::PRIMITIVE);
          }
          
          for(ogl::CLight* pLight : pDrawRenderer->getLights())
          {
            if(pLight->getType() == ogl::CLight::DIRECT)
            {
              ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
              pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
              pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
              pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
              pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
            }
            else if(pLight->getType() == ogl::CLight::SPOT)
            {
              //@TODO...
            }
            else if(pLight->getType() == ogl::CLight::POINT)
            {
              //@TODO...
            }
          }
        });
        pProgramRender = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
        
        glExitIfError();
      }
      
      delete pShaderBuilder;
      delete pProgramBuilder;
    }
    
    void init_lights()
    {
      pDirectLight = new ogl::CDirectLight;
      pDirectLight->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pDirectLight->mDirection = math::vec3(-1.0f, -1.0f, 0.0f);
      pDirectLight->mAmbientIntensity = 0.025f;
      pDirectLight->mDiffuseIntensity = 0.6f;
      
      pPointLights[0] = new ogl::CPointLight;
      pPointLights[1] = new ogl::CPointLight;
      pPointLights[0]->mColor    = math::vec3(0.0f, 0.0f, 0.0f);
      pPointLights[0]->mPosition = math::vec3(-5.0f, 5.0f, 0.0f);
      pPointLights[0]->mAmbientIntensity = 0.0f;
      pPointLights[0]->mDiffuseIntensity = 0.0f;
      pPointLights[0]->mK0 = 0.01f;
      pPointLights[0]->mK1 = 0.0f;
      pPointLights[0]->mK2 = 0.0f;
      pPointLights[1]->mColor    = math::vec3(1.0f, 1.0f, 1.0f);
      pPointLights[1]->mPosition = math::vec3(2.0f, 3.0f, 2.0f);
      pPointLights[1]->mAmbientIntensity = 0.01f;
      pPointLights[1]->mDiffuseIntensity = 0.45f;
      pPointLights[1]->mK0 = 0.0f;
      pPointLights[1]->mK1 = 0.1f;
      pPointLights[1]->mK2 = 0.01f;
      
      pSpotLights[0] = new ogl::CSpotLight;
      pSpotLights[1] = new ogl::CSpotLight;
      pSpotLights[0]->mColor     = math::vec3 (1.0f, 1.0f, 1.0f);
      pSpotLights[0]->mPosition  = math::vec3( 0.0f, 2.0f, 3.0f); // pCamera->getPosition();
      pSpotLights[0]->mDirection = math::vec3(-1.0f,-1.0f, 0.0f); // pCamera->getForward();
      pSpotLights[0]->mCutoff = 0.95f;
      pSpotLights[0]->mAmbientIntensity = 0.0f;
      pSpotLights[0]->mDiffuseIntensity = 0.5f;
      pSpotLights[0]->mK0 = 0.0f;
      pSpotLights[0]->mK1 = 0.03f;
      pSpotLights[0]->mK2 = 0.0f;
      pSpotLights[1]->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pSpotLights[1]->mPosition  = math::vec3(3.0f, 3.0f, 0.0f);
      pSpotLights[1]->mDirection = math::vec3(-1.0f,-1.0f, 0.0f);
      pSpotLights[1]->mCutoff = 0.90f;
      pSpotLights[1]->mAmbientIntensity = 0.01f;
      pSpotLights[1]->mDiffuseIntensity = 0.4f;
      pSpotLights[1]->mK0 = 0.08f;
      pSpotLights[1]->mK1 = 0.02f;
      pSpotLights[1]->mK2 = 0.0f;
      
      pLightController = new CLightController(pDirectLight);
    }
    
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(0.0f, -2.0f, -5.0f));
      pCameraController = new CCameraController(pCamera);
    }
    
    void init_renderers()
    {
      pDrawRenderer = new ogl::CDrawRenderer(mConfig.mWidth, mConfig.mHeight);
      pDrawRenderer->setProgram(pProgramRender);
      pDrawRenderer->setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      pDrawRenderer->setClearDepth(1.0f);
      pDrawRenderer->setWinding(GL_CW);
      pDrawRenderer->setCullFace(GL_BACK);
      
      pPickRenderer = new ogl::CPickRenderer(mConfig.mWidth, mConfig.mHeight);
      pPickRenderer->setProgram(pProgramPicking);
      
      pPickRendererController = new CPickRendererController(pPickRenderer);
      
      pShadowRenderer = new ogl::CShadowRenderer(mConfig.mWidth, mConfig.mHeight);
      
      glExitIfError();
    }
    
    void init_objects()
    {
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
        pTextureBuilder->setFile("wall/bricks_d.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        pTextureBuilder->setFile("wall/bricks_n.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        
        delete pObjectBuilder;
      }
      { // box from box-builder
//        ogl::CBoxObjectBuilder* pObjectBuilder = new ogl::CBoxObjectBuilder;
//        pObjectBuilder->setWidth(1.0f);
//        pObjectBuilder->setHeight(1.0f);
//        pObjectBuilder->setDepth(1.0f);
//        pObject = pObjectBuilder->build();
//        pObject->setM(math::translate(0.0f, -1.0f, 5.0f) * math::scale(10.0f));
//        delete pObjectBuilder;
      }
      { // random mesh
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("sphere.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObject1 = pObjectBuilder->build();
        pObject1->setM(math::translate(0.0f, 0.0f, 0.0f));
        delete pObjectBuilder;
      }
      { // skybox
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("skybox/skydome.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObjectS = pObjectBuilder->build();
        pObjectS->setM(math::scale(20.0f));
        delete pObjectBuilder;
      }
      { // billboarding
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(18.0f);
        pObjectBuilder->setHeight(18.0f);
        pObjectBuilder->setSubdivisions(6);
        // pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectB = pObjectBuilder->build();
        delete pObjectBuilder;
        
        ogl::CPngTextureBuilder* pTextureBuilder = new ogl::CPngTextureBuilder;
        pTextureBuilder->setFile("monster.png");
        ogl::CTexture* pTexture = pTextureBuilder->build();
        pTexture->setWrapping(ogl::CTexture::EWrapping::CLAMP_TO_BORDER);
        delete pTextureBuilder;
        
        ogl::CMaterial* pMaterial = new ogl::CMaterial;
        pMaterial->setTexture(ogl::CTexture::EScope::DIFFUSE, pTexture);
        
        pObjectB->setMode(GL_POINTS);
        pObjectB->getShape(0)->setMaterial(pMaterial);
      }
    }
  };
}

#endif // __cogldev09pickingapp_hpp__
