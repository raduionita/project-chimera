#ifndef __ceventmanager_hpp__
#define __ceventmanager_hpp__

#include <vector>

namespace app
{
  typedef uint event_type_t;
  const event_type_t EVENT_TYPE_NONE        = 0x0000;
  const event_type_t EVENT_TYPE_KEY         = 0x0001;
  const event_type_t EVENT_TYPE_MOUSEBUTTON = 0x0002;
  const event_type_t EVENT_TYPE_MOUSEMOVE   = 0x0003;
  const event_type_t EVENT_TYPE_MOUSEDRAG   = 0x0004;
  const event_type_t EVENT_TYPE_RESIZE      = 0x0005;
  const event_type_t EVENT_TYPE_UPDATE      = 0x0006;
  const event_type_t EVENT_TYPE_RENDER      = 0x0007;
  const event_type_t EVENT_TYPE_STOP        = 0x0008;
  const event_type_t EVENT_TYPE_PAUSE       = 0x0009;
  const event_type_t EVENT_TYPE_INIT        = 0x000A;
  const event_type_t EVENT_TYPE_ERROR       = 0x000B;
  const event_type_t EVENT_TYPE_WARNING     = 0x000C;
  const event_type_t EVENT_TYPE_DEBUG       = 0x000D;
  
  typedef uint error_code_t;
  const error_code_t ERROR_NONE   = 0x0000;
  const error_code_t ERROR_SYSTEM = 0x0001;
  const error_code_t ERROR_OPENGL = 0x0002;
  
  class CEvent
  {
    public:
    event_type_t mType;
    
    public:
    CEvent() : mType(EVENT_TYPE_NONE) 
    {
      
    }
      
    CEvent(event_type_t type) : mType(type) 
    {
      
    }
    
    virtual ~CEvent()
    {
      
    }
    
    public:
    virtual event_type_t getType() const
    {
      return mType;
    }
  };
  
  class CKeyEvent : public CEvent
  {
    public:
    int mKey;
    int mAction;
    
    public:
    CKeyEvent() : CEvent(EVENT_TYPE_KEY)
    {
      
    }
    
    CKeyEvent(int key, int action) : CEvent(EVENT_TYPE_KEY), mKey(key), mAction(action)
    {
      
    }
  };
  
  class CMouseEvent : public CEvent
  {
    public:
    int mX;
    int mY;
    
    public:
    CMouseEvent(event_type_t event) : CEvent(event), mX(0), mY(0)
    {
    
    }
    
    CMouseEvent(event_type_t event, int x, int y) : CEvent(event), mX(x), mY(y)
    {
      
    }
  };
  
  class CMouseButtonEvent : public CMouseEvent
  {
    public:
    int mButton; // press|release
    int mState; // press|release
    
    public: 
    CMouseButtonEvent() : CMouseEvent(EVENT_TYPE_MOUSEBUTTON), mButton(0), mState(0)
    {
      
    }
    
    CMouseButtonEvent(int button, int state, int x, int y) : CMouseEvent(EVENT_TYPE_MOUSEBUTTON, x, y), mButton(button), mState(state)
    {
    
    }
  };

  class CMouseMoveEvent : public CMouseEvent
  {
    public:
    CMouseMoveEvent() : CMouseEvent(EVENT_TYPE_MOUSEMOVE)
    {
      
    }
    
    CMouseMoveEvent(int x, int y) : CMouseEvent(EVENT_TYPE_MOUSEMOVE, x, y)
    {
    
    }
  };
  
  class CMouseDragEvent : public CMouseEvent
  {
    public: 
    CMouseDragEvent() : CMouseEvent(EVENT_TYPE_MOUSEDRAG)
    {
      
    }
    
    CMouseDragEvent(int x, int y) : CMouseEvent(EVENT_TYPE_MOUSEDRAG, x, y)
    {
      
    }
  };
  
  class CUpdateEvent : public CEvent
  {
    public:
    float mTime;
    
    public: 
    CUpdateEvent() : CEvent(EVENT_TYPE_UPDATE)
    {
      
    }
    
    CUpdateEvent(float time) : CEvent(EVENT_TYPE_UPDATE), mTime(time)
    {
      
    }
  };
  
  class CRenderEvent : public CEvent
  {
    public:
    float mTime;
    
    public: 
    CRenderEvent() : CEvent(EVENT_TYPE_RENDER)
    {
      
    }
    
    CRenderEvent(float time) : CEvent(EVENT_TYPE_RENDER), mTime(time)
    {
      
    }
  };
  
  class CErrorEvent : public CEvent
  {
    public:
    int         mCode;
    std::string mMessage;
    
    
    public: 
    CErrorEvent() : CEvent(EVENT_TYPE_ERROR), mCode(0)
    {
      
    }
    
    CErrorEvent(int code, const std::string& message) : CEvent(EVENT_TYPE_ERROR), mCode(code), mMessage(message)
    {
      
    }
    
    CErrorEvent(const std::string& message, int code) : CEvent(EVENT_TYPE_ERROR), mCode(code), mMessage(message)
    {
      
    }
  };
  
  //class CWarningEvent : public CEvent
  //class CDebugEvent : public CEvent
  
  class CResizeEvent : public CEvent
  {
    public:
    int mWidth;
    int mHeight;
    
    public: 
    CResizeEvent() : CEvent(EVENT_TYPE_RESIZE)
    {
      
    }
    
    CResizeEvent(int width, int height) : CEvent(EVENT_TYPE_RESIZE), mWidth(width), mHeight(height)
    {
      
    }
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  class CListener
  {
    protected:
    event_type_t mType;
    
    public:
    CListener() : mType(EVENT_TYPE_NONE)
    {
    
    }
    
    CListener(event_type_t type) : mType(type)
    {
    
    }
    
    virtual ~CListener()
    {
    
    }
    
    public:
    virtual void trigger(CEvent* pEvent) = 0;
    
    virtual event_type_t getType() const
    {
      return mType;
    }
  };
  
  class CEventManager : public sys::CSingleton<CEventManager> 
  {
    friend class sys::CSingleton<CEventManager>;
  
    protected:
    std::vector<CListener*> mListeners;
    
    protected:
    CEventManager()
    {
      sys::info << "app::CEventManager::CEventManager()" << sys::endl;
    }
    
    virtual ~CEventManager()
    {
      sys::info << "app::CEventManager::~CEventManager()" << sys::endl;
      // for(auto pListener : mListeners)
        // _DELETE(pListener);
    }
    
    public:
    void trigger(CEvent* pEvent)
    {
      for(auto pListener : mListeners)
      {
        if(pEvent->getType() == pListener->getType())
          pListener->trigger(pEvent);
      }
      _DELETE(pEvent); //@TODO: this needs a smart pointer ... otherwise it can be used with threads
    }
    
    void addListener(CListener* pListener)
    {
      mListeners.push_back(pListener);
    }
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  class COnMouseMoveListener : public CListener
  {
    public:
    COnMouseMoveListener() : CListener(EVENT_TYPE_MOUSEMOVE)
    {
      // add to event manager as a listener for mouse move
      CEventManager::getInstance()->addListener(this);
    }
    
    public:
    virtual void onMouseMove(CMouseMoveEvent*) = 0;
    
    virtual void trigger(CEvent* pEvent)
    {
      CMouseMoveEvent* pMouseMoveEvent = dynamic_cast<CMouseMoveEvent*>(pEvent);
      onMouseMove(pMouseMoveEvent);
    }
  };

  class COnMouseDragListener : public CListener
  {
    public:
    COnMouseDragListener() : CListener(EVENT_TYPE_MOUSEDRAG)
    {
      // add to event manager as a listener for mouse drag
      CEventManager::getInstance()->addListener(this);
    }
    
    public:
    virtual void onMouseDrag(CMouseDragEvent*) = 0;
    
    virtual void trigger(CEvent* pEvent)
    {
      CMouseDragEvent* pMouseDragEvent = dynamic_cast<CMouseDragEvent*>(pEvent);
      onMouseDrag(pMouseDragEvent);
    }
  };

  class COnKeyListener : public CListener
  {
    public:
    COnKeyListener() : CListener(EVENT_TYPE_KEY)
    {
      // add to event manager as a listener for keyboard input
      CEventManager::getInstance()->addListener(this);
    }
  
    protected:
    virtual void onKey(CKeyEvent*) = 0;
    
    virtual void trigger(CEvent* pEvent)
    {
      CKeyEvent* pKeyEvent = dynamic_cast<CKeyEvent*>(pEvent);
      onKey(pKeyEvent);
    }
  };
  
  class COnMouseButtonListener : public CListener
  {
    public:
    COnMouseButtonListener() : CListener(EVENT_TYPE_MOUSEBUTTON)
    {
      CEventManager::getInstance()->addListener(this);
    }
    
    protected:
    virtual void onMouseButton(CMouseButtonEvent*) = 0;
    
    virtual void trigger(CEvent* pEvent)
    {
      CMouseButtonEvent* pMouseButtonEvent = dynamic_cast<CMouseButtonEvent*>(pEvent);
      onMouseButton(pMouseButtonEvent);
    }
  };
  
  class COnUpdateListener : public CListener
  {
    public:
    COnUpdateListener() : CListener(EVENT_TYPE_UPDATE)
    {
      CEventManager::getInstance()->addListener(this);
    }
    
    protected:
    virtual void onUpdate(CUpdateEvent*) = 0;
    
    virtual void trigger(CEvent* pEvent)
    {
      CUpdateEvent* pUpdateEvent = dynamic_cast<CUpdateEvent*>(pEvent);
      onUpdate(pUpdateEvent);
    }
  };
  
  class COnRenderListener : public CListener
  {
    public:
    COnRenderListener() : CListener(EVENT_TYPE_RENDER)
    {
      CEventManager::getInstance()->addListener(this);
    }
    
    protected:
    virtual void onRender(CRenderEvent*) = 0;
    
    virtual void trigger(CEvent* pEvent)
    {
      CRenderEvent* pRenderEvent = dynamic_cast<CRenderEvent*>(pEvent);
      onRender(pRenderEvent);
    }
  };

  class COnResizeListener : public CListener
  {
    public:
    COnResizeListener() : CListener(EVENT_TYPE_RESIZE)
    {
      CEventManager::getInstance()->addListener(this);
    }
    
    protected:
    virtual void onResize(CResizeEvent*) = 0;
    
    virtual void trigger(CEvent* pEvent)
    {
      CResizeEvent* pResizeEvent = dynamic_cast<CResizeEvent*>(pEvent);
      onResize(pResizeEvent);
    }
  };
  
  class COnErrorListener : public CListener
  {
    public:
    COnErrorListener() : CListener(EVENT_TYPE_ERROR)
    {
      CEventManager::getInstance()->addListener(this);
    }
    
    protected:
    virtual void onError(CErrorEvent*) = 0;
    
    virtual void trigger(CEvent* pEvent)
    {
      CErrorEvent* pErrorEvent = dynamic_cast<CErrorEvent*>(pEvent);
      onError(pErrorEvent);
    }
  };
}

#endif // __ceventmanager_hpp__
