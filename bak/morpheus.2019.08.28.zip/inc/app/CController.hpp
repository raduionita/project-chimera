#ifndef __ccontroller_hpp__
#define __ccontroller_hpp__

namespace app
{
  class CController
  {
    public:
    CController()
    {
    
    }
    
    virtual ~CController()
    {
    
    }
  };
}

#endif // __ccontroller_hpp__
