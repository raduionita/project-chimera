#ifndef __app_cogldev42pcfshadowmap_hpp__
#define __app_cogldev42pcfshadowmap_hpp__

namespace app
{
  class COGLDev42PCFShadowMapApp : public CApp
  {
    protected:
    ogl::CDirectLight* pDirectLight;
    ogl::CPointLight*  pPointLight;
    ogl::CSpotLight*   pSpotLight;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CObject* pObjectP;
    ogl::CObject* pObjectB;
    ogl::CObject* pObject0;
    ogl::CObject* pObject1;
    
    ogl::CPCFShadowMapRenderer* pRenderer;
    
    public:
    COGLDev42PCFShadowMapApp()
    {
      pPointLight       = nullptr;
      pCamera           = nullptr;
      pCameraController = nullptr;
      pObjectP          = nullptr;
      pObjectB          = nullptr;
      pObject0          = nullptr;
      pObject1          = nullptr;
      pRenderer         = nullptr;
    
      sys::info << "app::COGLDev42PCFShadowMapApp::COGLDev42PCFShadowMapApp()" << sys::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      mConfig.mWidth           = 800;
      mConfig.mHeight          = 600;
      strcpy(mConfig.mTitle, "COGLDev42PCFShadowMapApp");
    }
    
    protected:
    void onInit()
    {
      sys::info << "app::COGLDev42PCFShadowMapApp::onInit() " << sys::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_renderers();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      sys::info << "app::COGLDev42PCFShadowMapApp::onDraw(nTime) > " << fTime << sys::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime)); // must
      
      /////////////////////////////////////////////////////
      
      //pObjectP->mPosition = math::vec3(0.0f, sin(fTime) * 3.0f, 0.0f);
      pPointLight->mPosition = math::vec3(sin(fTime) * 1.5f, 2.0f, cos(fTime) * 1.5f);
      pObject1->mPosition = math::vec3(pObject1->mPosition.x, sin(fTime) * 3.0f + 5.0f, cos(fTime) * 3.0f + 1.0f);
      
      /////////////////////////////////////////////////////
      
      pRenderer->setCamera(pCamera);
      pRenderer->addLight(pSpotLight);
      pRenderer->addLight(pDirectLight);
      pRenderer->addLight(pPointLight);
      pRenderer->addDrawable(pObjectB, ogl::EDrawOptions::NOSHADOWCAST);
      pRenderer->addDrawable(pObject0);
      pRenderer->addDrawable(pObject1);
      pRenderer->render();
      
      glCheckError();
      
      // CApp::exit();
    }
    
    void onStop()
    { 
      sys::info << "app::COGLDev42PCFShadowMapApp::onStop()" << sys::endl;
      
      _DELETE(pDirectLight);
      _DELETE(pPointLight);
      _DELETE(pSpotLight);
      
      _DELETE(pCamera);
      _DELETE(pCameraController);
      
      _DELETE(pRenderer);
      
      _DELETE(pObjectP);
      _DELETE(pObjectB);
      _DELETE(pObject0);
      _DELETE(pObject1);
      
      ogl::CProgramManager::freeInstance();
      app::CEventManager::freeInstance();
      ogl::CTransformHistory::freeInstance();
    }
    
    private:
    void init_lights()
    {
      sys::info << "app::COGLDev42PCFShadowMapApp::init_lights()" << sys::endl;
      
      pDirectLight                    = new ogl::CDirectLight;
      pDirectLight->mColor            = math::vec3( 1.00f,  1.00f,  1.00f);
      pDirectLight->mDirection        = math::vec3(-1.00f, -1.00f, -1.00f);
      pDirectLight->mAmbientIntensity = 0.20f;
      pDirectLight->mDiffuseIntensity = 0.80f;
      
      pPointLight                    = new ogl::CPointLight;
      pPointLight->mColor            = math::vec3(1.00f, 1.00f, 1.00f);
      pPointLight->mPosition         = math::vec3(2.00f, 2.00f, 2.00f);
      pPointLight->mAmbientIntensity = 0.50f;
      pPointLight->mDiffuseIntensity = 0.60f;
      pPointLight->mK0               = 0.10f;
      pPointLight->mK1               = 0.40f;
      pPointLight->mK2               = 0.00f;
      
      pSpotLight                    = new ogl::CSpotLight;
      pSpotLight->mColor            = math::vec3( 1.00f,  1.00f, 1.00f); // MUST
      pSpotLight->mPosition         = math::vec3( 1.25f,  2.50f, 0.00f); // MUST
      pSpotLight->mDirection        = math::vec3(-0.50f, -1.00f, 0.00f); // MUST
      pSpotLight->mCutoff           = 0.65f;                             // MUST
      pSpotLight->mAmbientIntensity = 0.55f;                             // MUST
      pSpotLight->mDiffuseIntensity = 0.45f;                             // MUST
      pSpotLight->mK0               = 0.00f;                             // MUST
      pSpotLight->mK1               = 0.40f;                             // MUST
      pSpotLight->mK2               = 0.00f;                             // MUST
    }
  
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(0.0f, 3.5f, -6.5f)); 
      pCameraController = new app::CCameraController(pCamera);
    }
    
    void init_programs()
    {
      ogl::CFileShaderBuilder*     pShaderBuilder = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      ogl::CProgramDescriptor* pProgramDescriptor = new ogl::CProgramDescriptor;
      ogl::CProgram*                     pProgram = nullptr;
      ogl::CProgramManager*       pProgramManager = ogl::CProgramManager::getInstance();
      
      ogl::CShader* pVShader = nullptr;
      ogl::CShader* pGShader = nullptr;
      ogl::CShader* pFShader = nullptr;
      
      { // null shader
        sys::info << sys::tab << "null_01" << sys::endl;
        
        pShaderBuilder->setType(ogl::CShader::VERTEX); 
        pShaderBuilder->setFile("null_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(ogl::CShader::FRAGMENT);
        pShaderBuilder->setFile("null_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* /* DEPRICATED */, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << sys::tab << "running null_01" << sys::endl;
          
          ogl::CForwardRenreder* pRenderer = dynamic_cast<ogl::CForwardRenreder*>(pDrawCommand->mRenderer);
          ogl::CProgram*         pProgram  = pDrawCommand->mProgram;
          ogl::CCamera*          pCamera   = pRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::NONE);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::NONE);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions(ogl::ERenderingOptions::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // quad shader
        sys::info << sys::tab << "quad_01" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("quad_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("quad_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->setCallback([](ogl::CRenderer* /* DEPRICATED */, ogl::CDrawCommand* /* DEPRICATED */) -> void {
          sys::info << sys::tab << "running quad_01" << sys::endl;
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::QUAD);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions(ogl::ERenderingOptions::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // simple shader
        sys::info << sys::tab << "simple_01" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("simple_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("simple_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMVP",       new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* /* DEPRICATED */, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << sys::tab << "running simple_01" << sys::endl;
          
          ogl::CPCFShadowMapRenderer* pRenderer = dynamic_cast<ogl::CPCFShadowMapRenderer*>(pDrawCommand->mRenderer);
          ogl::CProgram*              pProgram  = pDrawCommand->mProgram;
          ogl::CCamera*               pCamera   = pRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
          
          pProgram->setUniform("u_bWireframe", (bool)(pRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::FORWARD);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions(ogl::ERenderingOptions::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // wireframe shader
        sys::info << sys::tab << "wireframe_01" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("wireframe_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("wireframe_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMVP",       new ogl::CUniform(GL_FLOAT_MAT4));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* /* DEPRICATED */, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << sys::tab << "running wireframe_01" << sys::endl;
          
          ogl::CPCFShadowMapRenderer* pRenderer = dynamic_cast<ogl::CPCFShadowMapRenderer*>(pDrawCommand->mRenderer);
          ogl::CProgram*              pProgram  = pDrawCommand->mProgram;
          ogl::CCamera*               pCamera   = pRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::WIREFRAME);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::NONE);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions(ogl::ERenderingOptions::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // normals shader
        sys::info << sys::tab << "normals_01" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("normals_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_GEOMETRY_SHADER);
        pShaderBuilder->setFile("normals_01.gs.glsl");
        pGShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("normals_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pGShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mM",       new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mVP",       new ogl::CUniform(GL_FLOAT_MAT4));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* /* DEPRICATED */, ogl::CDrawCommand* /* DEPRICATED */) -> void {
          sys::info << sys::tab << "running normals_01" << sys::endl;
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::NORMALS);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::NONE);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions(ogl::ERenderingOptions::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pGShader;  delete pFShader; 
      }
      { // shadow_pcf shader
        sys::info << sys::tab << "shadow_pcf" << sys::endl;
        
        pShaderBuilder->setType(ogl::CShader::VERTEX); 
        pShaderBuilder->setFile("shadow_pcf.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(ogl::CShader::FRAGMENT);
        pShaderBuilder->setFile("shadow_pcf.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* /* DEPRICATED */, ogl::CDrawCommand* /* DEPRICATED */) -> void {
          /* DEPRICATED */ /* TODO: depricated program callbacks - move logic inside renderer service */
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::NONE);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions(ogl::ERenderingOptions::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // lighting shader
        sys::info << sys::tab << "lighting_02" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("lighting_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("lighting_02.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mM",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oDirectLight.vColor",            new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.vDirection",        new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.mVP",               new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oDirectLight.bEnabled",          new ogl::CUniform(GL_BOOL));
        pProgramBuilder->addUniform("u_oPointLight.vColor",            new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oPointLight.vPosition",         new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oPointLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK0",               new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK1",               new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK2",               new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.bEnabled",          new ogl::CUniform(GL_BOOL));
        pProgramBuilder->addUniform("u_oSpotLight.vColor",             new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oSpotLight.vPosition",          new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oSpotLight.vDirection",         new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oSpotLight.fCutoff",            new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oSpotLight.fAmbientIntensity",  new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oSpotLight.fDiffuseIntensity",  new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oSpotLight.fK0",                new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oSpotLight.fK1",                new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oSpotLight.fK2",                new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oSpotLight.mVP",                new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oSpotLight.bEnabled",           new ogl::CUniform(GL_BOOL));
        pProgramBuilder->addUniform("u_fSpecularIntensity",            new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularPower",                new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oCamera.vPosition",             new ogl::CUniform(GL_FLOAT_VEC3));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* /* DEPRICATED */, ogl::CDrawCommand* pDrawCommand) -> void {
          /** DEPRICATED */
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::FORWARD);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::BLINN_PHONG);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::BOTH);
        pProgramDescriptor->setRenderingOptions(ogl::ERenderingOptions::STATIC | ogl::ERenderingOptions::SHADOW);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      
      _DELETE(pShaderBuilder);
      _DELETE(pProgramBuilder);
      _DELETE(pProgramDescriptor);
    }
    
    void init_objects()
    {
      sys::info << "app::COGLDev42PCFShadowMapApp::init_objects()" << sys::endl;
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(25.0f);
        pObjectBuilder->setHeight(25.0f);
        pObjectBuilder->setSubdivisions(10);
        pObjectBuilder->setTextureScale(0.5f);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CObjectBuilder::TANGENTS);
        // pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CTgaTextureBuilder* pTgaTextureBuilder = new ogl::CTgaTextureBuilder;
        ogl::CDdsTextureBuilder* pDdsTextureBuilder = new ogl::CDdsTextureBuilder;
        pTgaTextureBuilder->setFile("ground/concrete_d.tga");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTgaTextureBuilder->build());
        pTgaTextureBuilder->setFile("ground/concrete_n.tga");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::NORMALS, pTgaTextureBuilder->build()); // normals
        pDdsTextureBuilder->setFile("skybox/planet.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::ENVIRONMENT, pDdsTextureBuilder->build());
        
        // pObjectP->translate(math::vec3(0.0f, -3.0f, 0.0f));
        
        // TODO: move this inside CObject or in a CObjectBuilder
        ogl::CTransformHistory::getInstance()->set(pObjectP, ogl::CTransform(pObjectP->mScale, pObjectP->mOrientation, pObjectP->mPosition));
        
        glExitIfError();
        
        delete pTgaTextureBuilder;
        delete pDdsTextureBuilder;
        delete pObjectBuilder;
      }
      { // box
        ogl::CBoxObjectBuilder* pObjectBuilder = new ogl::CBoxObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setDepth(10.0f);
        pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectBuilder->setTextureScale(0.5f);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::FLATFACE);
        
        pObjectB = pObjectBuilder->build();
        
        ogl::CTgaTextureBuilder* pTgaTextureBuilder = new ogl::CTgaTextureBuilder;
        ogl::CDdsTextureBuilder* pDdsTextureBuilder = new ogl::CDdsTextureBuilder;
        pTgaTextureBuilder->setFile("tiles/pavers_d.tga");
        pObjectB->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTgaTextureBuilder->build());
        pTgaTextureBuilder->setFile("tiles/pavers_n.tga");
        pObjectB->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::NORMALS, pTgaTextureBuilder->build()); // normals
        pDdsTextureBuilder->setFile("skybox/skydome.dds");
        pObjectB->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::ENVIRONMENT, pDdsTextureBuilder->build());
        
        pObjectB->translate(math::vec3(0.0f, 5.0f, 0.0f));
        
        glExitIfError();

        delete pTgaTextureBuilder;
        delete pDdsTextureBuilder;
        delete pObjectBuilder;
      }
      { // boblampclean
        ogl::CMd5ObjectBuilder* pObjectBuilder = new ogl::CMd5ObjectBuilder;
        pObjectBuilder->setFile("boblampclean/boblampclean.md5mesh");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::ADJACENCY); // TODO: unfuck up the MD5 parser
        pObject0 = pObjectBuilder->build();
        
        ogl::CTgaTextureBuilder* pTextureBuilder = new ogl::CTgaTextureBuilder;
        pTextureBuilder->setFile("boblampclean/guard1_body_n.tga");
        // sys::info << sys::tab << "set normal to shape: " << pObject0->getShape(0)->getName() << sys::endl;
        pObject0->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::NORMALS, pTextureBuilder->build());
        
        // TODO: need better normalization
        pObject0->scale(2.0f);
        pObject0->rotate(math::quat(-90.0f, math::X) * math::quat(180.0f, math::Z));
        
        // Remember previous transformation
        ogl::CTransformHistory::getInstance()->set(pObject0, ogl::CTransform(pObject0->mScale, pObject0->mOrientation, pObject0->mPosition));
        
        glExitIfError();
        
        delete pObjectBuilder;
        delete pTextureBuilder;
      }
      { // another box
        ogl::CMd5ObjectBuilder* pObjectBuilder = new ogl::CMd5ObjectBuilder;
        pObjectBuilder->setFile("cube.md5mesh");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObject1 = pObjectBuilder->build();
        
        pObject1->scale(0.5f);
        pObject1->translate(math::vec3(4.0f, 5.0f, 1.0f));
        
        ogl::CTransformHistory::getInstance()->set(pObject1, ogl::CTransform(pObject1->mScale, pObject1->mOrientation, pObject1->mPosition));
        
        delete pObjectBuilder;
      }
    }
  
    void init_renderers()
    {
      sys::info << "app::COGLDev42PCFShadowMapApp::init_renderers()" << sys::endl;
      
      pRenderer = new ogl::CPCFShadowMapRenderer(mConfig.mWidth, mConfig.mHeight);
    }
  };
}

#endif // __app_cogldev42pcfshadowmap_hpp__
