#ifndef __APP_COGLDEV41MOTIONBLURAPP_HPP__
#define __APP_COGLDEV41MOTIONBLURAPP_HPP__

namespace app
{
  class COGLDev41MotionBlurApp : public CApp
  {
    protected:
    ogl::CPointLight* pPointLight;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CObject* pObjectP;
    ogl::CObject* pObject0;
    
    ogl::CMotionBlurRenderer* pRenderer;
    
    public:
    COGLDev41MotionBlurApp()
    {
      pPointLight       = nullptr;
      pCamera           = nullptr;
      pCameraController = nullptr;
      pObjectP          = nullptr;
      pObject0          = nullptr;
      pRenderer         = nullptr;
    
      sys::info << "app::COGLDev41MotionBlurApp::COGLDev41MotionBlurApp()" << sys::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      mConfig.mWidth           = 640;
      mConfig.mHeight          = 480;
      strcpy(mConfig.mTitle, "COGLDev41MotionBlurApp");
    }
    
    protected:
    void onInit()
    {
      sys::info << "app::COGLDev41MotionBlurApp::onInit() " << sys::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_renderers();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      sys::info << "app::COGLDev41MotionBlurApp::onDraw(nTime) > " << fTime << sys::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime)); // must

      /////////////////////////////////////////////////////
      
      pPointLight->mPosition = math::vec3(sin(fTime) * 1.5f, 1.5f, cos(fTime) * 1.5f);
      
      // TODO: move this in CModelController::update() or something like that
      ogl::CTransformHistory::getInstance()->set(pObject0, ogl::CTransform(pObject0->mScale, pObject0->mOrientation, pObject0->mPosition));
      ogl::CTransformHistory::getInstance()->set(pObjectP, ogl::CTransform(pObjectP->mScale, pObjectP->mOrientation, pObjectP->mPosition));
      
      // need motion for motion blur to be visible
      pObject0->mPosition = math::vec3(sin(fTime * 2.0f) * 1.5f, 0.0f, cos(fTime * 2.0f) * 1.5f);
      pObjectP->mOrientation = math::quat(sin(fTime * 2.0f) * 90.0f, math::Y);
      
      /////////////////////////////////////////////////////
      
      pRenderer->setCamera(pCamera);
      pRenderer->addLight(pPointLight);
      pRenderer->addDrawable(pObjectP);
      pRenderer->addDrawable(pObject0);
      pRenderer->render();
      
      glCheckError();
      
      // CApp::exit();
    }
    
    void onStop()
    { 
      sys::info << "app::COGLDev41MotionBlurApp::onStop()" << sys::endl;
      
      _DELETE(pPointLight);
      
      _DELETE(pCamera);
      _DELETE(pCameraController);
      
      _DELETE(pRenderer);
      
      _DELETE(pObjectP);
      _DELETE(pObject0);
      
      ogl::CProgramManager::freeInstance();
      app::CEventManager::freeInstance();
      ogl::CTransformHistory::freeInstance();
    }
    
    private:
    void init_lights()
    {
      sys::info << "app::COGLDev41MotionBlurApp::init_lights()" << sys::endl;
    
      pPointLight                    = new ogl::CPointLight;
      pPointLight->mColor            = math::vec3(1.0f, 0.25f, 0.25f);
      pPointLight->mPosition         = math::vec3(2.5f, 2.5f, 2.5f);
      pPointLight->mDiffuseIntensity = 0.8f;
      pPointLight->mAmbientIntensity = 0.2f;
    }
    
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(0.0f, -1.5f, -3.5f));
      pCameraController = new CCameraController(pCamera);
    }
    
    void init_programs()
    {
      ogl::CFileShaderBuilder*     pShaderBuilder = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      ogl::CProgramDescriptor* pProgramDescriptor = new ogl::CProgramDescriptor;
      ogl::CProgram*                     pProgram = nullptr;
      ogl::CProgramManager*       pProgramManager = ogl::CProgramManager::getInstance();
      
      ogl::CShader* pVShader = nullptr;
      ogl::CShader* pFShader = nullptr;
      
      { // null shader
        sys::info << sys::tab << "null_01" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("null_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("null_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << sys::tab << "running null_01" << sys::endl;
          
          ogl::CForwardRenreder* pForwardRenderer = dynamic_cast<ogl::CForwardRenreder*>(pRenderer);
          ogl::CProgram*      pProgram            = pForwardRenderer->getProgram();
          ogl::CCamera*       pCamera             = pForwardRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::NONE);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::NONE);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }      
      { // simple shader
        sys::info << sys::tab << "simple_01" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("simple_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("simple_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << sys::tab << "running simple_01" << sys::endl;
          
          ogl::CForwardRenreder* pForwardRenderer = dynamic_cast<ogl::CForwardRenreder*>(pRenderer);
          ogl::CProgram*      pProgram      = pForwardRenderer->getProgram();
          ogl::CCamera*       pCamera       = pForwardRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMV", mV * mM);
          pProgram->setUniform("u_mP",  mP);
          
          pProgram->setUniform("u_bWireframe", (bool)(pForwardRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::FORWARD);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // motion blur quad shader
        sys::info << sys::tab << "motion_blur_quad" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("motion_blur_quad.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("motion_blur_quad.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << sys::tab << "running motion_blur_quad" << sys::endl;
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::MOTION_BLUR);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::NONE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::NONE);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions((uint)(ogl::ERenderingOptions::NONE));
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      { // motion blur color shader
        sys::info << sys::tab << "motion_blur_color" << sys::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("motion_blur_color.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("motion_blur_color.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mPrevM", new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mCurrM", new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",     new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",     new ogl::CUniform(GL_FLOAT_MAT4));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << sys::tab << "running motion_blur_color" << sys::endl;
          ogl::CObject*  pObject  = dynamic_cast<ogl::CObject*>(pDrawCommand->mDrawable);
          ogl::CProgram* pProgram = pRenderer->getProgram();
          ogl::CCamera*  pCamera  = pRenderer->getCamera();
          
          math::mat4 mPrevM = ogl::CTransformHistory::getInstance()->get(pObject).getModelMatrix();
          math::mat4 mCurrM = pDrawCommand->mModelMatrix;
          math::mat4 mV     = pCamera->getViewMatrix();
          math::mat4 mP     = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mPrevM", mPrevM);
          pProgram->setUniform("u_mCurrM", mCurrM);
          pProgram->setUniform("u_mV",     mV);
          pProgram->setUniform("u_mP",     mP);
        });
        
        pProgram = pProgramBuilder->build();
        pProgramDescriptor->setRenderingScope(ogl::ERenderingScope::FORWARD);
        pProgramDescriptor->setDrawStrategyType(ogl::EDrawStrategyType::SINGLE);
        pProgramDescriptor->setShadingMode(ogl::EShadingMode::FLAT);
        pProgramDescriptor->setLightingPass(ogl::ELightingPass::NONE);
        pProgramDescriptor->setRenderingOptions((uint)(ogl::ERenderingOptions::MOTION_BLUR));
        pProgramManager->addProgram(*pProgramDescriptor, pProgram);
        
        delete pVShader; delete pFShader; 
      }
      
      _DELETE(pShaderBuilder);
      _DELETE(pProgramBuilder);
      _DELETE(pProgramDescriptor);
    }
  
    void init_objects()
    {
      sys::info << "app::COGLDev41MotionBlurApp::init_objects()" << sys::endl;
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        pObjectBuilder->setTextureScale(0.5f);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        // pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CTgaTextureBuilder* pTextureBuilder = new ogl::CTgaTextureBuilder;
        pTextureBuilder->setFile("ground/concrete_d.tga");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        pTextureBuilder->setFile("ground/concrete_n.tga");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::NORMALS, pTextureBuilder->build()); // bump
        
        // TODO: move this inside CObject or in a CObjectBuilder
        ogl::CTransformHistory::getInstance()->set(pObjectP, ogl::CTransform(pObjectP->mScale, pObjectP->mOrientation, pObjectP->mPosition));
        
        glExitIfError();
        
        delete pObjectBuilder;
        delete pTextureBuilder;
      }
      { // boblampclean
        ogl::CMd5ObjectBuilder* pObjectBuilder = new ogl::CMd5ObjectBuilder;
        pObjectBuilder->setFile("boblampclean/boblampclean.md5mesh");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::ADJACENCY); // TODO: unfuck up the MD5 parser
        pObject0 = pObjectBuilder->build();
        
        // TODO: need better normalization
        pObject0->scale(2.0f);
        pObject0->rotate(math::quat(-90.0f, math::X) * math::quat(180.0f, math::Z));
        
        // Remember previous transformation
        ogl::CTransformHistory::getInstance()->set(pObject0, ogl::CTransform(pObject0->mScale, pObject0->mOrientation, pObject0->mPosition));
        
        glExitIfError();
        
        delete pObjectBuilder;
      }
    }
  
    void init_renderers()
    {
      sys::info << "app::COGLDev41MotionBlurApp::init_renderers()" << sys::endl;
      
      pRenderer = new ogl::CMotionBlurRenderer(mConfig.mWidth, mConfig.mHeight);
    }
  };
}

#endif // __APP_COGLDEV41MOTIONBLURAPP_HPP__
