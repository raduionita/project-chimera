#ifndef __cogldev10tessellationapp_hpp__
#define __cogldev10tessellationapp_hpp__

namespace app
{
  class COGLDev10TessellationApp : public CApp
  {
    private:
    ogl::CProgram*          pProgramTessellation0;
    ogl::CProgram*          pProgramTessellation1; // using bezier triangle
    // b(u,v,w) = B(300) * w^3 + B(030) * u^3 + B(003) * v^3 +
    //          + B(210) * 3*w^2*u + B(120) * 3*w*u^2 + B(201) * 3*w^2*v + B(021) * 3*u^2*v + B(102) * 3*w*v^2*u + B(012) * 3*u*v^2 +
    //          + B(111) * 6*w*u*v
    
    ogl::CObject*           pObjectP;
    ogl::CObject*           pObject0;
    
    ogl::CDirectLight*      pDirectLight;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CDrawRenderer*     pDrawRenderer;
    
    public:
    COGLDev10TessellationApp()
    {
      sys::info << "app::COGLDev10TessellationApp::COGLDev10TessellationApp()" << sys::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "COGLDev10TessellationApp");
    }
    
    void onInit()
    {
      sys::info << "app::COGLDev10TessellationApp::onInit() " << sys::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_renderers();
      
      glExitIfError();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      sys::info << "app::COGLDev10TessellationApp::onDraw(nTime) > " << nTime << sys::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime));
      
      pDrawRenderer->setCamera(pCamera);
      pDrawRenderer->addLight(pDirectLight);
      //pDrawRenderer->addDrawable(pObjectP); //, ogl::EDrawOptions::WIREFRAME);
      //pDrawRenderer->addDrawable(pObject0);
      pDrawRenderer->addDrawable(pObject0, ogl::EDrawOptions::WIREFRAME);
      pDrawRenderer->render();
      
      glExitIfError();
      
      //CApp::exit();
    }
    
    void onStop()
    {
      sys::info << "app::COGLDev10TessellationApp::onStop()" << sys::endl;
      
      _DELETE(pProgramTessellation0);
      _DELETE(pProgramTessellation1);
      
      _DELETE(pObjectP);
      _DELETE(pObject0);
      
      _DELETE(pDirectLight);
      
      _DELETE(pCamera);
      _DELETE(pCameraController);
      
      _DELETE(pDrawRenderer);
    }  
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    private:
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(0.0f, -2.0f, -5.0f));
      pCameraController = new CCameraController(pCamera);
    }
    
    void init_lights()
    {
      pDirectLight = new ogl::CDirectLight;
      pDirectLight->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pDirectLight->mDirection = math::vec3(-1.0f, -1.0f, 0.0f);
      pDirectLight->mAmbientIntensity = 0.525f;
      pDirectLight->mDiffuseIntensity = 0.0f;
    }
    
    void init_programs()
    {
      ogl::CFileShaderBuilder*    pShaderBuilder = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      
      ogl::CShader* pVShader;
      ogl::CShader* pCShader;
      ogl::CShader* pEShader;
      ogl::CShader* pFShader;
      {
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("tessellation_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_TESS_CONTROL_SHADER);
        pShaderBuilder->setFile("tessellation_01.cs.glsl");
        pCShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_TESS_EVALUATION_SHADER);
        pShaderBuilder->setFile("tessellation_01.es.glsl");
        pEShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("tessellation_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pCShader);
        pProgramBuilder->addShader(pEShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMV",           new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mM",            new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",            new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",            new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_fHeightFactor", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_vEyePosition",  new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_bWireframe",    new ogl::CUniform(GL_BOOL));
          
        pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << "pProgramTessellation0::mCallback()" << sys::endl;
          
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMV", mV * mM);
          pProgram->setUniform("u_mM", mM);
          pProgram->setUniform("u_mV", mV);
          pProgram->setUniform("u_mP", mP);
          pProgram->setUniform("u_vEyePosition",  pCamera->getPosition());
          pProgram->setUniform("u_bWireframe",    (bool)(pDrawRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
          pProgram->setUniform("u_fHeightFactor", 0.5f);
          
          for(ogl::CLight* pLight : pDrawRenderer->getLights())
          {
            if(pLight->getType() == ogl::CLight::DIRECT)
            {
              ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
              pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
              pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
              pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
              pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
            }
          }
        });
        pProgramTessellation0 = pProgramBuilder->build();
        delete pVShader; delete pCShader; delete pEShader; delete pFShader; 
        
        glExitIfError();
      }
      {
        glPatchParameteri(GL_PATCH_VERTICES, 3);
      
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("tessellation_02.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_TESS_CONTROL_SHADER);
        pShaderBuilder->setFile("tessellation_02.cs.glsl");
        pCShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_TESS_EVALUATION_SHADER);
        pShaderBuilder->setFile("tessellation_02.es.glsl");
        pEShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("tessellation_02.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pCShader);
        pProgramBuilder->addShader(pEShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMV",           new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mM",            new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",            new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",            new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_fHeightFactor", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_bWireframe",    new ogl::CUniform(GL_BOOL));
        pProgramBuilder->addUniform("u_fTessLevel",    new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_vEyePosition",  new ogl::CUniform(GL_FLOAT_VEC3));
          
        pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          sys::info << "pProgramTessellation1::mCallback()" << sys::endl;
          
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMV", mV * mM);
          pProgram->setUniform("u_mM", mM);
          pProgram->setUniform("u_mV", mV);
          pProgram->setUniform("u_mP", mP);
          pProgram->setUniform("u_fTessLevel",    2.0f);
          pProgram->setUniform("u_bWireframe",    (bool)(pDrawRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
          pProgram->setUniform("u_fHeightFactor", 0.5f);
          pProgram->setUniform("u_vEyePosition",  pCamera->getPosition());
          
          for(ogl::CLight* pLight : pDrawRenderer->getLights())
          {
            if(pLight->getType() == ogl::CLight::DIRECT)
            {
              ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
              pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
              pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
              pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
              pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
            }
          }
        });
        pProgramTessellation1 = pProgramBuilder->build();
        delete pVShader; delete pCShader; delete pEShader; delete pFShader; 
        
        glExitIfError();
      }
      
      delete pShaderBuilder;
      delete pProgramBuilder;
    }
    
    void init_objects()
    {
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        //pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
        pTextureBuilder->setFile("ground/rocks_d.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        pTextureBuilder->setFile("ground/rocks_h.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::HEIGHT, pTextureBuilder->build()); // displacement
        
        delete pObjectBuilder;
      }
      {
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("monkey/monkey.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObject0 = pObjectBuilder->build();
        pObject0->setM(math::translate(0.0f, 2.0f, 0.0f) * math::rotate(-90.0f, math::X));
        delete pObjectBuilder;
      }
    }
    
    void init_renderers()
    {
      pDrawRenderer = new ogl::CDrawRenderer(mConfig.mWidth, mConfig.mHeight);
      pDrawRenderer->setProgram(pProgramTessellation1);
      pDrawRenderer->setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      pDrawRenderer->setClearDepth(1.0f);
      pDrawRenderer->setWinding(GL_CW);
      pDrawRenderer->setCullFace(GL_BACK);
    }
  };
}

#endif // __cogldev10tessellationapp_hpp__
