#ifndef __CTest01App_hpp__
#define __CTest01App_hpp__

#include <thread>

namespace app
{
  class CTest01App : public CApp
  {
    public:
    CTest01App()
    {
      sys::info << "app::CTest01App::CTest01App()" << sys::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "CTest01App");
    }
  
    protected:
    void onInit()
    {
      sys::info << "app::CTest01App::onInit()" << sys::endl;
      
      sys::info << "app::CTest01App::onInit() > threads: " << std::thread::hardware_concurrency() << sys::endl;
      
      glClearColor(0.2f, 0.2f, 0.2f, 0.0f);
      glClearDepth(1.0f);
      
      sys::info.sync_with_stdio(true);
      std::thread t1([](){
        sys::info << "from thread t1" << sys::endl;
      });
      std::thread t2([](){
        sys::info << "from thread t2" << sys::endl;
      });
      std::thread t3([](){
        sys::info << "from thread t3" << sys::endl;
      });
      std::thread t4([](){
        sys::info << "from thread t4" << sys::endl;
      });
      t1.join();
      t2.join();
      t3.join();
      t4.join();
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      //ngin::CLoaderManager::getInstance()->getLoader("dds")->
      //ngin::CTexture* pTexture = new ngin::CTexture("path/to/file.ext");
      
      
      // ptr::smart<ngin::CTexture*> pTexture = ngin::CTextureManager::getInstance()->getTexture(id);
        // auto it = mTextures.find(file) // std::map<uint, mTextures*>
        // if(it == mTextures.end())
        //   // get texture descriptor by id
        //   
        //   CTextureBuilder* pTextureBuilder = CTextureBuilderManager::getInstance()->getBuilder(pDescriptor->getExt());
        //   
        //   pTextureBuilder->setFile(pDescriptor->getFilePath());
        //   CTexture* pTexture = pTextureBuilder->build();
        //   
    }
    
    void onDraw(int nTime)
    {
      sys::info << "app::CTest01App::onDraw(" << nTime << ")" << sys::endl;
      
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      //exit();
    }
    
    void onStop()
    {
      sys::info << "app::CTest01App::onStop()" << sys::endl;
    }
  };
}

#endif // __CTest01App_hpp__
