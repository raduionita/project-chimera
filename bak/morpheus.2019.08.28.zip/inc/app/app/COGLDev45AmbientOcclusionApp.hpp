#ifndef __app_cogldev45ambientocclusionapp_hpp__
#define __app_cogldev45ambientocclusionapp_hpp__

namespace app
{
  class COGLDev45AmbientOcclusionApp : public CApp
  {
    protected:
    ogl::CDeferredRenderer* pRenderer;
    app::CScene*            pScene;
    
    app::CCameraController* pCameraController;
    
    ogl::CObject* pBox;
    
    public:
    COGLDev45AmbientOcclusionApp() : CApp()
    {
      pScene            = nullptr;
      pRenderer         = nullptr;
      pCameraController = nullptr;
      
      pBox = nullptr;
    
      sys::info << "app::COGLDev45AmbientOcclusionApp::COGLDev45AmbientOcclusionApp()" << sys::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 3;
      mConfig.mWidth           = 800;
      mConfig.mHeight          = 600;
      strcpy(mConfig.mTitle, "COGLDev45AmbientOcclusionApp");
    }
    
    protected:
    void onInit()
    {
      sys::info << "app::COGLDev45AmbientOcclusionApp::onInit() " << sys::endl;
      
      init_programs();
      
      init_scene();
      
      init_renderers();
      
      init_controllers();
    }
    
    void onDraw(int nTime)
    {
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
      
      float fTime = nTime / 1000.0f;
      sys::info << "app::COGLDev45AmbientOcclusionApp::onDraw(nTime) > " << fTime << sys::endl;
      
      ogl::CCamera* pCamera = pScene->getCamera(app::tags::MAINCAMERA)->getCamera();
      
      pCameraController->setCamera(pCamera);
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime)); // must
      
      ///////////////////////////////////////////////////////////////////////////////////
      
      // 1st render scene to a cube env map using 6 cameras - render at the center of the fustrum
        // on lighting fs render - offset the env texel fetch using Light.Position - Fragment.Position
      
      ///////////////////////////////////////////////////////////////////////////////////
      
      // SELECT entity AS object       FROM scene WHERE object IN fustrum ORDER front_to_back
      // SELECT model_entity AS object FROM scene WHERE object IN fustrum ORDER back_to_front
      
      pRenderer->setCamera(pCamera);
      
      for(app::CSceneObject* pSceneObject : pScene->getObjects())
      {
        ogl::CObject* pObject        = pSceneObject->getObject();
        sys::CDescriptor oDescriptor = pSceneObject->getDescriptor();
        
        if(oDescriptor.hasTag(ogl::tags::MESH))
          pObject->setOrientation(math::quat(fTime * 90.0f, math::Y));
        
        if(oDescriptor.hasTag(ogl::tags::BOX))
          pObject->setPosition(math::vec3(-1.0f, 1.0f, -1.0f));
        
        pRenderer->addObject(pObject, oDescriptor);
      }
      for(app::CSceneLight* pSceneLight : pScene->getLights())
      {
        pRenderer->addLight(pSceneLight->getLight(), pSceneLight->getDescriptor());
      }
      
      pRenderer->render();
      
      glCheckError();
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
      
      //CApp::exit(); return;
    }
    
    void onStop()
    { 
      sys::info << "app::COGLDev45AmbientOcclusionApp::onStop()" << sys::endl;
      
      _DELETE(pScene);
      _DELETE(pRenderer);
      _DELETE(pCameraController);
      _DELETE(pBox);
      
      ogl::CProgramManager::freeInstance();
      app::CEventManager::freeInstance();
      ogl::CTransformHistory::freeInstance();
      ogl::CShadowManager::freeInstance();
    }
  
    private:
    void init_scene()
    {
      app::CXmlSceneBuilder* pSceneBuilder = new app::CXmlSceneBuilder;
      pSceneBuilder->setFile("default.xml"); // scene should be merged with its cached version(save file)
      pScene = pSceneBuilder->build();
      
      _DELETE(pSceneBuilder);
    }
  
    void init_programs()
    {
      ogl::CProgramManager*    pManager = ogl::CProgramManager::getInstance();
      ogl::CXmlProgramBuilder* pBuilder = new ogl::CXmlProgramBuilder;
      
      { /* shadow + shadowmap + pcf */
        pBuilder->setFile("shadow/shadowmap.pcf.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::SHADOW + ogl::tags::SHADOWMAP + ogl::tags::PCF);
      }
      { /* geometry + deferred + single */
        pBuilder->setFile("geometry/deferred.single.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::GEOMETRY + ogl::tags::DEFERRED + ogl::tags::SINGLE);
      }
      { /* geometry + deferred + single + parallax */
        pBuilder->setFile("geometry/deferred.single.parallax.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::GEOMETRY + ogl::tags::DEFERRED + ogl::tags::SINGLE + ogl::tags::PARALLAX);
      }
      { /* geometry + deferred + debug */
        pBuilder->setFile("geometry/deferred.debug.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::GEOMETRY + ogl::tags::DEFERRED + ogl::tags::DEBUG);
      }
      { /* lighting + deferred */
        pBuilder->setFile("lighting/deferred.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::LIGHTING + ogl::tags::DEFERRED);
      }
      { /* lighting + deferred  + debug */
        pBuilder->setFile("lighting/deferred.debug.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::LIGHTING + ogl::tags::DEFERRED + ogl::tags::DEBUG);
      }
      { /* lighting + deferred + occlussion */
        pBuilder->setFile("lighting/deferred.occlussion.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::LIGHTING + ogl::tags::DEFERRED + ogl::tags::OCCLUSSION);
      }
      { /* occlussion + deferred */
        pBuilder->setFile("occlussion/deferred.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::OCCLUSSION + ogl::tags::DEFERRED);
      }
      { /* postprocess + blur */
        pBuilder->setFile("postprocess/blur.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::POSTPROCESS + ogl::tags::BLUR);
      }
      { /* output + deferred + texture */
        pBuilder->setFile("output/deferred.texture.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::OUTPUT + ogl::tags::DEFERRED + ogl::tags::TEXTURE);
      }
      { /* quad + test */
        pBuilder->setFile("quad/test.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::QUAD + ogl::tags::TEST);
      }
      { /* debug + normals */
        pBuilder->setFile("debug/normals.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::DEBUG + ogl::tags::NORMALS);
      }
      { /* debug + normals + deferred */
        pBuilder->setFile("debug/depth.deferred.xml");
        pManager->addProgram(pBuilder->build(), ogl::tags::DEBUG + ogl::tags::DEPTH + ogl::tags::DEFERRED);
      }
      
      _DELETE(pBuilder);
    }
    
    void init_renderers()
    {
      pRenderer = new ogl::CDeferredRenderer(mConfig.mWidth, mConfig.mHeight);
    }
  
    void init_controllers()
    {
      pCameraController = new app::CCameraController;
    }
  };
}

#endif // __app_cogldev45ambientocclusionapp_hpp__
