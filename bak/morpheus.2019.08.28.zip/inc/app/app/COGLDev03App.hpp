#ifndef __cogldev03app_hpp__
#define __cogldev03app_hpp__

namespace app
{
  class COGLDev03App : public CApp
  {
    private:
    ogl::CProgram* pProgram;
    ogl::CObject*  pObject0;
    ogl::CObject*  pObject1;
    app::CCamera*  pCamera;
    
    
    ogl::CDirectLight* pDirectLight;
    ogl::CPointLight*  pPointLights[2];
    ogl::CSpotLight*   pSpotLights[2];
    
    public:
    COGLDev03App()
    {
      sys::info << "app::COGLDev03App::COGLDev03App()" << sys::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "COGLDev03App");
    }
    
    protected:
    void onInit()
    {
      sys::info << "app::COGLDev03App::onInit()" << sys::endl;
      
      pCamera = new app::CCamera(60.0f, mConfig.mRatio, 0.1f, 100.0f);
      pCamera->translateLocal(math::vec3(0.0f, -2.0f, -5.0f));
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      glEnable(GL_CULL_FACE);
      glFrontFace(GL_CW);
      glCullFace(GL_BACK);
      glEnable(GL_DEPTH_TEST);
      glDepthFunc(GL_LEQUAL);
    }
    
    void onDraw(int nTime)
    {
      const float fTime = nTime / 1000.0f;
      sys::info << "app::COGLDev03App::onDraw(" << nTime << ") > " << fTime << sys::endl;
      
      // CApp::exit();
      
      static const GLfloat gray[]  = { 0.1f, 0.1f, 0.1f, 0.0f };
      static const GLfloat ones[]  = { 1.0f };
      glClearBufferfv(GL_COLOR, 0, gray);
      glClearBufferfv(GL_DEPTH, 0, ones);
      glViewport(0, 0, mConfig.mWidth, mConfig.mHeight);
      
      math::mat4 mM;
      //math::mat4 mV = math::lookat(math::vec3(-3.0f, 2.0f, -7.0f), math::vec3(0.0f, 1.0f, 0.0f), math::Y);
      math::mat4 mV = pCamera->getViewMatrix();
      //math::mat4 mP = math::perspective(45.0f, mConfig.mRatio, 0.1f, 100.0f);
      math::mat4 mP = pCamera->getProjectionMatrix();
    
      pProgram->use();
      pProgram->setUniform("u_mP", mP);
      pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
      pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
      pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
      pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
      pProgram->setUniform("u_fSpecularIntensity", 0.5f);
      pProgram->setUniform("u_fSpecularPower",    32.0f);
      pProgram->setUniform("u_fEyePosition",       pCamera->getPosition());
      //pProgram->setUniform("u_fEyePosition",       math::vec3(-3.0f, 2.0f, -7.0f));
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oPointLights[%d].vColor", i);
        pProgram->setUniform(name, pPointLights[i]->mColor);
        snprintf(name, sizeof(name), "u_oPointLights[%d].vPosition", i);
        pProgram->setUniform(name, pPointLights[i]->mPosition);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fAmbientIntensity", i);
        pProgram->setUniform(name, pPointLights[i]->mAmbientIntensity);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fDiffuseIntensity", i);
        pProgram->setUniform(name, pPointLights[i]->mDiffuseIntensity);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK0", i);
        pProgram->setUniform(name, pPointLights[i]->mK0);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK1", i);
        pProgram->setUniform(name, pPointLights[i]->mK1);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK2", i);
        pProgram->setUniform(name, pPointLights[i]->mK2);
      }
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vColor", i);
        pProgram->setUniform(name, pSpotLights[i]->mColor);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vPosition", i);
        pProgram->setUniform(name, pSpotLights[i]->mPosition);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vDirection", i);
        pProgram->setUniform(name, pSpotLights[i]->mDirection);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fCutoff", i);
        pProgram->setUniform(name, pSpotLights[i]->mCutoff);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fAmbientIntensity", i);
        pProgram->setUniform(name, pSpotLights[i]->mAmbientIntensity);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fDiffuseIntensity", i);
        pProgram->setUniform(name, pSpotLights[i]->mDiffuseIntensity);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK0", i);
        pProgram->setUniform(name, pSpotLights[i]->mK0);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK1", i);
        pProgram->setUniform(name, pSpotLights[i]->mK1);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK2", i);
        pProgram->setUniform(name, pSpotLights[i]->mK2);
      }
      
      pProgram->setUniform("u_bWireframe", false);
      
      mM = pObject0->getM();
      pProgram->setUniform("u_mMV", mV * mM);
      pProgram->setUniform("u_mM", mM);
      // pObject0->draw(); // DEPRICATED
      
      mM = pObject1->getM() * math::rotate(fTime * 13.34f, math::Y);
      pProgram->setUniform("u_mMV", mV * mM);
      pProgram->setUniform("u_mM", mM);
      // pObject1->draw(); // DEPRICATED
      
      pProgram->setUniform("u_bWireframe", true); 
      //pObject1->draw(ogl::CObject::EDrawOptions::WIREFRAME);
      
      pProgram->setUniform("u_mMV", mV * pSpotLights[0]->getM());
      pSpotLights[0]->draw();
      pProgram->setUniform("u_mMV", mV * pSpotLights[1]->getM());
      pSpotLights[1]->draw();
      //pProgram->setUniform("u_mMV", mV * pPointLights[1]->getM());
      //pPointLights[1]->draw();
      //pProgram->setUniform("u_mMV", mV * pDirectLight->getM());
      //pDirectLight->draw();
      
      pProgram->unuse();
      
      //CApp::exit();
    }  
    
    void onStop()
    {
      sys::info << "app::COGLDev03App::onStop()" << sys::endl;
      delete pProgram;
      delete pObject0;
      delete pObject1;
      delete pCamera;
      
      delete pDirectLight;
      delete pPointLights[0];
      delete pPointLights[1];
      delete pSpotLights[0];
      delete pSpotLights[1];
    }
    /*
    void onKey(int key, int action)
    {
      CApp::onKey(key, action);
      pCamera->onKey(key, action);
    }
    
    void onMouseButton(int button, int state, int x, int y)
    {
      CApp::onMouseButton(button, state, x, y);
      pCamera->onMouseButton(button, state, x, y);
    }
    
    void onMouseMove(int x, int y)
    {
      CApp::onMouseMove(x, y);
      pCamera->onMouseMove(x, y);
    }
    
    void onMouseDrag(int x, int y)
    {
      CApp::onMouseDrag(x, y);
      pCamera->onMouseDrag(x, y);
    }
    */
    private:
    void init_programs()
    {
      ogl::CFileShaderBuilder* pShaderBuilder = new ogl::CFileShaderBuilder(); 
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("spot_light_01.vs.glsl");  // 
      ogl::CShader* pVShader = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("spot_light_01.fs.glsl");
      ogl::CShader* pFShader = pShaderBuilder->build();
      delete pShaderBuilder;
      
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      pProgramBuilder->addShader(pVShader);
      pProgramBuilder->addShader(pFShader);
      pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
      pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
      
      pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fEyePosition",     new ogl::CUniform(GL_FLOAT_VEC3));
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oPointLights[%d].vColor", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oPointLights[%d].vPosition", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fAmbientIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fDiffuseIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK0", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK1", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK2", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
      }
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vColor", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vPosition", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vDirection", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fCutoff", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fAmbientIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fDiffuseIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK0", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK1", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK2", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
      }
      
      pProgram = pProgramBuilder->build();
      delete pProgramBuilder;
      delete pVShader;
      delete pFShader;
    }
    
    void init_lights()
    {
      pDirectLight = new ogl::CDirectLight;
      pDirectLight->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pDirectLight->mDirection = math::vec3(0.0f, -1.0f, 0.0f);
      pDirectLight->mAmbientIntensity = 0.01f;
      pDirectLight->mDiffuseIntensity = 0.4f;
    
      pPointLights[0] = new ogl::CPointLight;
      pPointLights[1] = new ogl::CPointLight;
      pPointLights[0]->mColor    = math::vec3(0.0f, 0.0f, 0.0f);
      pPointLights[0]->mPosition = math::vec3(-5.0f, 5.0f, 0.0f);
      pPointLights[0]->mAmbientIntensity = 0.0f;
      pPointLights[0]->mDiffuseIntensity = 0.0f;
      pPointLights[0]->mK0 = 0.01f;
      pPointLights[0]->mK1 = 0.0f;
      pPointLights[0]->mK2 = 0.0f;
      pPointLights[1]->mColor    = math::vec3(1.0f, 1.0f, 1.0f);
      pPointLights[1]->mPosition = math::vec3(2.0f, 3.0f, 2.0f);
      pPointLights[1]->mAmbientIntensity = 0.01f;
      pPointLights[1]->mDiffuseIntensity = 0.45f;
      pPointLights[1]->mK0 = 0.0f;
      pPointLights[1]->mK1 = 0.1f;
      pPointLights[1]->mK2 = 0.01f;
      
      pSpotLights[0] = new ogl::CSpotLight;
      pSpotLights[1] = new ogl::CSpotLight;
      pSpotLights[0]->mColor     = math::vec3 (1.0f, 1.0f, 1.0f);
      pSpotLights[0]->mPosition  = math::vec3( 0.0f, 2.0f, 3.0f); // pCamera->getPosition();
      pSpotLights[0]->mDirection = math::vec3(-1.0f,-1.0f, 0.0f); // pCamera->getForward();
      pSpotLights[0]->mCutoff = 0.95f;
      pSpotLights[0]->mAmbientIntensity = 0.0f;
      pSpotLights[0]->mDiffuseIntensity = 0.5f;
      pSpotLights[0]->mK0 = 0.0f;
      pSpotLights[0]->mK1 = 0.03f;
      pSpotLights[0]->mK2 = 0.0f;
      pSpotLights[1]->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pSpotLights[1]->mPosition  = math::vec3(2.0f, 3.0f, 0.0f);
      pSpotLights[1]->mDirection = math::vec3(-1.0f,-1.0f, 0.0f);
      pSpotLights[1]->mCutoff = 0.90f;
      pSpotLights[1]->mAmbientIntensity = 0.01f;
      pSpotLights[1]->mDiffuseIntensity = 0.4f;
      pSpotLights[1]->mK0 = 0.08f;
      pSpotLights[1]->mK1 = 0.02f;
      pSpotLights[1]->mK2 = 0.0f;
    }
    
    void init_textures()
    {
//      ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
//      pTextureBuilder->setFile("notfound.dds");
//      pTexture = pTextureBuilder->build();
//      
//      pTexture->setFiltering(ogl::CTexture::EFiltering::TRILINEAR);
//      pTexture->setWrapping(GL_CLAMP_TO_EDGE);
//      
//      delete pTextureBuilder;
    }
    
    void init_objects()
    {
      {
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        // pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObject0 = pObjectBuilder->build();
        pObject0->setM(math::translate(0.0f, 0.0f, 0.0f));
        delete pObjectBuilder;
      }
//      ogl::CBoxObjectBuilder* pObjectBuilder = new ogl::CBoxObjectBuilder;
//      pObjectBuilder->setWidth(1.0f);
//      pObjectBuilder->setHeight(1.0f);
//      pObjectBuilder->setDepth(1.0f);
//      pObject = pObjectBuilder->build();
//      pObject->setM(math::translate(0.0f, -1.0f, 5.0f) * math::scale(10.0f));
//      delete pObjectBuilder;
      {
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("sphere.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObject1 = pObjectBuilder->build();
        pObject1->setM(math::translate(0.0f, 0.0f, 0.0f));
        delete pObjectBuilder;
      }
    }
  };
}

#endif // __cogldev03app_hpp__
