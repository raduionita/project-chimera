#ifndef __cogldev02app_hpp__
#define __cogldev02app_hpp__

namespace app
{
  class COGLDev02App : public CApp
  {
    private:
    app::CCamera*  pCamera;
    ogl::CProgram* pProgram;
    ogl::CTexture* pTexture;
    ogl::CObject*  pObject;
    
    struct DirectionalLight
    {
      math::vec3 vColor;
      math::vec3 vDirection;
      float fAmbientIntensity;
      float fDiffuseIntensity;
    } oDirectionalLight; 
    
    public:
    COGLDev02App()
    {
      std::cout << "app::COGLDev02App::COGLDev02App()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "COGLDev02App");
    }
    
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev02App::onInit()" << std::endl;
      
      pCamera = new app::CCamera(50.0f, mConfig.mRatio, 0.1f, 100.0f);
      pCamera->setPosition(math::vec3(0.0f, -1.0f, 0.0f));
      
      load_programs();
      
      load_textures();
      
      load_objects();
      
      oDirectionalLight.vColor     = math::vec3(1.0f, 1.0f, 1.0f);
      oDirectionalLight.vDirection = math::vec3(1.0f, 0.0f, 0.0f);
      oDirectionalLight.fAmbientIntensity = 0.20f;
      oDirectionalLight.fDiffuseIntensity = 0.60;
      
      glFrontFace(GL_CCW);
      glCullFace(GL_BACK);
      glEnable(GL_CULL_FACE);
      glEnable(GL_DEPTH_TEST);
      glDepthFunc(GL_LEQUAL);
    }  
    
    void onDraw(int nTime)
    {
      const float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev02App::onDraw(" << nTime << ") > " << fTime << std::endl;
      
      static const GLfloat gray[]  = { 0.1f, 0.1f, 0.1f, 0.0f };
      static const GLfloat ones[]  = { 1.0f };
      glClearBufferfv(GL_COLOR, 0, gray);
      glClearBufferfv(GL_DEPTH, 0, ones);
      
      math::mat4 mM = pObject->getM() *
                      math::rotate(fTime * 13.25f, math::Y);
      math::mat4 mV = pCamera->getViewMatrix();
      math::mat4 mP = pCamera->getProjectionMatrix();
//      math::mat4 mV = math::lookat(math::vec3(0.0f, 1.0f, 0.0f), math::vec3(0.0f, 0.8f, 0.5f), math::Y);
//      math::mat4 mP = math::perspective(60.0f, mConfig.mRatio, 0.1f, 100.0f);
      
      //math::mat4 mMV = math::translate(0.0f, 0.0f, -5.0f) *
      //                 math::rotate(fTime * 13.75f, math::Y);
      
      glViewport(0, 0, mConfig.mWidth, mConfig.mHeight);
      
      pProgram->use();
      pProgram->setUniform("u_fTime", fTime);
      //pProgram->setUniform("u_mM", mM);
      //pProgram->setUniform("u_mMV", mMV);
      pProgram->setUniform("u_mMV", mV * mM);
      pProgram->setUniform("u_mP",  mP);
      pProgram->setUniform("u_bWireframe",  false);
      pProgram->setUniform("u_oDirectLight.vColor",     oDirectionalLight.vColor);
      pProgram->setUniform("u_oDirectLight.vDirection", math::normalize(oDirectionalLight.vDirection));
      pProgram->setUniform("u_oDirectLight.fAmbientIntensity", oDirectionalLight.fAmbientIntensity);
      pProgram->setUniform("u_vEyePos",            pCamera->getPosition());
      pProgram->setUniform("u_fSpecularIntensity", 1.0f);
      pProgram->setUniform("u_fSpecularPower",     64.0f);
      
      pTexture->bind(GL_TEXTURE0);
      
      glEnable(GL_POLYGON_OFFSET_FILL);
      glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
      // pObject->draw(); // DEPRICATED
      
//      pProgram->setUniform("u_bWireframe",  true);
      
      pTexture->unbind();
      
//      glEnable(GL_POLYGON_OFFSET_LINE);
//      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
//      glLineWidth(1.0f);
//      pObject->draw();
//      glDisable(GL_POLYGON_OFFSET_LINE);
      
      pProgram->unuse();
    }  
    
    void onStop()
    {
      std::cout << "app::COGLDev02App::onStop()" << std::endl;
      delete pProgram;
      delete pCamera;
      delete pTexture;
      delete pObject;
    }
    /*
    void onKey(int key, int action)
    {
      CApp::onKey(key, action);
      pCamera->onKey(key, action);
    }
    
    void onMouseButton(int button, int state, int x, int y)
    {
      CApp::onMouseButton(button, state, x, y);
      pCamera->onMouseButton(button, state, x, y);
    }
    
    void onMouseMove(int x, int y)
    {
      CApp::onMouseMove(x, y);
      pCamera->onMouseMove(x, y);
    }
    
    void onMouseDrag(int x, int y)
    {
      CApp::onMouseDrag(x, y);
      pCamera->onMouseDrag(x, y);
    }
    */
    private:
    void load_programs()
    {
      //ogl::CBinaryShaderBuilder pShaderBuilder = new ogl::CBinaryShaderBuilder(); 
      ogl::CFileShaderBuilder* pShaderBuilder = new ogl::CFileShaderBuilder(); 
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("direct_light_01.vs.glsl");
      ogl::CShader* pVShader = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("direct_light_01.fs.glsl");
      ogl::CShader* pFShader = pShaderBuilder->build();
      delete pShaderBuilder;
      
      // ogl::CShaderManager pShaderManager;
      //pShaderManager->addShader(id, pShader);
      
      // pShader = pShaderManager->getShader(id);
      
      //ogl::CBinaryProgramBuilder pProgramBuilder = new ogl::CBinaryProgramBuilder;
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      pProgramBuilder->addShader(pVShader);
      pProgramBuilder->addShader(pFShader);
      pProgramBuilder->addUniform("u_fTime",      new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
      pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_vEyePos",            new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
      pProgram = pProgramBuilder->build();
      delete pProgramBuilder;
      delete pVShader;
      delete pFShader;
      
      //for(auto it = pProgram->getUniforms().begin(); it != pProgram->getUniforms().end(); ++it)
        //std::cout << "> INFO: uniform: " << it->first << std::endl;
      
      // ogl::CProgramManager pProgramManager;
      // pProgramManager->addProgram(pProgram);
      
      // pProgram = pProgramManager->getProgram(id);
    }
    
    void load_textures()
    {
      ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
      pTextureBuilder->setFile("test1.dds");
      pTexture = pTextureBuilder->build();
      
      pTexture->setFiltering(ogl::CTexture::EFiltering::TRILINEAR);
      pTexture->setWrapping(ogl::CTexture::EWrapping::CLAMP_TO_EDGE);
      
      delete pTextureBuilder;
    }
    
    void load_objects()
    {
      ogl::CBoxObjectBuilder* pObjectBuilder = new ogl::CBoxObjectBuilder;
      pObjectBuilder->setWidth(1.0f);
      pObjectBuilder->setHeight(1.0f);
      pObjectBuilder->setDepth(1.0f);
      pObject = pObjectBuilder->build();
      pObject->setM(math::rotate(45.0f, math::Z) * math::translate(0.0f, 0.0f, 4.0f));
      delete pObjectBuilder;
    }
  };
}

#endif // __cogldev02app_hpp__
