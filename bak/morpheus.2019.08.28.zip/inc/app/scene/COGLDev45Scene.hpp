#ifndef __app_cogldev45scene_hpp__
#define __app_cogldev45scene_hpp__

#include "../CScene.hpp"

namespace app
{
  class COGLDev45Scene : public CScene
  {
  
  };
}

#endif // __app_cogldev45scene_hpp__
