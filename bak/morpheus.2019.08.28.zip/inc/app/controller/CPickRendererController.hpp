#ifndef _app_cpickrenderercontroller_hpp__
#define _app_cpickrenderercontroller_hpp__

namespace app
{
  class CPickRendererController : public CController, COnMouseButtonListener
  {
    protected:
    ogl::CPickRenderer* mPickRenderer;
    
    public:
    CPickRendererController(ogl::CPickRenderer* pPickRenderer) : mPickRenderer(pPickRenderer)
    {
    
    }
    
    virtual ~CPickRendererController()
    {
      //@TODO: Needs smart pointer
      //_DELETE(mPickRenderer); 
    }
    
    public:
    void setPickRenderer(ogl::CPickRenderer* pPickRenderer)
    {
      mPickRenderer = pPickRenderer;
    }
    
    ogl::CPickRenderer* getPickRenderer() const
    {
      return mPickRenderer;
    }
    
    public:
    void onMouseButton(CMouseButtonEvent* pEvent)
    {
      if(pEvent->mButton == MOUSE_LEFT && pEvent->mState == MOUSE_PRESS)
      {
        mPickRenderer->setXY(pEvent->mX, pEvent->mY);
      }
    }
  };
}

#endif // _app_cpickrenderercontroller_hpp__
