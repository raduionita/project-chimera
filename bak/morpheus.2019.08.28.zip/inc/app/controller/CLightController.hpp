#ifndef __app_clightcontroller_hpp__
#define __app_clightcontroller_hpp__

namespace app
{
  class CLightController : public CController, COnUpdateListener
  {
    public:
    ogl::CLight* mLight;
    
    CLightController() : CController()
    {
    
    }
    
    CLightController(ogl::CLight* pLight) : CController(), mLight(pLight)
    {
    
    }
    
    virtual ~CLightController()
    {
      //_DELETE(mLight); 
      //@TODO: this requires a smart pointer
    }
    
    public:
    void onUpdate(CUpdateEvent* pEvent)
    {
      switch(mLight->getType())
      {
        default:
        case ogl::CLight::DIRECT:
        {
          //ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(mLight);
          //float fTime = pEvent->mTime;
          
          //math::vec3 vDirection = pDirectLight->getDirection();
          //pDirectLight->setDirection(math::vec3(cosf(fTime), 0.0f, sinf(fTime)));
          
        } break;
        case ogl::CLight::POINT:
        {
        
        } break;
        case ogl::CLight::SPOT:
        {
        
        } break;
      }
    }
  };
}

#endif // __app_clightcontroller_hpp__
