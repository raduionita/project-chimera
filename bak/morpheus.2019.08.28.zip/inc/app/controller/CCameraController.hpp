#ifndef __ccameracontroller_hpp__
#define __ccameracontroller_hpp__

namespace app
{
  class CCameraController : public CController, COnKeyListener, COnMouseDragListener, COnUpdateListener, COnMouseButtonListener
  {
    protected:
    ogl::CCamera* mCamera;
    
    bool mMoveForward;
    bool mMoveBackward;
    bool mMoveLeft;
    bool mMoveRight;
    
    bool mDragging;
    
    float mSpeed;
    
    public:
    CCameraController() 
    : mCamera(nullptr),
      mMoveForward(false), mMoveBackward(false), mMoveLeft(false), mMoveRight(false), mDragging(false), mSpeed(30.0f)
    {
    
    }
    
    CCameraController(ogl::CCamera* pCamera) 
    : mCamera(pCamera),
      mMoveForward(false), mMoveBackward(false), mMoveLeft(false), mMoveRight(false), mDragging(false), mSpeed(30.0f)
    {
    
    }
    
    virtual ~CCameraController()
    {
      //_DELETE(mCamera);
    }
    
    public: 
    ogl::CCamera* getCamera() const
    {
      return mCamera;
    }
    
    void setCamera(ogl::CCamera* pCamera)
    {
      mCamera = pCamera;
    }
    
    void onUpdate(CUpdateEvent* pEvent)
    { 
      sys::info << "app::CCamera::onUpdate() > Camera Position Move" << sys::endl;
      
      // float fTime = pEvent->mTime;
      
      if(mMoveForward)
        mCamera->translateLocal(0.0f, 0.0f, 0.05f);
      if(mMoveBackward)
        mCamera->translateLocal(0.0f, 0.0f,-0.05f);
      if(mMoveLeft)
        mCamera->translateLocal(-0.05f, 0.0f, 0.0f);
      if(mMoveRight)
        mCamera->translateLocal( 0.05f, 0.0f, 0.0f);
    }
    
    void onKey(CKeyEvent* pEvent) // COnKeyListener::onKey(int, int)
    {
      int action = pEvent->mAction;
      int key    = pEvent->mKey;
    
      if(action == KEY_PRESS)
      {
        if(key == KEY_W)
          mMoveForward = true;
        else if(key == KEY_S)
          mMoveBackward = true;
        else if(key == KEY_A)
          mMoveLeft = true;
        else if(key == KEY_D)
          mMoveRight = true;
        else if(KEY_NUM_6)
          mCamera->yaw(-1.0f);
        else if(KEY_NUM_8)
          mCamera->pitch(-1.0f);
        else if(KEY_NUM_2)
          mCamera->pitch(1.0f);
        else if(KEY_NUM_4)
          mCamera->yaw(1.0f);
        else if(KEY_NUM_7)
          mCamera->roll(-1.0f);
        else if(KEY_NUM_9)
          mCamera->roll(1.0f);
        else if(KEY_SHIFT)  
          mSpeed = 5.0f;
          
        mCamera->dirty();
      }
      else if(action == KEY_RELEASE)
      {
        if(key == KEY_W)
          mMoveForward = false;
        else if(key == KEY_S)
          mMoveBackward = false;
        else if(key == KEY_A)
          mMoveLeft = false;
        else if(key == KEY_D)
          mMoveRight = false;
        else if(KEY_SHIFT)  
          mSpeed = 30.0f;
      }
    }
    
    void onMouseButton(CMouseButtonEvent* pEvent)
    {
      if(pEvent->mButton == MOUSE_RIGHT)
      {
        int nWidth  = app::CApp::getConfig().mWidth; 
        int nHeight = app::CApp::getConfig().mHeight; 
        int nMidX = nWidth  / 2;
        int nMidY = nHeight / 2;
        glutWarpPointer(nMidX, nMidY);
        
        if(pEvent->mState == MOUSE_PRESS)
          mDragging = true;
        else
          mDragging = false;
      }
    }
    
    void onMouseDrag(CMouseDragEvent* pEvent)
    {
      if(mDragging == false)
        return;
    
      int x = pEvent->mX;
      int y = pEvent->mY;
    
      int nWidth  = app::CApp::getConfig().mWidth; 
      int nHeight = app::CApp::getConfig().mHeight; 
      int nMidX = nWidth  / 2;
      int nMidY = nHeight / 2;
      
      if(x == nMidX && y == nMidY)
        return;
      
      sys::info << "app::CCameraController::onMouseDrag(" << x << ", " << y << ") > Camera Target Move" << sys::endl;
      
      math::vec2 vDir = math::vec2((float)(nMidX - x), (float)(nMidY - y));
      vDir /= (nWidth / 2);
      vDir *= mSpeed;
      
      mCamera->pitch(-vDir.y);
      //math::vec3 vUp = getUp();
      mCamera->rotate(-vDir.x, math::Y);
      
      glutWarpPointer(nMidX, nMidY);
      
      // CApp::exit();
    }
  };
}

#endif // __ccameracontroller_hpp__
