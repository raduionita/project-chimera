#ifndef __COGLDev04ShadowMapApp_hpp__
#define __COGLDev04ShadowMapApp_hpp__

namespace app
{
  class COGLDev04ShadowMapApp : public CApp
  {
    private:
    ogl::CProgram* pProgramShadow;
    ogl::CProgram* pProgramRender;
    
    ogl::CObject*  pObjectQ;
    ogl::CObject*  pObject1;
    
    app::CCamera*  pCamera;
    
    ogl::CShadowFramebuffer* pShadowFBO;
    
    ogl::CDirectLight* pDirectLight;
    ogl::CPointLight*  pPointLights[2];
    ogl::CSpotLight*   pSpotLights[2];
    
    public:
    COGLDev04ShadowMapApp()
    {
      std::cout << "app::COGLDev04ShadowMapApp::COGLDev04ShadowMapApp()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "COGLDev04ShadowMapApp");
    }
    
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev04ShadowMapApp::onInit()" << std::endl;
      
      pCamera = new app::CCamera(60.0f, mConfig.mRatio, 1.f, 10.0f);
      pCamera->translateLocal(math::vec3(0.0f, -2.0f, -5.0f));
      
      pShadowFBO = new ogl::CShadowFramebuffer(mConfig.mWidth, mConfig.mHeight);
      
      init_programs();
      
      init_lights();
      
      init_textures();
      
      init_objects();
      
      glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      glClearDepthf(1.0f);
      glEnable(GL_CULL_FACE);
      glFrontFace(GL_CW);
      glCullFace(GL_BACK);
      glEnable(GL_DEPTH_TEST);
      //glDepthFunc(GL_LEQUAL);
    }
    
    void onDraw(int nTime)
    {
      draw_shadow_pass(nTime);
      draw_render_pass(nTime);
      
      CApp::exit();
    }
    
    void draw_shadow_pass(int nTime)
    {
      const float fTime = nTime / 1000.0f;
      //new ogl::CRenderer(ERendererOptions::SHADOW_PASS | ERendererOptions::RENDER_PASS);
    
      pShadowFBO->bind(); // bind shadow fbo for write
      
      glClear(GL_DEPTH_BUFFER_BIT);
      
      math::mat4 mM = pObject1->getM() * math::rotate(fTime * 13.34f, math::Y);
      math::mat4 mV = math::lookat(pSpotLights[1]->getPosition(), pSpotLights[1]->getDirection(), math::Y); // pCamera->getViewMatrix();
      math::mat4 mP = math::perspective(60.0f, mConfig.mRatio, 1.0f, 50.0f); // pCamera->getProjectionMatrix();

      pProgramShadow->use();
      pProgramShadow->setUniform("u_mMVP", mP * mV * mM);

      // pObject1->draw(ogl::CObject::EDrawOptions::NOMATERIAL); // DEPRICATED
      
      pProgramShadow->unuse();
    }
    
    void draw_render_pass(int nTime)
    {
      const float fTime = nTime / 1000.0f;
      
      glBindFramebuffer(GL_FRAMEBUFFER, 0);
      
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      math::mat4 mM;
      //math::mat4 mV = math::lookat(math::vec3(-3.0f, 2.0f, -7.0f), math::vec3(0.0f, 1.0f, 0.0f), math::Y);
      math::mat4 mV = pCamera->getViewMatrix();
      //math::mat4 mP = math::perspective(45.0f, mConfig.mRatio, 0.1f, 100.0f);
      math::mat4 mP = pCamera->getProjectionMatrix();
    
      pProgramRender->use();
      pProgramRender->setUniform("u_mP", mP);
      pProgramRender->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
      pProgramRender->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
      pProgramRender->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
      pProgramRender->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
      pProgramRender->setUniform("u_fSpecularIntensity", 0.5f);
      pProgramRender->setUniform("u_fSpecularPower",    32.0f);
      pProgramRender->setUniform("u_fEyePosition",       pCamera->getPosition());
      //pProgramRender->setUniform("u_fEyePosition",       math::vec3(-3.0f, 2.0f, -7.0f));
      
      pShadowFBO->bind(GL_TEXTURE1);
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oPointLights[%d].vColor", i);
        pProgramRender->setUniform(name, pPointLights[i]->mColor);
        snprintf(name, sizeof(name), "u_oPointLights[%d].vPosition", i);
        pProgramRender->setUniform(name, pPointLights[i]->mPosition);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fAmbientIntensity", i);
        pProgramRender->setUniform(name, pPointLights[i]->mAmbientIntensity);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fDiffuseIntensity", i);
        pProgramRender->setUniform(name, pPointLights[i]->mDiffuseIntensity);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK0", i);
        pProgramRender->setUniform(name, pPointLights[i]->mK0);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK1", i);
        pProgramRender->setUniform(name, pPointLights[i]->mK1);
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK2", i);
        pProgramRender->setUniform(name, pPointLights[i]->mK2);
      }
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vColor", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mColor);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vPosition", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mPosition);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vDirection", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mDirection);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fCutoff", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mCutoff);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fAmbientIntensity", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mAmbientIntensity);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fDiffuseIntensity", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mDiffuseIntensity);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK0", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mK0);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK1", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mK1);
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK2", i);
        pProgramRender->setUniform(name, pSpotLights[i]->mK2);
      }
      
      pProgramRender->setUniform("u_bWireframe", false);
      
      math::mat4 mLightM;
      math::mat4 mLightV;
      math::mat4 mLightP;
      
      mM = pObjectQ->getM();
      mLightM = mM;
      mLightV = math::lookat(pSpotLights[1]->getPosition(), pSpotLights[1]->getDirection(), math::Y);
      mLightP = math::perspective(60.0f, mConfig.mRatio, 1.0f, 50.0f);
      
      pProgramRender->setUniform("u_mLightMVP", mLightP* mLightV * mLightM);
      pProgramRender->setUniform("u_mMV", mV * mM);
      pProgramRender->setUniform("u_mM", mM);
      // pObjectQ->draw(); // DEPRICATED
      
      mM = pObject1->getM() * math::rotate(fTime * 13.34f, math::Y);  
      mLightM = mM;
      mLightV = math::lookat(pSpotLights[1]->getPosition(), pSpotLights[1]->getDirection(), math::Y);
      mLightP = math::perspective(60.0f, mConfig.mRatio, 1.0f, 50.0f);
      
      pProgramRender->setUniform("u_mLightMVP", mLightM);
      pProgramRender->setUniform("u_mMV", mV * mM);
      pProgramRender->setUniform("u_mM", mM);
      // pObject1->draw(); // DEPRICATED
      
      pProgramRender->setUniform("u_bWireframe", true); 
      //pObject1->draw(ogl::CObject::EDrawOptions::WIREFRAME);
      
      pProgramRender->setUniform("u_mMV", mV * pSpotLights[0]->getM());
      pSpotLights[0]->draw();
      pProgramRender->setUniform("u_mMV", mV * pSpotLights[1]->getM());
      pSpotLights[1]->draw();
      //pProgramRender->setUniform("u_mMV", mV * pPointLights[1]->getM());
      //pPointLights[1]->draw();
      //pProgramRender->setUniform("u_mMV", mV * pDirectLight->getM());
      //pDirectLight->draw();
      
      pProgramRender->unuse();
    }  
    
    void onStop()
    {
      std::cout << "app::COGLDev04ShadowMapApp::onStop()" << std::endl;
      
      delete pProgramShadow;
      delete pProgramRender;
      
      delete pObjectQ;
      delete pObject1;
      delete pCamera;
      
      delete pDirectLight;
      delete pPointLights[0];
      delete pPointLights[1];
      delete pSpotLights[0];
      delete pSpotLights[1];
      
      delete pShadowFBO;
    }
    /*
    void onKey(int key, int action)
    {
      CApp::onKey(key, action);
      pCamera->onKey(key, action);
    }
    
    void onMouseButton(int button, int state, int x, int y)
    {
      CApp::onMouseButton(button, state, x, y);
      pCamera->onMouseButton(button, state, x, y);
    }
    
    void onMouseMove(int x, int y)
    {
      CApp::onMouseMove(x, y);
      pCamera->onMouseMove(x, y);
    }
    
    void onMouseDrag(int x, int y)
    {
      CApp::onMouseDrag(x, y);
      pCamera->onMouseDrag(x, y);
    }
    */
    private:
    void init_programs()
    {
      ogl::CFileShaderBuilder* pShaderBuilder = new ogl::CFileShaderBuilder(); 
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("shadow_map_01.vs.glsl");
      ogl::CShader* pVShader0 = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("shadow_map_01_shadow.fs.glsl");
      ogl::CShader* pFShader0 = pShaderBuilder->build();
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("spot_light_01.vs.glsl");
      ogl::CShader* pVShader1 = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("spot_light_01.fs.glsl");
      ogl::CShader* pFShader1 = pShaderBuilder->build();
      delete pShaderBuilder;
      
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      pProgramBuilder->addShader(pVShader0);
      pProgramBuilder->addShader(pFShader0);
      pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramShadow = pProgramBuilder->build();
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      pProgramBuilder->addShader(pVShader1);
      pProgramBuilder->addShader(pFShader1);
      pProgramBuilder->addUniform("u_mLightMVP", new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
      pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
      
      pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fEyePosition",     new ogl::CUniform(GL_FLOAT_VEC3));
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oPointLights[%d].vColor", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oPointLights[%d].vPosition", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fAmbientIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fDiffuseIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK0", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK1", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK2", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
      }
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vColor", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vPosition", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vDirection", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fCutoff", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fAmbientIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fDiffuseIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK0", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK1", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK2", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
      }
      pProgramRender = pProgramBuilder->build();
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      delete pProgramBuilder;
      delete pVShader0;
      delete pFShader0;
      delete pVShader1;
      delete pFShader1;
    
    
      //vs1 = new ogl::CShader(GL_VERTEX_SHADER,   ogl::CGlslShaderLoader("path/to/shader.glsl"));
      //gs3 = new ogl::CShader(GL_GEOMETRY_SHADER, ogl::CBinShaderLoader("path/to/shader.glsl"));  
      //fs2 = new ogl::CShader(GL_FRAGMENT_SHADER, ogl::CBinShaderLoader("path/to/shader.glsl"));
      //pProgram1 = new ogl::CProgram({ vs1, gs3, fs2 });
      //pProgram1->addUniform("u_mMVP");
      //pProgram1->setUniform("u_mMVP", mMVP);
      //pProgram2 = new ogl::CProgram(ogl::CBinProgramLoader("path/to/binary.prog"));
      //pPipeline = new ogl::CPipeline({ pProgram1, pProgram2 });
      //pProgramManager->addProgram(id, pProgram1);
    }
    
    void init_lights()
    {
      pDirectLight = new ogl::CDirectLight;
      pDirectLight->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pDirectLight->mDirection = math::vec3(0.0f, -1.0f, 0.0f);
      pDirectLight->mAmbientIntensity = 0.01f;
      pDirectLight->mDiffuseIntensity = 0.4f;
    
      pPointLights[0] = new ogl::CPointLight;
      pPointLights[1] = new ogl::CPointLight;
      pPointLights[0]->mColor    = math::vec3(0.0f, 0.0f, 0.0f);
      pPointLights[0]->mPosition = math::vec3(-5.0f, 5.0f, 0.0f);
      pPointLights[0]->mAmbientIntensity = 0.0f;
      pPointLights[0]->mDiffuseIntensity = 0.0f;
      pPointLights[0]->mK0 = 0.01f;
      pPointLights[0]->mK1 = 0.0f;
      pPointLights[0]->mK2 = 0.0f;
      pPointLights[1]->mColor    = math::vec3(1.0f, 1.0f, 1.0f);
      pPointLights[1]->mPosition = math::vec3(2.0f, 3.0f, 2.0f);
      pPointLights[1]->mAmbientIntensity = 0.01f;
      pPointLights[1]->mDiffuseIntensity = 0.45f;
      pPointLights[1]->mK0 = 0.0f;
      pPointLights[1]->mK1 = 0.1f;
      pPointLights[1]->mK2 = 0.01f;
      
      pSpotLights[0] = new ogl::CSpotLight;
      pSpotLights[1] = new ogl::CSpotLight;
      pSpotLights[0]->mColor     = math::vec3 (1.0f, 1.0f, 1.0f);
      pSpotLights[0]->mPosition  = math::vec3( 0.0f, 2.0f, 3.0f); // pCamera->getPosition();
      pSpotLights[0]->mDirection = math::vec3(-1.0f,-1.0f, 0.0f); // pCamera->getForward();
      pSpotLights[0]->mCutoff = 0.95f;
      pSpotLights[0]->mAmbientIntensity = 0.0f;
      pSpotLights[0]->mDiffuseIntensity = 0.5f;
      pSpotLights[0]->mK0 = 0.0f;
      pSpotLights[0]->mK1 = 0.03f;
      pSpotLights[0]->mK2 = 0.0f;
      pSpotLights[1]->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pSpotLights[1]->mPosition  = math::vec3(3.0f, 3.0f, 0.0f);
      pSpotLights[1]->mDirection = math::vec3(-1.0f,-1.0f, 0.0f);
      pSpotLights[1]->mCutoff = 0.90f;
      pSpotLights[1]->mAmbientIntensity = 0.01f;
      pSpotLights[1]->mDiffuseIntensity = 0.4f;
      pSpotLights[1]->mK0 = 0.08f;
      pSpotLights[1]->mK1 = 0.02f;
      pSpotLights[1]->mK2 = 0.0f;
    }
    
    void init_textures()
    {
      ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
      pTextureBuilder->setFile("skybox/planet.dds");
      ogl::CTexture* pTexture = pTextureBuilder->build();
      
      pTexture->setFiltering(ogl::CTexture::EFiltering::TRILINEAR);
      pTexture->setWrapping(ogl::CTexture::EWrapping::CLAMP_TO_EDGE);
      
      delete pTextureBuilder;
      delete pTexture;
    }
    
    void init_objects()
    {
      {
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(1);
        // pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectQ = pObjectBuilder->build();
        pObjectQ->setM(math::translate(0.0f, 0.0f, 0.0f));
        delete pObjectBuilder;
      }
//      ogl::CBoxObjectBuilder* pObjectBuilder = new ogl::CBoxObjectBuilder;
//      pObjectBuilder->setWidth(1.0f);
//      pObjectBuilder->setHeight(1.0f);
//      pObjectBuilder->setDepth(1.0f);
//      pObject = pObjectBuilder->build();
//      pObject->setM(math::translate(0.0f, -1.0f, 5.0f) * math::scale(10.0f));
//      delete pObjectBuilder;
      {
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("sphere.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObject1 = pObjectBuilder->build();
        pObject1->setM(math::translate(0.0f, 0.0f, 0.0f));
        delete pObjectBuilder;
      }
    }
  };
}

#endif // __COGLDev04ShadowMapApp_hpp__
