#ifndef CAPP_HPP_
#define CAPP_HPP_

#include <cstdio>
#include <cstdarg>
#include <exception>

namespace app
{
  class CApp;

  app::CApp*  APP                  = nullptr;

  class CApp : public COnResizeListener, COnErrorListener, COnKeyListener, COnMouseButtonListener, COnMouseMoveListener, COnMouseDragListener
  {
    protected:
    typedef struct {                       // app/window config
      char   mTitle[128];
      float  mTimer;
      int    mWidth;
      int    mHeight;
      int    mBBP;
      float  mRatio;
      int    mFPS;
      bool   mFullscreen;
      struct {
        uint mMode;
        int  mContext;
        int  mMinor;
        int  mMajor;
        int  mMultisample;
      }      mOpenGL;
    } config_t;

    protected:
    config_t     mConfig;
    bool         mPaused;
    
    public:
    CApp()
    {
      sys::info << "app::CApp::CApp()" << sys::endl;
      
      mPaused = false;
      
      mConfig.mWidth      = 1024;
      mConfig.mHeight     = 768;
      mConfig.mBBP        = 32;
      mConfig.mRatio      = (float) mConfig.mWidth / (float) mConfig.mHeight;
      mConfig.mFPS        = 60;
      mConfig.mTimer      = 10.0f;
      mConfig.mFullscreen = false;
      mConfig.mOpenGL.mMode        = GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH;
      mConfig.mOpenGL.mContext     = GLUT_CORE_PROFILE | GLUT_DEBUG;
      mConfig.mOpenGL.mMajor       = 3;
      mConfig.mOpenGL.mMinor       = 3;
      mConfig.mOpenGL.mMultisample = 0;
      strcpy(mConfig.mTitle, "N/A");
    }
    
    virtual ~CApp()
    {
      sys::info << "app::CApp::~CApp()" << sys::endl;
    }
  
    public:
    void run(int argc, char** argv)
    {
      sys::info << "app::CApp::run(" << argc << ", \"" << *argv << "\")" << sys::endl;
      
      // glutInitContextFlags()
      // GLUT_RGBA - default
      // GLUT_INDEX - overrides GLUT_RGBA - select color index mode
      // GLUT_SINGLE - single bufferd
      // GLUT_DOUBLE - double buffered
      // GLUT_ACCUM - w/ accumulation buffer
      // GLUT_ALPHA - w/ alpha component to the color buffer
      // GLUT_DEPTH - w/ depth buffer
      // GLUT_STENCIL - w/ stencil buffer
      // GLUT_MULTISAMPLE - w/ multisampling support
      // GLUT_STEREO - to select a stereo window
      // GLUT_LUMINANCE - 'luminance' color model
      
      mConfig.mOpenGL.mContext |= GLUT_STENCIL;
      mConfig.mOpenGL.mContext |= GLUT_DEPTH;
      
      if(mConfig.mOpenGL.mMultisample)
        mConfig.mOpenGL.mContext |= GLUT_MULTISAMPLE;
      
      glutInit(&argc, argv);
      glutInitDisplayMode(mConfig.mOpenGL.mMode);
      glutInitContextVersion(mConfig.mOpenGL.mMajor, mConfig.mOpenGL.mMinor);
      glutInitContextFlags(mConfig.mOpenGL.mContext);
      glutInitWindowPosition(0, 0);
      glutInitWindowSize(mConfig.mWidth, mConfig.mHeight);
      glutInitErrorFunc(_onError);
      glutInitWarningFunc(_onWarning);
      
      int win = glutCreateWindow(mConfig.mTitle); // glutSetWindowTitle("title")
      
      if(ogl_LoadFunctions() == ogl_LOAD_FAILED)
      {
        sys::info << "app::CApp::run() > Failed to load glLoad" << sys::endl;
        glutDestroyWindow(win);
        return;
      }
      
      sys::info << "app::CApp::run() > Vendor    : " << ((char*)glGetString(GL_VENDOR))   << sys::endl;
      sys::info << "app::CApp::run() > Version   : " << ((char*)glGetString(GL_VERSION))  << sys::endl;
      sys::info << "app::CApp::run() > Renderer  : " << ((char*)glGetString(GL_RENDERER)) << sys::endl;
      sys::info << "app::CApp::run() > GLSL      : " << ((char*)glGetString(GL_SHADING_LANGUAGE_VERSION)) << sys::endl;
      
      if(mConfig.mFullscreen)
      {
        glutGameModeString("1024x768:32");
        if(glutGameModeGet(GLUT_GAME_MODE_POSSIBLE))
          glutEnterGameMode();
        else
          return;
      }
      
      glutReshapeFunc(_onResize);
      glutDisplayFunc(_onDraw);
      glutKeyboardFunc(_onKeyDown);
      glutKeyboardUpFunc(_onKeyUp);
      glutMouseFunc(_onMouseButton);
      glutMotionFunc(_onMouseDrag);
      glutPassiveMotionFunc(_onMouseMove);
      glutIdleFunc(_onIdle);                                       // called when events are not being received
      //glutCloseFunc(_onStop);
      
      // glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, ?);
      // GLUT_ACTION_EXIT                                          // exit immediately (default)
      // GLUT_ACTION_GLUTMAINLOOP_RETURNS                          // return from the main loop
      // GLUT_ACTION_CONTINUE_EXECUTION                            // continue execution of the remaining windows
      
      glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
      if(mConfig.mOpenGL.mMultisample)
        glutSetOption(GLUT_MULTISAMPLE, mConfig.mOpenGL.mMultisample);
      
      try {
        onInit();
        glutMainLoop();                                           // enters event processing loop
        onStop();
      } catch(std::exception& e) {
        onError(new CErrorEvent(e.what(), ERROR_SYSTEM));
      }
      
      if(mConfig.mFullscreen)
        glutLeaveFullScreen();
      
      // glBitmapString(GLUT_BITMAP_HELVETICA_12, "string");      // draw string on window
      
      // glutDestroyWindow(win);
    }
    
    protected:
    virtual void onInit() = 0;
    
    virtual void onDraw(int nTime) = 0;
    
    virtual void onStop() = 0;
    
    virtual void onIdle()
    {
      dirty();
    }
    
    virtual void onExit()
    {
      onStop();
      exit();
    }
    
    void dirty()
    {
      if(!mPaused)
        glutPostRedisplay();
    }
    
    void error(const char* formated, ...)
    {
      va_list vl;
      va_start(vl, formated);
      fprintf(stderr, "ERROR: ");
      vfprintf(stderr, formated, vl);
      fprintf(stderr, "\n");
      va_end(vl);
      APP->onError(new CErrorEvent(formated, ERROR_OPENGL));
    }
    
    virtual void onError(CErrorEvent* pEvent)
    {
      sys::error << sys::endl << "FATAL: " << pEvent->mMessage << sys::endl << sys::endl;
      onStop();
      ::exit(-1);
    }
    
    virtual void onResize(CResizeEvent* pEvent)
    { 
      mConfig.mWidth  = pEvent->mWidth;
      mConfig.mHeight = pEvent->mHeight;
      glViewport(0, 0, pEvent->mWidth, pEvent->mHeight);
    }
    
    virtual void onKey(CKeyEvent* pEvent)
    {
      if(pEvent->mKey == KEY_ESC && pEvent->mAction == KEY_PRESS)
        exit();
      else if(pEvent->mKey == KEY_SPACEBAR && pEvent->mAction == KEY_PRESS) 
        pause();
    }
    
    virtual void onMouseButton(CMouseButtonEvent* pEvent)
    {
      sys::info << "app::CApp::onMouseButton(" << pEvent->mButton << ", " << pEvent->mState << ", " << pEvent->mX << ", " << pEvent->mY << ")" << sys::endl;
    }
    
    virtual void onMouseDrag(CMouseDragEvent* pEvent)
    {
      sys::info << "app::CApp::onMouseDrag(" << pEvent->mX << ", " << pEvent->mY << ")" << sys::endl;
    }
    
    virtual void onMouseMove(CMouseMoveEvent* pEvent)
    {
      sys::info << "app::CApp::onMouseMove(" << pEvent->mX << ", " << pEvent->mY << ")" << sys::endl;
    }
  
    public:
   /**
    * Return elapsed time in milliseconds
    * @return int milliseconds
    * ************************ */
    static int getTime()
    {
      return glutGet(GLUT_ELAPSED_TIME);
    }
    
    static float getTimef()
    {
      return (float)(glutGet(GLUT_ELAPSED_TIME)) / 1000.0f;
    }
    
    static config_t getConfig()
    {
      return APP->mConfig;
    }
    
    static void pause()
    {
      APP->mPaused = !APP->mPaused;
    }
    
    static void exit()
    {
      glutLeaveMainLoop();
    }
    
    protected:
    static void _onIdle()
    {
      APP->onIdle();
    }
    
    static void _onDraw()
    {
      try {
        APP->onDraw(getTime());
        glutSwapBuffers();
      } catch(std::exception& e) {
        APP->onError(new CErrorEvent(e.what(), ERROR_SYSTEM));
      }
    }
    
    static void _onStop() // called at the end of draw if exit has been triggered
    {
      APP->onStop();
    }
    
    static void _onError(const char* formated, va_list vl)
    {
      //va_start(vl, formated);
      //fprintf(stderr, "ERROR: ");
      //vfprintf(stderr, formated, vl);
      char message[256];
      vsprintf(message, formated, vl);
      //fprintf(stderr, "\n");
      //va_end(vl);
      
      CEventManager::getInstance()->trigger(new CErrorEvent(message, ERROR_OPENGL));
      //APP->onError(message);
    }
    
    static void _onWarning(const char* formated, va_list vl)
    {
      //va_start(vl, formated);
      fprintf(stderr, "WARNING: ");
      vfprintf(stderr, formated, vl);
      fprintf(stderr, "\n");
      //va_end(vl);
      //APP->onError(formated);
    }
    
    static void _onResize(int width, int height)
    {
      CEventManager::getInstance()->trigger(new CResizeEvent(width, height));
      //APP->onResize(width, height);
    }
  
    static void _onKeyDown(unsigned char key, int x, int y)
    {
      CEventManager::getInstance()->trigger(new CKeyEvent((int)(key), KEY_PRESS));
      //APP->onKey(key, KEY_PRESS);
    }  
    
    static void _onKeyUp(unsigned char key, int x, int y)
    {
      CEventManager::getInstance()->trigger(new CKeyEvent((int)(key), KEY_RELEASE));
      //APP->onKey(key, KEY_RELEASE);
    }
  
    static void _onMouseButton(int button, int state, int x, int y)
    {
      CEventManager::getInstance()->trigger(new CMouseButtonEvent(button, state, x, y));
      //APP->onMouseButton(button, state, x, y);
    }
    
    static void _onMouseDrag(int x, int y)
    {
      CEventManager::getInstance()->trigger(new CMouseDragEvent(x, y));
      //APP->onMouseDrag(x, y);
    }
    
    static void _onMouseMove(int x, int y)
    {
      CEventManager::getInstance()->trigger(new CMouseMoveEvent(x, y));
      //APP->onMouseMove(x, y);
    }
  };
}

#endif /* CAPP_HPP_ */
