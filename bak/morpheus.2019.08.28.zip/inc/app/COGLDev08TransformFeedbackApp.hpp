#ifndef __COGLDEV08TRANSFORMFEEDBACKAPP_HPP__
#define __COGLDEV08TRANSFORMFEEDBACKAPP_HPP__

namespace app
{
  class COGLDev08TransformFeedbackApp : public CApp
  {
    protected:
    ogl::CProgram* pProgramBillboard;
    ogl::CProgram* pProgramSkybox;
    ogl::CProgram* pProgramRender;
    ogl::CProgram* pProgramShadow;
    
    ogl::CObject*  pObjectB;
    ogl::CObject*  pObjectP;
    ogl::CObject*  pObject1;
    ogl::CObject*  pObjectS;
    
    app::CCamera*  pCamera;
    
    ogl::CTexture* pNormalTexture;
    
    ogl::CShadowFramebuffer* pShadowFBO;
    
    ogl::CDirectLight* pDirectLight;
    ogl::CPointLight*  pPointLights[2];
    ogl::CSpotLight*   pSpotLights[2];
    
    ogl::CParticleSystem* pParticleSystem;
    
    int nPrevTime;
    
    public:
    COGLDev08TransformFeedbackApp()
    {
      std::cout << "app::COGLDev08TransformFeedbackApp::COGLDev08TransformFeedbackApp()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "COGLDev08TransformFeedbackApp");
    }
    
    protected:
    void onInit()
    {
      nPrevTime = getTime();
      std::cout << "app::COGLDev08TransformFeedbackApp::onInit() > " << nPrevTime << std::endl;
      
      pCamera = new app::CCamera(60.0f, mConfig.mRatio, 0.1f, 100.0f);
      pCamera->translateLocal(math::vec3(0.0f, -2.0f, -5.0f));
      
      pShadowFBO = new ogl::CShadowFramebuffer(mConfig.mWidth, mConfig.mHeight);
      
      init_programs();
      
      init_lights();
      
      init_textures();
      
      init_objects();
      
      init_particle_system();
      
      glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      glClearDepthf(1.0f);
      glEnable(GL_CULL_FACE);
      glFrontFace(GL_CW);
      glCullFace(GL_BACK);
      glEnable(GL_DEPTH_TEST);
      glDepthFunc(GL_LEQUAL);
    }
    
    void onDraw(int nCurrTime)
    {
      std::cout << "app::COGLDev08TransformFeedbackApp::onDraw(time) > " << nCurrTime << std::endl;
      const int nDiffTIme = nCurrTime - nPrevTime;
      nPrevTime = nCurrTime;
      
      glBindFramebuffer(GL_FRAMEBUFFER, 0);
    
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      math::mat4 mM;
      math::mat4 mV;
      math::mat4 mP;
      
      mM = pObjectP->getM();
      mV = pCamera->getViewMatrix();
      mP = pCamera->getProjectionMatrix();
      
      pProgramRender->enable();    // ::enable() ::disable()
      pProgramRender->setUniform("u_mM",  mM);
      pProgramRender->setUniform("u_mMV", mV * mM);
      pProgramRender->setUniform("u_mP",  mP);
      pProgramRender->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
      pProgramRender->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
      pProgramRender->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
      pProgramRender->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
      pProgramRender->setUniform("u_fSpecularIntensity",             0.0f);
      pProgramRender->setUniform("u_fSpecularPower",                 0.0f);
      pProgramRender->setUniform("u_fEyePosition",                   pCamera->getPosition());
      pProgramRender->setUniform("u_nOptions",                       (USE_DIFFUSE_MAP | USE_SHADOW_MAP)); // @TODO: doesn't work !?
      pProgramRender->setUniform("u_bWireframe",                     false);
      // pObjectP->draw(); // DEPRICATED
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      GLint prevCullFace;
      glGetIntegerv(GL_CULL_FACE_MODE, &prevCullFace);
      GLint prevDepthFunc;
      glGetIntegerv(GL_DEPTH_FUNC, &prevDepthFunc);
      
      glCullFace(GL_FRONT);
      glDepthFunc(GL_LEQUAL);
      
      pProgramSkybox->enable();
      mM = math::translate(pCamera->getPosition()) * pObjectS->getM();
      mV = pCamera->getViewMatrix();
      mP = pCamera->getProjectionMatrix();
      pProgramSkybox->setUniform("u_mMVP", mP * mV * mM);
      // pObjectS->draw(); // DEPRICATED
      
      glCullFace(prevCullFace);
      glDepthFunc(prevDepthFunc);
      
      glDisable(GL_BLEND);
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
      //glBlendColor(1.0f, 0.0f, 0.0f, 0.5f);
      
      pParticleSystem->setViewMatrix(pCamera->getViewMatrix());
      pParticleSystem->setProjectionMatrix(pCamera->getProjectionMatrix());
      pParticleSystem->setCameraPosition(pCamera->getPosition());
      pParticleSystem->draw(nDiffTIme);

      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      // CApp::exit();
    }
    
    void onStop()
    {
      std::cout << "app::COGLDev08TransformFeedbackApp::onStop()" << std::endl;
      
      _DELETE(pProgramBillboard);
      _DELETE(pProgramSkybox);
      _DELETE(pProgramShadow);
      _DELETE(pProgramRender);
      
      _DELETE(pObjectB);
      _DELETE(pObjectP);
      _DELETE(pObject1);
      _DELETE(pObjectS);
      _DELETE(pCamera);
      
      _DELETE(pDirectLight);
      _DELETE(pPointLights[0]);
      _DELETE(pPointLights[1]);
      _DELETE(pSpotLights[0]);
      _DELETE(pSpotLights[1]);
      
      _DELETE(pParticleSystem);
    }
    /*
    void onKey(int key, int action)
    {
      CApp::onKey(key, action);
      pCamera->onKey(key, action);
    }
    
    void onMouseButton(int button, int state, int x, int y)
    {
      CApp::onMouseButton(button, state, x, y);
      pCamera->onMouseButton(button, state, x, y);
    }
    
    void onMouseMove(int x, int y)
    {
      CApp::onMouseMove(x, y);
      pCamera->onMouseMove(x, y);
    }
    
    void onMouseDrag(int x, int y)
    {
      CApp::onMouseDrag(x, y);
      pCamera->onMouseDrag(x, y);
    }
    */
    private:
    void init_programs()
    {
      ogl::CFileShaderBuilder* pShaderBuilder = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      
      ogl::CShader* pVShader;
      ogl::CShader* pGShader;
      ogl::CShader* pFShader;
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("billboard_01.vs.glsl");
      pVShader = pShaderBuilder->build();
      pShaderBuilder->setType(GL_GEOMETRY_SHADER);
      pShaderBuilder->setFile("billboard_01.gs.glsl");
      pGShader = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("billboard_01.fs.glsl");
      pFShader = pShaderBuilder->build();
      
      pProgramBuilder->addShader(pVShader);
      pProgramBuilder->addShader(pGShader);
      pProgramBuilder->addShader(pFShader);
      pProgramBuilder->addUniform("u_mVP",             new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_vCameraPosition", new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBillboard = pProgramBuilder->build();
      
      delete pVShader; delete pGShader; delete pFShader;
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("skybox_01.vs.glsl");
      pVShader = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("skybox_01.fs.glsl");
      pFShader = pShaderBuilder->build();
      
      pProgramBuilder->addShader(pVShader);
      pProgramBuilder->addShader(pFShader);
      pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramSkybox = pProgramBuilder->build();
      
      delete pVShader; delete pFShader; 
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("shadow_map_01.vs.glsl");
      pVShader = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("shadow_map_01_shadow.fs.glsl");
      pFShader = pShaderBuilder->build();
      
      pProgramBuilder->addShader(pVShader);
      pProgramBuilder->addShader(pFShader);
      pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramShadow = pProgramBuilder->build();
      
      delete pVShader; delete pFShader; 
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      pShaderBuilder->setType(GL_VERTEX_SHADER);
      pShaderBuilder->setFile("lighting_01.vs.glsl");
      pVShader = pShaderBuilder->build();
      pShaderBuilder->setType(GL_FRAGMENT_SHADER);
      pShaderBuilder->setFile("lighting_01.fs.glsl");
      pFShader = pShaderBuilder->build();
      
      pProgramBuilder->addShader(pVShader);
      pProgramBuilder->addShader(pFShader);
      pProgramBuilder->addUniform("u_mLightMVP",  new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
      pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
      pProgramBuilder->addUniform("u_nOptions",   new ogl::CUniform(GL_UNSIGNED_INT));
      
      pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
      pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
      pProgramBuilder->addUniform("u_fEyePosition",       new ogl::CUniform(GL_FLOAT_VEC3));
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oPointLights[%d].vColor", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oPointLights[%d].vPosition", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fAmbientIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fDiffuseIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK0", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK1", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oPointLights[%d].fK2", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
      }
      
      for(size_t i = 0; i < 2; i++)
      {
        char name[128];
        memset(name, 0, sizeof(name));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vColor", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vPosition", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].vDirection", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fCutoff", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fAmbientIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fDiffuseIntensity", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK0", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK1", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        snprintf(name, sizeof(name), "u_oSpotLights[%d].fK2", i);
        pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
      }
      pProgramRender = pProgramBuilder->build();
      
      delete pVShader; delete pFShader; 
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      delete pShaderBuilder;
      delete pProgramBuilder;
    }
    
    void init_lights()
    {
      pDirectLight = new ogl::CDirectLight;
      pDirectLight->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pDirectLight->mDirection = math::vec3(-1.0f, -1.0f, 0.0f);
      pDirectLight->mAmbientIntensity = 0.025f;
      pDirectLight->mDiffuseIntensity = 0.6f;
    
      pPointLights[0] = new ogl::CPointLight;
      pPointLights[1] = new ogl::CPointLight;
      pPointLights[0]->mColor    = math::vec3(0.0f, 0.0f, 0.0f);
      pPointLights[0]->mPosition = math::vec3(-5.0f, 5.0f, 0.0f);
      pPointLights[0]->mAmbientIntensity = 0.0f;
      pPointLights[0]->mDiffuseIntensity = 0.0f;
      pPointLights[0]->mK0 = 0.01f;
      pPointLights[0]->mK1 = 0.0f;
      pPointLights[0]->mK2 = 0.0f;
      pPointLights[1]->mColor    = math::vec3(1.0f, 1.0f, 1.0f);
      pPointLights[1]->mPosition = math::vec3(2.0f, 3.0f, 2.0f);
      pPointLights[1]->mAmbientIntensity = 0.01f;
      pPointLights[1]->mDiffuseIntensity = 0.45f;
      pPointLights[1]->mK0 = 0.0f;
      pPointLights[1]->mK1 = 0.1f;
      pPointLights[1]->mK2 = 0.01f;
      
      pSpotLights[0] = new ogl::CSpotLight;
      pSpotLights[1] = new ogl::CSpotLight;
      pSpotLights[0]->mColor     = math::vec3 (1.0f, 1.0f, 1.0f);
      pSpotLights[0]->mPosition  = math::vec3( 0.0f, 2.0f, 3.0f); // pCamera->getPosition();
      pSpotLights[0]->mDirection = math::vec3(-1.0f,-1.0f, 0.0f); // pCamera->getForward();
      pSpotLights[0]->mCutoff = 0.95f;
      pSpotLights[0]->mAmbientIntensity = 0.0f;
      pSpotLights[0]->mDiffuseIntensity = 0.5f;
      pSpotLights[0]->mK0 = 0.0f;
      pSpotLights[0]->mK1 = 0.03f;
      pSpotLights[0]->mK2 = 0.0f;
      pSpotLights[1]->mColor     = math::vec3(1.0f, 1.0f, 1.0f);
      pSpotLights[1]->mPosition  = math::vec3(3.0f, 3.0f, 0.0f);
      pSpotLights[1]->mDirection = math::vec3(-1.0f,-1.0f, 0.0f);
      pSpotLights[1]->mCutoff = 0.90f;
      pSpotLights[1]->mAmbientIntensity = 0.01f;
      pSpotLights[1]->mDiffuseIntensity = 0.4f;
      pSpotLights[1]->mK0 = 0.08f;
      pSpotLights[1]->mK1 = 0.02f;
      pSpotLights[1]->mK2 = 0.0f;
    }
  
    void init_textures()
    {
      {
//        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
//        pTextureBuilder->setFile("box/bricks_n.dds");
//        pNormalTexture = pTextureBuilder->build();
//        
//        pNormalTexture->setFiltering(ogl::CTexture::EFiltering::TRILINEAR);
//        //pNormalTexture->setWrapping(GL_CLAMP_TO_EDGE);
//        
//        delete pTextureBuilder;
      }
    }
    
    void init_objects()
    {
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
        pTextureBuilder->setFile("wall/bricks_d.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        pTextureBuilder->setFile("wall/bricks_n.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::NORMALS, pTextureBuilder->build());
        
        
        delete pObjectBuilder;
      }
      { // box from box-builder
//        ogl::CBoxObjectBuilder* pObjectBuilder = new ogl::CBoxObjectBuilder;
//        pObjectBuilder->setWidth(1.0f);
//        pObjectBuilder->setHeight(1.0f);
//        pObjectBuilder->setDepth(1.0f);
//        pObject = pObjectBuilder->build();
//        pObject->setM(math::translate(0.0f, -1.0f, 5.0f) * math::scale(10.0f));
//        delete pObjectBuilder;
      }
      { // random mesh
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("box/box.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObject1 = pObjectBuilder->build();
        pObject1->setM(math::translate(0.0f, 0.0f, 2.0f));
        delete pObjectBuilder;
      }
      { // skybox
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("skybox/skydome.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObjectS = pObjectBuilder->build();
        pObjectS->setM(math::scale(20.0f));
        delete pObjectBuilder;
      }
      { // billboarding
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(18.0f);
        pObjectBuilder->setHeight(18.0f);
        pObjectBuilder->setSubdivisions(6);
        // pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectB = pObjectBuilder->build();
        delete pObjectBuilder;
        
        ogl::CPngTextureBuilder* pTextureBuilder = new ogl::CPngTextureBuilder;
        pTextureBuilder->setFile("monster.png");
        ogl::CTexture* pTexture = pTextureBuilder->build();
        pTexture->setWrapping(ogl::CTexture::EWrapping::CLAMP_TO_BORDER);
        delete pTextureBuilder;
        
        ogl::CMaterial* pMaterial = new ogl::CMaterial;
        pMaterial->setTexture(ogl::CTexture::EScope::DIFFUSE, pTexture);
        
        pObjectB->setMode(GL_POINTS);
        pObjectB->getShape(0)->setMaterial(pMaterial);
      }
    }
  
    void init_particle_system()
    {
      ogl::CTexture* pRandomTexture ;
      ogl::CTexture* pDiffuseTexture;
      {
        ogl::CRandomTextureBuilder* pTextureBuilder = new ogl::CRandomTextureBuilder;
        pTextureBuilder->setWidth(1000);
        pTextureBuilder->setTarget(GL_TEXTURE_1D);
        pRandomTexture = pTextureBuilder->build();
        _DELETE(pTextureBuilder);
      }
      {
        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
        pTextureBuilder->setFile("effects/alienrain.dds");
        pDiffuseTexture = pTextureBuilder->build();
        _DELETE(pTextureBuilder);
      }
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      ogl::CFileShaderBuilder*    pShaderBuilder  = new ogl::CFileShaderBuilder;
      ogl::CProgram* pUpdateProgram;
      ogl::CProgram* pRenderProgram;
      ogl::CShader* pVShader, * pGShader, * pFShader;
      {
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("particle_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_GEOMETRY_SHADER);
        pShaderBuilder->setFile("particle_01.gs.glsl");
        pGShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pGShader);
        
        pProgramBuilder->addVarying("v_fType");
        pProgramBuilder->addVarying("v_vPosition");
        pProgramBuilder->addVarying("v_vVelocity");
        pProgramBuilder->addVarying("v_fAge");
        
        pProgramBuilder->addUniform("u_fLauncherLifetime",  new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fPrimaryLifetime",   new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSecondaryLifetime", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fTertiaryLifetime",  new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fTime",              new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fDeltaTime",         new ogl::CUniform(GL_FLOAT));
        pUpdateProgram = pProgramBuilder->build();
        
        _DELETE(pVShader); _DELETE(pGShader);
      }
      {
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("billboard_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_GEOMETRY_SHADER);
        pShaderBuilder->setFile("billboard_01.gs.glsl");
        pGShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("billboard_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pGShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mVP",             new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_vCameraPosition", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_fBillboardSize",  new ogl::CUniform(GL_FLOAT));
        pRenderProgram = pProgramBuilder->build();
        
        _DELETE(pVShader); _DELETE(pGShader); _DELETE(pFShader); 
      }
      _DELETE(pShaderBuilder);
      _DELETE(pProgramBuilder);
      
      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
      pParticleSystem = new ogl::CParticleSystem;           //@TODO: COnInit* ogl::init(COnInit* pObject)
      pParticleSystem->setNumParticles(1000);
      pParticleSystem->setUpdateProgram(pUpdateProgram);
      pParticleSystem->setRenderProgram(pRenderProgram);
      pParticleSystem->setRandomTexture(pRandomTexture);
      pParticleSystem->setDiffuseTexture(pDiffuseTexture);
      pParticleSystem->init();
    }
  };
}

#endif // __COGLDEV08TRANSFORMFEEDBACKAPP_HPP__
