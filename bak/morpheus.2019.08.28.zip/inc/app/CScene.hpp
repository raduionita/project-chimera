#ifndef __app_cscene_hpp__
#define __app_cscene_hpp__

#include <cassert>

namespace app
{
  namespace tags
  {
    static const sys::CTag CAMERA("CAMERA");
    static const sys::CTag MAINCAMERA("MAINCAMERA");
    
    static const sys::CTag LIGHT("LIGHT");
    static const sys::CTag DIRECTLIGHT("DIRECTLIGHT");
    static const sys::CTag SPOTLIGHT("SPOTLIGHT");
    static const sys::CTag POINTLIGHT("POINTLIGHT");
    
    static const sys::CTag EVENT("EVENT");
    static const sys::CTag OBJECT("OBJECT");
  }
  
  class CSceneObject
  {
    protected:
    ogl::CObject*    mObject;
    sys::CDescriptor mDescriptor;
    
    public:
    CSceneObject() : mObject(nullptr)
    {
    
    }
    
    CSceneObject(ogl::CObject* pObject) : mObject(pObject)
    {
    
    }
    
    CSceneObject(ogl::CObject* pObject, const sys::CDescriptor& oDescriptor) : mObject(pObject), mDescriptor(oDescriptor)
    {
    
    }
    
    CSceneObject(const CSceneObject& that)
    {
      mObject     = that.mObject;
      mDescriptor = that.mDescriptor;
    }
    
    CSceneObject& operator = (const CSceneObject& that)
    {
      if(this != &that)
      {
        mObject     = that.mObject;
        mDescriptor = that.mDescriptor;
      }
      return *this;
    }
    
    public:
    sys::CDescriptor getDescriptor() const
    {
      return mDescriptor;
    }
    
    ogl::CObject* getObject() const
    {
      return mObject;
    }
  };
  
  class CSceneCamera
  {
    protected:
    ogl::CCamera*    mCamera;
    sys::CDescriptor mDescriptor;
    
    public:
    CSceneCamera() : mCamera(nullptr)
    {
    
    }
  
    CSceneCamera(ogl::CCamera* pCamera) : mCamera(pCamera)
    {
    
    }
    
    CSceneCamera(ogl::CCamera* pCamera, const sys::CDescriptor& oDescriptor) : mCamera(pCamera), mDescriptor(oDescriptor)
    {
    
    }
  
    CSceneCamera(const CSceneCamera& that)
    {
      mCamera     = that.mCamera;
      mDescriptor = that.mDescriptor;
    }
    
    CSceneCamera& operator = (const CSceneCamera& that)
    {
      if(this != &that)
      {
        mCamera     = that.mCamera;
        mDescriptor = that.mDescriptor;
      }
      return *this;
    }
  
    public:
    sys::CDescriptor getDescriptor() const
    {
      return mDescriptor;
    }
    
    ogl::CCamera* getCamera() const
    {
      return mCamera;
    }
  };
  
  class CSceneLight
  {
    protected:
    ogl::CLight*     mLight;
    sys::CDescriptor mDescriptor;
    
    public:
    CSceneLight() : mLight(nullptr)
    {
    
    }
  
    CSceneLight(ogl::CLight* pLight) : mLight(pLight)
    {
    
    }
    
    CSceneLight(ogl::CLight* pLight, const sys::CDescriptor& oDescriptor) : mLight(pLight), mDescriptor(oDescriptor)
    {
    
    }
    
    CSceneLight(const CSceneLight& that)
    {
      mLight      = that.mLight;
      mDescriptor = that.mDescriptor;
    }
    
    CSceneLight& operator = (const CSceneLight& that)
    {
      if(this != &that)
      {
        mLight      = that.mLight;
        mDescriptor = that.mDescriptor;
      }
      return *this;
    }
    
    public:
    sys::CDescriptor getDescriptor() const
    {
      return mDescriptor;
    }
    
    ogl::CLight* getLight() const
    {
      return mLight;
    }
  };
  
  class CSceneEvent
  {
    protected:
    // mSceneEvent; // triggered by time, interesection
    sys::CDescriptor mDescriptor;
    
    public:
    CSceneEvent()
    {
      
    }
    
    CSceneEvent(const sys::CDescriptor& oDescriptor) : mDescriptor(oDescriptor)
    {
      
    }
    
    CSceneEvent(const CSceneEvent& that)
    {
      mDescriptor = that.mDescriptor;
    }
    
    CSceneEvent& operator = (const CSceneEvent& that)
    {
      if(this != &that)
      {
        mDescriptor = that.mDescriptor;
      }
      return *this;
    }
    
    public:
    sys::CDescriptor getDescriptor() const
    {
      return mDescriptor;
    }
  };
  
  // class CForceEntity : public CEntity { }; // gravity, wind
  
  class CScene
  {
    protected:
    std::vector<CSceneObject*> mObjects;
    std::vector<CSceneCamera*> mCameras;
    std::vector<CSceneLight*>  mLights;
    std::vector<CSceneEvent*>  mEvents;
    
    public:
    CScene()
    {
      
    }
    
    virtual ~CScene()
    {
      for(CSceneObject*& pObject : mObjects)
        _DELETE(pObject);
      for(CSceneCamera*& pCamera : mCameras)
        _DELETE(pCamera);
      for(CSceneLight*& pLight : mLights)
        _DELETE(pLight);
      for(CSceneEvent*& pEvent : mEvents)
        _DELETE(pEvent);
    }
    
    public:
    void addObject(CSceneObject* pObject)
    {
      mObjects.push_back(pObject);
    }
    
    void addCamera(CSceneCamera* pCamera)
    {
      mCameras.push_back(pCamera);
    }
    
    void addLight(CSceneLight* pLight)
    {
      mLights.push_back(pLight);
    }
    
    void addEvents(CSceneEvent* pEvent)
    {
      mEvents.push_back(pEvent);
    }
    
    std::vector<CSceneObject*>& getObjects()
    {
      return mObjects;
    }
    
    std::vector<CSceneCamera*>& getCameras()
    {
      return mCameras;
    }
    
    std::vector<CSceneLight*>& getLights()
    {
      return mLights;
    }
    
    std::vector<CSceneEvent*>& getEvents()
    {
      return mEvents;
    }
    
    CSceneCamera*& getCamera(size_t i)
    {
      assert(i < mCameras.size());
      return mCameras[i];
    }
    
    CSceneCamera*& getCamera(const sys::CTag& oTag)
    {
      for(CSceneCamera*& pCamera : mCameras)
        if(pCamera->getDescriptor().hasTag(oTag))
          return pCamera;
      throw EXCEPTION << "app::CScene::getCamera(CTag) > Camera not found!"; // << sys::endl;
    }
    
    std::vector<CSceneCamera*> getCameras(const sys::CTag& oTag)
    {
      std::vector<CSceneCamera*> out;
      for(CSceneCamera*& pCamera : mCameras)
        if(pCamera->getDescriptor().hasTag(oTag))
          out.push_back(pCamera);
      return out;
    }
    
    CSceneCamera*& getCamera(const sys::CDescriptor& oDescriptor)
    {
      throw EXCEPTION << "NOT IMPLEMENTED!";
    }
  };
}

#endif // __app_cscene_hpp__






























