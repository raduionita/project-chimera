#ifndef __cogldev35deferredapp_hpp__
#define __cogldev35deferredapp_hpp__

namespace app
{
  class COGLDev35DeferredApp : public CApp
  {
    private:
    ogl::CDirectLight* pDirectLight;
    ogl::CPointLight*  pPointLight;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CDrawRenderer*          pDrawRenderer;
    ogl::CGeometryRenderer*      pGeometryRenderer;
    ogl::CPointLightRenderer*    pPointLightRenderer;
    ogl::CDirectLightRenderer*    pDirectLightRenderer;
    
    ogl::CObject* pObjectP;
    ogl::CObject* pObject0;
    ogl::CObject* pSphere0;
    ogl::CObject* pQuad0;
    
    ogl::CProgram* pProgramInstanced;     // ptr::smart<ogl::CProgram*> pProgramInstanced;
    ogl::CProgram* pProgramGeometry;
    ogl::CProgram* pProgramPointLight;
    ogl::CProgram* pProgramDirectLight;
    ogl::CProgram* pProgramStencil;
    
    public:
    COGLDev35DeferredApp()
    {
      std::cout << "app::COGLDev35DeferredApp::COGLDev35DeferredApp()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      mConfig.mWidth      = 640;
      mConfig.mHeight     = 480;
      strcpy(mConfig.mTitle, "COGLDev35DeferredApp");
    }
  
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev35DeferredApp::onInit() " << std::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_renderers();
      
      glExitIfError();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev35DeferredApp::onDraw(nTime) > " << nTime << std::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime));

      /////////////////////////////////////////////////////
      // geometry pass - w/ more movement
      
      // ogl::CInstancedDrawStrategy* pDrawStrategy = dynamic_cast<ogl::CInstancedDrawStrategy*>(pObject0->getDrawStrategy());
      // math::mat4 mM;
      // for(size_t i = 0, l = pDrawStrategy->getSize(); i < l; ++i)
      // {
      //   mM = pDrawStrategy->getModelMatrix(i);
      //   float fi = (float)(i)/(float)(l);
      //   pDrawStrategy->setModelMatrix(i, math::translate(cosf(0.13f * fTime + fi) * 0.03f, 0.0f, sinf(0.47f * fTime + fi) * 0.02f) * mM);
      // }
      
      // pDrawRenderer->addLight(pDirectLight);
      // pDrawRenderer->addDrawable(pObject0); //, ogl::EDrawOptions::WIREFRAME);
      // pDrawRenderer->addDrawable(pObject0, ogl::EDrawOptions::WIREFRAME);
      // pDrawRenderer->render();
      
      /////////////////////////////////////////////////////
      // geometry pass - simple
      
      math::mat4 mM = math::translate(math::vec3(0.0f, 0.0f, 0.0f)) * math::rotate(-90.0f, math::X) * math::rotate(fTime, math::Y);
      pObject0->setM(mM);
      
      pGeometryRenderer->addDrawable(pObject0);
      pGeometryRenderer->render();
      
      /////////////////////////////////////////////////////
      // point light(+stencil) pass
      
      // does this needs depth testing
      pPointLightRenderer->addLight(pPointLight);
      pPointLightRenderer->addDrawable(pSphere0); // should be setDrawable() ???
      pPointLightRenderer->render();
      
      /////////////////////////////////////////////////////
      // direct light pass
      
      pDirectLightRenderer->addLight(pDirectLight);
      pDirectLightRenderer->addDrawable(pQuad0);
      pDirectLightRenderer->render();
      
      /////////////////////////////////////////////////////
      // final pass
      
      glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
      pGeometryRenderer->getFramebuffer()->bind(GL_READ_FRAMEBUFFER);
      glReadBuffer(GL_COLOR_ATTACHMENT5);
      glBlitFramebuffer(0, 0, mConfig.mWidth, mConfig.mHeight, 0, 0, mConfig.mWidth, mConfig.mHeight, GL_COLOR_BUFFER_BIT, GL_LINEAR);
      
      /////////////////////////////////////////////////////
      // blit to default framebuffer
      
      // glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
      // 
      // glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      // 
      // pGeometryRenderer->getFramebuffer()->bind(GL_READ_FRAMEBUFFER);
      //      
      // GLsizei hWidth = (GLsizei)(mConfig.mWidth / 2.0f);
      // GLsizei hHeight = (GLsizei)(mConfig.mHeight / 2.0f);
      // 
      // // alternative to fullscreen quad, copy from one framebuffer to another
      // glReadBuffer(GL_COLOR_ATTACHMENT0);
      // glBlitFramebuffer(0, 0, mConfig.mWidth, mConfig.mHeight, 0, 0, hWidth, hHeight, GL_COLOR_BUFFER_BIT, GL_LINEAR);
      // glReadBuffer(GL_COLOR_ATTACHMENT1);
      // glBlitFramebuffer(0, 0, mConfig.mWidth, mConfig.mHeight, 0, hHeight, hWidth, mConfig.mHeight, GL_COLOR_BUFFER_BIT, GL_LINEAR);
      // glReadBuffer(GL_COLOR_ATTACHMENT2);
      // glBlitFramebuffer(0, 0, mConfig.mWidth, mConfig.mHeight, hWidth, hHeight, mConfig.mWidth, mConfig.mHeight, GL_COLOR_BUFFER_BIT, GL_LINEAR);
      // glReadBuffer(GL_COLOR_ATTACHMENT4);
      // glBlitFramebuffer(0, 0, mConfig.mWidth, mConfig.mHeight, hWidth, 0, mConfig.mWidth, hHeight, GL_COLOR_BUFFER_BIT, GL_LINEAR);
      
      glCheckError();
      
      //CApp::exit();
    }
    
    void onStop()
    { 
      _DELETE(pDirectLight);
      _DELETE(pPointLight);
      
      _DELETE(pCamera);
      _DELETE(pCameraController);
      
      _DELETE(pProgramInstanced);
      _DELETE(pProgramGeometry);
      _DELETE(pProgramPointLight);
      _DELETE(pProgramDirectLight);
      _DELETE(pProgramStencil);
      
      _DELETE(pDrawRenderer);
      _DELETE(pPointLightRenderer);
      _DELETE(pDirectLightRenderer);
      _DELETE(pGeometryRenderer);
      
      _DELETE(pObjectP);
      _DELETE(pObject0);
      _DELETE(pSphere0);
      _DELETE(pQuad0);
    }
    
    private:
    void init_lights()
    {
      pDirectLight                    = new ogl::CDirectLight;
      pDirectLight->mColor            = math::vec3(1.0f, 0.25f, 0.25f);
      pDirectLight->mDirection        = math::vec3(0.0f, 1.0f, 0.0f);
      pDirectLight->mAmbientIntensity = 0.1f;
      pDirectLight->mDiffuseIntensity = 0.7f;
      
      pPointLight = new ogl::CPointLight;
      pPointLight->mColor    = math::vec3(1.0f, 1.0f, 1.0f);
      pPointLight->mPosition = math::vec3(-1.0f, 3.0f, 1.0f);
      pPointLight->mAmbientIntensity = 0.1f;
      pPointLight->mDiffuseIntensity = 0.7f;
      pPointLight->mK0 = 0.01f;
      pPointLight->mK1 = 0.01f;
      pPointLight->mK2 = 0.5f;
      
      // ogl::CLightManager::getInstance()->addLight(pDirectLight); // 0
    }
    
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(4.0f, -2.0f, -5.0f));
      pCameraController = new CCameraController(pCamera);
      
      //ogl::CCameraManager::getInstance()->addCamera(pCamera); // 0
      //app::CControllerManager::getInstance()->addController(pCamaraController); // 0
    }
    
    void init_programs()
    {
      ogl::CFileShaderBuilder*    pShaderBuilder  = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      
      ogl::CShader* pVShader;
      ogl::CShader* pFShader;
    
      { // render + light + shadow + normal + pick
        std::cout << "app::COGLDev35DeferredApp::init_programs() > pProgramInstanced" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("instanced_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("instanced_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mLightMVP",  new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
        pProgramBuilder->addUniform("u_nOptions",   new ogl::CUniform(GL_UNSIGNED_INT));
        
        pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fEyePosition",       new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_vPickPixel",       new ogl::CUniform(GL_INT_VEC3));
        pProgramBuilder->addUniform("u_vIdentifier",      new ogl::CUniform(GL_INT_VEC3));
        pProgramBuilder->addUniform("u_nPickMode",        new ogl::CUniform(GL_INT));

        for(size_t i = 0; i < 2; i++)
        {
          char name[128];
          memset(name, 0, sizeof(name));
          snprintf(name, sizeof(name), "u_oPointLights[%d].vColor", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oPointLights[%d].vPosition", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fAmbientIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fDiffuseIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK0", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK1", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK2", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        }
        
        for(size_t i = 0; i < 2; i++)
        {
          char name[128];
          memset(name, 0, sizeof(name));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vColor", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vPosition", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vDirection", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fCutoff", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fAmbientIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fDiffuseIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK0", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK1", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK2", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        }
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramInstanced::mCallback()" << std::endl;
          
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          ogl::CPickPixel*    pPickPixel    = pDrawRenderer->getPickPixel();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mM",  mM);
          pProgram->setUniform("u_mV",  mV);
          pProgram->setUniform("u_mP",  mP);
          pProgram->setUniform("u_fSpecularIntensity",  0.0f);
          pProgram->setUniform("u_fSpecularPower",      0.0f);
          pProgram->setUniform("u_fEyePosition",        pCamera->getPosition());
          pProgram->setUniform("u_nOptions",            (USE_DIFFUSE_MAP | USE_SHADOW_MAP)); // @TODO: doesn't work !?
          pProgram->setUniform("u_bWireframe",          (bool)(pDrawRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
          
          if(pPickPixel)
          {
            pProgram->setUniform("u_vPickPixel",  pPickPixel->getData());
            pProgram->setUniform("u_vIdentifier", math::ivec3(pDrawRenderer->getObjectIndex(), pDrawRenderer->getDrawIndex(), 0));
            pProgram->setUniform("u_nPickMode",   ogl::EPickMode::PRIMITIVE);
          }
          
          for(ogl::CLight* pLight : pDrawRenderer->getLights())
          {
            if(pLight->getType() == ogl::CLight::DIRECT)
            {
              ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
              pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
              pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
              pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
              pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
            }
            else if(pLight->getType() == ogl::CLight::SPOT)
            {
              //@TODO...
            }
            else if(pLight->getType() == ogl::CLight::POINT)
            {
              //@TODO...
            }
          }
        });
        pProgramInstanced = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
        
        glExitIfError();
      }
      { // deferred render: geometry pass - process position map + texcoord map + normal map + color map + ..?
        std::cout << "app::COGLDev35DeferredApp::init_programs() > pProgramGeometry" << std::endl;
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("deferred_geometry_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("deferred_geometry_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
      
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramGeometry::mCallback()" << std::endl;
          
          ogl::CGeometryRenderer* pGeometryRenderer = dynamic_cast<ogl::CGeometryRenderer*>(pRenderer);
          ogl::CProgram*      pProgram              = pGeometryRenderer->getProgram();
          ogl::CCamera*       pCamera               = pGeometryRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mM",  mM);
          pProgram->setUniform("u_mV",  mV);
          pProgram->setUniform("u_mP",  mP);
        });
      
        pProgramGeometry = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
        
        glExitIfError();
      }
      { // point light pass - draw a sphere using stencil buffer to show only fragments affected by light
        std::cout << "app::COGLDev35DeferredApp::init_programs() > pProgramPointLight" << std::endl;
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("deferred_pointligth_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("deferred_pointligth_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mMVP",                          new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oPointLight.vColor",            new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oPointLight.vPosition",         new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oPointLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK0",               new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK1",               new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oPointLight.fK2",               new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularPower",                new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularIntensity",            new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_vEyePosition",                  new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_iLightType",                    new ogl::CUniform(GL_INT));
        pProgramBuilder->addUniform("u_vScreenSize",                   new ogl::CUniform(GL_FLOAT_VEC2));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramPointLight::mCallback()" << std::endl;
          
          ogl::CPointLightRenderer* pPointLightRenderer = dynamic_cast<ogl::CPointLightRenderer*>(pRenderer);
          ogl::CProgram*            pProgram            = pPointLightRenderer->getLightProgram();
          ogl::CCamera*             pCamera             = pPointLightRenderer->getCamera();
          ogl::CPointLight*         pPointLight         = pPointLightRenderer->getPointLight();

          float fScale = pPointLight->getRadius();  // calculate point sphere scale

          math::mat4 mM          = pPointLight->getM() * math::scale(fScale);
          math::mat4 mV          = pCamera->getViewMatrix();
          math::mat4 mP          = pCamera->getProjectionMatrix();
          math::vec2 vScreenSize = math::vec2((GLfloat)app::CApp::getConfig().mWidth, (GLfloat)app::CApp::getConfig().mHeight);
          
          pProgram->setUniform("u_oPointLight.vColor",            pPointLight->mColor);
          pProgram->setUniform("u_oPointLight.vPosition",         pPointLight->mPosition);
          pProgram->setUniform("u_oPointLight.fAmbientIntensity", pPointLight->mAmbientIntensity);
          pProgram->setUniform("u_oPointLight.fDiffuseIntensity", pPointLight->mDiffuseIntensity);
          pProgram->setUniform("u_oPointLight.fK0",               pPointLight->mK0);
          pProgram->setUniform("u_oPointLight.fK1",               pPointLight->mK1);
          pProgram->setUniform("u_oPointLight.fK2",               pPointLight->mK2);
          
          pProgram->setUniform("u_fSpecularIntensity", 0.5f);
          pProgram->setUniform("u_fSpecularPower",    32.0f);
          pProgram->setUniform("u_vEyePosition",      pCamera->getPosition());
          
          
          pProgram->setUniform("u_vScreenSize", vScreenSize);
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
        });
        
        pProgramPointLight = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
        
        glExitIfError();
      }
      { // direct light pass
        std::cout << "app::COGLDev35DeferredApp::init_programs() > pProgramDirectLight" << std::endl;
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("deferred_directligth_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("deferred_directligth_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_oDirectLight.vColor",            new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.vDirection",        new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_vEyePosition",       new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_iLightType",         new ogl::CUniform(GL_INT));
        pProgramBuilder->addUniform("u_vScreenSize",        new ogl::CUniform(GL_FLOAT_VEC2));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramDirectLight::mCallback()" << std::endl;
          
          ogl::CDirectLightRenderer* pDirectLightRenderer = dynamic_cast<ogl::CDirectLightRenderer*>(pRenderer);
          ogl::CProgram*             pProgram             = pDirectLightRenderer->getProgram();
          ogl::CCamera*              pCamera              = pDirectLightRenderer->getCamera();
          ogl::CDirectLight*         pDirectLight         = pDirectLightRenderer->getDirectLight();

          math::mat4 mM          = pDirectLight->getM() * math::scale(10.0f);
          //math::mat4 mV          = pCamera->getViewMatrix();
          //math::mat4 mP          = pCamera->getProjectionMatrix();
          math::vec2 vScreenSize = math::vec2((GLfloat)app::CApp::getConfig().mWidth, (GLfloat)app::CApp::getConfig().mHeight);
          
          pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
          pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection));
          pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
          pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
          
          pProgram->setUniform("u_fSpecularIntensity", 0.5f);
          pProgram->setUniform("u_fSpecularPower",    32.0f);
          pProgram->setUniform("u_vEyePosition",      pCamera->getPosition());
          
          
          pProgram->setUniform("u_vScreenSize", vScreenSize);
          
          pProgram->setUniform("u_mMVP", mM); // just M so that the quat stays parallel to the camera
        });
        
        pProgramDirectLight = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
      }
      { // stencil light pass - null program - pass-through vs + null fs
        std::cout << "app::COGLDev35DeferredApp::init_programs() > pProgramStencil" << std::endl;
        pShaderBuilder->setType(GL_VERTEX_SHADER);
        pShaderBuilder->setFile("deferred_stencil_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("deferred_stencil_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mMVP", new ogl::CUniform(GL_FLOAT_MAT4));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramStencil::mCallback()" << std::endl;
          
          ogl::CPointLightRenderer* pPointLightRenderer = dynamic_cast<ogl::CPointLightRenderer*>(pRenderer);
          ogl::CProgram*            pProgram            = pPointLightRenderer->getStencilProgram();
          ogl::CCamera*             pCamera             = pPointLightRenderer->getCamera();
          ogl::CPointLight*         pPointLight         = pPointLightRenderer->getPointLight();
          
          float fScale = pPointLight->getRadius();  // calculate point sphere scale
          
          math::mat4 mM = pPointLight->getM() * math::scale(fScale);
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMVP", mP * mV * mM);
        });
        
        pProgramStencil = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
      }  
    }
    
    void init_objects()
    {
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        //pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
        pTextureBuilder->setFile("ground/rocks_d.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        pTextureBuilder->setFile("ground/rocks_h.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::HEIGHT, pTextureBuilder->build()); // displacement
        
        delete pObjectBuilder;
      }
      { // mesh
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("monkey/monkey.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        
        ogl::CInstancedDrawStrategy* pDrawStrategy = new ogl::CInstancedDrawStrategy(64);
        math::mat4 mM;
        for(uint i = 0, l = pDrawStrategy->getSize(); i < l; ++i)
        {
          float fi = (float)(i)/(float)(l);
          mM = math::rotate(90.0f * math::rand(), math::Z) *
               math::rotate(fi * -90.0f, math::Y) *
               math::translate(math::vec3(cosf(fi * 37.3f) * 5.1f, math::rand() * 2.3f, sinf(fi * 25.7f) * 4.7f));
          pDrawStrategy->setModelMatrix(i, mM);
        }
        pObjectBuilder->setDrawStrategy(pDrawStrategy);
        
        pObject0 = pObjectBuilder->build();
        //pObject0->setM(math::translate(0.0f, 2.0f, 0.0f) * math::rotate(-90.0f, math::X));
        
        delete pObjectBuilder;
      }
      { // sphere
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("sphere.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pSphere0 = pObjectBuilder->build();
        
        delete pObjectBuilder;
      } 
      { // quad
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("quad.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pQuad0 = pObjectBuilder->build();
        
        delete pObjectBuilder;
      }
    }
    
    void init_renderers()
    {
      pDrawRenderer = new ogl::CDrawRenderer(mConfig.mWidth, mConfig.mHeight);
      pDrawRenderer->setProgram(pProgramInstanced);
      pDrawRenderer->setCamera(pCamera);
      pDrawRenderer->setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      pDrawRenderer->setClearDepth(1.0f);
      pDrawRenderer->setWinding(GL_CW);
      pDrawRenderer->setCullFace(GL_BACK);
      
      pGeometryRenderer = new ogl::CGeometryRenderer(mConfig.mWidth, mConfig.mHeight);
      pGeometryRenderer->setProgram(pProgramGeometry);
      pGeometryRenderer->setCamera(pCamera);
      pGeometryRenderer->setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      pGeometryRenderer->setClearDepth(1.0f);
      pGeometryRenderer->setWinding(GL_CW);
      pGeometryRenderer->setCullFace(GL_BACK);
      
      pPointLightRenderer = new ogl::CPointLightRenderer(mConfig.mWidth, mConfig.mHeight);
      pPointLightRenderer->setGeometryRenderer(pGeometryRenderer);
      pPointLightRenderer->setCamera(pCamera);
      pPointLightRenderer->setLightProgram(pProgramPointLight);
      pPointLightRenderer->setStencilProgram(pProgramStencil);
      pPointLightRenderer->setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      pPointLightRenderer->setClearDepth(1.0f);
      pPointLightRenderer->setWinding(GL_CW);
      pPointLightRenderer->setCullFace(GL_BACK);
      
      pDirectLightRenderer = new ogl::CDirectLightRenderer(mConfig.mWidth, mConfig.mHeight);
      pDirectLightRenderer->setGeometryRenderer(pGeometryRenderer);
      pDirectLightRenderer->setCamera(pCamera);
      pDirectLightRenderer->setProgram(pProgramDirectLight);
    }
  };
}

#endif // __cogldev35deferredapp_hpp__
