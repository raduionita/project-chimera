#ifndef __cogldev11instancedapp_hpp__
#define __cogldev11instancedapp_hpp__

namespace app
{
  class COGLDev11InstancedApp : public CApp
  {
    private:
    ogl::CDirectLight* pDirectLight;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CDrawRenderer*          pDrawRenderer;
    
    ogl::CObject* pObjectP;
    ogl::CObject* pObject0;
    
    ogl::CProgram* pProgramInstanced;
    
    public:
    COGLDev11InstancedApp()
    {
      std::cout << "app::COGLDev11InstancedApp::COGLDev11InstancedApp()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      strcpy(mConfig.mTitle, "COGLDev11InstancedApp");
    }
  
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev11InstancedApp::onInit() " << std::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_renderers();
      
      glExitIfError();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev11InstancedApp::onDraw(nTime) > " << nTime << std::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime));
      
//      ogl::CInstancedDrawStrategy* pDrawStrategy = dynamic_cast<ogl::CInstancedDrawStrategy*>(pObject0->getDrawStrategy());
//      math::mat4 mM;
//      for(size_t i = 0, l = pDrawStrategy->getSize(); i < l; ++i)
//      {
//        mM = pDrawStrategy->getModelMatrix(i);
//        float fi = (float)(i)/(float)(l);
//        pDrawStrategy->setModelMatrix(i, math::translate(cosf(0.13f * fTime + fi) * 0.03f, 0.0f, sinf(0.47f * fTime + fi) * 0.02f) * mM);
//      }
      
      pDrawRenderer->setCamera(pCamera);
      pDrawRenderer->addLight(pDirectLight);
      pDrawRenderer->addDrawable(pObject0); //, ogl::EDrawOptions::WIREFRAME);
      pDrawRenderer->addDrawable(pObject0, ogl::EDrawOptions::WIREFRAME);
      pDrawRenderer->render();
      
      //CApp::exit();
    }
    
    void onStop()
    { 
      _DELETE(pDirectLight);
      
      _DELETE(pCamera);
      _DELETE(pCameraController);
      
      _DELETE(pProgramInstanced);
      
      _DELETE(pDrawRenderer);
      
      _DELETE(pObjectP);
      _DELETE(pObject0);
    }
    
    private:
    void init_lights()
    {
      pDirectLight                    = new ogl::CDirectLight;
      pDirectLight->mColor            = math::vec3(1.0f, 1.0f, 1.0f);
      pDirectLight->mDirection        = math::vec3(-1.0f, -1.0f, 0.0f);
      pDirectLight->mAmbientIntensity = 0.525f;
      pDirectLight->mDiffuseIntensity = 0.0f;
      
      // ogl::CLightManager::getInstance()->addLight(pDirectLight); // 0
    }
    
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(0.0f, -2.0f, -5.0f));
      pCameraController = new CCameraController(pCamera);
      
      //ogl::CCameraManager::getInstance()->addCamera(pCamera); // 0
      //app::CControllerManager::getInstance()->addController(pCamaraController); // 0
    }
    
    void init_programs()
    {
      ogl::CFileShaderBuilder*    pShaderBuilder  = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      
      ogl::CShader* pVShader;
      ogl::CShader* pFShader;
    
      { // render + light + shadow + normal + pick
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("instanced_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("instanced_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mLightMVP",  new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
        pProgramBuilder->addUniform("u_nOptions",   new ogl::CUniform(GL_UNSIGNED_INT));
        
        pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fEyePosition",       new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_vPickPixel",       new ogl::CUniform(GL_INT_VEC3));
        pProgramBuilder->addUniform("u_vIdentifier",      new ogl::CUniform(GL_INT_VEC3));
        pProgramBuilder->addUniform("u_nPickMode",        new ogl::CUniform(GL_INT));
        
        for(size_t i = 0; i < 2; i++)
        {
          char name[128];
          memset(name, 0, sizeof(name));
          snprintf(name, sizeof(name), "u_oPointLights[%d].vColor", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oPointLights[%d].vPosition", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fAmbientIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fDiffuseIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK0", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK1", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oPointLights[%d].fK2", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        }
        
        for(size_t i = 0; i < 2; i++)
        {
          char name[128];
          memset(name, 0, sizeof(name));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vColor", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vPosition", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].vDirection", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_VEC3));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fCutoff", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fAmbientIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fDiffuseIntensity", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK0", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK1", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
          snprintf(name, sizeof(name), "u_oSpotLights[%d].fK2", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT));
        }
      
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pProgramRender::mCallback()" << std::endl;
          
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          ogl::CPickPixel*    pPickPixel    = pDrawRenderer->getPickPixel();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mM",  mM);
          pProgram->setUniform("u_mV",  mV);
          pProgram->setUniform("u_mP",  mP);
          pProgram->setUniform("u_mMV", mV * mM);
          pProgram->setUniform("u_fSpecularIntensity",  0.0f);
          pProgram->setUniform("u_fSpecularPower",      0.0f);
          pProgram->setUniform("u_fEyePosition",        pCamera->getPosition());
          pProgram->setUniform("u_nOptions",            (USE_DIFFUSE_MAP | USE_SHADOW_MAP)); // @TODO: doesn't work !?
          pProgram->setUniform("u_bWireframe",          (bool)(pDrawRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
          
          if(pPickPixel)
          {
            pProgram->setUniform("u_vPickPixel",  pPickPixel->getData());
            pProgram->setUniform("u_vIdentifier", math::ivec3(pDrawRenderer->getObjectIndex(), pDrawRenderer->getDrawIndex(), 0));
            pProgram->setUniform("u_nPickMode",   ogl::EPickMode::PRIMITIVE);
          }
          
          for(ogl::CLight* pLight : pDrawRenderer->getLights())
          {
            if(pLight->getType() == ogl::CLight::DIRECT)
            {
              ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
              pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
              pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
              pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
              pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
            }
            else if(pLight->getType() == ogl::CLight::SPOT)
            {
              //@TODO...
            }
            else if(pLight->getType() == ogl::CLight::POINT)
            {
              //@TODO...
            }
          }
        });
        pProgramInstanced = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
        
        glExitIfError();
      }
    }
    
    void init_objects()
    {
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        //pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
        pTextureBuilder->setFile("ground/rocks_d.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        pTextureBuilder->setFile("ground/rocks_h.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::HEIGHT, pTextureBuilder->build()); // displacement
        
        delete pObjectBuilder;
      }
      { // mesh
        ogl::CAssimpObjectBuilder* pObjectBuilder = new ogl::CAssimpObjectBuilder;
        pObjectBuilder->setFile("monkey/monkey.obj");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        
        ogl::CInstancedDrawStrategy* pDrawStrategy = new ogl::CInstancedDrawStrategy(128);
        math::mat4 mM;
        for(uint i = 0, l = pDrawStrategy->getSize(); i < l; ++i)
        {
          float fi = (float)(i)/(float)(l);
          mM = math::rotate(90.0f * math::rand(), math::Z) *
               math::rotate(fi * -90.0f, math::Y) *
               math::translate(math::vec3(cosf(fi * 37.3f) * 5.1f, math::rand() * 2.3f, sinf(fi * 25.7f) * 4.7f));
          pDrawStrategy->setModelMatrix(i, mM);
        }
        pObjectBuilder->setDrawStrategy(pDrawStrategy);
        
        pObject0 = pObjectBuilder->build();
        pObject0->setM(math::translate(0.0f, 2.0f, 0.0f) * math::rotate(-90.0f, math::X));
        
        delete pObjectBuilder;
      }
    }
    
    void init_renderers()
    {
      pDrawRenderer = new ogl::CDrawRenderer(mConfig.mWidth, mConfig.mHeight);
      pDrawRenderer->setProgram(pProgramInstanced);
      pDrawRenderer->setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      pDrawRenderer->setClearDepth(1.0f);
      pDrawRenderer->setWinding(GL_CW);
      pDrawRenderer->setCullFace(GL_BACK);
    }
  };
}

#endif // __cogldev11instancedapp_hpp__
