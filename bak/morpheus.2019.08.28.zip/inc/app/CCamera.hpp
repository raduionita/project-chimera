#ifndef __ccamera_hpp__off__
#define __ccamera_hpp__off__

namespace app
{
  //@TODO: extends CFrustum -- which calculates perspective/orthographic projection
  //@TODO: camera should be updated by a CCameraController that implements eventlisteners
  //@TODO: need a better fix for handdedness issue
  class CCamera
  {
    protected:
    static constexpr float fStep = 0.1f;
    
    math::vec3 mPosition;
    math::vec3 mUp;
    math::vec3 mLeft;
    math::vec3 mForward;
    
    math::quat mOrientation;
    math::mat4 mViewMatrix;
    math::mat4 mProjectionMatrix;
    
    float mFov;
    float mRatio;
    float mNear;
    float mFar;
    
    bool mDirty;
    
    
    bool mMoveForward;
    bool mMoveBackward;
    bool mMoveLeft;
    bool mMoveRight;
    
    public:
    CCamera() 
    : mPosition(0.0f, 0.0f, 0.0f), mUp(0.0f, 1.0f, 0.0f), mLeft(-1.0f, 0.0f, 0.0f), mForward(0.0f, 0.0f, 1.0f),
      mOrientation(1.0f, 0.0f, 0.0f, 0.0f), 
      mFov(45.0f), mRatio(1.33f), mNear(0.1f), mFar(1000.0f),
      mDirty(true), mMoveForward(false), mMoveBackward(false), mMoveLeft(false), mMoveRight(false)
    {
      sys::info << "app::CCamera::Camera()" << sys::endl;
      mProjectionMatrix = math::perspective(mFov, mRatio, mNear, mFar);
      roll(math::radians(180.0f)); //@FIX handedness fix
    }
    
    CCamera(float fov, float ratio, float near, float far) 
    : mPosition(0.0f, 0.0f, 0.0f), mUp(0.0f, 1.0f, 0.0f), mLeft(-1.0f, 0.0f, 0.0f), mForward(0.0f, 0.0f, 1.0f),
      mOrientation(1.0f, 0.0f, 0.0f, 0.0f),
      mFov(fov), mRatio(ratio), mNear(near), mFar(far),
      mDirty(true), mMoveForward(false), mMoveBackward(false), mMoveLeft(false), mMoveRight(false)
    {
      sys::info << "app::CCamera::Camera(" << fov << ", " << ratio << ", " << near << ", " << far << ")" << sys::endl;
      mProjectionMatrix = math::perspective(mFov, mRatio, mNear, mFar);
      roll(math::radians(180.0f)); //@FIX handedness fix
    }
    
    CCamera(float left, float right, float bottom, float top, float near, float far) 
    : mPosition(0.0f, 0.0f, 0.0f), mUp(0.0f, 1.0f, 0.0f), mLeft(-1.0f, 0.0f, 0.0f), mForward(0.0f, 0.0f, 1.0f),
      mOrientation(1.0f, 0.0f, 0.0f, 0.0f),
      mFov(0.0f), mRatio((right-left)/(top-bottom)), mNear(near), mFar(far),
      mDirty(true), mMoveForward(false), mMoveBackward(false), mMoveLeft(false), mMoveRight(false)
    {
      sys::info << "app::CCamera::Camera(left, right, bottom, top, near, far)" << sys::endl;
      mProjectionMatrix = math::ortho(left, right, bottom, top, near, far);
      roll(math::radians(180.0f)); //@FIX handedness fix
    }
    
    CCamera(const CCamera& that)
    {
      mPosition = that.mPosition;
      mUp = that.mUp;
      mLeft = that.mLeft;
      mForward = that.mForward;
      
      mOrientation = that.mOrientation;
      mViewMatrix = that.mViewMatrix;
      mProjectionMatrix = that.mProjectionMatrix;
      
      mFov = that.mFov;
      mRatio = that.mRatio;
      mNear = that.mNear;
      mFar = that.mFar;
      
      mDirty = that.mDirty;
    }
    
    virtual ~CCamera()
    {
      
    }
    
    CCamera& operator = (const CCamera& that)
    {
      if(this != &that)
      {
        mPosition = that.mPosition;
        mUp = that.mUp;
        mLeft = that.mLeft;
        mForward = that.mForward;
        
        mOrientation = that.mOrientation;
        mViewMatrix = that.mViewMatrix;
        mProjectionMatrix = that.mProjectionMatrix;
        
        mFov = that.mFov;
        mRatio = that.mRatio;
        mNear = that.mNear;
        mFar = that.mFar;
        
        mDirty = that.mDirty;
      }
      return *this;
    }
    
    public:
    float getFov() const
    {
      return mFov;
    }
    
    void setFov(float fov)
    {
      mFov = fov;
    }
    
    float getRatio() const
    {
      return mRatio;
    }
    
    void setRatio(float ratio)
    {
      mRatio = ratio;
    }
    
    float getNear() const
    {
      return mNear;
    }
    
    void setNear(float near) 
    {
      mNear = near;
    }
    
    float getFar() const
    {
      return mFar;
    }
    
    void setFar(float far)
    {
      mFar = far;
    }
    
    math::vec3 getPosition() const
    {
      return mPosition;
    }
    
    void setPosition(float x, float y, float z)
    {
      mPosition = math::vec3(x, y, z);
    }    
    
    void setPosition(const math::vec3& position)
    {
      mPosition = position;
    }
    
    math::vec3 getUp() const
    {
      return mUp;
    }
    
    math::vec3 getLeft() const
    {
      return mLeft;
    }
    
    math::vec3 getForward() const
    {
      return mForward;
    }
    
    math::quat getOrientation() const
    {
      return mOrientation;
    }
    
    math::mat4 getViewMatrix()
    {
      // return math::lookat(mPosition, mForward, mUp);
      
      if(mDirty)
      {
        onUpdate();
      
        math::quat Q = mOrientation;
        Q.inverse();
        mViewMatrix = Q.asMatrix();
        
        math::vec3 v = -mPosition;
        math::mat4 m = mViewMatrix;
        mViewMatrix[3] = (m[0] * v[0]) + (m[1] * v[1]) + (m[2] * v[2]) + m[3];
        
        //@TODO: try to fix handedness
        // mViewMatrix[1][0] = -1.0f;
        
        mViewMatrix = math::scale(-1.0f) * mViewMatrix; //@FIX: Handedness fix
        
        //mViewMatrix *= math::rotate(180.0f, math::Y);
        
        mDirty = false;
      }
      
      return mViewMatrix;
    }
    
    math::mat4 getProjectionMatrix()
    {
      return mProjectionMatrix;
    }
    
    void dirty() // TODO: needs a better algorithm for deciding when to set dirty
    {
      mDirty = true;
      
      normalize();
    }
    
    void normalize()
    {
      mLeft.normalize();
      mUp.normalize();
      mForward.normalize();
      mOrientation.normalize();
      
      //if mForward is correct
      mLeft = math::cross(mForward, mUp);
      mUp   = math::cross(mLeft,mForward);
    }
    
    void zoom(float amount)
    {
      // TODO: set zoom & recalculate projection matrix
    }
    
   /**
    * Rotates camera around Z axis (forward direction) by angle radians.
    * @note              Use negative angle for counter-clockwise rotations 
    * @param angle float Roration in radians [-2PI, 2PI]
    */
    void roll(float angle)
    {
      math::quat Q(angle, mForward);
      
      mUp   = math::rotate(Q, mUp);
      mLeft = math::rotate(Q, mLeft);
      
      mOrientation = Q * mOrientation;
      
      dirty();
    }
    
   /**
    * Rotates camera around X axis (left direction) by angle radians.
    * @note              Use negative angle for counter-clockwise rotations 
    * @param angle float Roration in radians [-2PI, 2PI]
    */
    void pitch(float angle)
    {
      math::quat Q(angle, mLeft);
      
      mUp      = math::rotate(Q, mUp);
      mForward = math::rotate(Q, mForward);
      
      mOrientation = Q * mOrientation;
      
      dirty();
    }
    
   /**
    * Rotates camera around Y axis (up direction) by angle radians.
    * @note              Use negative angle for counter-clockwise rotations 
    * @param angle float Roration in radians [-2PI, 2PI]
    */
    void yaw(float angle)
    {
      math::quat Q(angle, mUp);
      
      // sys::info << Q << sys::endl;
      
      mLeft    = math::rotate(Q, mLeft);
      mForward = math::rotate(Q, mForward);
      
      mLeft.normalize();
      mForward.normalize();
      
      // sys::info << mLeft << sys::endl;
      // sys::info << mForward << sys::endl;
      // sys::info << sys::endl;
      
      mOrientation = Q * mOrientation;
      
      dirty();
    }
  
   /**
    * Rotate camera angle radians around axis -- camera local componets
    * @note              Use negative angle for counter-clockwise rotations 
    * @param angle float Rotation angle in radians
    * @param axis  vec3  Rotation axis using relative values
    */
    void rotate(float angle, const math::vec3& axis)
    {
      math::vec3 n = math::normalize(axis);
      math::quat Q(angle, n);
      
      mLeft    = math::rotate(Q, mLeft);
      mUp      = math::rotate(Q, mUp);
      mForward = math::rotate(Q, mForward);
      
      mOrientation = Q * mOrientation;
      
      dirty();
    }
    
    void translate(float x, float y, float z)
    {
      mPosition.x += x;
      mPosition.y += y;
      mPosition.z += z;
      
      dirty();
    }
    
    void translate(const math::vec3& v)
    {
      translate(v.x, v.y, v.z);
    }
    
    void translateLocal(float left, float up, float forward)
    {
      mPosition += left * mLeft;
      mPosition += up * mUp;
      mPosition += forward * mForward;
      
      dirty();
    }
    
    void translateLocal(const math::vec3& v)
    {
      translateLocal(v.x, v.y, v.z);
    }
    
    public: 
    void onUpdate()
    { 
      sys::info << "app::CCamera::onUpdate() > Camera Position Move" << sys::endl;
      
      if(mMoveForward)
        translateLocal(0.0f, 0.0f, 0.1f);
      if(mMoveBackward)
        translateLocal(0.0f, 0.0f,-0.1f);
      if(mMoveLeft)
        translateLocal(-0.1f, 0.0f, 0.0f);
      if(mMoveRight)
        translateLocal( 0.1f, 0.0f, 0.0f);
    }
    
    void onKey(int key, int action) // COnKeyListener::onKey(int, int)
    {
      if(action == KEY_PRESS)
      {
        if(key == KEY_W)
          mMoveForward = true;
        else if(key == KEY_S)
          mMoveBackward = true;
        else if(key == KEY_A)
          mMoveLeft = true;
        else if(key == KEY_D)
          mMoveRight = true;
        else if(KEY_NUM_6)
          yaw(math::radians(-1.0f));
        else if(KEY_NUM_8)
          pitch(math::radians(-1.0f));
        else if(KEY_NUM_2)
          pitch(math::radians(1.0f));
        else if(KEY_NUM_4)
          yaw(math::radians(1.0f));
        else if(KEY_NUM_7)
          roll(math::radians(-1.0f));
        else if(KEY_NUM_9)
          roll(math::radians(1.0f));
          
        dirty();
      }
      else if(action == KEY_RELEASE)
      {
        if(key == KEY_W)
          mMoveForward = false;
        else if(key == KEY_S)
          mMoveBackward = false;
        else if(key == KEY_A)
          mMoveLeft = false;
        else if(key == KEY_D)
          mMoveRight = false;
      }
    }
    
    void onMouseMove(int x, int y)
    {
    
    }
    
    void onMouseDrag(int x, int y)
    {
      int nWidth  = app::CApp::getConfig().mWidth; 
      int nHeight = app::CApp::getConfig().mHeight; 
      int nMidX = nWidth  / 2;
      int nMidY = nHeight / 2;
      
      if(x == nMidX && y == nMidY)
        return;
      
      sys::info << "app::CCamera::onMouseDrag(" << x << ", " << y << ") > Camera Target Move" << sys::endl;
      
      math::vec2 vDir = math::vec2((float)(nMidX - x), (float)(nMidY - y));
      vDir /= (nWidth / 2);
      vDir *= math::PI * 2.0f * 0.2f;
      
      pitch(-vDir.y);
      //math::vec3 vUp = getUp();
      rotate(-vDir.x, math::Y);
      
      glutWarpPointer(nMidX, nMidY);
      
      // CApp::exit();
    }
    
    void onMouseButton(int button, int state, int x, int y)
    {
      sys::info << "app::CCamera::onMouseButton(" << button << ", " << state << ", " << x << ", " << y << ")" << sys::endl;
      int nWidth  = app::CApp::getConfig().mWidth; 
      int nHeight = app::CApp::getConfig().mHeight; 
      int nMidX = nWidth  / 2;
      int nMidY = nHeight / 2;
      glutWarpPointer(nMidX, nMidY);
      
      // mDragging = (state == MOUSE_PRESS);
    }
  };
}

#endif // __ccamera_hpp__off__
