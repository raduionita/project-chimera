#ifndef __cogldev38skinningapp_hpp__
#define __cogldev38skinningapp_hpp__

namespace app
{
  class COGLDev38SkinningApp : public CApp
  {
    private:
    ogl::CDirectLight* pDirectLight;
    //ogl::CPointLight*  pPointLight;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CObject* pObjectP;
    ogl::CObject* pObject0;
    
    ogl::CAnimation* pAnim0;
    
    ogl::CDrawRenderer* pDrawRenderer;
    
    ogl::CProgram*      pSkinningProgram; // ptr::smart<ogl::CProgram> pSkinningProgram;
    ogl::CProgram*      pLightingProgram;
    ogl::CProgram*      pSimpleProgram;
    
    float fPrevTime;
    float fCurrTime;
    
    public:
    COGLDev38SkinningApp()
    { 
      fPrevTime = 0.0f;
      fCurrTime = 0.0f;
    
      pDirectLight = nullptr;
      pCamera = nullptr;
      pCameraController = nullptr;
      pObjectP = nullptr;
      pObject0 = nullptr;
      pAnim0 = nullptr;
      pDrawRenderer = nullptr;
      pSkinningProgram = nullptr;
      pLightingProgram = nullptr;
      pSimpleProgram = nullptr;
    
      std::cout << "app::COGLDev38SkinningApp::COGLDev38SkinningApp()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      mConfig.mWidth      = 640;
      mConfig.mHeight     = 480;
      strcpy(mConfig.mTitle, "COGLDev38SkinningApp");
    }
  
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev38SkinningApp::onInit() " << std::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_animations();
      
      init_renderers();
      
      glExitIfError();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev38SkinningApp::onDraw(nTime) > " << nTime << std::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime)); // must

      /////////////////////////////////////////////////////
      
      fCurrTime = fTime;
      float fDelta = fCurrTime - fPrevTime;
      fPrevTime = fCurrTime;
      pAnim0->update(fDelta);
      pAnim0->animate(pObject0);
      
      pDrawRenderer->addLight(pDirectLight);
      pDrawRenderer->addDrawable(pObjectP);
      //pDrawRenderer->addDrawable(pObjectP, ogl::EDrawOptions::WIREFRAME);
      pDrawRenderer->addDrawable(pObject0);
      //pDrawRenderer->addDrawable(pObject0, ogl::EDrawOptions::WIREFRAME);
      pDrawRenderer->render();

      glCheckError();
      
      //CApp::exit();
    }
    
    void onStop()
    { 
      std::cout << "app::COGLDev38SkinningApp::onStop()" << std::endl;
      
      _DELETE(pDirectLight);
      
      _DELETE(pCamera);
      _DELETE(pCameraController);
      
      _DELETE(pSkinningProgram);
      _DELETE(pLightingProgram);
      _DELETE(pSimpleProgram);
      
      _DELETE(pDrawRenderer);
      
      _DELETE(pObjectP);
      _DELETE(pObject0);
      _DELETE(pAnim0);
    }
    
    private:
    void init_lights()
    {
      std::cout << "app::COGLDev38SkinningApp::init_lights()" << std::endl;
    
      pDirectLight                    = new ogl::CDirectLight;
      pDirectLight->mColor            = math::vec3(1.0f, 0.25f, 0.25f);
      pDirectLight->mDirection        = math::vec3(0.0f, 1.0f, 0.0f);
      pDirectLight->mAmbientIntensity = 0.1f;
      pDirectLight->mDiffuseIntensity = 0.7f;
      
      // ogl::CLightManager::getInstance()->addLight(pDirectLight); // 0
    }
    
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(0.0f, -1.5f, -4.0f));
      pCameraController = new CCameraController(pCamera);
      
      //ogl::CCameraManager::getInstance()->addCamera(pCamera); // 0
      //app::CControllerManager::getInstance()->addController(pCamaraController); // 0
    }
    
    void init_programs()
    {
      ogl::CFileShaderBuilder*    pShaderBuilder  = new ogl::CFileShaderBuilder; 
      ogl::CShaderProgramBuilder* pProgramBuilder = new ogl::CShaderProgramBuilder;
      
      ogl::CShader* pVShader;
      ogl::CShader* pFShader;
      
      { // simple shader
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("texture_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("texture_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        
        pProgramBuilder->addUniform("u_mMV",        new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pSimpleProgram::mCallback()" << std::endl;
          
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mMV", mV * mM);
          pProgram->setUniform("u_mP",  mP);
          
          pProgram->setUniform("u_bWireframe", (bool)(pDrawRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
        });
        pSimpleProgram = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
      }
      { // render + light + shadow + normal + pick
        std::cout << "app::COGLDev38SkinningApp::init_programs() > pSkinningProgram" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("lighting_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("lighting_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
        pProgramBuilder->addUniform("u_nOptions",   new ogl::CUniform(GL_UNSIGNED_INT));
        
        pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
        pProgramBuilder->addUniform("u_fEyePosition",       new ogl::CUniform(GL_FLOAT_VEC3));
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pLightingProgram::mCallback()" << std::endl;
          
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mM",  mM);
          pProgram->setUniform("u_mV",  mV);
          pProgram->setUniform("u_mP",  mP);
          pProgram->setUniform("u_fSpecularIntensity",  1.0f);
          pProgram->setUniform("u_fSpecularPower",     32.0f);
          pProgram->setUniform("u_fEyePosition",       pCamera->getPosition());
          pProgram->setUniform("u_nOptions",           (USE_DIFFUSE_MAP | USE_SHADOW_MAP)); // @TODO: doesn't work !?
          pProgram->setUniform("u_bWireframe",         (bool)(pDrawRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
          
          for(ogl::CLight* pLight : pDrawRenderer->getLights())
          {
            if(pLight->getType() == ogl::CLight::DIRECT)
            {
              ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
              pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
              pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
              pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
              pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
            }
            else if(pLight->getType() == ogl::CLight::SPOT)
            {
              //@TODO...
            }
            else if(pLight->getType() == ogl::CLight::POINT)
            {
              //@TODO...
            }
          }
        });
        pLightingProgram = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
      }
      { // skinning
        std::cout << "app::COGLDev38SkinningApp::init_programs() > pSkinningProgram" << std::endl;
        
        pShaderBuilder->setType(GL_VERTEX_SHADER); 
        pShaderBuilder->setFile("skinning_01.vs.glsl");
        pVShader = pShaderBuilder->build();
        pShaderBuilder->setType(GL_FRAGMENT_SHADER);
        pShaderBuilder->setFile("skinning_01.fs.glsl");
        pFShader = pShaderBuilder->build();
        
        pProgramBuilder->addShader(pVShader);
        pProgramBuilder->addShader(pFShader);
        pProgramBuilder->addUniform("u_mM",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mV",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_mP",         new ogl::CUniform(GL_FLOAT_MAT4));
        pProgramBuilder->addUniform("u_bWireframe", new ogl::CUniform(GL_BOOL));
//        pProgramBuilder->addUniform("u_nOptions",   new ogl::CUniform(GL_UNSIGNED_INT));
        
//        pProgramBuilder->addUniform("u_oDirectLight.vColor",     new ogl::CUniform(GL_FLOAT_VEC3));
//        pProgramBuilder->addUniform("u_oDirectLight.vDirection", new ogl::CUniform(GL_FLOAT_VEC3));
//        pProgramBuilder->addUniform("u_oDirectLight.fAmbientIntensity", new ogl::CUniform(GL_FLOAT));
//        pProgramBuilder->addUniform("u_oDirectLight.fDiffuseIntensity", new ogl::CUniform(GL_FLOAT));
//        pProgramBuilder->addUniform("u_fSpecularIntensity", new ogl::CUniform(GL_FLOAT));
//        pProgramBuilder->addUniform("u_fSpecularPower",     new ogl::CUniform(GL_FLOAT));
//        pProgramBuilder->addUniform("u_fEyePosition",       new ogl::CUniform(GL_FLOAT_VEC3));
        
        for(size_t i = 0; i < MAX_BONES; ++i)
        {
          char name[128];
          memset(name, 0, sizeof(name));
          snprintf(name, sizeof(name), "u_mB[%d]", i);
          pProgramBuilder->addUniform(name, new ogl::CUniform(GL_FLOAT_MAT4));
        }
        
        pProgramBuilder->setCallback([](ogl::CRenderer* pRenderer, ogl::CDrawCommand* pDrawCommand) -> void {
          std::cout << "pSkinningProgram::mCallback()" << std::endl;
          
          ogl::CDrawRenderer* pDrawRenderer = dynamic_cast<ogl::CDrawRenderer*>(pRenderer);
          ogl::CProgram*      pProgram      = pDrawRenderer->getProgram();
          ogl::CCamera*       pCamera       = pDrawRenderer->getCamera();
          
          math::mat4 mM = pDrawCommand->mModelMatrix;
          math::mat4 mV = pCamera->getViewMatrix();
          math::mat4 mP = pCamera->getProjectionMatrix();
          
          pProgram->setUniform("u_mM",  mM);
          pProgram->setUniform("u_mV",  mV);
          pProgram->setUniform("u_mP",  mP);
//          pProgram->setUniform("u_fSpecularIntensity",  0.0f);
//          pProgram->setUniform("u_fSpecularPower",      0.0f);
//          pProgram->setUniform("u_fEyePosition",        pCamera->getPosition());
//          pProgram->setUniform("u_nOptions",            (USE_DIFFUSE_MAP | USE_SHADOW_MAP)); // @TODO: doesn't work !?
          pProgram->setUniform("u_bWireframe",          (bool)(pDrawRenderer->getOptions() & ogl::EDrawOptions::WIREFRAME));
          
          // TODO: find a solution between CDrawCommand CObject & CAnimatable
          
          ogl::CAnimatable* pAnimatable = dynamic_cast<ogl::CAnimatable*>(pDrawCommand->mDrawable);
          for(size_t ji = 0; ji < pAnimatable->mSkeleton->numJoints; ++ji)
          {
            math::mat4 mB = pAnimatable->getBoneMatrix(ji);
            char name[128];
            memset(name, 0, sizeof(name));
            snprintf(name, sizeof(name), "u_mB[%d]", ji);
            pProgram->setUniform(name, mB);
            // std::cout << mB << std::endl << std::endl;
          }
          
          for(ogl::CLight* pLight : pDrawRenderer->getLights())
          {
            if(pLight->getType() == ogl::CLight::DIRECT)
            {
//              ogl::CDirectLight* pDirectLight = dynamic_cast<ogl::CDirectLight*>(pLight);
//              pProgram->setUniform("u_oDirectLight.vColor",            pDirectLight->mColor);
//              pProgram->setUniform("u_oDirectLight.vDirection",        math::normalize(pDirectLight->mDirection)); // left to rigth
//              pProgram->setUniform("u_oDirectLight.fAmbientIntensity", pDirectLight->mAmbientIntensity);
//              pProgram->setUniform("u_oDirectLight.fDiffuseIntensity", pDirectLight->mDiffuseIntensity);
            }
            else if(pLight->getType() == ogl::CLight::SPOT)
            {
              //@TODO...
            }
            else if(pLight->getType() == ogl::CLight::POINT)
            {
              //@TODO...
            }
          }
        });
        pSkinningProgram = pProgramBuilder->build();
        delete pVShader; delete pFShader; 
        
        glExitIfError();
      }
    }
    
    void init_objects()
    {
      std::cout << "app::COGLDev38SkinningApp::init_objects()" << std::endl;
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        pObjectBuilder->setTextureScale(0.5f);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CDdsTextureBuilder* pTextureBuilder = new ogl::CDdsTextureBuilder;
        pTextureBuilder->setFile("ground/rocks_d.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::DIFFUSE, pTextureBuilder->build());
        pTextureBuilder->setFile("ground/rocks_h.dds");
        pObjectP->getShape(0)->getMaterial()->setTexture(ogl::CTexture::EScope::HEIGHT,  pTextureBuilder->build()); // displacement
        
        delete pObjectBuilder;
      }
      { // bob lamp clean
        ogl::CMd5ObjectBuilder* pObjectBuilder = new ogl::CMd5ObjectBuilder;
        pObjectBuilder->setFile("boblampclean/boblampclean.md5mesh");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        pObject0 = pObjectBuilder->build();
        
        pObject0->scale(2.0f);
        pObject0->rotate(math::quat(-90.0f, math::X) * math::quat(180.0f, math::Z));
        
        delete pObjectBuilder;
      }
    }
    
    void init_animations()
    {
      std::cout << "app::COGLDev38SkinningApp::init_animations()" << std::endl;
      
      { // bob lamp clean
        ogl::CMd5AnimationBuilder* pAnimationBuilder = new ogl::CMd5AnimationBuilder;
        pAnimationBuilder->setFile("boblampclean/boblampclean.md5anim");
        pAnimationBuilder->addOption(ogl::CAnimationBuilder::NORMALIZED);
        pAnim0 = pAnimationBuilder->build();
        
        delete pAnimationBuilder;
      }
    }
    
    void init_renderers()
    {
      std::cout << "app::COGLDev38SkinningApp::init_renderers()" << std::endl;
      
      pDrawRenderer = new ogl::CDrawRenderer(mConfig.mWidth, mConfig.mHeight);
      pDrawRenderer->setProgram(pSkinningProgram);
      pDrawRenderer->setCamera(pCamera);
      pDrawRenderer->setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      pDrawRenderer->setClearDepth(1.0f);
      pDrawRenderer->setWinding(GL_CCW);
      pDrawRenderer->setCullFace(GL_BACK);
    }
  };
}

#endif // __cogldev38skinningapp_hpp__
