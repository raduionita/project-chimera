#ifndef __app_COGLDEV42PCFSHADOWMAP_HPP__
#define __app_COGLDEV42PCFSHADOWMAP_HPP__

namespace app
{
  class COGLDev42PCFShadowMap : public CApp
  {
    protected:
    ogl::CDirectLight* pDirectLight;
    ogl::CPointLight*  pPointLight;
    ogl::CSpotLight*   pSpotLight;
    
    ogl::CCamera*           pCamera;
    app::CCameraController* pCameraController;
    
    ogl::CObject* pObjectP;
    ogl::CObject* pObject0;
    
    ogl::CPCFShadowMapRenderer* pRenderer;
    
    public:
    COGLDev42PCFShadowMap()
    {
      pPointLight       = nullptr;
      pCamera           = nullptr;
      pCameraController = nullptr;
      pObjectP          = nullptr;
      pObject0          = nullptr;
      pRenderer         = nullptr;
    
      std::cout << "app::COGLDev42PCFShadowMap::COGLDev42PCFShadowMap()" << std::endl;
      mConfig.mOpenGL.mMajor   = 4;
      mConfig.mOpenGL.mMinor   = 2;
      mConfig.mWidth           = 640;
      mConfig.mHeight          = 480;
      strcpy(mConfig.mTitle, "COGLDev42PCFShadowMap");
    }
    
    protected:
    void onInit()
    {
      std::cout << "app::COGLDev42PCFShadowMap::onInit() " << std::endl;
      
      init_cameras();
      
      init_programs();
      
      init_lights();
      
      init_objects();
      
      init_renderers();
    }
    
    void onDraw(int nTime)
    {
      float fTime = nTime / 1000.0f;
      std::cout << "app::COGLDev42PCFShadowMap::onDraw(nTime) > " << fTime << std::endl;
      
      CEventManager::getInstance()->trigger(new CUpdateEvent(fTime)); // must

      /////////////////////////////////////////////////////
      
      pPointLight->mPosition = math::vec3(sin(fTime) * 1.5f, 1.5f, cos(fTime) * 1.5f);

      /////////////////////////////////////////////////////
      
      pRenderer->setCamera(pCamera);
      pRenderer->addLight(pDirectLight);
      pRenderer->addLight(pPointLight);
      pRenderer->addLight(pSpotLight);
      pRenderer->addDrawable(pObjectP, ogl::EDrawOptions::NOSHADOWCAST);
      pRenderer->addDrawable(pObject0);
      pRenderer->render();
      
      glCheckError();
      
      CApp::exit();
    }
    
    private:
    void init_lights()
    {
      std::cout << "app::COGLDev42PCFShadowMap::init_lights()" << std::endl;
      
      pDirectLight                    = new ogl::CDirectLight;
      pDirectLight->mColor            = math::vec3(0.25f, 0.25f, 1.0f);
      pDirectLight->mDirection        = math::normalize(math::vec3(0.0f, -1.0f, 0.0f));
      pDirectLight->mAmbientIntensity = 0.2f;
      pDirectLight->mDiffuseIntensity = 0.8f;
      
      pPointLight                    = new ogl::CPointLight;
      pPointLight->mColor            = math::vec3(1.0f, 0.25f, 0.25f);
      pPointLight->mPosition         = math::vec3(2.0f, 2.5f, 2.0f);
      pPointLight->mDiffuseIntensity = 0.8f;
      pPointLight->mAmbientIntensity = 0.2f;
      pPointLight->mK0               = 1.0f;
      
      pSpotLight             = new ogl::CSpotLight;
      pSpotLight->mColor     = math::vec3(0.25, 1.0f, 0.25f);
      pSpotLight->mPosition  = math::vec3(1.0f, 2.0f, 1.0f);
      pSpotLight->mDirection = math::vec3(0.0f, -1.0f, 0.0f);
      pSpotLight->mCutoff    = 0.95f;
    }
  
    void init_cameras()
    {
      pCamera           = new ogl::CCamera(math::vec3(0.0f, -1.5f, -3.5f)); 
      // FIX: this should be 1.5f not -1.5f
      pCameraController = new app::CCameraController(pCamera);
    }
    
    void init_programs()
    {
    
    }
    
    void init_objects()
    {
      std::cout << "app::COGLDev42PCFShadowMap::init_objects()" << std::endl;
      { // plane
        ogl::CPlaneObjectBuilder* pObjectBuilder = new ogl::CPlaneObjectBuilder;
        pObjectBuilder->setWidth(10.0f);
        pObjectBuilder->setHeight(10.0f);
        pObjectBuilder->setSubdivisions(10);
        pObjectBuilder->setTextureScale(0.5f);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::REPEAT_UV);
        pObjectBuilder->addOption(ogl::CPlaneObjectBuilder::TANGENTS);
        // pObjectBuilder->addOption(ogl::CObjectBuilder::INVERTED);
        pObjectP = pObjectBuilder->build();
        
        ogl::CTgaTextureBuilder* pTextureBuilder = new ogl::CTgaTextureBuilder;
        pTextureBuilder->setFile("ground/concrete_d.tga");
        pObjectP->getShape(0)->getMaterial()->setDiffuseTexture(pTextureBuilder->build());
        pTextureBuilder->setFile("ground/concrete_n.tga");
        pObjectP->getShape(0)->getMaterial()->setNormalTexture(pTextureBuilder->build()); // displacement
        
        // TODO: move this inside CObject or in a CObjectBuilder
        ogl::CTransformHistory::getInstance()->set(pObjectP, ogl::CTransform(pObjectP->mScale, pObjectP->mOrientation, pObjectP->mPosition));
        
        glExitIfError();
        
        delete pObjectBuilder;
        delete pTextureBuilder;
      }
      { // boblampclean
        ogl::CMd5ObjectBuilder* pObjectBuilder = new ogl::CMd5ObjectBuilder;
        pObjectBuilder->setFile("boblampclean/boblampclean.md5mesh");
        pObjectBuilder->addOption(ogl::CObjectBuilder::NORMALIZED);
        //pObjectBuilder->addOption(ogl::CObjectBuilder::ADJACENCY); // TODO: unfuck up the MD5 parser
        pObject0 = pObjectBuilder->build();
        
        // TODO: need better normalization
        pObject0->scale(2.0f);
        pObject0->rotate(math::quat(-90.0f, math::X) * math::quat(180.0f, math::Z));
        
        // Remember previous transformation
        ogl::CTransformHistory::getInstance()->set(pObject0, ogl::CTransform(pObject0->mScale, pObject0->mOrientation, pObject0->mPosition));
        
        glExitIfError();
        
        delete pObjectBuilder;
      }
    }
  
    void init_renderers()
    {
      std::cout << "app::COGLDev42PCFShadowMap::init_renderers()" << std::endl;
      
      pRenderer = new ogl::CPCFShadowMapRenderer(mConfig.mWidth, mConfig.mHeight);
    }
  };
}


#endif // __app_COGLDEV42PCFSHADOWMAP_HPP__
