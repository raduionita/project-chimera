#ifndef __ogl_hpp__
#define __ogl_hpp__

#define DIRECTORY_SEPARATOR "/"

#define DATAPATH    "data/"
#define MODELPATH   "data/models/"
#define TEXTUREPATH "data/textures/"
#define SHADERPATH  "data/shaders/"
#define SCENEPATH   "data/scenes/"

#ifndef GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT
#define GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT 0x84FE
#endif

#ifndef GL_TEXTURE_STORAGE_SPARSE_BIT_AMD
#define GL_TEXTURE_STORAGE_SPARSE_BIT_AMD 0x00000001
#endif

#define INVALID_MATERIAL   0xFFFFFFFF
#define INVALID_OGL_VALUE  0xFFFFFFFF
#define INVALID_UINT      -1

// @see lighting_02.fs.glsl
#define OGL_TEXTURE_GENERIC      GL_TEXTURE0
#define OGL_TEXTURE_DIFFUSE      GL_TEXTURE1
#define OGL_TEXTURE_NORMALS      GL_TEXTURE2  // orientation of the fragment
#define OGL_TEXTURE_HEIGHT       GL_TEXTURE11 // depth/height of the fragment
#define OGL_TEXTURE_POSITIONS    GL_TEXTURE3
#define OGL_TEXTURE_SPECULAR     GL_TEXTURE3
#define OGL_TEXTURE_DIRECTSHADOW GL_TEXTURE4
#define OGL_TEXTURE_SPOTSHADOW   GL_TEXTURE5
#define OGL_TEXTURE_POINTSHADOW  GL_TEXTURE6
#define OGL_TEXTURE_ENVIRONMENT  GL_TEXTURE7
#define OGL_TEXTURE_OCCLUSSION   GL_TEXTURE8
#define OGL_TEXTURE_NOISE2D      GL_TEXTURE9
#define OGL_TEXTURE_DEPTH        GL_TEXTURE10

#define OGL_ATTACHEMENT_DIFFUSE       GL_COLOR_ATTACHMENT0
#define OGL_ATTACHEMENT_COLOR         GL_COLOR_ATTACHMENT0
#define OGL_ATTACHEMENT_POSITIONS     GL_COLOR_ATTACHMENT1
#define OGL_ATTACHEMENT_NORMALS       GL_COLOR_ATTACHMENT2
#define OGL_ATTACHEMENT_SPECULAR      GL_COLOR_ATTACHMENT3
#define OGL_ATTACHEMENT_DEPTH         GL_DEPTH_ATTACHMENT
#define OGL_ATTACHEMENT_DEPTH_STENCIL GL_DEPTH_STENCIL_ATTACHMENT

#define POSITION_ATTRIBUTE    0
#define TEXCOORD_ATTRIBUTE    1
#define NORMAL_ATTRIBUTE      2
#define TANGENT_ATTRIBUTE     3
#define BINORMAL_ATTRIBUTE    4
#define BONE_ID_ATTRIBUTE     5
#define BONE_WEIGHT_ATTRIBUTE 6

#define INDEX_BUFFER_INDEX       0
#define POSITION_BUFFER_INDEX    1
#define TEXCOORD_BUFFER_INDEX    2
#define NORMAL_BUFFER_INDEX      3
#define TANGENT_BUFFER_INDEX     4
#define BINORMAL_BUFFER_INDEX    5
#define BONE_ID_BUFFER_INDEX     6
#define BONE_WEIGHT_BUFFER_INDEX 7
#define MODEL_BUFFER_INDEX       8

#define USE_DIFFUSE_MAP 0x0001u
#define USE_SHADOW_MAP  0x0002u
#define USE_NORMAL_MAP  0x0004u

#define MAX_BONES 100
#define MAX_BONES_PER_VERTEX 4

#define glExitIfError()                                                                         \
{                                                                                               \
  GLenum error = glGetError();                                                                  \
  if(error != GL_NO_ERROR)                                                                      \
  {                                                                                             \
    std::ostringstream os;                                                                      \
    os << __FILE__ << ":" << __LINE__ << " " << error;                                          \
    app::CEventManager::getInstance()->trigger(new app::CErrorEvent(0, os.str()));              \
  }                                                                                             \
}

#define glDrawFullscreenQuad()            \
{                                         \
  static GLuint __vao = 0;                \
  if(__vao == 0)                          \
    glGenVertexArrays(1, &__vao);         \
  glBindVertexArray(__vao);               \
  glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);  \
  glBindVertexArray(0);                   \
  /* TODO: find a way to clean this */    \
}

// 1280 GL_INVALID_ENUM      
// 1281 GL_INVALID_VALUE     
// 1282 GL_INVALID_OPERATION 
// 1283 GL_STACK_OVERFLOW    
// 1284 GL_STACK_UNDERFLOW   
// 1285 GL_OUT_OF_MEMORY
// 1286 invalid framebuffer operation

#define glCheckError() (glGetError() == GL_NO_ERROR)

#include <iostream>
#include <cstring>
#include <memory>

namespace ogl
{
  typedef unsigned int   bitfield;
  typedef unsigned int   uint;
  typedef char           byte;
  typedef unsigned char  ubyte;
  typedef unsigned short ushort;
  typedef unsigned long  ulong;
  typedef long long      llong;
  
  typedef uint           GLsizeui;
  
  static const struct typename_t {
    GLenum      type;
    const char* name;
  } typenames[] = {
    GL_FLOAT,                       "float",
    GL_FLOAT_VEC2,                  "vec2",
    GL_FLOAT_VEC3,                  "vec3",
    GL_FLOAT_VEC4,                  "vec4",
    GL_FLOAT_MAT2,                  "mat2",
    GL_FLOAT_MAT3,                  "mat3",
    GL_FLOAT_MAT4,                  "mat4",
    GL_DOUBLE,                      "double",
    GL_DOUBLE_VEC2,                 "dvec2",
    GL_DOUBLE_VEC3,                 "dvec3",
    GL_DOUBLE_VEC4,                 "dvec4",
    GL_DOUBLE_MAT2,                 "dmat2",
    GL_DOUBLE_MAT3,                 "dmat3",
    GL_DOUBLE_MAT4,                 "dmat4",
    GL_INT,                         "int",
    GL_INT_VEC2,                    "ivec2",
    GL_INT_VEC3,                    "ivec3",
    GL_INT_VEC4,                    "ivec4",
 // GL_INT_MAT2,                    "imat2",
 // GL_INT_MAT3,                    "imat3",
 // GL_INT_MAT4,                    "imat4",
    GL_UNSIGNED_INT,                "uint",
    GL_UNSIGNED_INT_VEC2,           "uvec2",
    GL_UNSIGNED_INT_VEC3,           "uvec3",
    GL_UNSIGNED_INT_VEC4,           "uvec4",
 // GL_UNSIGNED_INT_MAT2,           "umat2",
 // GL_UNSIGNED_INT_MAT3,           "umat3",
 // GL_UNSIGNED_INT_MAT4,           "umat4",
    GL_BOOL,                        "bool",
    GL_BOOL_VEC2,                   "bvec2",
    GL_BOOL_VEC3,                   "bvec3",
    GL_BOOL_VEC4,                   "bvec4",
 // GL_BOOL_MAT2,                   "bmat2",
 // GL_BOOL_MAT3,                   "bmat3",
 // GL_BOOL_MAT4,                   "bmat4",
    GL_SAMPLER,                     "sampler",
    GL_SAMPLER_1D,                  "sampler1D",
    GL_SAMPLER_1D_ARRAY,            "sampler1DArray",
    GL_SAMPLER_1D_ARRAY_SHADOW,     "sampler1DArrayShadow",
    GL_SAMPLER_1D_SHADOW,           "sampler1DShadow",
    GL_SAMPLER_2D,                  "sampler2D",
    GL_SAMPLER_2D_ARRAY_SHADOW,     "sampler2DArrayShadow",
    GL_SAMPLER_2D_MULTISAMPLE,      "sampler2DMultisample",
    GL_SAMPLER_2D_MULTISAMPLE_ARRAY,"sampler2DMultisampleArray",
    GL_SAMPLER_2D_RECT,             "sampler2DRect",
    GL_SAMPLER_2D_RECT_SHADOW,      "sampler2DRectShadow",
    GL_SAMPLER_2D_SHADOW,           "sampler2DShadow",
    GL_NONE,                        NULL
  };
  
  const char* getTypeName(GLenum type)
  {
    for(const typename_t* ptr = &typenames[0]; ptr->name != NULL; ptr++)
      if(ptr->type == type)
        return ptr->name;
      return NULL;
  }
  
  GLenum getTypeEnum(const std::string& name)
  {
    for(const typename_t* ptr = &typenames[0]; ptr->name != NULL; ptr++)
      if(strncmp(ptr->name, name.c_str(), name.size()) == 0)
        return ptr->type;
    return GL_NONE;
  }

  static inline int getTime()
  {
    return glutGet(GLUT_ELAPSED_TIME);
  }  
  
  static inline float getTimef()
  {
    return (float)glutGet(GLUT_ELAPSED_TIME) / 1000.0f;
  }
  
  GLuint getSizeOf(GLenum type)
  {
    switch(type)
    {
      case GL_DOUBLE:
        return 8;
      case GL_UNSIGNED_INT:
      case GL_INT:
      case GL_FLOAT:
        return 4;
      case GL_UNSIGNED_SHORT:
      case GL_SHORT:
        return 2;
      case GL_UNSIGNED_BYTE:  
      case GL_BYTE:
        return 1;
      default:
        return 0;
    }
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  enum class EProgramType : uint // 1, 2, 4, 8, 10, 20, 40, 80, 100, 200...
  {
    RENDER_NULL,          // 0x00000001
    RENDER_FORWARD,       // 0x00000002
    RENDER_DEFFERED,      // 0x00000004
    RENDER_GBUFFER,       // 0x00000008 // render to geometry buffer(positions, texcoords, normals, colors) for deffered
    RENDER_SHADOW_VOLUME, // 0x00000010
    RENDER_WIREFRAME,     // 0x00000020
    RENDER_SELECTOR,
    RENDER_BILLBOARD,
    RENDER_PARTICLE_EMITTER, // for particle generation(update), use RENDER_BILLBOARD for rendering
    
    DRAW_SINGLE,
    DRAW_INTSTANCED,        // NONE(nothing passed to gl_Position), SINGLE, INSTANCED
    MESH_ANIMATED,          // SKINNING vs STATIC
    MESH_SELECTABLE,
    SHADOW_MAP,
    SHADOW_VOLUME,
    LIGHTS_DIRECTIONAL,     // or NONE(works with MATERIAL_FLAT)
    LIGHTS_POINT,
    LIGHTS_SPOT,
    LIGHTS_ALL,
    LIGHTING_PASS_DIFFUSE,  // no shadow map // diffuse + specular calculations
    LIGHTING_PASS_AMBIENT,  // only ambient caclculations
    LIGHTING_PASS_BOTH,
    TEXTURE_DIFFUSE,
    TEXTURE_NORMALS,
    TEXTURE_SPECULAR,
    TEXTURE_ENVIRONMENT,    // use smapleCubeMap skybox
    MATERIAL_COLORED,
    MATERIAL_TEXTURED,  // += MATERIAL_COLORED // reads color from diffuse texture
    MATERIAL_2SIDED,    // += MATERIAL_COLORED 
    SHADING_GOURAUD,
    SHADING_PHONG,
    SHADING_CELL,
    LIGHTING_MODEL_FLAT,          // pass color from material to the fragment output
    LIGHTING_MODEL_BLINN_PHONG,   
    LIGHTING_MODEL_RIM,
    LIGHTING_MODEL_COOK_TORRANCE,
    LIGHTING_MODEL_OREN_NAYAR,
    LIGHTING_MODEL_HEMISPHERE,    
    EFFECTS_FOG,
  };
  
  enum EDrawOptions : uint
  {
    INVISIBLE    = 0x0000,
    GENERIC      = 0x0001,
    WIREFRAME    = 0x0002,
    NOMATERIAL   = 0x0004,
    NODEPTHTEST  = 0x0008,
    NOSHADOWCAST = 0x0010,
    NOLIGHT      = 0x0020
  };
  
  enum EPickMode : ushort
  {
    OBJECT    = 1,
    DRAW      = 2,
    PRIMITIVE = 3
  };
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  enum class ERenderingScope : ushort // CTag<CRenderer>
  {
    NONE          = 0x00,
    FORWARD       = 0x02,
    DEFFERED      = 0x03,
    SILHOUETTE    = 0x04,
    SHADOW_VOLUME = 0x05,
    QUAD          = 0x06,
    MOTION_BLUR   = 0x07,
    SELECTOR      = 0x08,
    NORMALS       = 0x09,
    WIREFRAME     = 0x0A,
  };
  
  enum class EDrawStrategyType : ushort // CTag<CDrawStrategy>
  {
    NONE      = 0x00,
    SINGLE    = 0x01,
    INSTANCED = 0x02
  };

  enum class EShadingMode : ushort // CTag<CProgram>
  {
    NONE          = 0x00,
    FLAT          = 0x02,
    GOURAUD       = 0x03,
    BLINN_PHONG   = 0x04,
    COOK_TORRANCE = 0x05
  };
  
  enum class ELightingPass : ushort // 
  {
    NONE    = 0x00,
    AMBIENT = 0x01,
    DIFFUSE = 0x02,
    BOTH    = 0x03,
  };
  
  enum class ERenderingOptions : ushort // 
  {
    NONE        = 0x00000,
    STATIC      = 0x00001,
    ANIMATED    = 0x00003,  // 2 + 1
    MOTION_BLUR = 0x00004,
    SELECTABLE  = 0x00008,
    SHADOW      = 0x00010,
  };

  namespace tags
  {
    //static const sys::CTag SHADOW = ++sys::tags::CURRENT;
    
    static const sys::CTag NOSHADOW("NOSHADOW");
    static const sys::CTag SHADOW("SHADOW");
    static const sys::CTag SHADOWMAP("SHADOWMAP");
    static const sys::CTag SHADOWVOLUME("SHADOWVOLUME");
    static const sys::CTag PCF("PCF");
    
    static const sys::CTag QUAD("QUAD");
    static const sys::CTag FULL("FULL");
    
    static const sys::CTag TEST("TEST");
    static const sys::CTag DEBUG("DEBUG");
    
    static const sys::CTag WIREFRAME("WIREFRAME");
    static const sys::CTag NORMALS("NORMALS");
    static const sys::CTag DEPTH("DEPTH");
    
    static const sys::CTag DEFERRED("DEFERRED");
    static const sys::CTag FORWARD("FORWARD");
    
    static const sys::CTag GBUFFER("GBUFFER");
    static const sys::CTag GEOMETRY("GEOMETRY");
    static const sys::CTag OCCLUSSION("OCCLUSSION");
    //static const sys::CTag SHADOW("SHADOW");
    static const sys::CTag LIGHTING("LIGHTING");
    
    static const sys::CTag AMBIENT("AMBIENT");
    static const sys::CTag DIFFUSE("DIFFUSE");
    
    static const sys::CTag MULTIMATERIAL("MULTIMATERIAL");
    
    static const sys::CTag SINGLE("SINGLE");
    static const sys::CTag INSTANCED("INSTANCED");
    
    static const sys::CTag PLANE("PLANE");
    static const sys::CTag BOX("BOX");
    static const sys::CTag MESH("MESH");
    static const sys::CTag MD5MESH("MD5MESH");
    
    static const sys::CTag POSTPROCESS("POSTPROCESS");
    static const sys::CTag BLUR("BLUR");
    
    static const sys::CTag OUTPUT("OUTPUT");
    static const sys::CTag TEXTURE("TEXTURE");
    
    static const sys::CTag PARALLAX("PARALLAX");
  }
}

#include "ogl/CException.hpp"

#include "ogl/CCallback.hpp"

#include "ogl/CCamera.hpp"

#include "ogl/CTransformHistory.hpp"

#include "ogl/CManager.hpp"

#include "ogl/CDescriptor.hpp"
#include "ogl/CShader.hpp"
#include "ogl/CProgram.hpp"
#include "ogl/CUniform.hpp"
#include "ogl/CProgramManager.hpp"
#include "ogl/CShaderBuilder.hpp"
#include "ogl/CSourceShaderBuilder.hpp"
#include "ogl/CFileShaderBuilder.hpp"
#include "ogl/CShaderProgramBuilder.hpp"
#include "ogl/CXmlProgramBuilder.hpp"

#include "ogl/CBufferRange.hpp"
#include "ogl/CDrawable.hpp"

#include "ogl/CTextureData.hpp"
#include "ogl/CTexture.hpp"
#include "ogl/CTextureBuilder.hpp"
#include "ogl/CDdsTextureBuilder.hpp"
#include "ogl/CPngTextureBuilder.hpp"
#include "ogl/CTgaTextureBuilder.hpp"
#include "ogl/CBmpTextureBuilder.hpp"
#include "ogl/CNoiseTextureBuilder.hpp"
#include "ogl/CMaterial.hpp"
#include "ogl/CMaterialManager.hpp"

#include "ogl/CFramebuffer.hpp"

#include "ogl/CLight.hpp"
#include "ogl/CDirectLight.hpp"
#include "ogl/CPointLight.hpp"
#include "ogl/CSpotLight.hpp"
#include "ogl/CLightManager.hpp"
#include "ogl/CShadow.hpp"

#include "ogl/CVertex.hpp"
#include "ogl/CBuffer.hpp"
#include "ogl/CShape.hpp"
#include "ogl/CAnimatable.hpp"
#include "ogl/CSkeleton.hpp"
#include "ogl/CObject.hpp"
#include "ogl/CObjectBuilder.hpp"
#include "ogl/CBoxObjectBuilder.hpp"
#include "ogl/CPlaneObjectBuilder.hpp"
//#include "ogl/CAssimpObjectBuilder.hpp"
#include "ogl/CMd5ObjectBuilder.hpp"
#include "ogl/CAnimation.hpp"
#include "ogl/CAnimationBuilder.hpp"
#include "ogl/CMd5AnimationBuilder.hpp"

#include "ogl/framebuffers/CShadowFramebuffer.hpp"  //@TODO: rename to CShadowRenderPass ??

#include "ogl/CParticle.hpp"
#include "ogl/CParticleSystem.hpp"

#include "ogl/CRenderer.hpp"
#include "ogl/renderers/CDeferredRenderer.hpp"

#endif /* __ogl_hpp__ */
